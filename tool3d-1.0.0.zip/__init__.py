"""
3D tool - Blender Edition
Multi-Cut Extended: Cut + Separate + Offset + Fill + Bevel
"""

bl_info = {
    "name": "3D tool",
    "author": "Tool3D",
    "version": (1, 0, 0),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > 3D tool",
    "description": "Cut mesh, separate pieces, offset, fill holes, bevel, UV presets",
    "category": "Mesh",
}

import math

import bpy
import bmesh
from mathutils.geometry import intersect_point_line
from bpy.props import FloatProperty, IntProperty, BoolProperty, EnumProperty
from collections import deque


# ========== LIVE INTERSECTION STATE ==========
#
# depsgraph_update_post can be called many times while an object is being
# transformed.  The handler therefore only marks the detector as dirty and a
# short one-shot timer performs the expensive BVH work.
_tool3d_live_object_names = set()
_tool3d_live_dirty = False
_tool3d_live_timer_registered = False
_tool3d_live_updating = False
_TOOL3D_INTERSECTION_DISPLAY = "_Intersection_Display"
_TOOL3D_INTERSECTION_MESH = "_Intersection_Display_Mesh"
_TOOL3D_INTERSECTION_MATERIAL = "_Intersection_Red"
# Legacy overlay temp object name (see TOOL3D_OT_detect_self_intersect /
# TOOL3D_OT_disable_self_intersect below, which still use the literal
# string directly -- this constant is only for Task 3's exclusion filter so
# those legacy operators are not touched).
_TOOL3D_INTERSECT_OVERLAY_TEMP = "_Intersect_Overlay_Temp"

_SEAM_FACE_ROLE = "_seam_surface_role"
_SEAM_VERT_SIDE = "_seam_vertex_side"
_SEAM_FOLD_EDGE = "_seam_fold_edge"
# Keep Wall v3: a scratch FACE int layer on the cavity bmesh holding
# `concave cluster index + 1` (0 = not concave). Needed because filling one
# dent's pocket deletes faces, which shifts every later face index -- so
# cluster membership cannot be carried by index across the fills. Removed
# again before the cavity is written out.
_KEEP_WALL_CLUSTER_TAG = "_keep_wall_cluster"
_SEAM_UV = ((0.0, 0.0), (1.0, 0.0), (0.5, 0.0))
_WEIGHTED_NORMAL_OWNER = "_3d_tool_weighted_normal"

# Hollow Shape (2026-09-11): how the cavity of a hollow piece is built.
# SURFACE is the original behaviour (`_hollow_piece`); the others carve a
# primitive fitted to the source's bounding box (`_hollow_piece_shape`).
_HOLLOW_SHAPE_ITEMS = (
    ('SURFACE', "Surface", "Inner surface is the outer surface scaled towards the origin"),
    ('BOX', "Box", "Cavity is the source bounding box scaled towards the origin"),
    ('CYLINDER', "Cylinder", "Cavity is a cylinder along the longest bounding-box axis"),
    ('SPHERE', "Sphere", "Cavity is a sphere sized by the shortest bounding-box side"),
    ('HULL', "Convex Hull", "Cavity is the convex hull of the source vertices"),
)
_HOLLOW_SHAPE_SEGMENTS = 32


# ========== MARK SEAM SPLIT: PROVENANCE LAYER NAMES ==========
#
# BMesh named integer layers used to stamp discovered Seam-loop cut_id onto
# edges/vertices so later pipeline stages (Task 3-5) can recover which loop a
# piece of geometry came from without relying on edge/vertex index identity,
# which topology operations (edge_split, separate, ...) do not preserve.
#
# NOTE (Task 3 fix pass): these two MUST be distinct strings. Blender's
# generic mesh Attribute system (bm.to_mesh() -> Mesh.attributes) requires
# attribute names to be unique across the whole mesh regardless of domain.
# Task 2 originally gave both layers the identical name "tool3d_sharp_cut_id"
# (verified fine only within a single continuously-open BMesh, which never
# collides); once real orchestration round-trips through an actual Mesh
# datablock (bm.to_mesh() then a fresh bm.from_mesh(), which
# _split_object_by_sharp_loops + bpy.ops.mesh.separate + _remap_cut_boundaries
# all do), Blender silently keeps only the POINT-domain attribute under that
# name and drops the EDGE-domain one entirely -- so the edge marker layer
# that "prioritize marker values first" depends on would never actually
# survive a real split. Confirmed via a direct round-trip check before this
# fix (edge layer disappeared, vert layer's values ended up on a plain
# POINT attribute) and after (both layers independently present and
# correct post-separate).
_SHARP_CUT_EDGE_LAYER = "tool3d_sharp_cut_id"
_SHARP_CUT_VERT_LAYER = "tool3d_sharp_cut_id_vert"

# ========== MARK SEAM SPLIT: DIMENSION-SEPARATED EPSILONS / BUDGETS ==========
#
# Final fix pass (I5): `sharp_fill_tolerance` is a DISTANCE (scene units).
# It was previously reused unchanged as the threshold for three different
# physical dimensions at once -- lengths, areas and normal dot products --
# which is wrong for any tolerance >= 1.0: a normal dot product can never
# exceed 1.0, so comparing `dot <= tolerance` rejected every single face as
# soon as the (distance) tolerance grew past 1.0, even for a perfectly
# valid cap. Callers now derive three separate values from one distance
# tolerance `t`:
#   length_eps = t              -- planarity / coordinate distances
#   area_eps   = t * t          -- polygon areas, 2D cross products
#   angle_eps  = _SHARP_ANGLE_EPS  -- dimensionless normal dot products
# _SHARP_ANGLE_EPS is deliberately a fixed, scale-free constant (the brief's
# `min(1.0e-3, max(1.0e-9, 1.0e-6))`): an orientation test must not become
# more or less strict just because the model is measured in millimetres
# instead of metres.
_SHARP_ANGLE_EPS = min(1.0e-3, max(1.0e-9, 1.0e-6))

# Final fix pass (I8): above this many LOOP VERTICES, the O(n^2)/O(n^3)
# pure-Python planar paths (self-intersection scan, ear clipping, pairwise
# new-face overlap validation) are skipped in favour of the C-side
# bmesh.ops.triangle_fill, so a large Seam ring can never hang the UI.
# Small loops (the overwhelmingly common case, and the one where planar
# ear-clip quality actually matters) are completely unaffected.
#
# Final repair pass: the UNIT here is loop vertices, and every comparison
# against this constant must use an actual loop vertex count -- never a
# face-corner total. `_new_cap_faces_self_intersect` previously summed the
# new faces' own vertex counts (i.e. corners) and compared that, so an
# ear-clipped 46-gon cap (44 triangles = 132 corners) exceeded a "128
# vertex" budget and skipped validation on a loop barely a third of the
# budget's real size. See that method for the corrected derivation.
_SHARP_LARGE_LOOP_VERT_BUDGET = 128


# ========== SHARED GEOMETRY HELPERS ==========
#
# Hollow Shape fix pass (2026-09-11): both of these were duplicated
# verbatim in two places each -- the clamped point-to-segment distance in
# `_closest_is_fold` and `_hollow_piece_shape`, the bbox-derived signature
# tolerance in `_hollow_piece` and `_hollow_piece_shape`. Identical
# arithmetic, so extracting them changes no tolerance and no result.

def _point_segment_distance(point, start, end):
    """Distance from `point` to the SEGMENT `[start, end]` (not the
    infinite line): `intersect_point_line` reports the projection plus
    its fraction along the segment, and the fraction is clamped to the
    endpoints so a point beyond either end measures to that end."""
    closest, fraction = intersect_point_line(point, start, end)
    if fraction <= 0.0:
        closest = start
    elif fraction >= 1.0:
        closest = end
    return (point - closest).length


def _bbox_tolerance(bm):
    """Signature/merge tolerance derived from `bm`'s bounding-box
    diagonal: one part per million of it, floored at 1e-8 so a
    degenerate (or empty) mesh still yields a strictly positive grid."""
    from mathutils import Vector

    if not bm.verts:
        return 1e-8
    low = Vector(tuple(min(v.co[a] for v in bm.verts) for a in range(3)))
    high = Vector(tuple(max(v.co[a] for v in bm.verts) for a in range(3)))
    return max((high - low).length * 1e-6, 1e-8)


# ========== Tool3DAddonPreferences ==========

class Tool3DAddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    offset_value: FloatProperty(
        name="Offset",
        default=0.0,
        precision=3
    )

    bevel_width: FloatProperty(
        name="Bevel Width",
        default=0.1,
        precision=3
    )

    bevel_segments: IntProperty(
        name="Bevel Segments",
        default=1,
        min=1,
        max=20
    )

    def draw(self, context):
        layout = self.layout
        layout.label(text="Default Values")
        layout.prop(self, "offset_value")
        layout.prop(self, "bevel_width")
        layout.prop(self, "bevel_segments")


def _init_multicut_uv(obj):
    """Gan UV (1.0, 0.0) cho toan bo mesh goc cua piece trong Multi-Cut."""
    mesh = obj.data
    if mesh.uv_layers.active is None:
        mesh.uv_layers.new(name="UVMap")
    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        uv_layer = bm.loops.layers.uv.get(mesh.uv_layers.active.name)
        if uv_layer is not None:
            for face in bm.faces:
                for loop in face.loops:
                    loop[uv_layer].uv = (1.0, 0.0)
            bm.to_mesh(mesh)
    finally:
        bm.free()
    mesh.update()


def _set_selected_faces_uv(obj, uv_coord=(0.5, 0.0)):
    """Gan UV cho cac face dang duoc select (face tao boi fill hoac bevel) trong edit mode."""
    bm = bmesh.from_edit_mesh(obj.data)
    active_name = obj.data.uv_layers.active.name if obj.data.uv_layers.active else "UVMap"
    uv_layer = bm.loops.layers.uv.get(active_name) or bm.loops.layers.uv.verify()
    for face in bm.faces:
        if face.select:
            for loop in face.loops:
                loop[uv_layer].uv = uv_coord
    bmesh.update_edit_mesh(obj.data)


# ========== OPERATORS ==========

class TOOL3D_OT_split_by_edges(bpy.types.Operator):
    """Tach mesh dua tren cac edges dang duoc chon (edge_split + separate + offset + fill + bevel)"""
    bl_idname = "tool3d.split_by_edges"
    bl_label = "Split By Selected Edges"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and context.mode == 'EDIT_MESH'
    
    def execute(self, context):
        props = context.scene.tool3d_props
        
        # Lay tat ca mesh objects dang duoc edit
        edit_objects = [o for o in context.objects_in_mode if o.type == 'MESH']
        if not edit_objects:
            edit_objects = [context.active_object]
        
        all_new_objects = []
        meshes_to_separate = []
        
        # Xu ly tung mesh: kiem tra edges va edge_split
        for obj in edit_objects:
            bm = bmesh.from_edit_mesh(obj.data)
            selected_edges = [e for e in bm.edges if e.select]
            
            if not selected_edges:
                continue
            
            cut_edge_set = set(e.index for e in selected_edges)
            face_groups = self._find_face_groups(bm, cut_edge_set)
            
            if len(face_groups) < 2:
                continue
            
            meshes_to_separate.append(obj)
        
        if not meshes_to_separate:
            self.report({'WARNING'}, "Khong co mesh nao co duong cat xuyen qua!")
            return {'CANCELLED'}
        
        # Edge split tren tat ca (trong edit mode)
        # Chay cho tung mesh: set active, select edges, edge_split
        for obj in meshes_to_separate:
            context.view_layer.objects.active = obj
            bm = bmesh.from_edit_mesh(obj.data)
            # Dam bao chi select edges cua mesh nay
            bpy.ops.mesh.edge_split(type='EDGE')
        
        # Chuyen sang Object mode
        bpy.ops.object.mode_set(mode='OBJECT')
        
        # Separate tung mesh
        for obj in meshes_to_separate:
            bpy.ops.object.select_all(action='DESELECT')
            obj.select_set(True)
            context.view_layer.objects.active = obj
            
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.separate(type='LOOSE')
            bpy.ops.object.mode_set(mode='OBJECT')
            
            new_objs = [o for o in context.selected_objects if o.type == 'MESH']
            all_new_objects.extend(new_objs)
        
        if not all_new_objects:
            self.report({'WARNING'}, "Khong tach duoc!")
            return {'CANCELLED'}

        for piece in all_new_objects:
            _init_multicut_uv(piece)

        # Offset border vertices
        collision_detected = False
        if props.offset_value > 0:
            for piece in all_new_objects:
                if self._offset_border_verts(piece, props.offset_value):
                    collision_detected = True
        
        if collision_detected:
            self.report({'WARNING'}, "Offset bi gioi han o mot so vertex de tranh lam hong model!")
        
        # Luu border edges TRUOC khi fill
        border_edges_map = {}
        if props.auto_bevel:
            for piece in all_new_objects:
                me = piece.data
                bm = bmesh.new()
                bm.from_mesh(me)
                border_edges_map[piece.name] = [e.index for e in bm.edges if e.is_boundary]
                bm.free()
        
        if props.auto_fill:
            for piece in all_new_objects:
                self._fill_holes(context, piece)
        
        if props.auto_bevel:
            for piece in all_new_objects:
                edge_indices = border_edges_map.get(piece.name, [])
                if edge_indices:
                    self._bevel_saved_edges(context, piece, edge_indices, props.bevel_width, props.bevel_segments)
        
        # Select tat ca pieces
        bpy.ops.object.select_all(action='DESELECT')
        for o in all_new_objects:
            if o and o.name in bpy.data.objects:
                o.select_set(True)
        if all_new_objects:
            context.view_layer.objects.active = all_new_objects[0]
        
        self.report({'INFO'}, "Done! {} pieces.".format(len(all_new_objects)))
        return {'FINISHED'}
    
    def _find_face_groups(self, bm, cut_edge_set):
        """Flood-fill tim face groups tach biet boi cut edges"""
        visited = set()
        groups = []
        
        for face in bm.faces:
            if face.index in visited:
                continue
            
            group = set()
            queue = deque([face])
            visited.add(face.index)
            group.add(face.index)
            
            while queue:
                current = queue.popleft()
                for edge in current.edges:
                    if edge.index in cut_edge_set:
                        continue
                    for linked_face in edge.link_faces:
                        if linked_face.index not in visited:
                            visited.add(linked_face.index)
                            group.add(linked_face.index)
                            queue.append(linked_face)
            
            groups.append(group)
        
        return groups
    
    def _offset_border_verts(self, obj, offset_value):
        """Day border vertices lui vao trong - dung huong vuong goc voi boundary edge trong mat phang face"""
        from mathutils import Vector
        
        me = obj.data
        bm = bmesh.new()
        bm.from_mesh(me)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        bm.normal_update()
        
        # Tim border verts va border edges
        border_edges = [e for e in bm.edges if e.is_boundary]
        if not border_edges:
            bm.free()
            return
        
        border_vert_indices = set()
        for edge in border_edges:
            for v in edge.verts:
                border_vert_indices.add(v.index)
        
        # Tinh huong offset cho tung border vert
        vert_directions = {}  # {vert_index: Vector}
        
        for edge in border_edges:
            # Boundary edge chi co 1 face
            if not edge.link_faces:
                continue
            face = edge.link_faces[0]
            
            face_center = face.calc_center_median()
            edge_mid = (edge.verts[0].co + edge.verts[1].co) / 2
            to_center = face_center - edge_mid
            
            # Tinh inward: chieu to_center len mat phang vuong goc voi edge
            edge_vec = (edge.verts[1].co - edge.verts[0].co).normalized()
            projected = to_center - to_center.dot(edge_vec) * edge_vec
            
            if projected.length > 1e-6:
                inward = projected.normalized()
            elif to_center.length > 1e-6:
                inward = to_center.normalized()
            else:
                continue
            
            # Cong don huong cho ca 2 vertex cua edge
            for v in edge.verts:
                if v.index not in vert_directions:
                    vert_directions[v.index] = Vector((0, 0, 0))
                vert_directions[v.index] += inward
        
        # Di chuyen tung vert theo huong trung binh, kiem tra va cham
        collision_warned = False
        for v_idx, direction in vert_directions.items():
            if direction.length > 0.0001:
                direction.normalize()
                vert = bm.verts[v_idx]
                
                # Kiem tra khoang cach toi tat ca vertex khac (khong phai border)
                min_dist = float('inf')
                for other_edge in vert.link_edges:
                    other_v = other_edge.other_vert(vert)
                    if other_v.index in vert_directions:
                        continue
                    dist = (other_v.co - vert.co).length
                    if dist < min_dist:
                        min_dist = dist
                
                # Gioi han offset: khong vuot qua 80% khoang cach den vertex gan nhat
                max_allowed = min_dist * 0.8 if min_dist < float('inf') else offset_value
                actual_offset = min(offset_value, max_allowed)
                
                if actual_offset < offset_value:
                    collision_warned = True
                
                if actual_offset > 0.0001:
                    vert.co += direction * actual_offset
        
        bm.to_mesh(me)
        bm.free()
        me.update()
        
        return collision_warned
    
    def _fill_holes(self, context, obj):
        """Fill tat ca border loops bang bmesh"""
        context.view_layer.objects.active = obj
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_mode(type='EDGE')
        
        # Dung bmesh de chon boundary edges (nhanh hon)
        bm = bmesh.from_edit_mesh(obj.data)
        for edge in bm.edges:
            edge.select = edge.is_boundary
        bmesh.update_edit_mesh(obj.data)
        
        # Fill bang n-gon (khong triangulate)
        filled = False
        try:
            bpy.ops.mesh.edge_face_add()
            filled = True
        except:
            try:
                bpy.ops.mesh.fill()
                bpy.ops.mesh.tris_convert_to_quads(face_threshold=3.14159, shape_threshold=3.14159)
                filled = True
            except:
                pass

        if filled:
            _set_selected_faces_uv(obj, (0.5, 0.0))

        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')

    def _bevel_borders(self, context, obj, width, segments):
        """Bevel border edges"""
        context.view_layer.objects.active = obj
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_mode(type='EDGE')

        # Chon border edges (dung bmesh cho nhanh)
        bm = bmesh.from_edit_mesh(obj.data)
        for edge in bm.edges:
            edge.select = edge.is_boundary
        bmesh.update_edit_mesh(obj.data)

        # Bevel
        try:
            bpy.ops.mesh.bevel(
                offset=width,
                segments=segments,
                offset_type='OFFSET',
                affect='EDGES',
                clamp_overlap=True
            )
            _set_selected_faces_uv(obj, (0.5, 0.0))
        except:
            pass

        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')

    def _bevel_saved_edges(self, context, obj, edge_indices, width, segments):
        """Bevel cac edges da luu (theo index) - dung sau khi fill"""
        context.view_layer.objects.active = obj
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_mode(type='EDGE')

        bm = bmesh.from_edit_mesh(obj.data)
        bm.edges.ensure_lookup_table()

        count = 0
        for idx in edge_indices:
            if idx < len(bm.edges):
                bm.edges[idx].select = True
                count += 1
        bmesh.update_edit_mesh(obj.data)

        if count == 0:
            bpy.ops.object.mode_set(mode='OBJECT')
            return

        try:
            bpy.ops.mesh.bevel(
                offset=width,
                segments=segments,
                offset_type='OFFSET',
                affect='EDGES',
                clamp_overlap=True
            )
            _set_selected_faces_uv(obj, (0.5, 0.0))
        except:
            pass

        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')


class TOOL3D_OT_knife_cut_pipeline(bpy.types.Operator):
    """Knife Cut tu dong: cat xong Enter -> tu dong tach + offset + fill + bevel (ho tro nhieu mesh)"""
    bl_idname = "tool3d.knife_cut_pipeline"
    bl_label = "Knife Cut + Auto Split"
    bl_options = {'REGISTER', 'UNDO'}
    
    _timer = None
    _mesh_counts = {}  # {obj_name: (edge_count_before, vert_count_before)}
    _tick_count = 0
    _max_ticks = 600
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH'
    
    def invoke(self, context, event):
        self._tick_count = 0
        self._mesh_counts = {}
        
        # Ghi nhan tat ca mesh dang chon
        selected_meshes = [o for o in context.selected_objects if o.type == 'MESH']
        if not selected_meshes:
            self.report({'WARNING'}, "Chon mesh truoc!")
            return {'CANCELLED'}
        
        # Vao edit mode (multi-object edit)
        if context.mode != 'EDIT_MESH':
            bpy.ops.object.mode_set(mode='EDIT')
        
        # Deselect all edges tren tat ca mesh
        bpy.ops.mesh.select_all(action='DESELECT')
        
        # Ghi nhan edge count VA vert count cho tung mesh
        # (vert count dung de loc cut edges that su sau knife)
        for obj in selected_meshes:
            bm = bmesh.from_edit_mesh(obj.data)
            self._mesh_counts[obj.name] = (len(bm.edges), len(bm.verts))
        
        # Dang ky modal + timer
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.3, window=context.window)
        wm.modal_handler_add(self)
        
        # Bat dau Knife voi Cut Through
        bpy.ops.mesh.knife_tool('INVOKE_DEFAULT', use_occlude_geometry=False)
        
        self.report({'INFO'}, "Knife active (Cut Through). Cat xuyen mesh roi nhan Enter...")
        return {'RUNNING_MODAL'}
    
    def modal(self, context, event):
        if event.type == 'TIMER':
            self._tick_count += 1
            
            if self._tick_count > self._max_ticks:
                self._cleanup(context)
                self.report({'WARNING'}, "Timeout - huy.")
                return {'CANCELLED'}
            
            if context.mode != 'EDIT_MESH':
                self._cleanup(context)
                return {'CANCELLED'}
            
            # Kiem tra co mesh nao co edges moi khong
            try:
                any_new = False
                for obj_name, (old_e_count, _old_v_count) in self._mesh_counts.items():
                    obj = bpy.data.objects.get(obj_name)
                    if not obj:
                        continue
                    bm = bmesh.from_edit_mesh(obj.data)
                    if len(bm.edges) > old_e_count:
                        # Co edges moi, kiem tra co selected khong
                        selected = [e for e in bm.edges if e.select]
                        if selected:
                            any_new = True
                            break
                
                if any_new:
                    self._cleanup(context)
                    # Xu ly tung mesh co edges moi
                    self._process_all_meshes(context)
                    return {'FINISHED'}
            except:
                pass
        
        return {'PASS_THROUGH'}
    
    def _process_all_meshes(self, context):
        """Xu ly tat ca mesh da duoc cat"""
        props = context.scene.tool3d_props
        all_new_objects = []
        
        # Thu thap thong tin cac mesh co edges moi
        meshes_to_process = []
        for obj_name, (old_e_count, _old_v_count) in self._mesh_counts.items():
            obj = bpy.data.objects.get(obj_name)
            if not obj:
                continue
            bm = bmesh.from_edit_mesh(obj.data)
            if len(bm.edges) > old_e_count:
                selected = [e for e in bm.edges if e.select]
                if selected:
                    meshes_to_process.append(obj)
        
        if not meshes_to_process:
            self.report({'WARNING'}, "Khong co mesh nao duoc cat!")
            return
        
        # Xu ly tung mesh: loc CUT EDGES that su va edge_split
        for obj in meshes_to_process:
            old_v_count = self._mesh_counts[obj.name][1]
            
            context.view_layer.objects.active = obj
            
            bm = bmesh.from_edit_mesh(obj.data)
            
            # Loc cut edges that su: ca 2 vertex deu la vertex moi (index >= old_v_count)
            # Edge ma 1 dau la vertex cu va 1 dau la vertex moi -> KHONG phai cut edge
            # (do la "split edge" - cach cu bi knife chia doi)
            real_cut_edges = []
            for e in bm.edges:
                if e.select:
                    if all(v.index >= old_v_count for v in e.verts):
                        real_cut_edges.append(e)
            
            if not real_cut_edges:
                continue
            
            # Re-select chi nhung cut edges that su (bo split edges)
            for e in bm.edges:
                e.select = False
            for e in real_cut_edges:
                e.select = True
            bmesh.update_edit_mesh(obj.data)
            
            # Kiem tra cut co xuyen qua khong
            cut_edge_set = set(e.index for e in real_cut_edges)
            face_groups = self._find_face_groups(bm, cut_edge_set)
            
            if len(face_groups) < 2:
                continue
            
            # Edge split chi tren cut edges that su
            bpy.ops.mesh.edge_split(type='EDGE')
        
        # Chuyen sang object mode
        bpy.ops.object.mode_set(mode='OBJECT')
        
        # Separate tung mesh
        for obj in meshes_to_process:
            bpy.ops.object.select_all(action='DESELECT')
            obj.select_set(True)
            context.view_layer.objects.active = obj
            
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.separate(type='LOOSE')
            bpy.ops.object.mode_set(mode='OBJECT')
            
            new_objs = [o for o in context.selected_objects if o.type == 'MESH']
            all_new_objects.extend(new_objs)
        
        if not all_new_objects:
            self.report({'WARNING'}, "Khong tach duoc!")
            return

        for piece in all_new_objects:
            _init_multicut_uv(piece)

        # Offset
        collision_detected = False
        if props.offset_value > 0:
            for piece in all_new_objects:
                if self._offset_border_verts(piece, props.offset_value):
                    collision_detected = True
        
        if collision_detected:
            self.report({'WARNING'}, "Offset bi gioi han o mot so vertex de tranh lam hong model!")
        
        # Luu border edges truoc fill
        border_edges_map = {}
        if props.auto_bevel:
            for piece in all_new_objects:
                me = piece.data
                bm = bmesh.new()
                bm.from_mesh(me)
                border_edges_map[piece.name] = [e.index for e in bm.edges if e.is_boundary]
                bm.free()
        
        # Fill
        if props.auto_fill:
            for piece in all_new_objects:
                self._fill_holes(context, piece)
        
        # Bevel
        if props.auto_bevel:
            for piece in all_new_objects:
                edge_indices = border_edges_map.get(piece.name, [])
                if edge_indices:
                    self._bevel_saved_edges(context, piece, edge_indices, props.bevel_width, props.bevel_segments)
        
        # Select all pieces
        bpy.ops.object.select_all(action='DESELECT')
        for o in all_new_objects:
            if o and o.name in bpy.data.objects:
                o.select_set(True)
        if all_new_objects:
            context.view_layer.objects.active = all_new_objects[0]
        
        self.report({'INFO'}, "Done! {} pieces total.".format(len(all_new_objects)))
    
    def _find_face_groups(self, bm, cut_edge_set):
        visited = set()
        groups = []
        for face in bm.faces:
            if face.index in visited:
                continue
            group = set()
            queue = deque([face])
            visited.add(face.index)
            group.add(face.index)
            while queue:
                current = queue.popleft()
                for edge in current.edges:
                    if edge.index in cut_edge_set:
                        continue
                    for linked_face in edge.link_faces:
                        if linked_face.index not in visited:
                            visited.add(linked_face.index)
                            group.add(linked_face.index)
                            queue.append(linked_face)
            groups.append(group)
        return groups
    
    def _offset_border_verts(self, obj, offset_value):
        from mathutils import Vector
        me = obj.data
        bm = bmesh.new()
        bm.from_mesh(me)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        bm.normal_update()
        
        border_edges = [e for e in bm.edges if e.is_boundary]
        if not border_edges:
            bm.free()
            return False
        
        vert_directions = {}
        for edge in border_edges:
            if not edge.link_faces:
                continue
            face = edge.link_faces[0]
            
            face_center = face.calc_center_median()
            edge_mid = (edge.verts[0].co + edge.verts[1].co) / 2
            to_center = face_center - edge_mid
            
            edge_vec = (edge.verts[1].co - edge.verts[0].co).normalized()
            projected = to_center - to_center.dot(edge_vec) * edge_vec
            
            if projected.length > 1e-6:
                inward = projected.normalized()
            elif to_center.length > 1e-6:
                inward = to_center.normalized()
            else:
                continue
            
            for v in edge.verts:
                if v.index not in vert_directions:
                    vert_directions[v.index] = Vector((0, 0, 0))
                vert_directions[v.index] += inward
        
        collision_warned = False
        for v_idx, direction in vert_directions.items():
            if direction.length > 0.0001:
                direction.normalize()
                vert = bm.verts[v_idx]
                
                min_dist = float('inf')
                for other_edge in vert.link_edges:
                    other_v = other_edge.other_vert(vert)
                    if other_v.index in vert_directions:
                        continue
                    dist = (other_v.co - vert.co).length
                    if dist < min_dist:
                        min_dist = dist
                
                max_allowed = min_dist * 0.8 if min_dist < float('inf') else offset_value
                actual_offset = min(offset_value, max_allowed)
                
                if actual_offset < offset_value:
                    collision_warned = True
                
                if actual_offset > 0.0001:
                    vert.co += direction * actual_offset
        
        bm.to_mesh(me)
        bm.free()
        me.update()
        return collision_warned
    
    def _fill_holes(self, context, obj):
        context.view_layer.objects.active = obj
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        bpy.ops.object.mode_set(mode='EDIT')
        bm = bmesh.from_edit_mesh(obj.data)
        bpy.ops.mesh.select_all(action='DESELECT')
        for edge in bm.edges:
            edge.select = edge.is_boundary
        bmesh.update_edit_mesh(obj.data)
        filled = False
        try:
            bpy.ops.mesh.edge_face_add()
            filled = True
        except:
            try:
                bpy.ops.mesh.fill()
                bpy.ops.mesh.tris_convert_to_quads(face_threshold=3.14159, shape_threshold=3.14159)
                filled = True
            except:
                pass
        if filled:
            _set_selected_faces_uv(obj, (0.5, 0.0))
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')

    def _bevel_saved_edges(self, context, obj, edge_indices, width, segments):
        context.view_layer.objects.active = obj
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_mode(type='EDGE')
        bm = bmesh.from_edit_mesh(obj.data)
        bm.edges.ensure_lookup_table()
        count = 0
        for idx in edge_indices:
            if idx < len(bm.edges):
                bm.edges[idx].select = True
                count += 1
        bmesh.update_edit_mesh(obj.data)
        if count == 0:
            bpy.ops.object.mode_set(mode='OBJECT')
            return
        try:
            bpy.ops.mesh.bevel(offset=width, segments=segments, offset_type='OFFSET',
                                affect='EDGES', clamp_overlap=True)
            _set_selected_faces_uv(obj, (0.5, 0.0))
        except:
            pass
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')

    def _cleanup(self, context):
        if self._timer:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None


class TOOL3D_OT_separate_and_process(bpy.types.Operator):
    """Tach mesh da duoc cut (loose parts) va xu ly pipeline"""
    bl_idname = "tool3d.separate_and_process"
    bl_label = "Separate Loose + Fill + Bevel"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and context.mode == 'OBJECT'
    
    def execute(self, context):
        props = context.scene.tool3d_props
        obj = context.active_object
        
        if not obj:
            self.report({'WARNING'}, "Chon mesh truoc!")
            return {'CANCELLED'}
        
        # Dem shells truoc
        me = obj.data
        bm = bmesh.new()
        bm.from_mesh(me)
        shell_count = self._count_shells(bm)
        bm.free()
        
        if shell_count < 2:
            self.report({'WARNING'}, "Mesh chi co 1 shell. Dung Knife cut truoc!")
            return {'CANCELLED'}
        
        # Separate by loose parts
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj
        
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.separate(type='LOOSE')
        bpy.ops.object.mode_set(mode='OBJECT')
        
        new_objects = [o for o in context.selected_objects if o.type == 'MESH']

        for piece in new_objects:
            _init_multicut_uv(piece)

        # Offset
        collision_detected = False
        if props.offset_value > 0:
            for piece in new_objects:
                if self._offset_border_verts(piece, props.offset_value):
                    collision_detected = True
        
        if collision_detected:
            self.report({'WARNING'}, "Offset bi gioi han o mot so vertex de tranh lam hong model!")
        
        # Luu border edges truoc khi fill
        border_edges_map = {}
        if props.auto_bevel:
            for piece in new_objects:
                me = piece.data
                bm = bmesh.new()
                bm.from_mesh(me)
                border_edges_map[piece.name] = [e.index for e in bm.edges if e.is_boundary]
                bm.free()
        
        # Fill
        if props.auto_fill:
            for piece in new_objects:
                self._fill_holes(context, piece)
        
        # Bevel (dung saved edges)
        if props.auto_bevel:
            for piece in new_objects:
                edge_indices = border_edges_map.get(piece.name, [])
                if edge_indices:
                    self._bevel_saved_edges(context, piece, edge_indices, props.bevel_width, props.bevel_segments)
        
        # Select all pieces
        bpy.ops.object.select_all(action='DESELECT')
        for o in new_objects:
            o.select_set(True)
        if new_objects:
            context.view_layer.objects.active = new_objects[0]
        
        self.report({'INFO'}, "Done! {} pieces.".format(len(new_objects)))
        return {'FINISHED'}
    
    def _count_shells(self, bm):
        visited = set()
        count = 0
        for face in bm.faces:
            if face.index in visited:
                continue
            count += 1
            queue = deque([face])
            visited.add(face.index)
            while queue:
                current = queue.popleft()
                for edge in current.edges:
                    for f in edge.link_faces:
                        if f.index not in visited:
                            visited.add(f.index)
                            queue.append(f)
        return count
    
    def _offset_border_verts(self, obj, offset_value):
        from mathutils import Vector
        
        me = obj.data
        bm = bmesh.new()
        bm.from_mesh(me)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        bm.normal_update()
        
        border_edges = [e for e in bm.edges if e.is_boundary]
        if not border_edges:
            bm.free()
            return False
        
        vert_directions = {}
        
        for edge in border_edges:
            if not edge.link_faces:
                continue
            face = edge.link_faces[0]
            
            face_center = face.calc_center_median()
            edge_mid = (edge.verts[0].co + edge.verts[1].co) / 2
            to_center = face_center - edge_mid
            
            edge_vec = (edge.verts[1].co - edge.verts[0].co).normalized()
            projected = to_center - to_center.dot(edge_vec) * edge_vec
            
            if projected.length > 1e-6:
                inward = projected.normalized()
            elif to_center.length > 1e-6:
                inward = to_center.normalized()
            else:
                continue
            
            for v in edge.verts:
                if v.index not in vert_directions:
                    vert_directions[v.index] = Vector((0, 0, 0))
                vert_directions[v.index] += inward
        
        collision_warned = False
        for v_idx, direction in vert_directions.items():
            if direction.length > 0.0001:
                direction.normalize()
                vert = bm.verts[v_idx]
                
                min_dist = float('inf')
                for other_edge in vert.link_edges:
                    other_v = other_edge.other_vert(vert)
                    if other_v.index in vert_directions:
                        continue
                    dist = (other_v.co - vert.co).length
                    if dist < min_dist:
                        min_dist = dist
                
                max_allowed = min_dist * 0.8 if min_dist < float('inf') else offset_value
                actual_offset = min(offset_value, max_allowed)
                
                if actual_offset < offset_value:
                    collision_warned = True
                
                if actual_offset > 0.0001:
                    vert.co += direction * actual_offset
        
        bm.to_mesh(me)
        bm.free()
        me.update()
        return collision_warned
    
    def _fill_holes(self, context, obj):
        context.view_layer.objects.active = obj
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        
        bpy.ops.object.mode_set(mode='EDIT')
        
        bm = bmesh.from_edit_mesh(obj.data)
        bpy.ops.mesh.select_all(action='DESELECT')
        
        for edge in bm.edges:
            edge.select = edge.is_boundary
        bmesh.update_edit_mesh(obj.data)
        
        filled = False
        try:
            bpy.ops.mesh.edge_face_add()
            filled = True
        except:
            try:
                bpy.ops.mesh.fill()
                bpy.ops.mesh.tris_convert_to_quads(face_threshold=3.14159, shape_threshold=3.14159)
                filled = True
            except:
                pass

        if filled:
            _set_selected_faces_uv(obj, (0.5, 0.0))

        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')

    def _bevel_borders(self, context, obj, width, segments):
        context.view_layer.objects.active = obj
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')

        bm = bmesh.from_edit_mesh(obj.data)
        for edge in bm.edges:
            edge.select = edge.is_boundary
        bmesh.update_edit_mesh(obj.data)

        try:
            bpy.ops.mesh.bevel(
                offset=width,
                segments=segments,
                offset_type='OFFSET',
                affect='EDGES',
                clamp_overlap=True
            )
            _set_selected_faces_uv(obj, (0.5, 0.0))
        except:
            pass

        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')

    def _bevel_saved_edges(self, context, obj, edge_indices, width, segments):
        """Bevel cac edges da luu (theo index) - dung sau khi fill"""
        context.view_layer.objects.active = obj
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.mesh.select_mode(type='EDGE')

        bm = bmesh.from_edit_mesh(obj.data)
        bm.edges.ensure_lookup_table()

        count = 0
        for idx in edge_indices:
            if idx < len(bm.edges):
                bm.edges[idx].select = True
                count += 1
        bmesh.update_edit_mesh(obj.data)

        if count == 0:
            bpy.ops.object.mode_set(mode='OBJECT')
            return

        try:
            bpy.ops.mesh.bevel(
                offset=width,
                segments=segments,
                offset_type='OFFSET',
                affect='EDGES',
                clamp_overlap=True
            )
            _set_selected_faces_uv(obj, (0.5, 0.0))
        except:
            pass

        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')


class TOOL3D_OT_fill_holes(bpy.types.Operator):
    """Fill holes tren mesh dang chon"""
    bl_idname = "tool3d.fill_holes"
    bl_label = "Fill Holes"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH'
    
    def execute(self, context):
        obj = context.active_object
        if obj.data.uv_layers.active is None:
            _init_multicut_uv(obj)

        if context.mode != 'EDIT_MESH':
            bpy.ops.object.mode_set(mode='EDIT')

        bm = bmesh.from_edit_mesh(obj.data)
        bpy.ops.mesh.select_all(action='DESELECT')

        for edge in bm.edges:
            edge.select = edge.is_boundary
        bmesh.update_edit_mesh(obj.data)

        filled = False
        try:
            bpy.ops.mesh.edge_face_add()
            filled = True
        except:
            try:
                bpy.ops.mesh.fill()
                bpy.ops.mesh.tris_convert_to_quads(face_threshold=3.14159, shape_threshold=3.14159)
                filled = True
            except:
                self.report({'WARNING'}, "Fill failed!")
                return {'CANCELLED'}

        if filled:
            _set_selected_faces_uv(obj, (0.5, 0.0))

        bpy.ops.mesh.select_all(action='DESELECT')
        self.report({'INFO'}, "Holes filled!")
        return {'FINISHED'}


class TOOL3D_OT_bevel_borders(bpy.types.Operator):
    """Bevel border edges"""
    bl_idname = "tool3d.bevel_borders"
    bl_label = "Bevel Borders"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH'

    def execute(self, context):
        props = context.scene.tool3d_props
        obj = context.active_object
        if obj.data.uv_layers.active is None:
            _init_multicut_uv(obj)

        if context.mode != 'EDIT_MESH':
            bpy.ops.object.mode_set(mode='EDIT')

        bpy.ops.mesh.select_all(action='DESELECT')
        bm = bmesh.from_edit_mesh(obj.data)

        border_count = 0
        for edge in bm.edges:
            if edge.is_boundary:
                edge.select = True
                border_count += 1
        bmesh.update_edit_mesh(obj.data)

        if border_count == 0:
            self.report({'WARNING'}, "No border edges found!")
            return {'CANCELLED'}

        try:
            bpy.ops.mesh.bevel(
                offset=props.bevel_width,
                segments=props.bevel_segments,
                offset_type='OFFSET',
                affect='EDGES',
                clamp_overlap=True
            )
            _set_selected_faces_uv(obj, (0.5, 0.0))
        except:
            self.report({'WARNING'}, "Bevel failed!")
            return {'CANCELLED'}

        bpy.ops.mesh.select_all(action='DESELECT')
        self.report({'INFO'}, "Beveled {} edges.".format(border_count))
        return {'FINISHED'}


class TOOL3D_OT_split_mark_sharp(bpy.types.Operator):
    """Tach mesh doc theo cac Seam-edge loop kin, roi offset / smart-fill /
    bevel rieng tung duong cat.

    Moi mesh dang duoc chon deu duoc xu ly doc lap trong mot lan chay: tim
    cac Seam loop kin hop le, danh dau provenance (cut_id), tach thanh
    cac manh roi, va -- theo cac tuy chon sharp_* -- day cac dinh cua
    duong cat vao trong, va vet lo cat (chi lo cat, khong bao gio dong lo
    co san), roi bevel vanh cat. Cac shell roi co san (khong lien quan den
    duong cat nao) duoc giu nguyen thanh mot object, khong bi tach ra."""
    bl_idname = "tool3d.split_mark_sharp"
    bl_label = "Split Mark Seam + Fill Cuts"
    bl_options = {'REGISTER', 'UNDO'}

    # ===== Final fix pass (I7): undo granularity =====
    #
    # The spec's acceptance criterion is that ONE undo reverts the whole
    # operation. Blender pushes an undo step per OPERATOR, not per Python
    # statement, so the way to satisfy this is to make sure the operator's
    # core path invokes no nested operators of its own. Previously it
    # called `bpy.ops.object.mode_set(EDIT)`, `bpy.ops.mesh.separate(LOOSE)`,
    # `bpy.ops.object.mode_set(OBJECT)` per source and, with bevel enabled,
    # another `mode_set` pair plus `bpy.ops.mesh.select_all`,
    # `bpy.ops.mesh.select_mode` and `bpy.ops.mesh.bevel` per piece -- so a
    # single click could push a double-digit number of undo steps and the
    # criterion could not hold.
    #
    # This pass removes ALL of them from the core path:
    #   - separation      -> BMesh component partition + bpy.data.objects
    #                        (see _split_object_by_sharp_loops)
    #   - bevel           -> bmesh.ops.bevel        (see _bevel_cut_edges)
    #   - mode_set(EDIT)  -> no longer needed anywhere; the operator never
    #                        enters Edit Mode at all
    # What remains is `bpy.ops.object.select_all(action='DESELECT')` plus
    # per-object `select_set()` for the final selection state, which is
    # selection bookkeeping rather than a topology change.
    #
    # Verified by `test_single_undo_reverts_whole_operation` (background
    # Blender): after the operator runs, ONE `bpy.ops.ed.undo()` restores
    # the original object count, mesh datablock counts and vertex
    # positions. See final-fix-report.md for the recorded output.

    # Runtime configuration for this operator's own pipeline (contract fixed
    # in Task 1; the Scene-level MARK SEAM CUT box presets these onto the
    # panel button, see TOOL3D_PT_main_panel.draw).
    sharp_auto_fill: BoolProperty(name="Fill Holes", default=True)
    sharp_auto_bevel: BoolProperty(name="Bevel", default=False)

    sharp_offset_value: FloatProperty(
        name="Offset",
        default=0.0,
        min=0.0,
        max=20.0,
        precision=3,
    )

    sharp_bevel_width: FloatProperty(
        name="Bevel Width",
        default=0.01,
        min=0.001,
        max=5.0,
        precision=3,
    )

    sharp_bevel_segments: IntProperty(
        name="Bevel Segments",
        default=1,
        min=1,
        max=20,
    )

    # Final fix pass (M1): defaults/ranges now match the Scene-level
    # `Tool3DProperties.sharp_fill_tolerance` exactly (default=0.0001,
    # min=0.000001, max=0.1, precision=6). Previously the operator
    # declared default=1.0e-6/min=0.0/precision=8 while the UI slider the
    # user actually drives declared 0.0001/0.000001/0.1 -- so the panel
    # button and a direct bpy.ops call with no arguments silently behaved
    # differently, and a UI value could not even be represented by the
    # operator's own (unbounded-above) property. One shared contract now.
    sharp_fill_tolerance: FloatProperty(
        name="Fill Tolerance",
        default=0.0001,
        min=0.000001,
        max=0.1,
        precision=6,
    )

    # Hollow shell (user request, 2026-09-09): instead of capping each cut
    # face flat, turn every piece into a shell -- the piece's own outer
    # surface, a copy of it scaled towards the object origin by
    # `sharp_hollow_scale`, and a ring of quads joining each outer cut
    # edge to its scaled twin. Off by default on the OPERATOR so the
    # flat-cap behaviour every earlier test pins is unchanged; the
    # Scene-level `Tool3DProperties.sharp_hollow` the panel presets the
    # button from defaults to ON (user request 2026-09-11). Same ranges
    # as the Scene-level fields (M1 contract).
    sharp_hollow: BoolProperty(name="Hollow", default=False)
    sharp_hollow_scale: FloatProperty(
        name="Inner Scale",
        default=0.8,
        min=0.1,
        max=0.99,
        precision=3,
    )
    sharp_crease_angle: FloatProperty(
        name="Crease Angle",
        description="Hollow shell: a rim rung is beveled as a crease when the "
                    "bridge band turns by more than this angle",
        default=math.radians(15.0),
        min=0.0,
        max=math.radians(180.0),
        subtype='ANGLE',
    )
    sharp_hollow_shape: EnumProperty(
        name="Hollow Shape",
        description="Shape of the cavity when Hollow is on",
        items=_HOLLOW_SHAPE_ITEMS,
        default='SURFACE',
    )
    # Keep Wall (user decision 2026-09-12): scaling the surface copy about
    # the origin thins the wall wherever the outer surface is CONCAVE -- a
    # dent 0.3 deep in a unit sphere puts its floor at radius 0.7 while the
    # copy of that floor sits at 0.8, so the inner surface pokes OUT through
    # the outer one (user screenshots). Off by default per user request
    # (2026-09-21); enable explicitly to flatten the inner dent panel.
    # Convex pieces keep the ordinary scaled inner copy.
    sharp_keep_wall: BoolProperty(
        name="Keep Wall",
        description="Surface hollow: cut the cavity like the default hollow, but "
                    "FLATTEN the inner face under each dent into one panel, "
                    "instead of a scaled copy that would break through the dent",
        default=False,
    )
    sharp_instance_approximate: BoolProperty(
        name="Instance gần giống", default=True,
        description="Share nearly matching meshes; may change shape and gaps at cut joints",
    )
    sharp_instance_tolerance: FloatProperty(
        name="Sai số (%)", default=2.0, min=0.0, max=5.0, precision=2,
        description="Maximum vertex displacement as a percentage of the reference piece radius",
    )

    @classmethod
    def poll(cls, context):
        """True in Object Mode when ANY selected object is a usable mesh.

        Final fix pass (I1): this previously tested only
        `context.active_object`, so a perfectly valid selection (a mesh
        with a Seam loop selected alongside an Empty that happens to be
        active -- a completely ordinary state after adding a helper
        object) disabled the operator outright, even though `execute()`
        processes every selected mesh and never needs the active object
        to be one of them. The temporary display objects the intersection
        detector creates are excluded here for the same reason
        `_collect_selected_meshes` excludes them: they are tool scaffolding,
        never user input.
        """
        excluded_names = {
            _TOOL3D_INTERSECTION_DISPLAY,
            _TOOL3D_INTERSECT_OVERLAY_TEMP,
        }
        if context.mode == 'OBJECT':
            candidates = context.selected_objects
        elif context.mode == 'EDIT_MESH':
            # User report (2026-09-09): the button was greyed out in Edit
            # Mode -- exactly where a user has just finished marking edges
            # Seam and expects to click it. Accept the meshes being edited;
            # execute() switches to Object Mode itself (one operator, one
            # undo step, see there).
            candidates = context.objects_in_mode
        else:
            return False
        for obj in candidates:
            if obj.type == 'MESH' and obj.name not in excluded_names:
                return True
        return False

    # Final fix pass (I2): the exception types a per-source failure is
    # allowed to be absorbed from. RuntimeError covers a refused bpy.ops /
    # bmesh operator, ReferenceError a BMesh element whose owning BMesh is
    # gone, ValueError/TypeError malformed geometry or a bad argument
    # reaching a BMesh call. Anything outside this set is a genuine
    # programming error and is handled by the outer boundary instead (which
    # still refuses to traceback out of the operator).
    _RECOVERABLE_ERRORS = (RuntimeError, ValueError, ReferenceError, TypeError)

    @staticmethod
    def _failure_record(object_name, reason, cut_id=None, edge_count=0):
        """Return one failure record in the single shape every consumer
        (report formatter, console dump, tests) can rely on.

        Final fix pass (M3): failure records used to come in two different
        shapes -- `{"object", "reason"}` from the split step and
        `{"object", "cut_id", "edge_count", "reason"}` from fill/bevel --
        so the console dump could not print a uniform line. Every producer
        now goes through here."""
        return {
            "object": object_name,
            "cut_id": cut_id,
            "edge_count": edge_count,
            "reason": reason,
        }

    def execute(self, context):
        # Edit Mode entry (user report, 2026-09-09): a user marks edges
        # Seam in Edit Mode and clicks the button right there. The meshes
        # being edited are the input; leave Edit Mode FIRST so their
        # BMesh edits are flushed to mesh data and every later step reads
        # the real geometry. This is the only nested operator call on the
        # path, and it comes before any topology change, so the whole
        # operation is still reverted by a single undo. Any other mode
        # (sculpt, pose, ...) is refused without touching anything.
        if context.mode == 'EDIT_MESH':
            edit_meshes = [o for o in context.objects_in_mode if o.type == 'MESH']
            bpy.ops.object.mode_set(mode='OBJECT')
            for obj in edit_meshes:
                obj.select_set(True)
        elif context.mode != 'OBJECT':
            return {'CANCELLED'}

        objects = self._collect_selected_meshes(context)

        original_selected_names = [o.name for o in context.selected_objects]
        original_active = context.view_layer.objects.active
        original_active_name = original_active.name if original_active else None

        # Final repair pass 3: an explicit creation log for the whole run.
        # `_split_object_by_sharp_loops` reads this off `self` and appends
        # every object it links, as well as rolling back its own partials,
        # so the outer boundary can tell "an object this operation created"
        # from "an object that was already in the file" EXACTLY, with no
        # name-diffing or scene scanning -- a scan would risk removing
        # something an unrelated handler created while the operator ran.
        # Reset per run: operator instances are reused by Blender.
        run_created_objects = []
        self._run_created_objects = run_created_objects
        self._run_source_bbox = None
        # Keep Wall v2: the erosion cavity must be measured on the SOURCE
        # surface, before the split -- the pieces' fill caps are not source
        # faces and would be read as a concave floor. A COPY is kept for the
        # duration of one source's pipeline and released straight after.
        self._run_source_mesh = None

        # Task 5: exact result-dict contract.
        result = {
            "selected_objects": len(objects),
            "processed_objects": 0,
            "skipped_objects": 0,
            "pieces": 0,
            "valid_loops": 0,
            "ignored_components": 0,
            "filled_loops": 0,
            "failed_loops": [],
            "offset_warnings": 0,
            "beveled_edges": 0,
            "linked_pieces": 0,
            "hollow_warnings": 0,
        }
        piece_groups = []

        if not objects:
            self.report({'WARNING'}, "Chon mesh truoc!")
            return {'CANCELLED'}

        all_pieces = []

        # Final fix pass (I2): ONE outer boundary around the entire
        # operation. Previously a RuntimeError/ReferenceError escaping any
        # of the BMesh/separate/fill steps propagated straight out of
        # execute(), which (a) tracebacks through normal operator use and
        # (b) could strand the file in Edit Mode with an arbitrary
        # selection, because the mode/selection restoration all lived on
        # the normal return path only. The `finally` below now always runs
        # the Object-Mode restoration, and the `except` turns an
        # unexpected failure into a controlled WARNING with the caller's
        # original selection/active object put back.
        try:
            for obj in objects:
                # Final fix pass (I2): a failure while processing ONE source
                # must never abort the other selected sources. Each source's
                # whole pipeline is wrapped, so a bad mesh is recorded and
                # skipped rather than cancelling the run.
                try:
                    loops, ignored_components = (
                        self._find_valid_sharp_loops_with_stats(obj))
                    # Final fix pass (M2): genuinely invalid Seam components
                    # (open chains, branches, lone edges, non-separating
                    # rings) are now counted and reported instead of being
                    # silently folded into "skipped objects".
                    result["ignored_components"] += ignored_components

                    if not loops:
                        result["skipped_objects"] += 1
                        continue
                    result["valid_loops"] += len(loops)

                    # `_split_object_by_sharp_loops` mutates `obj` in place
                    # (the source object keeps one produced piece); nothing
                    # below this call may read `obj`'s original (pre-split)
                    # geometry again.
                    from mathutils import Vector
                    coords = obj.data.vertices
                    self._run_source_bbox = (
                        Vector(tuple(min(v.co[a] for v in coords) for a in range(3))),
                        Vector(tuple(max(v.co[a] for v in coords) for a in range(3))),
                    ) if len(coords) else None
                    # Keep Wall v2: snapshot the SOURCE surface itself, for
                    # the concavity test. Removed in this method's `finally`.
                    if self._run_source_mesh is not None:
                        if self._run_source_mesh.users == 0:
                            bpy.data.meshes.remove(self._run_source_mesh)
                        self._run_source_mesh = None
                    self._run_source_mesh = obj.data.copy()
                    shared_mesh = obj.data if obj.data.users > 1 else None
                    if shared_mesh is not None:
                        obj.data = shared_mesh.copy()
                    try:
                        pieces, provenance, failures = self._split_object_by_sharp_loops(
                            context, obj, loops)
                    except Exception:
                        if shared_mesh is not None:
                            failed_mesh = obj.data
                            obj.data = shared_mesh
                            if failed_mesh.users == 0:
                                bpy.data.meshes.remove(failed_mesh)
                        raise
                    result["failed_loops"].extend(failures)
                    if not pieces:
                        if shared_mesh is not None:
                            unused_mesh = obj.data
                            obj.data = shared_mesh
                            if unused_mesh.users == 0:
                                bpy.data.meshes.remove(unused_mesh)
                        result["skipped_objects"] += 1
                        continue

                    result["processed_objects"] += 1
                    result["pieces"] += len(pieces)
                    all_pieces.extend(pieces)
                    piece_groups.append(list(pieces))

                    # Steps 5-7: classify/offset/fill/bevel this source's own
                    # produced pieces against its own provenance, independently
                    # of every other source. `self` is passed as the settings
                    # object (`props`) because the operator already carries
                    # these as its own bl_options-exposed properties (Task 1-2
                    # contract) -- kept as a distinct parameter so the method
                    # itself never hard-codes which settings object it reads
                    # from.
                    settings_result = self._apply_mark_sharp_settings(
                        context, pieces, provenance, self)
                    result["offset_warnings"] += settings_result["offset_warnings"]
                    result["beveled_edges"] += settings_result["bevel_count"]
                    result["filled_loops"] += settings_result["fill_count"]
                    result["failed_loops"].extend(settings_result["fill_failures"])
                    result["hollow_warnings"] += settings_result.get("hollow_warnings", 0)
                except TOOL3D_OT_split_mark_sharp._RECOVERABLE_ERRORS as exc:
                    # Controlled per-source failure: record it, make sure
                    # this source did not leave us in Edit Mode, and carry
                    # on with the next selected source.
                    source_name = "<removed object>"
                    try:
                        source_name = obj.name
                    except ReferenceError:
                        pass
                    result["skipped_objects"] += 1
                    result["failed_loops"].append(
                        TOOL3D_OT_split_mark_sharp._failure_record(
                            source_name,
                            "{}: {}".format(type(exc).__name__, exc),
                        )
                    )
                    if context.mode != 'OBJECT':
                        bpy.ops.object.mode_set(mode='OBJECT')

            # Step 8: marker layers are temporary provenance only -- strip
            # them from every produced piece's FINAL mesh data before
            # anything else, regardless of fill/bevel settings, so they are
            # never persisted. A source with no valid loop never reaches
            # `_split_object_by_sharp_loops` at all, so it never gained a
            # marker layer to begin with; a pre-existing (unrelated) hole on
            # any piece was never touched by these layers either.
            # Step 8a (user request 2026-09-23): the Seam marks were only
            # the cut instruction. Once the pieces exist they are spent, and
            # left in place they pollute UV unwrapping and re-cutting (every
            # rim of a hollow shell and every bevel band inherits them: 164
            # seam edges on one meteor piece). Cleared here, BEFORE the
            # instancer below, so every congruent piece carries the same
            # (all-False) seam flags in its edge signature. Sharp flags are
            # NOT touched: `_shade_cut_piece` owns them (Auto Sharp) and the
            # Weighted Normal modifier's `keep_sharp` needs them.
            for piece in all_pieces:
                try:
                    if piece and piece.name in bpy.data.objects:
                        TOOL3D_OT_split_mark_sharp._strip_cut_marker_layers(piece)
                        TOOL3D_OT_split_mark_sharp._clear_cut_seams(piece)
                except TOOL3D_OT_split_mark_sharp._RECOVERABLE_ERRORS as exc:
                    result["failed_loops"].append(
                        TOOL3D_OT_split_mark_sharp._failure_record(
                            getattr(piece, "name", "<unknown piece>"),
                            "marker cleanup failed: {}".format(exc),
                        )
                    )

            # Step 8b: identical pieces of ONE source share mesh data. Only
            # meshes this run created may be freed afterwards; a source's
            # own pre-existing datablock is never removed here.
            created_meshes = {o.data for o in run_created_objects
                              if o and o.name in bpy.data.objects}
            for group in piece_groups:
                live = [p for p in group if p and p.name in bpy.data.objects]
                if len(live) < 2:
                    continue
                try:
                    shared = TOOL3D_OT_split_mark_sharp._instance_cut_pieces(
                        live, approximate=self.sharp_instance_approximate,
                        tolerance_percent=self.sharp_instance_tolerance)
                except TOOL3D_OT_split_mark_sharp._RECOVERABLE_ERRORS as exc:
                    result["failed_loops"].append(
                        TOOL3D_OT_split_mark_sharp._failure_record(
                            live[0].name, "instance: {}".format(exc)))
                    continue
                result["linked_pieces"] += shared["linked"]
                result["approximate_linked"] = result.get("approximate_linked", 0) + shared.get("approximate_linked", 0)
                result["instance_max_error_percent"] = max(
                    result.get("instance_max_error_percent", 0.0), shared.get("max_error_percent", 0.0))
                for mesh in shared["unused_meshes"]:
                    if mesh in created_meshes and mesh.users == 0:
                        bpy.data.meshes.remove(mesh)

            valid_pieces = [
                piece for piece in all_pieces
                if piece and piece.name in bpy.data.objects
            ]

            if not valid_pieces:
                # Nothing usable happened -- restore the caller's original
                # selection/active object exactly as saved.
                self._restore_selection(
                    context, original_selected_names, original_active_name)
                self._print_failure_details(result)
                if result["failed_loops"]:
                    self.report(
                        {'WARNING'},
                        "Split Mark Seam: khong tach duoc; {} loi (xem Console).".format(
                            len(result["failed_loops"]))
                    )
                else:
                    self.report(
                        {'WARNING'},
                        "Khong tim thay Seam loop kin hop le de tach!")
                return {'CANCELLED'}

            # Step 9: select produced pieces, set a valid active piece, leave
            # Object Mode (guaranteed by the `finally` below).
            bpy.ops.object.select_all(action='DESELECT')
            for piece in valid_pieces:
                piece.select_set(True)
            context.view_layer.objects.active = valid_pieces[0]

            # Step 10: report via INFO if no failures, WARNING otherwise,
            # and always dump the full failure detail to the console.
            self._print_failure_details(result)
            message = self._format_result_report(result)
            if result["failed_loops"]:
                self.report({'WARNING'}, message)
            else:
                self.report({'INFO'}, message)
            return {'FINISHED'}

        except Exception as exc:  # noqa: BLE001 -- deliberate outer boundary
            # Final fix pass (I2): an unexpected failure must still leave a
            # usable file, not a half-applied operation in Edit Mode with a
            # scrambled selection. Restore what we saved, report a
            # controlled warning, and never let a traceback reach the user
            # through normal operator use.
            print(
                "[Tool3D] split_mark_sharp: unexpected {}: {}".format(
                    type(exc).__name__, exc)
            )
            import traceback
            traceback.print_exc()
            # Final repair pass 3: this path CANCELS the whole operation
            # and puts the caller's original selection back, so it must not
            # also leave the objects the cancelled operation created lying
            # in the scene. `_split_object_by_sharp_loops` already rolls
            # back a split that failed part-way through; this removes the
            # pieces of splits that COMPLETED before a later step (offset,
            # fill, bevel, marker cleanup) raised. Only objects recorded in
            # this run's own creation log are removed -- never the source
            # objects, never anything that was already in the file. Done
            # BEFORE the selection restore so the restore cannot re-select
            # an object that is about to be removed.
            try:
                discarded = TOOL3D_OT_split_mark_sharp._discard_created_objects(
                    run_created_objects)
                if discarded:
                    print(
                        "[Tool3D] removed {} partial piece(s) created by the "
                        "cancelled operation: {}".format(len(discarded), discarded)
                    )
            except Exception as cleanup_exc:  # noqa: BLE001
                print("[Tool3D] partial-piece cleanup failed: {}".format(cleanup_exc))
            try:
                self._restore_selection(
                    context, original_selected_names, original_active_name)
            except Exception as restore_exc:  # noqa: BLE001
                print("[Tool3D] selection restore also failed: {}".format(restore_exc))
            self._print_failure_details(result)
            self.report(
                {'WARNING'},
                "Split Mark Seam: loi khong mong doi ({}) -- xem Console.".format(
                    type(exc).__name__)
            )
            return {'CANCELLED'}

        finally:
            # Keep Wall v2: the source snapshot is scratch data for one run.
            try:
                source_mesh = getattr(self, "_run_source_mesh", None)
                self._run_source_mesh = None
                if source_mesh is not None and source_mesh.users == 0:
                    bpy.data.meshes.remove(source_mesh)
            except Exception as snapshot_exc:  # noqa: BLE001
                print("[Tool3D] source snapshot cleanup failed: {}".format(snapshot_exc))
            # Unconditional: whatever happened above, this operator never
            # returns while the file is still in Edit Mode.
            try:
                if context.mode != 'OBJECT':
                    bpy.ops.object.mode_set(mode='OBJECT')
            except Exception as mode_exc:  # noqa: BLE001
                print("[Tool3D] could not restore Object Mode: {}".format(mode_exc))

    @staticmethod
    def _restore_selection(context, selected_names, active_name):
        """Put the caller's original selection/active object back by NAME.

        Names, not object references: an object reference saved before the
        operation can be invalidated by the operation itself, and reading
        `.name` off it afterwards raises ReferenceError."""
        bpy.ops.object.select_all(action='DESELECT')
        for name in selected_names:
            restored = bpy.data.objects.get(name)
            if restored:
                restored.select_set(True)
        if active_name:
            active = bpy.data.objects.get(active_name)
            if active:
                context.view_layer.objects.active = active

    @staticmethod
    def _print_failure_details(result):
        """Print every failure record in full to the system console.

        Final fix pass (M3): the status bar can only carry a one-line
        summary, so the per-cut detail (which object, which cut_id, how
        many edges, and the exact reason) used to be lost entirely. It is
        now always dumped here, with the counts summary alongside it, so a
        user who sees "3 failure(s)" can find out what they were."""
        failures = result.get("failed_loops") or []
        if not failures:
            return
        print("[Tool3D] Split Mark Seam: {} failure record(s):".format(len(failures)))
        for record in failures:
            print(
                "  - object={} cut_id={} edge_count={} reason={}".format(
                    record.get("object"),
                    record.get("cut_id"),
                    record.get("edge_count", 0),
                    record.get("reason"),
                )
            )

    def _collect_selected_meshes(self, context):
        """Return selected mesh objects excluding temporary display objects."""
        excluded_names = {
            _TOOL3D_INTERSECTION_DISPLAY,
            _TOOL3D_INTERSECT_OVERLAY_TEMP,
        }
        return [
            obj for obj in context.selected_objects
            if obj.type == 'MESH' and obj.name not in excluded_names
        ]

    # ===== Task 4: smart cap/fill geometry =====
    #
    # Everything below implements per-cut_id "smart cap" fill: order a
    # boundary loop's own edges into a simple polygon, try a best-fit
    # planar ear-clip triangulation first, fall back to
    # bmesh.ops.triangle_fill restricted to only that loop's edges when the
    # loop is not planar (or the planar attempt fails validation), and
    # validate every result before it is allowed to persist. Nothing here
    # is reachable from the legacy operators (TOOL3D_OT_split_by_edges,
    # TOOL3D_OT_knife_cut_pipeline, TOOL3D_OT_separate_and_process,
    # TOOL3D_OT_fill_holes, TOOL3D_OT_bevel_borders), which keep using
    # their own untouched _fill_holes.

    @staticmethod
    def _ordered_boundary_loop(edges):
        """Return (vertices, reason) for one closed boundary loop.

        Builds adjacency from only the supplied BMEdge objects (never from
        bm.edges at large), requires every vertex touched by them to have
        degree exactly 2 within that set, then walks the resulting simple
        cycle starting from the first endpoint of the first supplied edge,
        taking the lowest-ordinal direction first so the result is fully
        deterministic. Returns (None, reason) for: fewer than 3 edges, an
        invalid/degenerate BMEdge reference, a zero-length edge, a
        duplicate-vertex edge, branching/open-chain topology (any degree
        != 2, or the walk cannot find exactly one unvisited edge to
        continue on), and near-duplicate vertex coordinates elsewhere in
        the loop (a self-touching/pinched loop).

        Final repair pass 3 (identity). Every element comparison here is
        now by Python object IDENTITY, plus a STABLE POSITIONAL map built
        from the supplied `edges` sequence itself -- never `BMVert.index`
        or `BMEdge.index`. Blender does not keep index tables current
        through topology edits, so inside one live BMesh a freshly created
        element reports `.index == -1`, and several distinct elements can
        report the SAME index. Measured on this build against a valid
        4-edge ring whose BMesh had never been `index_update()`d, the old
        index-keyed version rejected it three different ways:
          - `v0.index == v1.index` reported "zero-length edge (duplicate
            vertex)", because both endpoints read -1;
          - `vert_by_index` collapsed every vertex onto the single key -1,
            so the count check reported "branching or duplicate edge";
          - `visited_edge_indices` collapsed every edge onto -1, so the
            walk broke on its first step.
        A positional map has none of those failure modes: ordinals are
        assigned on first appearance while iterating `edges` in the order
        given, so the start vertex and walk direction stay fully
        deterministic for a given input, and the determinism no longer
        depends on index-table freshness. The map is only meaningful
        within this one call on one live BMesh, which is exactly its
        scope; callers that need portable identity across BMesh
        boundaries use endpoint coordinates (`_edge_signature`) instead.
        """
        edges = list(edges)
        if len(edges) < 3:
            return None, "loop must have at least 3 edges"

        lengths = []
        vert_ordinal = {}       # BMVert (identity) -> stable ordinal
        verts_by_ordinal = {}   # stable ordinal -> BMVert
        adjacency = {}          # ordinal -> [(neighbour ordinal, BMEdge), ...]

        def ordinal_of(vert):
            """Ordinal of `vert`, assigned on first appearance."""
            existing = vert_ordinal.get(vert)
            if existing is not None:
                return existing
            assigned = len(vert_ordinal)
            vert_ordinal[vert] = assigned
            verts_by_ordinal[assigned] = vert
            return assigned

        for edge in edges:
            if not getattr(edge, "is_valid", True):
                return None, "edge reference is invalid"
            verts = edge.verts
            if len(verts) != 2:
                return None, "malformed edge without exactly 2 vertices"
            v0, v1 = verts[0], verts[1]
            # IDENTITY, never `.index`: two DISTINCT fresh vertices both
            # reporting -1 are not one duplicated vertex.
            if v0 is v1:
                return None, "zero-length edge (duplicate vertex)"
            length = (v0.co - v1.co).length
            if length <= 1.0e-12:
                return None, "zero-length edge segment"
            lengths.append(length)
            ordinal_0 = ordinal_of(v0)
            ordinal_1 = ordinal_of(v1)
            adjacency.setdefault(ordinal_0, []).append((ordinal_1, edge))
            adjacency.setdefault(ordinal_1, []).append((ordinal_0, edge))

        if len(vert_ordinal) != len(edges):
            return None, "branching or duplicate edge (vertex/edge count mismatch)"

        for neighbors in adjacency.values():
            if len(neighbors) != 2:
                return None, "vertex degree is not exactly 2 (open chain or branch)"
            if neighbors[0][0] == neighbors[1][0]:
                return None, "degenerate two-edge loop between the same vertex pair"

        avg_length = sum(lengths) / len(lengths)
        epsilon = max(avg_length * 1.0e-6, 1.0e-9)
        epsilon_sq = epsilon * epsilon

        # I8: the duplicate-coordinate check used to be an unconditional
        # O(n^2) pairwise scan (a 256-vertex ring = ~32k Vector
        # subtractions before any capping even starts). It is now done by
        # hashing each vertex onto a grid of cell size `epsilon` and
        # comparing only against the 27 neighbouring cells -- the same
        # answer for the near-duplicate case this guards against, in
        # linear time. `_point_signature`'s quantization is reused so the
        # grid semantics match the rest of the file.
        all_verts = list(verts_by_ordinal.values())
        occupied = {}
        for vert in all_verts:
            cell = TOOL3D_OT_split_mark_sharp._point_signature(vert.co, epsilon)
            for dx in (-1, 0, 1):
                for dy in (-1, 0, 1):
                    for dz in (-1, 0, 1):
                        neighbour = (cell[0] + dx, cell[1] + dy, cell[2] + dz)
                        for other in occupied.get(neighbour, ()):
                            if (vert.co - other.co).length_squared <= epsilon_sq:
                                return None, "duplicate vertex coordinates within epsilon"
            occupied.setdefault(cell, []).append(vert)

        # Ordinal 0 is the first endpoint of the first supplied edge, so
        # the start point and direction are a deterministic function of the
        # caller's own edge sequence rather than of index-table freshness.
        start_ordinal = 0
        neighbors_of_start = sorted(adjacency[start_ordinal], key=lambda item: item[0])
        next_ordinal, first_edge = neighbors_of_start[0]

        ordered_ordinals = [start_ordinal]
        # Edge identity, never `.index`: a set of BMEdge objects. Distinct
        # fresh edges all reading -1 would otherwise collapse into one
        # entry and break the walk on its first step.
        visited_edges = {first_edge}
        current_ordinal = next_ordinal

        while current_ordinal != start_ordinal:
            ordered_ordinals.append(current_ordinal)
            candidates = [
                (n_ordinal, e) for n_ordinal, e in adjacency[current_ordinal]
                if e not in visited_edges
            ]
            if len(candidates) != 1:
                return None, "loop walk broke: branch or disconnected component"
            next_ordinal, edge = candidates[0]
            visited_edges.add(edge)
            current_ordinal = next_ordinal

        if len(visited_edges) != len(edges):
            return None, "loop walk did not visit every supplied edge"
        if len(ordered_ordinals) < 3:
            return None, "closed loop needs at least 3 distinct vertices"

        ordered_verts = [verts_by_ordinal[ordinal] for ordinal in ordered_ordinals]
        return ordered_verts, None

    @staticmethod
    def _orthonormal_basis(normal):
        """Return (axis_u, axis_v) orthonormal to `normal`, seeded from the
        world axis least aligned with it for numerical stability."""
        from mathutils import Vector

        world_axes = (
            Vector((1.0, 0.0, 0.0)),
            Vector((0.0, 1.0, 0.0)),
            Vector((0.0, 0.0, 1.0)),
        )
        seed = min(world_axes, key=lambda axis: abs(axis.dot(normal)))
        axis_u = seed - normal * seed.dot(normal)
        if axis_u.length_squared <= 1.0e-20:
            seed = Vector((0.0, 1.0, 0.0)) if abs(normal.x) > 0.9 else Vector((1.0, 0.0, 0.0))
            axis_u = seed - normal * seed.dot(normal)
        axis_u.normalize()
        axis_v = normal.cross(axis_u)
        axis_v.normalize()
        return axis_u, axis_v

    @staticmethod
    def _connected_edge_loops(edges):
        """Partition `edges` into connected components (lists of BMEdge).

        Used by `_fill_cut_loops` so that a cut_id whose boundary edges
        form several separate closed loops on one piece is capped loop by
        loop rather than as one impossible combined loop. Connectivity is
        by shared BMVert IDENTITY, never `.index` (the index table is
        dirty on the live BMesh this runs on). Each component's edge order
        follows the input order, so the result is deterministic for a
        deterministic input.
        """
        edges = [edge for edge in edges if edge is not None]
        by_vert = {}
        for edge in edges:
            for vert in edge.verts:
                by_vert.setdefault(vert, []).append(edge)

        seen = set()
        components = []
        for start in edges:
            if start in seen:
                continue
            seen.add(start)
            component = [start]
            stack = [start]
            while stack:
                current = stack.pop()
                for vert in current.verts:
                    for neighbour in by_vert.get(vert, ()):
                        if neighbour not in seen:
                            seen.add(neighbour)
                            component.append(neighbour)
                            stack.append(neighbour)
            components.append(component)
        return components

    @staticmethod
    def _split_folded_loop(bm, ordered_verts, length_eps):
        """Split ONE closed boundary loop that is really several planar
        cut faces folded along shared cut lines into those planar faces.

        The user's "cut a cube into four with two crossing Seam rings"
        case: every quarter ends up with two square cut faces at right
        angles that share the cut line where the rings crossed. After
        `split_edges` that is one 8-vertex boundary loop shaped like an
        L (measured on this build: 8 edges, every vertex degree 2, best-fit
        plane normal (0.7, 0, 0.7), max distance 0.53 -- so the planar
        path refused it and `triangle_fill` produced mixed-normal
        garbage). The loop is not a hole in a surface; it is two flat
        holes glued along one line, and it must be capped as two flat
        polygons.

        Generalised to N planes (three crossing rings cut a cube into
        eight octants; each octant carries THREE square cut faces meeting
        at the cube's centre, which is not a mesh vertex at all -- so its
        boundary is one 6-vertex loop shaped like a Y, and no cap that uses
        only existing vertices can close it correctly; a triangulation
        would chamfer the corner off).

        Fold vertices are found TOPOLOGICALLY, not from the geometry: a
        genuine corner of the loop is a fold when BOTH of its incident
        boundary edges lie on the SAME existing face. That is exactly what
        a ring crossing looks like after `split_edges` -- the piece keeps
        one quadrant face of the crossing, and its boundary turns from one
        ring onto the other within that face. At an ordinary corner (the
        ring bending around a mesh edge) the two boundary edges lie on
        different faces. A geometric rule was tried first and failed here:
        at a fold vertex the two incident edges span the face's own plane,
        which is a perfectly good plane covering as many loop vertices as
        the real cut planes do, so "the plane through the most vertices"
        cannot tell them apart once every run is only two edges long.

        Sphere support (a UV sphere cut by three crossing rings): at a
        sphere POLE the crossing sits on a triangle fan, so the piece keeps
        a wedge of SEVERAL triangles there and the two incident boundary
        edges lie on two DIFFERENT faces of that wedge -- the same-face
        rule misses it (measured on this build: the octant loop's pole
        vertex had `same_face=False` with 4 linked faces, while its two
        equator crossings were found). The second rule generalises the
        first: a fold is where the boundary turns from one ring onto the
        other THROUGH the piece's own faces rather than across a mesh
        edge. At an ordinary bend of a ring the piece holds exactly the
        two faces on either side of the ONE mesh edge the ring bends over
        (`len(vert.link_faces) == 2`); at a crossing on a fan it holds the
        whole wedge between the two rings (3 or more faces); and the
        same-face case is the degenerate wedge of one face. So a real
        corner of the loop is a fold when the piece has one face or at
        least three faces around it -- never exactly two.

        A first attempt at this second rule compared the plane of the two
        edges before the vertex with the plane of the two after it; that
        is wrong on a curved arc, where consecutive edge pairs of ONE ring
        already span different planes (|dot| = 0.19 measured on a 16-segment
        sphere), so every ordinary bend fired. The face-count rule is
        purely topological and has no such false positive.

        The loop is then cut at the fold vertices into N runs, one cut
        face each, and closed:
          - N == 2: a NEW seam edge between the two fold vertices; each run
            plus the seam is one flat polygon (the quarter case).
          - N >= 3: a NEW apex vertex at the point where all N run planes
            meet (least-squares intersection; exact for three planes in
            general position, rejected when the planes do not share a
            point), plus a NEW seam edge from the apex to every fold
            vertex; each run plus the apex is one flat polygon. The apex
            gets every shape-key layer set to its own position so it does
            not end up at the origin in a shape key.
          - N >= 3 whose planes do NOT share a point (the apex system is
            singular, or its residual is too large): the runs are grouped
            by COPLANARITY and each group is closed with CHORDS between
            fold vertices -- see `_fold_plane_group_polygons`. This is the
            user's three-seam-ring sphere (two parallel latitude rings plus
            one meridian): no apex can exist because two of the planes are
            parallel, yet each band half is still exactly three flat cut
            faces (two latitude half-disks and one meridian cross-section)
            that close over chords.
        Seams and the apex are real interior geometry of the cut, not
        diagonals, so nothing here can be mistaken for a rollback leftover;
        `_discard_fold_geometry` removes them again if a later polygon
        fails.

        Returns (list_of_vertex_polygons, fold_geometry, reason) where
        `fold_geometry` is `{"seams": [new BMEdge, ...], "apex": BMVert or
        None}`. `None, None, reason` means "this is not a foldable loop,
        cap it as it is" -- the caller falls back to the single-surface
        path, which reports a controlled failure if it cannot cap either.
        """
        from mathutils import Matrix, Vector

        n = len(ordered_verts)
        if n < 6:
            return None, None, "loop too short to be a folded pair"

        coords = [v.co.copy() for v in ordered_verts]

        # Boundary edge k joins loop vertex k to k+1.
        loop_edges = []
        for k in range(n):
            edge = bm.edges.get((ordered_verts[k], ordered_verts[(k + 1) % n]))
            if edge is None:
                return None, None, "loop segment has no edge"
            loop_edges.append(edge)

        def sole_face(edge):
            faces = edge.link_faces
            return faces[0] if len(faces) == 1 else None

        folds = []
        for k in range(n):
            a = coords[k] - coords[k - 1]
            b = coords[(k + 1) % n] - coords[k]
            cross = a.cross(b)
            if cross.length <= 1.0e-9 * max(a.length * b.length, 1.0e-30):
                continue  # collinear: not a corner, so not a fold
            face_in = sole_face(loop_edges[k - 1])
            face_out = sole_face(loop_edges[k])
            if face_in is not None and face_in is face_out:
                folds.append(k)
                continue
            # Second rule (a crossing on a fan, e.g. a sphere pole): the
            # piece holds a wedge of >= 3 faces around this vertex. An
            # ordinary bend of one ring over a mesh edge holds exactly 2.
            if len(ordered_verts[k].link_faces) >= 3:
                folds.append(k)
        if len(folds) < 2:
            return None, None, "loop has fewer than two fold vertices"

        runs = []
        for i, start in enumerate(folds):
            end = folds[(i + 1) % len(folds)]
            seq = [start]
            k = (start + 1) % n
            while k != end:
                seq.append(k)
                k = (k + 1) % n
            seq.append(end)
            if len(seq) < 3:
                return None, None, "a fold run has fewer than two edges"
            runs.append(seq)

        while len(runs) > 2:
            for i in range(len(runs)):
                j = (i + 1) % len(runs)
                merged = runs[i] + runs[j][1:]
                points = [ordered_verts[k] for k in merged]
                _, _, deviation, _, _ = TOOL3D_OT_split_mark_sharp._fit_loop_plane(points)
                if deviation <= length_eps:
                    if j == 0:
                        runs = [merged] + runs[1:i]
                    else:
                        runs[i] = merged
                        del runs[j]
                    break
            else:
                break
        fold_verts = [ordered_verts[seq[0]] for seq in runs]

        if len(runs) == 2:
            fold_a, fold_b = fold_verts
            new_seams = []
            seam = bm.edges.get((fold_a, fold_b))
            if seam is None:
                seam = bm.edges.new((fold_a, fold_b))
                new_seams.append(seam)
            polygons = [[ordered_verts[k] for k in seq] for seq in runs]
            return polygons, {"seams": new_seams, "apex": None}, None

        # N >= 3: every run's plane (Newell normal + centroid), then the
        # point closest to all of them.
        planes = []
        for seq in runs:
            pts = [coords[k] for k in seq]
            centroid = Vector((0.0, 0.0, 0.0))
            for p in pts:
                centroid += p
            centroid /= len(pts)
            normal = Vector((0.0, 0.0, 0.0))
            for i in range(len(pts)):
                p0 = pts[i]
                p1 = pts[(i + 1) % len(pts)]
                normal.x += (p0.y - p1.y) * (p0.z + p1.z)
                normal.y += (p0.z - p1.z) * (p0.x + p1.x)
                normal.z += (p0.x - p1.x) * (p0.y + p1.y)
            if normal.length <= 1.0e-12:
                return None, None, "a fold run does not define a plane"
            planes.append((normal.normalized(), centroid))

        # The apex strategy is tried FIRST for every N >= 3, unchanged: it
        # is what caps the grid-cube octants, the sphere octants and the 16
        # wedges (pinned by the legacy and pipeline suites), and its single
        # corner vertex is the geometrically right answer whenever the run
        # planes really do meet at one point.
        apex_reason = None
        apex_co = None
        system = Matrix(((0.0, 0.0, 0.0), (0.0, 0.0, 0.0), (0.0, 0.0, 0.0)))
        rhs = Vector((0.0, 0.0, 0.0))
        for normal, centroid in planes:
            for r in range(3):
                for c in range(3):
                    system[r][c] += normal[r] * normal[c]
            rhs += normal * normal.dot(centroid)
        if abs(system.determinant()) <= 1.0e-12:
            apex_reason = "fold planes do not meet at a single point"
        else:
            apex_co = system.inverted() @ rhs
            residual = max(abs((apex_co - centroid).dot(normal)) for normal, centroid in planes)
            if residual > max(length_eps, 1.0e-9):
                apex_reason = (
                    "fold planes do not share a corner (residual {:.3g})".format(residual))

        if apex_reason is None:
            loop_centroid = Vector((0.0, 0.0, 0.0))
            for p in coords:
                loop_centroid += p
            loop_centroid /= n
            extent = max((p - loop_centroid).length for p in coords)
            if (apex_co - loop_centroid).length > 2.0 * extent:
                return None, None, "fold apex lies far outside the loop"

            apex = bm.verts.new(apex_co)
            for layer in bm.verts.layers.shape.values():
                apex[layer] = apex_co.copy()
            new_seams = []
            for fold_vert in fold_verts:
                seam = bm.edges.get((apex, fold_vert))
                if seam is None:
                    seam = bm.edges.new((apex, fold_vert))
                    new_seams.append(seam)
            polygons = [[ordered_verts[k] for k in seq] + [apex] for seq in runs]
            return polygons, {"seams": new_seams, "apex": apex}, None

        # No common corner (two of the planes are PARALLEL, or the system
        # is singular). The cut faces are still flat; they close over
        # chords instead of an apex -- the user's three-Seam-ring sphere.
        polygons, chords, group_reason = (
            TOOL3D_OT_split_mark_sharp._fold_plane_group_polygons(
                bm, ordered_verts, runs, planes, length_eps))
        if polygons is None:
            return None, None, "{} / {}".format(apex_reason, group_reason)
        return polygons, {"seams": chords, "apex": None}, None

    # Two run planes count as ONE plane (one cut face) when their normals
    # are parallel to within this angle AND they have no offset along it.
    _FOLD_COPLANAR_COS = math.cos(math.radians(1.0))

    @staticmethod
    def _fold_plane_group_polygons(bm, ordered_verts, runs, planes, length_eps):
        """The `_split_folded_loop` strategy for a loop whose run planes do
        NOT share a point -- the user's three-Seam-ring sphere.

        Returns `(polygons, chords, reason)`: `chords` is the list of chord
        BMEdges the caller records as fold seams, `reason` is a string when
        the configuration is not cappable this way (and nothing was
        created in that case).

        The apex strategy assumes all N run planes meet at one corner. Two
        PARALLEL planes never do, so it is unusable on the user's mesh: a
        "band half" between two latitude Seam rings, cut by one meridian
        ring, has one 50-edge boundary made of 4 runs on 3 planes (top
        latitude, meridian, bottom latitude, meridian again) -- measured on
        this build the least-squares apex landed 6580 units away with
        residual 0.38, and the planar and `triangle_fill` fallbacks then
        rejected the loop as mixed normals, leaving the piece OPEN.

        That piece is still exactly three FLAT cut faces; they just close
        over CHORDS instead of an apex. Runs are grouped by coplanarity
        (parallel normals, no offset along them), which puts the two
        meridian runs in one group and each latitude run in its own -- the
        real cut faces, one per group. A group is then closed by walking
        its runs in loop order and joining each run's end fold vertex to
        the next group run's start fold vertex with a chord; a single-run
        group closes onto its own start. On the measured mesh the meridian
        group becomes the band's full meridian cross-section (two vertical
        arcs plus the chords across the top and bottom latitude planes) and
        each latitude group becomes that ring's half-disk -- geometrically
        the exact flat faces of the solid.

        Every chord must be shared by EXACTLY two groups, because a chord
        is the interior crease where two cut faces meet. A chord belonging
        to one group only means the groups do not tile the loop's interior
        (three mutually crossing planes with no common corner, say), the
        polygons would have to intersect each other, and this strategy
        refuses rather than building garbage.
        """
        n = len(ordered_verts)
        count = len(runs)

        # Union-find over coplanar runs. `|n_i . n_j|` (not the signed dot)
        # because two runs of ONE plane are walked in opposite directions
        # around the loop, so Newell gives them opposite normals -- exactly
        # what the two meridian runs do on the measured mesh.
        parent = list(range(count))

        def find(item):
            while parent[item] != item:
                parent[item] = parent[parent[item]]
                item = parent[item]
            return item

        for i in range(count):
            normal_i, centroid_i = planes[i]
            for j in range(i + 1, count):
                normal_j, centroid_j = planes[j]
                if abs(normal_i.dot(normal_j)) <= TOOL3D_OT_split_mark_sharp._FOLD_COPLANAR_COS:
                    continue
                if abs((centroid_i - centroid_j).dot(normal_i)) > length_eps:
                    continue
                parent[find(i)] = find(j)

        groups = {}
        for i in range(count):
            groups.setdefault(find(i), []).append(i)
        # Loop order, so the polygons are built deterministically.
        group_runs = sorted(groups.values(), key=lambda members: members[0])
        if len(group_runs) < 2:
            return None, None, "fold runs all lie in one plane"

        # Walk each group and collect its polygon plus the chord pairs it
        # needs. Nothing is created yet: the sharing check below may refuse
        # the whole configuration, and a refusal must leave `bm` untouched.
        polygons_by_index = []
        chord_pairs = []          # (group position, loop index a, loop index b)
        for position, members in enumerate(group_runs):
            polygon = []
            for offset, run_index in enumerate(members):
                run = runs[run_index]
                next_run_index = members[(offset + 1) % len(members)]
                if (run_index + 1) % count == next_run_index:
                    # The two runs already meet at this fold vertex: it is
                    # contributed by the next run's own walk.
                    polygon.extend(run[:-1])
                else:
                    polygon.extend(run)
                    chord_pairs.append((position, run[-1], runs[next_run_index][0]))
            if len(polygon) < 3:
                return None, None, "a fold plane group is too small to cap"
            polygons_by_index.append(polygon)

        # Every chord is the crease between exactly two cut faces.
        sharing = {}
        for position, a, b in chord_pairs:
            sharing.setdefault(frozenset((a, b)), []).append(position)
        for positions in sharing.values():
            if len(set(positions)) != 2:
                return None, None, "fold groups do not close"
        # Review fix: a chord that already exists as a SURFACE edge means the
        # chord line is part of the piece itself, so the two group polygons
        # sharing it would give that edge four faces -- a non-manifold
        # overlap that `_cap_structure_failure` cannot see, because it counts
        # edge uses per polygon. Refuse before anything is created.
        for key in sharing:
            a, b = sorted(key)
            existing = bm.edges.get((ordered_verts[a], ordered_verts[b]))
            if existing is not None and existing.link_faces:
                return None, None, "a fold chord is already a surface edge"

        # Committed: create the chord edges. Only edges created HERE are
        # recorded as seams (same rule as the N == 2 path): a reused wire
        # edge is not ours to roll back or to mark as a fold crease.
        chords = []
        for key in sorted(sharing.keys(), key=lambda pair: sorted(pair)):
            a, b = sorted(key)
            vert_a, vert_b = ordered_verts[a], ordered_verts[b]
            chord = bm.edges.get((vert_a, vert_b))
            if chord is None:
                chord = bm.edges.new((vert_a, vert_b))
                chords.append(chord)

        polygons = [[ordered_verts[k] for k in polygon] for polygon in polygons_by_index]
        return polygons, chords, None

    @staticmethod
    def _discard_fold_geometry(bm, fold_geometry):
        """Remove the seam edges and apex vertex `_split_folded_loop`
        created, once the faces using them are gone. Safe to call after
        `_remove_faces_created` already swept the seams (they are new wire
        edges by then); an apex still holding an edge is left alone."""
        if not fold_geometry:
            return
        for seam in fold_geometry.get("seams", ()):
            if seam is not None and seam.is_valid and seam.is_wire:
                bm.edges.remove(seam)
        apex = fold_geometry.get("apex")
        if apex is not None and apex.is_valid and not apex.link_edges:
            bm.verts.remove(apex)

    @staticmethod
    def _cap_polygon(bm, polygon, length_eps, area_eps, epsilon, existing_edges_before):
        """Cap ONE closed polygon: `polygon` is a list of BMVert in loop
        order whose consecutive pairs (including last -> first) are all
        existing edges of `bm` -- the boundary edges of one folded run
        plus the seam. Planar ear-clip when the polygon is flat within
        `length_eps`; otherwise `bmesh.ops.triangle_fill` over exactly the
        polygon's own edges (a folded cut face is flat by construction,
        but the cut-only offset tilts the two faces of a fold by slightly
        different amounts, so a small residual is expected and must not
        fail the cap). The result is validated like any other cap, with
        the orientation vote taken from THIS polygon's own adjacent faces.

        Returns (faces, reason). On failure everything this attempt
        created is already rolled back, so the caller only has to undo
        earlier polygons of the same fold.
        """
        centroid, normal, max_distance, axis_u, axis_v = (
            TOOL3D_OT_split_mark_sharp._fit_loop_plane(polygon))
        expected = TOOL3D_OT_split_mark_sharp._expected_cap_normal(polygon, normal)

        faces = None
        if max_distance <= length_eps:
            points_2d = TOOL3D_OT_split_mark_sharp._project_loop(
                polygon, centroid, axis_u, axis_v)
            faces, _reason = TOOL3D_OT_split_mark_sharp._triangulate_projected_loop(
                bm, polygon, points_2d, length_eps, area_eps)

        if faces is None:
            m = len(polygon)
            edges = []
            for i in range(m):
                edge = bm.edges.get((polygon[i], polygon[(i + 1) % m]))
                if edge is None:
                    return None, "folded polygon segment has no edge"
                edges.append(edge)
            try:
                result = bmesh.ops.triangle_fill(
                    bm, edges=edges, use_beauty=True, use_dissolve=False)
            except (ValueError, RuntimeError) as exc:
                return None, "triangle_fill raised on folded polygon: {}".format(exc)
            faces = [
                elem for elem in result.get("geom", [])
                if isinstance(elem, bmesh.types.BMFace) and elem.is_valid
            ] or [face for face in result.get("faces", []) if face.is_valid]
            if not faces:
                return None, "triangle_fill produced no faces on folded polygon"
            polygon_verts = set(polygon)
            if any(v not in polygon_verts for face in faces for v in face.verts):
                TOOL3D_OT_split_mark_sharp._remove_faces_created(
                    bm, faces, existing_edges_before)
                return None, "triangle_fill touched vertices outside the folded polygon"

        ok, reason = TOOL3D_OT_split_mark_sharp._validate_new_cap(faces, expected, epsilon)
        if not ok:
            TOOL3D_OT_split_mark_sharp._remove_faces_created(
                bm, faces, existing_edges_before)
            return None, reason
        return faces, None

    @staticmethod
    def _fit_loop_plane(vertices):
        """Return (centroid, normal, max_distance, axis_u, axis_v).

        Normal via Newell's method (robust for non-convex loops); if that
        degenerates near zero (near-collinear points), falls back to the
        largest-magnitude cross product among consecutive edge triples.
        axis_u/axis_v form an orthonormal basis for the plane, built from
        the world axis least aligned with the normal. max_distance is the
        largest absolute signed distance from any loop vertex to the fitted
        plane -- the planarity measure the caller compares to tolerance.
        """
        from mathutils import Vector

        n = len(vertices)
        centroid = Vector((0.0, 0.0, 0.0))
        for v in vertices:
            centroid += v.co
        centroid /= n

        normal = Vector((0.0, 0.0, 0.0))
        for i in range(n):
            p0 = vertices[i].co
            p1 = vertices[(i + 1) % n].co
            normal.x += (p0.y - p1.y) * (p0.z + p1.z)
            normal.y += (p0.z - p1.z) * (p0.x + p1.x)
            normal.z += (p0.x - p1.x) * (p0.y + p1.y)

        if normal.length_squared <= 1.0e-20:
            best_length_sq = 0.0
            best_normal = Vector((0.0, 0.0, 0.0))
            for i in range(n):
                p0 = vertices[i].co
                p1 = vertices[(i + 1) % n].co
                p2 = vertices[(i + 2) % n].co
                candidate = (p1 - p0).cross(p2 - p1)
                length_sq = candidate.length_squared
                if length_sq > best_length_sq:
                    best_length_sq = length_sq
                    best_normal = candidate
            normal = best_normal

        if normal.length_squared <= 1.0e-20:
            normal = Vector((0.0, 0.0, 1.0))
        else:
            normal.normalize()

        axis_u, axis_v = TOOL3D_OT_split_mark_sharp._orthonormal_basis(normal)

        max_distance = 0.0
        for v in vertices:
            distance = abs((v.co - centroid).dot(normal))
            if distance > max_distance:
                max_distance = distance

        return centroid, normal, max_distance, axis_u, axis_v

    @staticmethod
    def _project_loop(vertices, centroid, axis_u, axis_v):
        """Return list of 2D projected points."""
        points_2d = []
        for v in vertices:
            offset = v.co - centroid
            points_2d.append((offset.dot(axis_u), offset.dot(axis_v)))
        return points_2d

    @staticmethod
    def _signed_area_2d(points):
        area = 0.0
        n = len(points)
        for i in range(n):
            x0, y0 = points[i]
            x1, y1 = points[(i + 1) % n]
            area += x0 * y1 - x1 * y0
        return area * 0.5

    @staticmethod
    def _segments_intersect_2d(p1, p2, p3, p4, epsilon):
        """True if closed segments p1-p2 and p3-p4 cross at a point
        interior to both (a shared endpoint is never treated as a
        crossing, so adjacent polygon edges never trip this)."""
        def cross(o, a, b):
            return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])

        d1 = cross(p3, p4, p1)
        d2 = cross(p3, p4, p2)
        d3 = cross(p1, p2, p3)
        d4 = cross(p1, p2, p4)

        return (
            ((d1 > epsilon and d2 < -epsilon) or (d1 < -epsilon and d2 > epsilon))
            and ((d3 > epsilon and d4 < -epsilon) or (d3 < -epsilon and d4 > epsilon))
        )

    @staticmethod
    def _polygon_2d_self_intersects(points, epsilon):
        """True if the closed polygon `points` (in order) is not simple."""
        n = len(points)
        if n < 4:
            return False
        for i in range(n):
            a1, a2 = points[i], points[(i + 1) % n]
            for j in range(i + 1, n):
                if j == i or (j + 1) % n == i or j == (i + 1) % n:
                    continue
                b1, b2 = points[j], points[(j + 1) % n]
                if TOOL3D_OT_split_mark_sharp._segments_intersect_2d(
                        a1, a2, b1, b2, epsilon):
                    return True
        return False

    @staticmethod
    def _point_in_triangle_2d(p, a, b, c, epsilon):
        """Boundary-inclusive point-in-triangle test (used by ear clipping,
        where a vertex sitting on the candidate ear's boundary must still
        block it -- treating that vertex as 'outside' could clip through
        another polygon vertex)."""
        def sign(p1, p2, p3):
            return (p1[0] - p3[0]) * (p2[1] - p3[1]) - (p2[0] - p3[0]) * (p1[1] - p3[1])

        d1, d2, d3 = sign(p, a, b), sign(p, b, c), sign(p, c, a)
        has_neg = (d1 < -epsilon) or (d2 < -epsilon) or (d3 < -epsilon)
        has_pos = (d1 > epsilon) or (d2 > epsilon) or (d3 > epsilon)
        return not (has_neg and has_pos)

    @staticmethod
    def _triangulate_projected_loop(bm, vertices, points_2d, length_eps, area_eps):
        """Return (faces, reason) for planar cap.

        Ear-clips the simple polygon described by `points_2d` (same order
        as `vertices`), rejecting a self-crossing input outright and
        skipping any candidate ear that is reflex, degenerate, or contains
        another polygon vertex. New faces are built only from `vertices`
        (existing boundary BMVerts) via bm.faces.new(); winding follows the
        polygon's own CCW orientation, corrected up front by reversing the
        walk if the raw ordering was CW.

        Final fix pass (M7): the old `normal` parameter was accepted and
        then never read -- the winding is decided entirely by the sign of
        the projected polygon's own 2D signed area, and the caller
        separately validates the result against the expected normal. It is
        removed rather than given a synthetic use, so the interface states
        what the function actually depends on.

        Final fix pass (I5): the single `epsilon` is replaced by the two
        dimensionally-correct values this function actually needs --
        `length_eps` for 2D coordinate distances (the segment-crossing
        test) and `area_eps` for areas and cross products. Previously a
        distance tolerance was squared and compared against areas in one
        place and used raw against cross products in another.
        """
        n = len(vertices)
        if n < 3 or len(points_2d) != n:
            return None, "vertex/point count mismatch or too few points"

        if TOOL3D_OT_split_mark_sharp._polygon_2d_self_intersects(points_2d, length_eps):
            return None, "loop projects to a self-intersecting 2D polygon"

        signed_area = TOOL3D_OT_split_mark_sharp._signed_area_2d(points_2d)
        if abs(signed_area) <= area_eps:
            return None, "projected loop has near-zero area"

        index_map = list(range(n))
        if signed_area < 0.0:
            index_map.reverse()
        working_points = [points_2d[i] for i in index_map]

        remaining = list(range(n))
        triangles = []
        guard = 0
        max_iterations = n * n + 8
        while len(remaining) > 3 and guard < max_iterations:
            guard += 1
            ear_found = False
            m = len(remaining)
            for offset in range(m):
                i_prev = remaining[(offset - 1) % m]
                i_curr = remaining[offset]
                i_next = remaining[(offset + 1) % m]
                a, b, c = working_points[i_prev], working_points[i_curr], working_points[i_next]

                cross = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
                if cross <= area_eps:
                    continue  # reflex or degenerate vertex: not a valid ear

                ear_is_clean = True
                for other in remaining:
                    if other in (i_prev, i_curr, i_next):
                        continue
                    if TOOL3D_OT_split_mark_sharp._point_in_triangle_2d(
                            working_points[other], a, b, c, area_eps):
                        ear_is_clean = False
                        break
                if not ear_is_clean:
                    continue

                triangles.append((index_map[i_prev], index_map[i_curr], index_map[i_next]))
                remaining.pop(offset)
                ear_found = True
                break

            if not ear_found:
                return None, "ear clipping failed: no valid ear found (degenerate polygon)"

        if len(remaining) == 3:
            i0, i1, i2 = remaining
            triangles.append((index_map[i0], index_map[i1], index_map[i2]))
        elif len(remaining) != 0:
            return None, "ear clipping did not fully reduce the polygon"

        if not triangles:
            return None, "ear clipping produced no triangles"

        # Snapshot BEFORE creating any face: for a loop of > 3 vertices,
        # ear clipping's bm.faces.new() calls create not just the
        # triangles but also whichever interior diagonal edge(s) don't
        # already exist (e.g. exactly one new diagonal for a quad).
        # bm.faces.remove() removes only the face, never a now-unused
        # edge it was using, so any partial-failure rollback below must
        # also sweep up newly-created edges that end up with no face
        # left on them (is_wire) -- otherwise a failed triangulation
        # leaves an orphan diagonal cutting across the still-open loop.
        existing_edges_before = set(bm.edges)

        faces = []
        for tri in triangles:
            tri_verts = [vertices[i] for i in tri]
            if bm.faces.get(tri_verts) is not None:
                TOOL3D_OT_split_mark_sharp._remove_faces_created(
                    bm, faces, existing_edges_before)
                return None, "a face already exists on this loop's vertices"
            try:
                face = bm.faces.new(tri_verts)
            except ValueError as exc:
                TOOL3D_OT_split_mark_sharp._remove_faces_created(
                    bm, faces, existing_edges_before)
                return None, "bmesh.faces.new failed: {}".format(exc)
            faces.append(face)

        return faces, None

    @staticmethod
    def _expected_cap_normal(ordered_verts, plane_normal):
        """Return plane_normal or its negation, whichever keeps every
        boundary edge's existing single linked face traversing that edge
        in the OPPOSITE direction from `ordered_verts`' own walk order --
        the exact 2-manifold consistency rule (each edge must end up with
        its two faces traversing it in opposite directions). This is used
        instead of a plain average of adjacent face normals because that
        average degenerates to (near) zero for the common case this
        feature targets: a hole surrounded by walls roughly perpendicular
        to the cap plane (e.g. capping the cut ring of an extruded/prism
        shape), where opposite-side wall normals cancel out. Falls back to
        +plane_normal if no boundary edge has a determinable adjacent-face
        winding (e.g. free/wire edges)."""
        n = len(ordered_verts)
        votes = 0
        for i in range(n):
            v_a = ordered_verts[i]
            v_b = ordered_verts[(i + 1) % n]
            edge = None
            for candidate in v_a.link_edges:
                if candidate.other_vert(v_a) is v_b:
                    edge = candidate
                    break
            if edge is None or not edge.link_faces:
                continue
            face = edge.link_faces[0]
            for loop in face.loops:
                if loop.vert is v_a and loop.link_loop_next.vert is v_b:
                    votes -= 1  # existing face already goes a->b: reverse needed
                    break
                if loop.vert is v_b and loop.link_loop_next.vert is v_a:
                    votes += 1  # existing face goes b->a: current order is right
                    break

        return plane_normal if votes >= 0 else -plane_normal

    @staticmethod
    def _point_strictly_in_triangle_2d(p, a, b, c, epsilon):
        """Boundary-EXCLUSIVE point-in-triangle test (used for overlap
        detection, where two triangles merely touching at a shared edge or
        vertex must NOT be reported as intersecting)."""
        def sign(p1, p2, p3):
            return (p1[0] - p3[0]) * (p2[1] - p3[1]) - (p2[0] - p3[0]) * (p1[1] - p3[1])

        d1, d2, d3 = sign(p, a, b), sign(p, b, c), sign(p, c, a)
        if abs(d1) <= epsilon or abs(d2) <= epsilon or abs(d3) <= epsilon:
            return False
        has_neg = (d1 < 0.0) or (d2 < 0.0) or (d3 < 0.0)
        has_pos = (d1 > 0.0) or (d2 > 0.0) or (d3 > 0.0)
        return not (has_neg and has_pos)

    @staticmethod
    def _triangles_2d_overlap(tri_a, tri_b, epsilon):
        """True if 2D triangles tri_a/tri_b overlap with nonzero area
        (touching only at a shared vertex/edge is not an overlap)."""
        for p in tri_a:
            if TOOL3D_OT_split_mark_sharp._point_strictly_in_triangle_2d(
                    p, tri_b[0], tri_b[1], tri_b[2], epsilon):
                return True
        for p in tri_b:
            if TOOL3D_OT_split_mark_sharp._point_strictly_in_triangle_2d(
                    p, tri_a[0], tri_a[1], tri_a[2], epsilon):
                return True
        edges_a = ((tri_a[0], tri_a[1]), (tri_a[1], tri_a[2]), (tri_a[2], tri_a[0]))
        edges_b = ((tri_b[0], tri_b[1]), (tri_b[1], tri_b[2]), (tri_b[2], tri_b[0]))
        for a1, a2 in edges_a:
            for b1, b2 in edges_b:
                if TOOL3D_OT_split_mark_sharp._segments_intersect_2d(a1, a2, b1, b2, epsilon):
                    return True
        return False

    @staticmethod
    def _new_cap_faces_self_intersect(faces, expected_normal, epsilon,
                                      loop_vert_count=None):
        """Best-effort self-intersection check for a freshly created cap:
        projects every new face's triangles onto a plane orthonormal to
        `expected_normal` and looks for a real (nonzero-area) 2D overlap
        between any two triangles that do not already share a vertex
        (sharing a vertex/edge is expected for adjacent triangulation
        triangles, not a self-intersection).

        Final fix pass (I8): this comparison is inherently O(t^2) in the
        number of new triangles, with a constant-factor 2D overlap test
        inside it -- for a 256-sided ring that is ~32k pure-Python overlap
        tests on top of the ear clipping itself, enough to visibly hang
        the UI. Above `_SHARP_LARGE_LOOP_VERT_BUDGET` the check is skipped
        (reported as "no detected self-intersection"), because a loop that
        large is only ever capped via `bmesh.ops.triangle_fill`, whose
        C-side triangulation of a single closed loop does not produce
        overlapping triangles, and the remaining per-face
        validity/area/normal checks (all O(t)) still run.

        Final repair pass (budget unit): the skip used to be decided by
        summing every new face's own vertex count -- i.e. the number of
        face CORNERS, not vertices. A cap is a triangulation of ONE loop, so its
        corner count is roughly 3x its vertex count (an ear-clipped 46-gon
        is 44 triangles = 132 corners), which meant a 46-vertex planar loop
        tripped a budget documented and named as a 128-VERTEX budget and
        silently skipped its self-intersection validation. The budget is
        now compared against the actual loop vertex count:
        `loop_vert_count` when the caller supplies it, otherwise the number
        of DISTINCT vertices the new faces reference -- which, for a cap
        built over a single closed loop (both the ear-clip path and the
        `triangle_fill` path, the latter explicitly verified by
        `_smart_cap_loop` to touch no vertex outside the loop), is exactly
        that loop's vertex count. So a 46- or 60-vertex loop is always
        fully validated, and only a genuinely >128-vertex loop skips the
        pairwise scan.

        Final repair pass 2, two corrections:

        1. The shared-vertex skip below compared `v.index` values. A BMVert
           created since the last index update reports `.index == -1`, so on
           the dirty index table that follows the topology edits creating a
           cap, EVERY new vertex compared equal to every other and every
           triangle pair looked like it shared a vertex -- the scan returned
           "no self-intersection" without a single real comparison.
           Measured on this build: a 45-triangle fan plus a genuinely
           overlapping disjoint triangle reported `False` on the dirty table
           and `True` after `index_update()`. It now compares BMVert
           IDENTITY, which is correct regardless of index state.
        2. Skipping past the budget is still correct for THIS scan, but a
           skipped scan is no longer the same as an unvalidated cap:
           `_validate_new_cap` now also runs `_cap_structure_failure`, a
           bounded O(n) structural check, on every cap at every size.

        Final repair pass 3 (scope correction): pass 2 fixed the index
        defect in THIS method and in `_validate_new_cap` only, and its
        notes read as though the defect was then fully closed. It was not:
        `_ordered_boundary_loop` (which decides whether a loop is a valid
        cycle at all, and in what order) and `_smart_cap_loop`'s
        outside-vertex guard were still keyed on `.index` afterwards, so a
        valid loop could be rejected outright before any of these
        validators were ever reached. Those two sites are fixed in pass 3;
        the index defect is closed across the cap path only as of that
        pass.
        """
        if loop_vert_count is None:
            # Identity, not `.index`: BMesh index tables are dirty right
            # after the topology edits that create these faces.
            loop_vert_count = len({v for face in faces for v in face.verts})
        if loop_vert_count > _SHARP_LARGE_LOOP_VERT_BUDGET:
            return False

        axis_u, axis_v = TOOL3D_OT_split_mark_sharp._orthonormal_basis(expected_normal)

        def project(co):
            return (co.dot(axis_u), co.dot(axis_v))

        triangles = []
        for face in faces:
            verts = list(face.verts)
            pts = [project(v.co) for v in verts]
            if len(verts) == 3:
                triangles.append((verts, pts))
            else:
                for i in range(1, len(verts) - 1):
                    triangles.append((
                        [verts[0], verts[i], verts[i + 1]],
                        [pts[0], pts[i], pts[i + 1]],
                    ))

        for i in range(len(triangles)):
            verts_a, pts_a = triangles[i]
            shared_a = set(verts_a)
            for j in range(i + 1, len(triangles)):
                verts_b, pts_b = triangles[j]
                # IDENTITY, never `.index` -- see the docstring's note on the
                # dirty index table. Two brand-new vertices both reporting
                # `.index == -1` are NOT the same vertex.
                if not shared_a.isdisjoint(verts_b):
                    continue
                if TOOL3D_OT_split_mark_sharp._triangles_2d_overlap(pts_a, pts_b, epsilon):
                    return True
        return False

    @staticmethod
    def _cap_structure_failure(faces):
        """Return a reason string when `faces` are not a well-formed cap
        over ONE closed loop, else None. Bounded: O(total face corners),
        with no pairwise comparison at all.

        Final repair pass 2: this exists because the pairwise
        self-intersection scan is deliberately skipped above
        `_SHARP_LARGE_LOOP_VERT_BUDGET` (see
        `_new_cap_faces_self_intersect`), which left a >128-vertex cap
        validated by nothing but the per-face validity/area/normal checks.
        Measured before this check existed: a 200-triangle fan plus one
        disjoint intruding triangle -- a cap that spans two separate
        boundary loops and overlaps itself -- was accepted outright as
        `(True, None)`, at every size past the budget. The same shape at 46
        vertices was correctly rejected, purely because it was small enough
        for the expensive scan to run.

        These invariants catch that class of defect in linear time, so they
        run on EVERY cap regardless of size:

          - no edge may be used by more than two of the new faces
            (a non-manifold fan);
          - the faces' boundary (edges used exactly once) must form exactly
            ONE simple closed cycle -- this is what a cap over a single
            closed loop means, and it is violated both by a cap that leaves
            an interior hole and by a face set that actually spans two
            disjoint loops;
          - no cap vertex may sit outside that boundary cycle.

        Verified on this build against 96 real cap fixtures (planar
        ear-clip and `triangle_fill`, convex and star-shaped, planar and
        non-planar, 3 to 600 vertices): zero were rejected. The
        fan-plus-intruder shape was rejected at 20, 46, 129, 200 and 400
        vertices, an edge shared by three faces was rejected, and an
        annulus (a cap with a hole, two boundary loops) was rejected.

        Every comparison here is by BMesh element IDENTITY, never `.index`:
        `.index` is -1 on every element created since the last index
        update, so an index-keyed set would silently collapse all of them
        into one entry.
        """
        if not faces:
            return "no faces to validate"

        edge_use = {}
        cap_verts = set()
        for face in faces:
            for vert in face.verts:
                cap_verts.add(vert)
            for edge in face.edges:
                edge_use[edge] = edge_use.get(edge, 0) + 1

        if any(count > 2 for count in edge_use.values()):
            return "cap edge is shared by more than two new faces"

        border = [edge for edge, count in edge_use.items() if count == 1]
        if not border:
            return "cap has no boundary edge"

        adjacency = {}
        for edge in border:
            vert_a, vert_b = edge.verts[0], edge.verts[1]
            adjacency.setdefault(vert_a, []).append(vert_b)
            adjacency.setdefault(vert_b, []).append(vert_a)
        if any(len(neighbours) != 2 for neighbours in adjacency.values()):
            return "cap boundary is not a simple closed loop"

        start = border[0].verts[0]
        visited = {start}
        previous, current = None, start
        while True:
            neighbours = adjacency[current]
            following = neighbours[0] if neighbours[0] is not previous else neighbours[1]
            if following is start:
                break
            if following in visited:
                return "cap boundary revisits a vertex"
            visited.add(following)
            previous, current = current, following

        if len(visited) != len(adjacency):
            return "cap boundary forms more than one closed loop"
        if cap_verts - visited:
            return "cap uses vertices outside its own boundary loop"
        return None

    @staticmethod
    def _validate_new_cap(faces, expected_normal, epsilon, loop_vert_count=None):
        """Return (bool, reason).

        Checks (in order): every face is valid with >= 3 distinct
        vertices and nonzero area; every face has a well-defined normal;
        those normals agree with `expected_normal` -- if ALL of them
        consistently oppose it, the winding is flipped in place (the only
        case the brief allows a reversal) and rechecked, but a MIXED set
        (some agree, some oppose) fails outright as inconsistent; then a
        bounded structural check (`_cap_structure_failure`) that runs at
        EVERY loop size; finally a best-effort planar-projection overlap
        check across all new triangles guards against self-intersection.

        Final repair pass 2: the structural check is the answer to "a
        >128-vertex loop may use the bounded path but must still validate
        enough geometry to satisfy no invalid cap". The pairwise scan is
        deliberately size-gated; the structural invariants are not, so no
        cap at any size is accepted without its topology being checked.

        Final repair pass: `loop_vert_count` is OPTIONAL and defaults to
        None, so the historical 3-argument call shape still works exactly
        as before -- the existing tests monkeypatch this method with a
        3-parameter stub, and every in-tree caller therefore deliberately
        keeps calling it with 3 arguments. When it is omitted,
        `_new_cap_faces_self_intersect` derives the loop's vertex count
        itself from the distinct vertices of the new faces (a cap always
        spans exactly one loop), so the budget is measured in vertices on
        both routes. Passing it explicitly is supported for direct callers
        that already know the count.

        Final fix pass (I5): `epsilon` is a DISTANCE (the caller's
        `cap_tolerance`, itself derived from the user-facing
        `sharp_fill_tolerance` slider, whose max is 0.1 and which is scaled
        by the mesh diagonal -- so on a scale-10 model it comfortably
        exceeds 1.0). It was previously compared directly against normal
        DOT PRODUCTS, which live in [-1, 1]: once the scaled tolerance
        passed 1.0, `any(d <= epsilon for d in dots)` was true for every
        possible orientation and EVERY valid cap was rejected as "normal
        does not agree with expected direction". The signature is kept
        (existing tests monkeypatch this exact 3-argument shape), but the
        three dimensions are now separated internally:
          - area comparisons use `epsilon * epsilon`
          - orientation comparisons use the scale-free `_SHARP_ANGLE_EPS`
          - the self-intersection projection keeps the distance `epsilon`
        """
        if not faces:
            return False, "no faces to validate"

        area_eps = epsilon * epsilon
        angle_eps = _SHARP_ANGLE_EPS

        for face in faces:
            if not face.is_valid:
                return False, "created face is invalid"
            # IDENTITY, never `.index`: a BMVert created since the last
            # index update reports `.index == -1`, so an index-keyed set
            # collapses a perfectly good triangle's three distinct vertices
            # into ONE entry and rejects it as degenerate. Measured on this
            # build: a brand-new valid triangle on an un-updated BMesh was
            # rejected with "face does not have at least 3 distinct
            # vertices" purely because all three verts read -1.
            if len(set(face.verts)) < 3:
                return False, "face does not have at least 3 distinct vertices"
            if face.calc_area() <= area_eps:
                return False, "created face has near-zero area"

        face_normals = []
        for face in faces:
            face.normal_update()
            n = face.normal
            if n.length_squared <= 1.0e-20:
                return False, "created face has an undefined normal"
            face_normals.append(n.normalized())

        dots = [n.dot(expected_normal) for n in face_normals]

        if all(d < -angle_eps for d in dots):
            for face in faces:
                face.normal_flip()
                face.normal_update()
            dots = [face.normal.normalized().dot(expected_normal) for face in faces]
        elif any(d < -angle_eps for d in dots) and any(d > angle_eps for d in dots):
            return False, "new faces have inconsistent/mixed normal orientation"

        if any(d <= angle_eps for d in dots):
            return False, "new face normal does not agree with expected direction"

        if TOOL3D_OT_split_mark_sharp._new_cap_faces_self_intersect(
                faces, expected_normal, epsilon, loop_vert_count):
            return False, "new cap faces self-intersect"

        # Final repair pass 2: the bounded structural check runs on EVERY
        # cap, at every size, and is NOT gated on the loop-vertex budget.
        # Above the budget the pairwise scan above returns early by design,
        # which used to leave a large cap validated by nothing but the
        # per-face checks -- measured: a 200-triangle fan plus a disjoint
        # intruding triangle was accepted as `(True, None)`, while the same
        # shape at 46 vertices was correctly rejected purely because it was
        # small enough for the scan to run. See `_cap_structure_failure`.
        #
        # It runs AFTER the pairwise scan, not before, so that a cap which
        # both self-intersects AND is structurally malformed is still
        # reported as "new cap faces self-intersect" whenever the scan
        # actually ran -- the specific, more informative diagnosis, and the
        # one existing callers and tests already rely on.
        structure_failure = TOOL3D_OT_split_mark_sharp._cap_structure_failure(faces)
        if structure_failure is not None:
            return False, structure_failure

        return True, None

    @staticmethod
    def _ngon_cap_loop(bm, edges, ordered_verts, expected_normal, epsilon,
                       existing_edges_before):
        """Last-resort cap: ONE ngon over the loop (`bmesh.ops.holes_fill`),
        then `bmesh.ops.triangulate` it. Return `(faces, None)` or
        `(None, reason)`; on any failure everything created here is rolled
        back so the loop is left open exactly as before.

        Why a second C-side path (user's meteor, 2026-09-23): a cell-
        network cut on a cratered sphere leaves boundary loops that wander
        up to 30% of the piece radius out of their best-fit plane.
        `bmesh.ops.triangle_fill` on such a saddle builds a fan that is
        partly inside-out (measured: 13 of 39 triangles against the loop's
        expected normal, 14 cap edges wound the same way twice, or a
        self-intersecting projection on the neighbouring piece). The ngon
        fill inherits its winding from the boundary itself, and the
        ngon triangulation stays on the ngon's own polygon, so it came out
        consistently wound (0 reversed triangles on both loops) and passed
        every existing validator unchanged. Kept AFTER `triangle_fill`
        so every loop the old path already capped keeps byte-identical
        geometry.
        """
        loop_verts = set(ordered_verts)
        try:
            filled = bmesh.ops.holes_fill(bm, edges=list(edges), sides=0)
        except (ValueError, RuntimeError) as exc:
            return None, "holes_fill raised: {}".format(exc)
        ngons = [f for f in filled.get("faces", []) if f.is_valid]
        if not ngons:
            return None, "holes_fill produced no face"
        if (len(ngons) != 1
                or len(ngons[0].verts) != len(ordered_verts)
                or any(v not in loop_verts for v in ngons[0].verts)):
            TOOL3D_OT_split_mark_sharp._remove_faces_created(
                bm, ngons, existing_edges_before)
            return None, "holes_fill did not produce one face over exactly this loop"

        try:
            result = bmesh.ops.triangulate(
                bm, faces=ngons, quad_method='BEAUTY', ngon_method='BEAUTY')
        except (ValueError, RuntimeError) as exc:
            TOOL3D_OT_split_mark_sharp._remove_faces_created(
                bm, ngons, existing_edges_before)
            return None, "triangulate raised: {}".format(exc)
        # `triangulate` reuses the original face as one of the triangles,
        # so the union below is what "everything created here" means.
        new_faces = [f for f in result.get("faces", []) if f.is_valid]
        for ngon in ngons:
            if ngon.is_valid and ngon not in new_faces:
                new_faces.append(ngon)
        if not new_faces:
            return None, "triangulate produced no faces"

        if any(v not in loop_verts for face in new_faces for v in face.verts):
            TOOL3D_OT_split_mark_sharp._remove_faces_created(
                bm, new_faces, existing_edges_before)
            return None, "ngon cap touched vertices outside this loop"

        ok, valid_reason = TOOL3D_OT_split_mark_sharp._validate_new_cap(
            new_faces, expected_normal, epsilon)
        if not ok:
            TOOL3D_OT_split_mark_sharp._remove_faces_created(
                bm, new_faces, existing_edges_before)
            return None, "ngon cap failed validation: {}".format(valid_reason)
        return new_faces, None

    @staticmethod
    def _remove_faces_created(bm, faces, existing_edges_before=None):
        """Remove exactly the (still-valid) faces this call created --
        used to roll back a trial cap attempt so the loop is left open.

        CRITICAL: `bm.faces.remove(face)` removes only the face itself; it
        does NOT remove an edge that face was using even if that edge now
        has no face left on it at all (confirmed empirically). For a loop
        of more than 3 vertices, both the planar ear-clip path
        (`bm.faces.new`) and the `bmesh.ops.triangle_fill` fallback create
        at least one interior diagonal edge that did not exist before the
        attempt -- if the faces using it are later rolled back without
        also removing that diagonal, it is left behind as an orphan WIRE
        edge cutting across the (supposedly still-open) loop, and would be
        persisted by a caller's `bm.to_mesh()` even when a completely
        unrelated SIBLING cut_id's cap succeeds in the same BMesh session.

        When `existing_edges_before` (a set of the BMEdges present in `bm`
        captured before the attempt started) is given, this also removes
        every edge that (a) was NOT in that set (i.e. genuinely created by
        this attempt, never a pre-existing/boundary/shared edge) and (b)
        is now `is_wire` (no face references it any more) after the face
        removal above. An edge that already existed before the attempt is
        never touched here, regardless of its post-removal state -- this
        is what keeps the loop's own original boundary edges (and any
        unrelated mesh edge) safe from ever being removed by this
        cleanup.
        """
        for face in faces:
            if face is not None and face.is_valid:
                bm.faces.remove(face)

        if existing_edges_before is None:
            return

        for edge in list(bm.edges):
            if edge.is_valid and edge.is_wire and edge not in existing_edges_before:
                bm.edges.remove(edge)

    @staticmethod
    def _smart_cap_loop(bm, edges, tolerance):
        """Return result dict with filled/method/faces/reason.

        `method` is one of "planar" (flat loop, ear-clipped), "folded" (a
        non-planar loop that is really two flat cut faces sharing a crease
        -- see `_split_folded_loop`, the crossing-Seam-rings case),
        "triangle_fill" (genuinely non-planar loop, C-side fill) or "none"
        (controlled failure, nothing created).

        Does not update object data itself (no bm.to_mesh()) -- the caller
        owns the BMesh lifecycle, per contract. Order of attempts: (1)
        validate the loop's own topology, (2) best-fit-plane + ear-clip
        triangulation if the loop is planar within `tolerance`, (3)
        bmesh.ops.triangle_fill restricted to only this loop's edges as a
        fallback (used both for genuinely non-planar loops and when the
        planar attempt's triangulation or validation fails). Any faces a
        failed attempt created are removed before moving on or returning,
        so a failure never leaves a partial cap behind.

        Final repair pass 3 (identity): this method and everything it
        calls now compare BMesh elements by Python object identity (or a
        stable positional map built within one call), never by `.index`.
        The previous pass fixed only `_validate_new_cap` and
        `_new_cap_faces_self_intersect`; the loop ordering in
        `_ordered_boundary_loop` and this method's own
        outside-vertex guard were still index-keyed, so the defect was
        only PARTLY addressed then and is completed here. See
        `_ordered_boundary_loop` for the measured symptoms.
        """
        def failure(reason):
            return {"filled": False, "method": "none", "faces": [], "reason": reason}

        edges = [e for e in list(edges) if e is not None]
        if not edges:
            return failure("empty edge list")
        for edge in edges:
            if not edge.is_valid:
                return failure("edge reference is invalid")
            if not edge.is_boundary:
                # Final repair pass 3: identified by ENDPOINT COORDINATES,
                # not `.index`. This string is pure diagnostics, but on the
                # dirty index table this method is normally called with it
                # read "edge -1 is not a boundary edge" for every edge,
                # naming nothing. Coordinates are stable and portable, and
                # are the same identity the rest of the file uses across
                # BMesh boundaries (`_edge_signature`).
                return failure(
                    "edge {} -> {} is not a boundary edge".format(
                        tuple(round(c, 6) for c in edge.verts[0].co),
                        tuple(round(c, 6) for c in edge.verts[1].co),
                    )
                )

        ordered_verts, reason = TOOL3D_OT_split_mark_sharp._ordered_boundary_loop(edges)
        if ordered_verts is None:
            return failure("loop validation failed: {}".format(reason))

        # Duplicate-cap guard: if a face already spans exactly this loop's
        # vertex set (bm.faces.get() matches regardless of vertex order,
        # rotation, or winding direction -- confirmed empirically), adding
        # a new cap here would create a second, coincident/overlapping
        # surface directly on top of it (e.g. a cut placed exactly along
        # an already-closed single face's own boundary, isolating that
        # face as its own tiny piece). Refuse with a controlled failure
        # instead of silently doubling the geometry -- this loop is
        # already effectively closed by the pre-existing face, so leaving
        # it "unfilled" here is the correct, non-destructive outcome.
        if bm.faces.get(ordered_verts) is not None:
            return failure(
                "a face already spans this loop's vertices; refusing to "
                "add a duplicate/overlapping cap"
            )

        # I5: one distance tolerance in, three dimensionally-correct
        # epsilons out. `length_eps` measures real distances (planarity,
        # 2D coordinate separation); `area_eps` measures areas and 2D
        # cross products; orientation checks use the scale-free
        # `_SHARP_ANGLE_EPS` inside `_validate_new_cap`.
        length_eps = tolerance if tolerance and tolerance > 0 else 1.0e-8
        area_eps = length_eps * length_eps
        epsilon = length_eps  # kept for the distance-based uses below

        # Snapshot BEFORE any attempt: shared by every rollback below so a
        # failed attempt (planar OR fallback) removes not just its trial
        # faces but any interior diagonal edge it created along with them
        # (bm.faces.remove() alone never removes a now-unused edge -- see
        # _remove_faces_created). Taken once here, not per-attempt: after
        # a correct planar-attempt rollback, bm.edges is back to exactly
        # this snapshot, so reusing it for the fallback's rollback too is
        # still exact.
        existing_edges_before = set(bm.edges)

        centroid, normal, max_distance, axis_u, axis_v = (
            TOOL3D_OT_split_mark_sharp._fit_loop_plane(ordered_verts))
        expected_normal = TOOL3D_OT_split_mark_sharp._expected_cap_normal(
            ordered_verts, normal)

        # I8: above the vertex budget, skip the pure-Python planar path
        # entirely (its self-intersection scan is O(n^2) and its ear
        # clipping O(n^2)-O(n^3)) and go straight to the C-side
        # `bmesh.ops.triangle_fill` below, which handles a large ring in
        # native code. Small loops -- where the planar ear-clip's better
        # quad/triangle quality actually matters -- are untouched.
        loop_is_small = len(ordered_verts) <= _SHARP_LARGE_LOOP_VERT_BUDGET

        # Crossing-cut support: a NON-planar loop may really be two planar
        # cut faces folded along the line where two Seam rings crossed
        # (see `_split_folded_loop`). Cap those as two flat polygons
        # sharing a new seam edge, before any single-surface attempt.
        if loop_is_small and max_distance > length_eps:
            polygons, fold_geometry, _fold_reason = (
                TOOL3D_OT_split_mark_sharp._split_folded_loop(
                    bm, ordered_verts, length_eps))
            if polygons is not None:
                created = []
                fold_failure = None
                for polygon in polygons:
                    faces, reason = TOOL3D_OT_split_mark_sharp._cap_polygon(
                        bm, polygon, length_eps, area_eps, epsilon, existing_edges_before)
                    if faces is None:
                        fold_failure = reason
                        break
                    created.extend(faces)
                if fold_failure is None:
                    fold_layer = bm.edges.layers.int.get(_SEAM_FOLD_EDGE)
                    if fold_layer is not None:
                        for seam in fold_geometry["seams"]:
                            seam[fold_layer] = 1
                    return {"filled": True, "method": "folded", "faces": created, "reason": None}
                # A polygon failed: roll back every face of the earlier
                # polygons (their diagonals and the seams become wire and
                # are swept with them -- all created after the snapshot),
                # then the apex, then fall through to the single-surface
                # attempts below, which report a controlled failure if
                # they cannot cap either.
                TOOL3D_OT_split_mark_sharp._remove_faces_created(
                    bm, created, existing_edges_before)
                TOOL3D_OT_split_mark_sharp._discard_fold_geometry(bm, fold_geometry)

        if loop_is_small and max_distance <= length_eps:
            points_2d = TOOL3D_OT_split_mark_sharp._project_loop(
                ordered_verts, centroid, axis_u, axis_v)
            faces, tri_reason = TOOL3D_OT_split_mark_sharp._triangulate_projected_loop(
                bm, ordered_verts, points_2d, length_eps, area_eps)

            if faces is not None:
                ok, valid_reason = TOOL3D_OT_split_mark_sharp._validate_new_cap(
                    faces, expected_normal, epsilon)
                if ok:
                    return {"filled": True, "method": "planar", "faces": faces, "reason": None}
                TOOL3D_OT_split_mark_sharp._remove_faces_created(
                    bm, faces, existing_edges_before)
            # else: planar triangulation itself failed (self-crossing loop,
            # no valid ear, ...) -- fall through to the fallback below.
            # _triangulate_projected_loop already rolled back its own
            # partial faces/edges internally in that case.

        try:
            result = bmesh.ops.triangle_fill(
                bm,
                edges=list(edges),
                use_beauty=True,
                use_dissolve=False,
            )
        except (ValueError, RuntimeError) as exc:
            return failure("triangle_fill raised: {}".format(exc))

        # NOTE: the brief's own snippet reads `result.get("faces", [])`,
        # but this build of bmesh.ops.triangle_fill (Blender 5.2.1) does
        # not return a "faces" key at all -- it returns a single mixed
        # "geom" list containing both the new BMFaces and any new BMEdges
        # (e.g. a fill diagonal). Confirmed directly: `result.get("faces",
        # [])` is always `[]` here, which would make this entire fallback
        # silently non-functional (every non-planar loop would report
        # "triangle_fill produced no faces"). Filtering "geom" for BMFace
        # is the actual working equivalent for this Blender version, kept
        # tolerant of a future/older API that DOES use "faces" via the
        # `or result.get("faces", [])` fallback below.
        new_faces = [
            elem for elem in result.get("geom", [])
            if isinstance(elem, bmesh.types.BMFace) and elem.is_valid
        ] or [face for face in result.get("faces", []) if face.is_valid]
        if not new_faces:
            return failure("triangle_fill produced no faces")

        # IDENTITY, never `.index` (final repair pass 3). This guard is the
        # sole reason `_new_cap_faces_self_intersect` may derive the loop's
        # vertex count from the produced faces, so it must not be
        # defeatable by a dirty index table.
        #
        # HONEST SCOPE. Unlike `_ordered_boundary_loop`'s index defect,
        # this one was NOT reproducible as a live symptom on this build: it
        # was measured that `bmesh.ops.triangle_fill` REBUILDS the vertex
        # index table as a side effect (indices read all -1 going in and
        # 0..n coming out), so by the time this line runs the table happens
        # to be clean and the old `.index` form gave the right answer.
        # Reverting this line to `.index` therefore does not fail any test
        # -- a surviving mutant, disclosed rather than hidden.
        #
        # It is still changed, because the correctness of the old form
        # rested entirely on an undocumented side effect of a bmesh
        # operator: nothing in the API promises that `triangle_fill`
        # refreshes indices, the `or result.get("faces", [])` branch just
        # above exists precisely because this code already accommodates
        # other bmesh builds, and on any build that does not refresh them
        # the guard silently becomes a no-op (every vertex reading -1 makes
        # the membership test vacuously true). Identity has no such
        # dependency.
        loop_verts = set(ordered_verts)
        if any(v not in loop_verts for face in new_faces for v in face.verts):
            TOOL3D_OT_split_mark_sharp._remove_faces_created(
                bm, new_faces, existing_edges_before)
            return failure("triangle_fill touched vertices outside this loop")

        ok, valid_reason = TOOL3D_OT_split_mark_sharp._validate_new_cap(
            new_faces, expected_normal, epsilon)
        if ok:
            return {"filled": True, "method": "triangle_fill", "faces": new_faces, "reason": None}
        TOOL3D_OT_split_mark_sharp._remove_faces_created(
            bm, new_faces, existing_edges_before)
        triangle_fill_reason = "triangle_fill result failed validation: {}".format(
            valid_reason)

        # Strongly non-planar (saddle) loop where the triangle fan came out
        # partly inside-out or self-overlapping -- see `_ngon_cap_loop`.
        ngon_faces, ngon_reason = TOOL3D_OT_split_mark_sharp._ngon_cap_loop(
            bm, edges, ordered_verts, expected_normal, epsilon,
            existing_edges_before)
        if ngon_faces is not None:
            return {"filled": True, "method": "ngon_fill", "faces": ngon_faces, "reason": None}
        return failure("{}; ngon fill: {}".format(triangle_fill_reason, ngon_reason))

    @staticmethod
    def _mesh_diagonal(obj):
        """Return positive local-space mesh diagonal, fallback 1.0."""
        verts = obj.data.vertices
        if not verts:
            return 1.0
        xs = [v.co.x for v in verts]
        ys = [v.co.y for v in verts]
        zs = [v.co.z for v in verts]
        from mathutils import Vector
        bbox_min = Vector((min(xs), min(ys), min(zs)))
        bbox_max = Vector((max(xs), max(ys), max(zs)))
        diagonal = (bbox_max - bbox_min).length
        return diagonal if diagonal > 0.0 else 1.0

    @staticmethod
    def _validate_closed_loop(component):
        """Validate a connected sharp-edge component as a closed cut network.

        Returns (is_valid, ordered_edges, ordered_verts). Rejects: fewer than
        3 edges, zero-length edges, duplicate/degenerate vertices, any vertex
        of degree 1 inside the component (an open chain's endpoint), and any
        edge that does not have exactly 2 linked faces (mesh boundary or
        non-manifold edge).

        Cut NETWORK support: any vertex of degree >= 2 is accepted here.
        Degree 4 is where two closed Seam rings cross (a horizontal ring
        and a vertical ring on one cube); degree 3 is a three-way junction
        of a cell network (the user's meteor: Voronoi-like patches whose
        Seam borders meet three at a vertex, like a football). Both are
        complete, self-consistent sets of cuts as long as every Seam edge
        actually lies between two different face regions -- and THAT is
        what `_find_valid_sharp_loops_with_stats` checks next, per edge,
        via `_face_region_map`. The earlier "even degree only" rule used
        parity as a proxy for "no cut dies inside a face"; the proxy was
        wrong for degree-3 junctions (0 valid loops on a fully closed
        network), so the real test replaced it. A T-junction whose spoke
        dies inside a face is still rejected: the spoke's far end has
        degree 1, and even a spoke ending on another Seam vertex is caught
        by the per-edge separation test (both its faces fall in one
        region). `bmesh.ops.split_edges` handles a degree-3 vertex the
        same way as a degree-4 one (every incident piece gets its own copy
        of the vertex, and each piece's boundary is a plain degree-2 loop).
        """
        if len(component) < 3:
            return False, None, None

        degree = {}
        for edge in component:
            v0, v1 = edge.verts[0], edge.verts[1]
            if v0.index == v1.index:
                return False, None, None
            if (v0.co - v1.co).length_squared <= 1.0e-18:
                return False, None, None
            degree[v0.index] = degree.get(v0.index, 0) + 1
            degree[v1.index] = degree.get(v1.index, 0) + 1

        # Degree 1 is an open chain's endpoint: that cut dies inside a
        # face. Every other degree (2 ring, 3 cell junction, 4 crossing) is
        # a legal network vertex; whether each edge really separates two
        # regions is decided by the caller's per-edge region test.
        if any(count < 2 for count in degree.values()):
            return False, None, None

        for edge in component:
            if len(edge.link_faces) != 2:
                return False, None, None

        verts_by_index = {}
        for edge in component:
            for v in edge.verts:
                verts_by_index[v.index] = v

        ordered_edges = sorted(component, key=lambda e: e.index)
        ordered_verts = sorted(verts_by_index.values(), key=lambda v: v.index)
        return True, ordered_edges, ordered_verts

    @staticmethod
    def _find_valid_sharp_loops(obj):
        """Return list of loop dicts; invalid Seam components omitted.

        Unchanged contract (Task 2-6, every existing caller and test): a
        plain list. Use `_find_valid_sharp_loops_with_stats` when the
        ignored-component count is also wanted (M2).
        """
        loops, _ignored = (
            TOOL3D_OT_split_mark_sharp._find_valid_sharp_loops_with_stats(obj))
        return loops

    @staticmethod
    def _find_valid_sharp_loops_with_stats(obj):
        """Return `(loops, ignored_component_count)`.

        Final fix pass (M2): `_find_valid_sharp_loops` deliberately keeps
        its plain-list return for every existing caller, so the count of
        Seam components that were found but REJECTED (open chain,
        branching, lone edge, degenerate, or a closed ring that does not
        actually separate the mesh into two face regions) is exposed here
        instead of through a mutable class attribute -- deterministic, and
        safe to call concurrently/reentrantly. `execute()` reports this as
        `ignored_components`, so a user who marked something Seam that
        cannot be cut is told so, rather than seeing only "1 skipped".
        """
        mesh = obj.data
        bm = bmesh.new()
        try:
            bm.from_mesh(mesh)
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()

            diagonal = TOOL3D_OT_split_mark_sharp._mesh_diagonal(obj)
            tolerance = max(diagonal * 1.0e-6, 1.0e-8)

            sharp_edges = [
                edge for edge in bm.edges
                if edge.index < len(mesh.edges)
                and mesh.edges[edge.index].use_seam
            ]
            if not sharp_edges:
                return [], 0

            vert_to_sharp_edges = {}
            for edge in sharp_edges:
                for v in edge.verts:
                    vert_to_sharp_edges.setdefault(v.index, []).append(edge)

            visited = set()
            components = []
            for edge in sharp_edges:
                if edge.index in visited:
                    continue
                component = []
                queue = deque([edge])
                visited.add(edge.index)
                while queue:
                    current = queue.popleft()
                    component.append(current)
                    for v in current.verts:
                        for other in vert_to_sharp_edges.get(v.index, ()):
                            if other.index not in visited:
                                visited.add(other.index)
                                queue.append(other)
                components.append(component)

            candidates = []
            ignored_components = 0
            for component in components:
                is_valid, ordered_edges, ordered_verts = (
                    TOOL3D_OT_split_mark_sharp._validate_closed_loop(component)
                )
                if not is_valid:
                    ignored_components += 1
                    continue
                min_edge_index = ordered_edges[0].index
                candidates.append((min_edge_index, ordered_edges, ordered_verts))

            # Separation is judged on ALL closed components TOGETHER (user
            # report 2026-10-01, ring/torus): one cross-section ring of a
            # torus does not split it, but four rings together cut it into
            # four arcs -- per-component testing rejected every one of
            # them. Every Seam edge must lie BETWEEN two different face
            # regions of the combined barrier; an edge whose two faces share
            # a region is a spoke that dies inside a face (or a chord that
            # closes on itself), so its whole component is rejected. Dropping
            # a component merges regions, so repeat until stable. A loop
            # that separates on its own still separates here (more barriers
            # only refine regions), so previously accepted cuts are kept.
            while candidates:
                region_of_face = TOOL3D_OT_split_mark_sharp._face_region_map(
                    bm, [e for _i, edges, _v in candidates for e in edges])
                kept = [
                    item for item in candidates
                    if all(
                        len({region_of_face[f.index] for f in e.link_faces}) >= 2
                        for e in item[1]
                    )
                ]
                if len(kept) == len(candidates):
                    break
                ignored_components += len(candidates) - len(kept)
                candidates = kept

            candidates.sort(key=lambda item: item[0])

            loops = []
            for cut_id, (_min_index, ordered_edges, ordered_verts) in enumerate(
                    candidates, start=1):
                edge_indices = [e.index for e in ordered_edges]
                vertex_indices = [v.index for v in ordered_verts]
                edge_signatures = [
                    TOOL3D_OT_split_mark_sharp._edge_signature(
                        e.verts[0].co, e.verts[1].co, tolerance)
                    for e in ordered_edges
                ]
                loops.append({
                    "cut_id": cut_id,
                    "edge_indices": edge_indices,
                    "vertex_indices": vertex_indices,
                    "edge_signatures": edge_signatures,
                })

            return loops, ignored_components
        finally:
            bm.free()

    @staticmethod
    def _edge_signature(v0, v1, tolerance):
        """Return sorted quantized endpoint tuple.

        Endpoint-order independent and stable under tiny floating point
        drift: coordinates are snapped to a grid sized by `tolerance` before
        the two endpoints are sorted, so an edge's signature is the same
        regardless of vertex winding or which side it is walked from. Used
        as an identity fallback once edge/vertex indices are invalidated by
        topology operations (edge_split, separate, ...).
        """
        if tolerance <= 0:
            tolerance = 1.0e-8

        def quantize(co):
            return (
                round(co[0] / tolerance),
                round(co[1] / tolerance),
                round(co[2] / tolerance),
            )

        q0 = quantize(v0)
        q1 = quantize(v1)
        return tuple(sorted((q0, q1)))

    @staticmethod
    def _point_signature(co, tolerance):
        """Return a single quantized point signature (same grid as
        _edge_signature) for provenance vertex-fallback matching."""
        if tolerance <= 0:
            tolerance = 1.0e-8
        return (
            round(co[0] / tolerance),
            round(co[1] / tolerance),
            round(co[2] / tolerance),
        )

    @staticmethod
    def _face_region_count(bm, cut_edges):
        """Return number of face regions when cut_edges are barriers."""
        region_of_face = TOOL3D_OT_split_mark_sharp._face_region_map(
            bm, cut_edges)
        return len(set(region_of_face.values()))

    @staticmethod
    def _face_region_map(bm, cut_edges):
        """Return `{face.index: region_id}` when cut_edges are barriers.

        Region ids are 1-based in face-index order of each region's first
        face (deterministic). `_face_region_count` is its `len(set(...))`;
        the map itself lets `_find_valid_sharp_loops_with_stats` check per
        Seam edge that both linked faces fall in DIFFERENT regions, which
        is the real "closed cut" criterion for a network with degree-3
        junctions.
        """
        barrier_indices = set()
        for edge in cut_edges:
            barrier_indices.add(edge.index if hasattr(edge, "index") else int(edge))

        region_of_face = {}
        region_count = 0
        for face in bm.faces:
            if face.index in region_of_face:
                continue
            region_count += 1
            queue = deque([face])
            region_of_face[face.index] = region_count
            while queue:
                current = queue.popleft()
                for edge in current.edges:
                    if edge.index in barrier_indices:
                        continue
                    for linked_face in edge.link_faces:
                        if linked_face.index not in region_of_face:
                            region_of_face[linked_face.index] = region_count
                            queue.append(linked_face)
        return region_of_face

    @staticmethod
    def _create_cut_layers(bm):
        """Return (edge_layer, vert_layer), clearing both layers."""
        edge_layer = bm.edges.layers.int.get(_SHARP_CUT_EDGE_LAYER)
        if edge_layer is None:
            edge_layer = bm.edges.layers.int.new(_SHARP_CUT_EDGE_LAYER)

        vert_layer = bm.verts.layers.int.get(_SHARP_CUT_VERT_LAYER)
        if vert_layer is None:
            vert_layer = bm.verts.layers.int.new(_SHARP_CUT_VERT_LAYER)

        for edge in bm.edges:
            edge[edge_layer] = 0
        for vert in bm.verts:
            vert[vert_layer] = 0

        return edge_layer, vert_layer

    @staticmethod
    def _mark_cut_provenance(bm, loops, edge_layer, vert_layer):
        """Set loop cut_id on all loop edges and vertices."""
        bm.edges.ensure_lookup_table()
        bm.verts.ensure_lookup_table()
        for loop in loops:
            cut_id = loop["cut_id"]
            for edge_index in loop["edge_indices"]:
                if edge_index < len(bm.edges):
                    bm.edges[edge_index][edge_layer] = cut_id
            for vertex_index in loop["vertex_indices"]:
                if vertex_index < len(bm.verts):
                    bm.verts[vertex_index][vert_layer] = cut_id

    @staticmethod
    def _connected_vert_groups(bm):
        """Return connected components as lists of POSITIONAL ordinals.

        Ordinals (a vertex's position in `list(bm.verts)`), never
        `BMVert.index`: after `bmesh.ops.split_edges` the index table is
        dirty, and `bm.copy()` is only guaranteed to preserve element
        ORDER (verified directly against this Blender build). Positional
        identity therefore transfers exactly from a BMesh to its copy,
        while `.index` may not.
        """
        verts = list(bm.verts)
        ordinal_of = {vert: i for i, vert in enumerate(verts)}

        seen = set()
        groups = []
        for start_ordinal, start_vert in enumerate(verts):
            if start_ordinal in seen:
                continue
            seen.add(start_ordinal)
            stack = [start_vert]
            group = [start_ordinal]
            while stack:
                current = stack.pop()
                for edge in current.link_edges:
                    other = edge.other_vert(current)
                    other_ordinal = ordinal_of.get(other)
                    if other_ordinal is not None and other_ordinal not in seen:
                        seen.add(other_ordinal)
                        group.append(other_ordinal)
                        stack.append(other)
            groups.append(sorted(group))
        return groups

    @staticmethod
    def _write_vert_group_to_mesh(bm, keep_ordinals, target_mesh, strip_markers=False):
        """Write only the vertices in `keep_ordinals` (plus everything they
        span) from `bm` into `target_mesh`.

        Works on a `bm.copy()` so the caller's BMesh is never consumed and
        can be reused for the next group. `strip_markers=True` removes the
        temporary cut_id layers before writing -- used for the untouched
        leftover shells (I3), which must come out byte-for-byte as they went
        in, carrying no provenance junk.
        """
        work = bm.copy()
        try:
            work.verts.ensure_lookup_table()
            doomed = [
                vert for ordinal, vert in enumerate(work.verts)
                if ordinal not in keep_ordinals
            ]
            if doomed:
                bmesh.ops.delete(work, geom=doomed, context='VERTS')

            if strip_markers:
                edge_layer = work.edges.layers.int.get(_SHARP_CUT_EDGE_LAYER)
                if edge_layer is not None:
                    work.edges.layers.int.remove(edge_layer)
                vert_layer = work.verts.layers.int.get(_SHARP_CUT_VERT_LAYER)
                if vert_layer is not None:
                    work.verts.layers.int.remove(vert_layer)
                face_role = work.faces.layers.int.get(_SEAM_FACE_ROLE)
                if face_role is not None:
                    work.faces.layers.int.remove(face_role)
                vert_side = work.verts.layers.int.get(_SEAM_VERT_SIDE)
                if vert_side is not None:
                    work.verts.layers.int.remove(vert_side)
                fold_layer = work.edges.layers.int.get(_SEAM_FOLD_EDGE)
                if fold_layer is not None:
                    work.edges.layers.int.remove(fold_layer)

            work.to_mesh(target_mesh)
        finally:
            work.free()
        target_mesh.update()

    # ===== AUTOMATIC LINKED MESH INSTANCING =====
    #
    # Congruent cut pieces (cube halves, hollow quarters, sphere octants)
    # are the same mesh seen from a different angle. Rebinding them onto
    # ONE datablock and pushing the difference into each object's own
    # transform keeps the world result pixel-identical while making an
    # edit to one piece reach every instance.
    #
    # Every comparison below is order independent and rigid-only: a rigid
    # candidate is built from three anchor correspondences (which always
    # yields det +1, so a mirrored piece can never be accepted), then it
    # must survive a KDTree vertex bijection, a full edge-set match and an
    # oriented face-cycle match carrying role/UV/material/smooth/flags.
    _INSTANCE_MAX_RIGID_CANDIDATES = 256
    # Relative to the piece's centroid radius. bmesh.ops.bevel places its
    # profile vertices with ~5e-5 float noise on a unit piece, so congruent
    # beveled pieces need a looser bound than the 1e-5 raw geometry gives;
    # a real shape difference is orders of magnitude bigger.
    _INSTANCE_RELATIVE_TOL = 2.0e-4
    _INSTANCE_UV_TOL = 1.0e-6

    @staticmethod
    def _instance_is_shareable(obj):
        """True when `obj` carries nothing a shared datablock would break."""
        if obj is None or getattr(obj, "type", None) != 'MESH':
            return False
        if obj.name not in bpy.data.objects:
            return False
        mesh = getattr(obj, "data", None)
        if mesh is None or not mesh.vertices or not mesh.polygons:
            return False
        if mesh.shape_keys is not None:
            return False
        if any(vert.groups for vert in mesh.vertices):
            return False
        if obj.constraints:
            return False
        if obj.animation_data is not None or mesh.animation_data is not None:
            return False
        # The only modifier allowed is the tool's own Weighted Normal, in
        # exactly the configuration `_shade_cut_piece` writes, identified
        # by the name the tool recorded on the object.
        owned = obj.get(_WEIGHTED_NORMAL_OWNER, "")
        for modifier in obj.modifiers:
            if modifier.name != owned or modifier.type != 'WEIGHTED_NORMAL':
                return False
            if modifier.mode != 'FACE_AREA' or not modifier.keep_sharp:
                return False
            if modifier.weight != 50:
                return False
        return True

    @staticmethod
    def _instance_int_attribute(mesh, name, domain):
        attributes = getattr(mesh, "attributes", None)
        if attributes is None:
            return None
        try:
            attribute = attributes.get(name)
        except (AttributeError, TypeError, KeyError):
            return None
        if attribute is None or attribute.domain != domain:
            return None
        return [item.value for item in attribute.data]

    @staticmethod
    def _instance_face_uv_constant(face, uv_layers, tolerance):
        """One UV pair per layer when this face's corners all agree there,
        otherwise None. Merging two faces is only lossless when both are
        UV-constant, which is exactly what the cut pieces' role-driven UVs
        (outer 1,0 / inner .5,.5 / cap 0,0) are."""
        constants = []
        for layer in uv_layers:
            first = None
            for loop in face.loops:
                uv = loop[layer].uv
                if first is None:
                    first = (uv[0], uv[1])
                elif (abs(uv[0] - first[0]) > tolerance
                        or abs(uv[1] - first[1]) > tolerance):
                    return None
            constants.append(first)
        return tuple(constants)

    @staticmethod
    def _instance_merge_coplanar(bm):
        """Dissolve the seams BETWEEN coplanar faces that agree on
        everything a merge would have to discard, so two pieces cut the
        same shape but triangulated differently still compare equal.

        Runs on a private BMesh snapshot only -- an actual mesh is never
        edited. Material, smooth flag, role, per-layer UV and the edge's
        own seam/sharp flags are all protective: a distinct role or a
        marked edge keeps its face boundary.
        """
        role = bm.faces.layers.int.get(_SEAM_FACE_ROLE)
        uv_layers = list(bm.loops.layers.uv.values())
        tolerance = TOOL3D_OT_split_mark_sharp._INSTANCE_UV_TOL
        constants = {}

        def constant_uv(face):
            if face not in constants:
                constants[face] = (
                    TOOL3D_OT_split_mark_sharp._instance_face_uv_constant(
                        face, uv_layers, tolerance))
            return constants[face]

        doomed = []
        for edge in bm.edges:
            if len(edge.link_faces) != 2 or edge.seam or not edge.smooth:
                continue
            first, second = edge.link_faces
            if first.material_index != second.material_index:
                continue
            if first.smooth != second.smooth:
                continue
            if role is not None and first[role] != second[role]:
                continue
            if first.normal.dot(second.normal) < 1.0 - _SHARP_ANGLE_EPS:
                continue
            left, right = constant_uv(first), constant_uv(second)
            if left is None or right is None:
                continue
            if any(abs(a[0] - b[0]) > tolerance or abs(a[1] - b[1]) > tolerance
                   for a, b in zip(left, right)):
                continue
            doomed.append(edge)
        if doomed:
            bmesh.ops.dissolve_edges(bm, edges=doomed, use_verts=False)
            bm.normal_update()

    @staticmethod
    def _instance_read_bmesh(bm):
        from mathutils import Vector
        bm.verts.ensure_lookup_table()
        bm.verts.index_update()
        verts = [vert.co.copy() for vert in bm.verts]
        count = len(verts)
        centroid = Vector((0.0, 0.0, 0.0))
        for co in verts:
            centroid += co
        centroid /= count
        # Rotation-invariant size: a bounding-box diagonal is NOT, so a
        # piece whose local frame is turned would fail a size compare even
        # when it is exactly congruent.
        radius = max((co - centroid).length for co in verts) or 1.0

        edges = {}
        neighbors = [set() for _ in range(count)]
        for edge in bm.edges:
            a, b = (vert.index for vert in edge.verts)
            edges[(a, b) if a < b else (b, a)] = (
                bool(edge.seam), not bool(edge.smooth))
            neighbors[a].add(b)
            neighbors[b].add(a)

        role = bm.faces.layers.int.get(_SEAM_FACE_ROLE)
        side = bm.verts.layers.int.get(_SEAM_VERT_SIDE)
        uv_layers = list(bm.loops.layers.uv.values())
        faces, face_data, face_uvs = [], [], []
        for face in bm.faces:
            faces.append(tuple(loop.vert.index for loop in face.loops))
            face_data.append((
                face.material_index,
                bool(face.smooth),
                face[role] if role is not None else 0,
            ))
            face_uvs.append(tuple(
                tuple((loop[layer].uv[0], loop[layer].uv[1])
                      for loop in face.loops)
                for layer in uv_layers
            ))

        return {
            "verts": verts,
            "centroid": centroid,
            "radius": radius,
            "edges": edges,
            "neighbors": neighbors,
            "faces": faces,
            "face_data": face_data,
            "face_uvs": face_uvs,
            "sides": (None if side is None
                      else [vert[side] for vert in bm.verts]),
            "uv_layers": list(bm.loops.layers.uv.keys()),
        }

    @staticmethod
    def _instance_snapshot(obj, normalize=True):
        """Read-only picture of one piece, normalized so an incidental
        difference in coplanar triangulation does not hide a congruence.
        `normalize=False` reads the mesh exactly as it stands -- the
        stricter reading `_instance_cut_pieces` falls back to.
        Built in a private BMesh; the real mesh is never touched."""
        mesh = obj.data
        snapshot = None
        for merge in ((True, False) if normalize else (False,)):
            bm = bmesh.new()
            try:
                bm.from_mesh(mesh)
                if merge:
                    TOOL3D_OT_split_mark_sharp._instance_merge_coplanar(bm)
                snapshot = TOOL3D_OT_split_mark_sharp._instance_read_bmesh(bm)
                break
            except TOOL3D_OT_split_mark_sharp._RECOVERABLE_ERRORS:
                snapshot = None
            finally:
                bm.free()
        if snapshot is None:
            raise RuntimeError("could not read piece {}".format(obj.name))
        snapshot["object"] = obj
        snapshot["mesh"] = mesh
        snapshot["materials"] = [getattr(m, "name", "") for m in mesh.materials]
        snapshot["auto_sharp"] = bool(obj.get(_WEIGHTED_NORMAL_OWNER, "")) and any(
            m.name == obj.get(_WEIGHTED_NORMAL_OWNER) and m.type == 'WEIGHTED_NORMAL'
            for m in obj.modifiers)
        return snapshot

    @staticmethod
    def _instance_descriptors(snapshot):
        """Per-vertex rigid invariants: degree, the face sizes and roles
        meeting there, its sorted incident edge lengths and its distance
        to the mesh centroid. Nothing here depends on element order."""
        cached = snapshot.get("descriptors")
        if cached is not None:
            return cached
        verts = snapshot["verts"]
        centroid = snapshot["centroid"]
        sizes = [[] for _ in verts]
        roles = [[] for _ in verts]
        for face, data in zip(snapshot["faces"], snapshot["face_data"]):
            for index in face:
                sizes[index].append(len(face))
                roles[index].append(data[2])
        descriptors = []
        for index, co in enumerate(verts):
            lengths = sorted((verts[other] - co).length
                             for other in snapshot["neighbors"][index])
            descriptors.append((
                len(lengths),
                tuple(sorted(sizes[index])),
                tuple(sorted(roles[index])),
                tuple(lengths),
                (co - centroid).length,
            ))
        snapshot["descriptors"] = descriptors
        return descriptors

    @staticmethod
    def _instance_descriptor_match(left, right, tolerance):
        if left[0] != right[0] or left[1] != right[1] or left[2] != right[2]:
            return False
        if abs(left[4] - right[4]) > tolerance:
            return False
        return all(abs(a - b) <= tolerance for a, b in zip(left[3], right[3]))

    @staticmethod
    def _instance_frame(origin, first, second):
        """Orthonormal frame of three points, or None if degenerate. Built
        with e3 = e1 x e2, so its determinant is always +1 -- a reflected
        piece therefore never produces a matching transform."""
        from mathutils import Matrix
        e1 = first - origin
        if e1.length <= 0.0:
            return None
        e1 = e1.normalized()
        towards = second - origin
        e2 = towards - e1 * towards.dot(e1)
        if e2.length <= 0.0:
            return None
        e2 = e2.normalized()
        return Matrix((e1, e2, e1.cross(e2))).transposed()

    @staticmethod
    def _instance_anchors(snapshot, tolerance):
        """Three well-spread canonical vertices, rarest descriptor first,
        so the candidate search starts from the fewest possibilities."""
        descriptors = TOOL3D_OT_split_mark_sharp._instance_descriptors(snapshot)
        buckets = {}
        for index, descriptor in enumerate(descriptors):
            key = (
                descriptor[0], descriptor[1], descriptor[2],
                tuple(int(round(length / tolerance)) for length in descriptor[3]),
                int(round(descriptor[4] / tolerance)),
            )
            buckets.setdefault(key, []).append(index)
        rarity = {}
        for members in buckets.values():
            for index in members:
                rarity[index] = len(members)

        verts = snapshot["verts"]
        order = sorted(range(len(verts)),
                       key=lambda i: (rarity[i], -descriptors[i][4], i))
        separation = max(tolerance * 10.0, snapshot["radius"] * 1.0e-3)
        first = order[0]
        second = next((i for i in order
                       if i != first
                       and (verts[i] - verts[first]).length >= separation), None)
        if second is None:
            return None
        axis = (verts[second] - verts[first]).normalized()
        third = None
        for index in order:
            if index in (first, second):
                continue
            offset = verts[index] - verts[first]
            if (offset - axis * offset.dot(axis)).length >= separation:
                third = index
                break
        if third is None:
            return None
        return first, second, third

    @staticmethod
    def _instance_verify(canonical, candidate, transform, tolerance, mapping=None):
        """Full structural check of one rigid candidate. Returns the
        vertex mapping when the two pieces are the same mesh under
        `transform`, otherwise None."""
        from mathutils.kdtree import KDTree
        target = candidate["verts"]
        tree = candidate.get("tree")
        if tree is None:
            tree = KDTree(len(target))
            for index, co in enumerate(target):
                tree.insert(co, index)
            tree.balance()
            candidate["tree"] = tree

        if mapping is None:
            mapping = []
            for co in canonical["verts"]:
                _, index, distance = tree.find(transform @ co)
                if index is None or distance > tolerance:
                    return None
                mapping.append(index)
        elif (len(mapping) != len(canonical["verts"])
              or any(index < 0 or index >= len(target) for index in mapping)
              or any((transform @ co - target[index]).length > tolerance
                     for co, index in zip(canonical["verts"], mapping))):
            return None
        if len(set(mapping)) != len(mapping):
            return None

        sides = canonical["sides"], candidate["sides"]
        if (sides[0] is None) != (sides[1] is None):
            return None
        if sides[0] is not None:
            for source, mapped in enumerate(mapping):
                if sides[0][source] != sides[1][mapped]:
                    return None

        mapped_edges = {}
        for (a, b), flags in canonical["edges"].items():
            key = (mapping[a], mapping[b])
            mapped_edges[key if key[0] < key[1] else (key[1], key[0])] = flags
        if mapped_edges != candidate["edges"]:
            return None

        by_verts = {}
        for index, face in enumerate(candidate["faces"]):
            by_verts.setdefault(tuple(sorted(face)), []).append(index)
        uv_tolerance = TOOL3D_OT_split_mark_sharp._INSTANCE_UV_TOL
        used = set()
        for source, face in enumerate(canonical["faces"]):
            mapped = [mapping[index] for index in face]
            matched = False
            for other in by_verts.get(tuple(sorted(mapped)), ()):
                if other in used:
                    continue
                shift = TOOL3D_OT_split_mark_sharp._instance_cycle_shift(
                    mapped, candidate["faces"][other])
                if shift is None:
                    continue
                if canonical["face_data"][source] != candidate["face_data"][other]:
                    continue
                if not TOOL3D_OT_split_mark_sharp._instance_uv_match(
                        canonical["face_uvs"][source], candidate["face_uvs"][other],
                        shift, uv_tolerance):
                    continue
                used.add(other)
                matched = True
                break
            if not matched:
                return None
        if len(used) != len(candidate["faces"]):
            return None
        return mapping

    @staticmethod
    def _instance_cycle_shift(mapped, actual):
        """Rotation offset that makes `actual` equal `mapped`, or None.
        Only rotations count: a reversed cycle is the opposite winding."""
        size = len(actual)
        if len(mapped) != size:
            return None
        for shift in range(size):
            if all(actual[(shift + i) % size] == mapped[i] for i in range(size)):
                return shift
        return None

    @staticmethod
    def _instance_uv_match(source_uvs, target_uvs, shift, tolerance):
        if len(source_uvs) != len(target_uvs):
            return False
        for source_layer, target_layer in zip(source_uvs, target_uvs):
            size = len(source_layer)
            if size != len(target_layer):
                return False
            for corner in range(size):
                a = source_layer[corner]
                b = target_layer[(shift + corner) % size]
                if abs(a[0] - b[0]) > tolerance or abs(a[1] - b[1]) > tolerance:
                    return False
        return True

    @staticmethod
    def _instance_rigid_map(canonical, candidate):
        """Rigid transform taking canonical LOCAL space onto candidate
        LOCAL space, or None when the two pieces are not congruent."""
        from mathutils import Matrix
        if canonical["uv_layers"] != candidate["uv_layers"]:
            return None
        if canonical["materials"] != candidate["materials"]:
            return None
        for key in ("verts", "edges", "faces"):
            if len(canonical[key]) != len(candidate[key]):
                return None
        if sorted(canonical["face_data"]) != sorted(candidate["face_data"]):
            return None

        tolerance = max(canonical["radius"]
                        * TOOL3D_OT_split_mark_sharp._INSTANCE_RELATIVE_TOL, 1.0e-9)
        if abs(canonical["radius"] - candidate["radius"]) > tolerance:
            return None
        anchors = TOOL3D_OT_split_mark_sharp._instance_anchors(canonical, tolerance)
        if anchors is None:
            return None

        source = canonical["verts"]
        target = candidate["verts"]
        source_descriptors = TOOL3D_OT_split_mark_sharp._instance_descriptors(canonical)
        target_descriptors = TOOL3D_OT_split_mark_sharp._instance_descriptors(candidate)
        pools = []
        for anchor in anchors:
            pools.append([
                index for index in range(len(target))
                if TOOL3D_OT_split_mark_sharp._instance_descriptor_match(
                    source_descriptors[anchor], target_descriptors[index], tolerance)
            ])
            if not pools[-1]:
                return None
        spans = (
            (source[anchors[1]] - source[anchors[0]]).length,
            (source[anchors[2]] - source[anchors[0]]).length,
            (source[anchors[2]] - source[anchors[1]]).length,
        )
        source_frame = TOOL3D_OT_split_mark_sharp._instance_frame(
            source[anchors[0]], source[anchors[1]], source[anchors[2]])
        if source_frame is None:
            return None
        inverse_frame = source_frame.transposed()

        tried = 0
        budget = TOOL3D_OT_split_mark_sharp._INSTANCE_MAX_RIGID_CANDIDATES
        for first in pools[0]:
            for second in pools[1]:
                if abs((target[second] - target[first]).length - spans[0]) > tolerance:
                    continue
                for third in pools[2]:
                    if abs((target[third] - target[first]).length - spans[1]) > tolerance:
                        continue
                    if abs((target[third] - target[second]).length - spans[2]) > tolerance:
                        continue
                    if tried >= budget:
                        return None
                    tried += 1
                    target_frame = TOOL3D_OT_split_mark_sharp._instance_frame(
                        target[first], target[second], target[third])
                    if target_frame is None:
                        continue
                    rotation = target_frame @ inverse_frame
                    if rotation.determinant() <= 0.0:
                        continue
                    transform = (
                        Matrix.Translation(
                            target[first] - rotation @ source[anchors[0]])
                        @ rotation.to_4x4())
                    if TOOL3D_OT_split_mark_sharp._instance_verify(
                            canonical, candidate, transform, tolerance) is not None:
                        return transform
        return None

    @staticmethod
    def _instance_approximate_pair(canonical, candidate):
        """Only tool-shaded pieces may adopt the reference's automatic sharp flags."""
        if not (canonical.get("auto_sharp") and candidate.get("auto_sharp")):
            return canonical, candidate
        result = []
        for snapshot in (canonical, candidate):
            copy = dict(snapshot)
            copy["edges"] = {key: (flags[0], False) for key, flags in snapshot["edges"].items()}
            result.append(copy)
        return tuple(result)

    @staticmethod
    def _instance_approximate_map(canonical, candidate, tolerance_percent):
        """Topology-constrained fit; preserve UV/seams and non-tool sharp flags.

        Search is bounded and fails closed. Pair distances may differ by
        twice the vertex error, but the final maximum error is checked at
        the requested bound, not at that broader search bound.
        """
        import numpy as np
        from mathutils import Matrix
        op = TOOL3D_OT_split_mark_sharp
        canonical, candidate = op._instance_approximate_pair(canonical, candidate)
        if canonical["uv_layers"] != candidate["uv_layers"] or canonical["materials"] != candidate["materials"]:
            return None
        if any(len(canonical[k]) != len(candidate[k]) for k in ("verts", "edges", "faces")):
            return None
        if sorted(canonical["face_data"]) != sorted(candidate["face_data"]):
            return None
        count = len(canonical["verts"])
        if count < 3:
            return None
        if count > 800:
            print("[Tool3D] approximate instance skipped: {} vertices exceeds the 800-vertex search limit".format(count))
            return None
        tolerance = canonical["radius"] * max(0.0, min(tolerance_percent, 5.0)) / 100.0
        if tolerance <= 0.0 or abs(canonical["radius"] - candidate["radius"]) > 2 * tolerance:
            return None
        snapshots = (canonical, candidate)
        descriptors = [op._instance_descriptors(s) for s in snapshots]
        labels = []
        for s, desc in zip(snapshots, descriptors):
            labels.append([(d[0], d[1], d[2],
                            None if s["sides"] is None else s["sides"][i])
                           for i, d in enumerate(desc)])
        # Refine discrete vertex classes together, so equal class IDs have
        # the same meaning on both pieces regardless of element ordering.
        for _ in range(4):
            ids = {}
            encoded = []
            for values in labels:
                encoded.append([ids.setdefault(value, len(ids)) for value in values])
            labels = []
            for s, values in zip(snapshots, encoded):
                labels.append([(values[i], tuple(sorted(
                    (values[j], s["edges"][tuple(sorted((i, j)))])
                    for j in s["neighbors"][i]))) for i in range(count)])
        a = np.array([tuple(v) for v in canonical["verts"]], dtype=float)
        b = np.array([tuple(v) for v in candidate["verts"]], dtype=float)
        distances_a = np.linalg.norm(a[:, None] - a[None, :], axis=2)
        distances_b = np.linalg.norm(b[:, None] - b[None, :], axis=2)
        domains = []
        for i in range(count):
            domains.append([j for j in range(count)
                            if labels[0][i] == labels[1][j]
                            and op._instance_descriptor_match(
                                descriptors[0][i], descriptors[1][j], 2 * tolerance)])
            if not domains[-1]:
                return None
        mapping = [-1] * count
        used = set()
        assigned = []
        budget = [20000]
        center_a = a.mean(axis=0)
        centered_a = a - center_a

        def fit():
            matched = b[mapping]
            center_b = matched.mean(axis=0)
            u, _, vt = np.linalg.svd(centered_a.T @ (matched - center_b))
            correction = np.eye(3)
            correction[2, 2] = np.linalg.det(u @ vt)
            row_rotation = u @ correction @ vt
            translation = center_b - center_a @ row_rotation
            errors = np.linalg.norm(a @ row_rotation + translation - matched, axis=1)
            maximum = float(errors.max())
            if maximum > tolerance:
                return None
            transform = Matrix(row_rotation.T.tolist()).to_4x4()
            transform.translation = translation.tolist()
            if op._instance_verify(canonical, candidate, transform, tolerance, mapping) is None:
                return None
            return {"transform": transform, "mapping": list(mapping),
                    "max_error": maximum, "tolerance": tolerance,
                    "mode": "approximate"}

        def search():
            if budget[0] <= 0:
                return None
            budget[0] -= 1
            if len(assigned) == count:
                return fit()
            # Frontier first: mapped neighbors constrain thin bevel strips
            # much better than a nearest-point guess can.
            i = min((i for i in range(count) if mapping[i] < 0),
                    key=lambda i: (-sum(mapping[j] >= 0 for j in canonical["neighbors"][i]),
                                   len(domains[i]), -descriptors[0][i][4], i))
            for j in domains[i]:
                if j in used:
                    continue
                if any(abs(distances_a[i, k] - distances_b[j, mapping[k]]) > 2 * tolerance
                       or canonical["edges"].get(tuple(sorted((i, k)))) !=
                       candidate["edges"].get(tuple(sorted((j, mapping[k]))))
                       for k in assigned):
                    continue
                mapping[i] = j
                assigned.append(i)
                used.add(j)
                result = search()
                if result is not None:
                    return result
                used.remove(j)
                assigned.pop()
                mapping[i] = -1
                if budget[0] <= 0:
                    break
            return None

        match = search()
        if match is None and budget[0] <= 0:
            print("[Tool3D] approximate instance skipped: topology search budget exhausted")
        return match

    @staticmethod
    def _instance_rebind_approximate(piece, snapshot, canonical, match):
        """Allow bounded shape replacement, but not a wrong object transform."""
        op = TOOL3D_OT_split_mark_sharp
        transform = match["transform"]
        canonical, snapshot = op._instance_approximate_pair(canonical, snapshot)
        if op._instance_verify(canonical, snapshot, transform, match["tolerance"],
                               match["mapping"]) is None:
            return False
        old_mesh = piece.data
        old_matrix = piece.matrix_world.copy()
        wanted = old_matrix @ transform
        valid = False
        try:
            piece.data = canonical["mesh"]
            piece.matrix_world = wanted
            bpy.context.view_layer.update()
            actual = piece.matrix_world
            if any(abs(actual[r][c] - wanted[r][c]) > 1e-6 * max(1.0, abs(wanted[r][c]))
                   for r in range(4) for c in range(4)):
                return False
            world_tolerance = max(1e-7, canonical["radius"] * 1e-6 *
                                  max(wanted.to_3x3().col[i].length for i in range(3)))
            valid = all((actual @ v.co - wanted @ v.co).length <= world_tolerance
                        for v in piece.data.vertices)
            return valid
        finally:
            if not valid:
                piece.data = old_mesh
                piece.matrix_world = old_matrix
                bpy.context.view_layer.update()

    @staticmethod
    def _instance_points_match(source, target, tolerance):
        from mathutils.kdtree import KDTree
        if len(source) != len(target):
            return False
        tree = KDTree(len(target))
        for index, co in enumerate(target):
            tree.insert(co, index)
        tree.balance()
        seen = set()
        for co in source:
            _, index, distance = tree.find(co)
            if index is None or distance > tolerance or index in seen:
                return False
            seen.add(index)
        return True

    @staticmethod
    def _instance_rebind(piece, snapshot, canonical, transform, tolerance):
        """Point `piece` at the canonical mesh and absorb `transform` into
        its own matrix. Verified against the object's ACTUAL matrix (a
        parent or a delta transform can refuse the assignment) and against
        its world coordinates; anything off restores the old data and
        transform. Both point sets are read from the normalized snapshots,
        which the structural check already proved correspond."""
        old_mesh = piece.data
        old_matrix = piece.matrix_world.copy()
        canonical_mesh = canonical["mesh"]
        # Prefer the real vertex lists; they only differ in length when
        # normalization merged a differing triangulation, and then the
        # normalized snapshots are the corresponding sets.
        if len(old_mesh.vertices) == len(canonical_mesh.vertices):
            source = [vert.co.copy() for vert in old_mesh.vertices]
            target = [vert.co.copy() for vert in canonical_mesh.vertices]
        else:
            source, target = snapshot["verts"], canonical["verts"]
        before = [old_matrix @ co for co in source]
        wanted = old_matrix @ transform

        piece.data = canonical_mesh
        piece.matrix_world = wanted
        bpy.context.view_layer.update()

        actual = piece.matrix_world
        ok = all(abs(actual[row][column] - wanted[row][column]) <= tolerance
                 for row in range(4) for column in range(4))
        if ok:
            after = [actual @ co for co in target]
            ok = TOOL3D_OT_split_mark_sharp._instance_points_match(
                before, after, tolerance)
        if not ok:
            piece.data = old_mesh
            piece.matrix_world = old_matrix
            bpy.context.view_layer.update()
            return False
        return True

    @staticmethod
    def _instance_cut_pieces(pieces, approximate=False, tolerance_percent=2.0):
        """Rebind every piece congruent to the FIRST usable one onto that
        piece's mesh datablock, compensating each rebound object's
        transform so its world geometry is unchanged.

        Only objects in this one supplied group are ever touched, and only
        their `data`/transform -- no actual mesh is edited, and a piece
        that fails any check keeps its own data untouched.

        Returns {'linked', 'unique', 'skipped', 'unused_meshes'}, where
        'unused_meshes' lists the datablocks a rebind left with zero
        users. They are REPORTED, never removed: a piece may still carry a
        mesh the user owned before the split, so deleting is the caller's
        call.
        """
        result = {"linked": 0, "unique": 0, "skipped": 0, "unused_meshes": [],
                  "approximate_linked": 0, "max_error_percent": 0.0}
        usable = []
        for piece in pieces or ():
            if TOOL3D_OT_split_mark_sharp._instance_is_shareable(piece):
                usable.append(piece)
            else:
                result["skipped"] += 1
        if not usable:
            return result

        # A piece that matches no earlier canonical opens a new class, so a
        # source with several congruence classes (octants plus wedges) links
        # each class instead of only the first.
        canonicals = []
        raw_reads = {}

        def raw_read(obj):
            """The unmerged reading of one piece, built at most once and
            only for a pair the merged compare already rejected."""
            if obj.name not in raw_reads:
                raw_reads[obj.name] = TOOL3D_OT_split_mark_sharp._instance_snapshot(
                    obj, normalize=False)
            return raw_reads[obj.name]

        for piece in usable:
            snapshot = TOOL3D_OT_split_mark_sharp._instance_snapshot(piece)
            linked = False
            for canonical_snapshot, tolerance in canonicals:
                pair = (canonical_snapshot, snapshot)
                transform = TOOL3D_OT_split_mark_sharp._instance_rigid_map(*pair)
                if transform is None:
                    # A coplanar ANNULUS cannot dissolve to a single face,
                    # so the merge must leave one edge standing and picks a
                    # different one per piece. The raw reading makes no such
                    # choice; every gate below still runs, on it alone.
                    pair = (raw_read(canonical_snapshot["object"]), raw_read(piece))
                    transform = TOOL3D_OT_split_mark_sharp._instance_rigid_map(*pair)
                if transform is not None and TOOL3D_OT_split_mark_sharp._instance_rebind(
                        piece, pair[1], pair[0], transform, tolerance):
                    linked = True
                    break
            if not linked and approximate:
                for canonical_snapshot, _ in canonicals:
                    pair = (raw_read(canonical_snapshot["object"]), raw_read(piece))
                    match = TOOL3D_OT_split_mark_sharp._instance_approximate_map(
                        *pair, tolerance_percent)
                    if match is not None and TOOL3D_OT_split_mark_sharp._instance_rebind_approximate(
                            piece, pair[1], pair[0], match):
                        linked = True
                        result["approximate_linked"] += 1
                        result["max_error_percent"] = max(result["max_error_percent"],
                            100.0 * match["max_error"] / pair[0]["radius"])
                        break
            if linked:
                result["linked"] += 1
                old_mesh = snapshot["mesh"]
                if old_mesh.users == 0:
                    result["unused_meshes"].append(old_mesh)
                continue
            result["unique"] += 1
            canonicals.append((snapshot, max(
                snapshot["radius"] * TOOL3D_OT_split_mark_sharp._INSTANCE_RELATIVE_TOL,
                1.0e-9)))
        return result

    @staticmethod
    def _new_piece_object(source_obj, source_mesh):
        """Create a sibling object of `source_obj` carrying a copy of
        `source_mesh`, ready for `_write_vert_group_to_mesh` to overwrite
        with just this piece's geometry.

        `source_obj.copy()` (rather than `bpy.data.objects.new`) so the new
        piece inherits the source's transform, parent, modifiers, material
        slots and custom properties -- the same object-level fidelity
        `bpy.ops.mesh.separate` gives, but without its nested operator call
        and its extra undo push (I7).

        Final repair pass (mesh-level data): the mesh used to be a brand-new
        `bpy.data.meshes.new(...)` with only the material list copied over,
        which made every produced piece a BARE mesh. That silently destroyed
        everything that lives on the mesh DATABLOCK rather than in the
        BMesh's per-element data, confirmed empirically on this Blender
        build against a source carrying two weighted vertex groups and a
        shape key:
          - shape keys: the piece came out with `mesh.shape_keys is None` --
            every key block gone, even though the BMesh still carried the
            per-vertex shape layers;
          - vertex groups: the piece's `object.vertex_groups` was EMPTY
            while its vertices still carried deform weights referring to
            group indices 0/1 -- weights pointing at groups that no longer
            existed (on this build the vertex-group NAME list is owned by
            the mesh datablock, so `source_obj.copy()` alone does not carry
            it when the copy's `data` is then replaced by a bare mesh).

        `source_mesh.copy()` is used instead: it starts the piece from a
        full-fidelity duplicate of the source mesh -- shape keys (as an
        INDEPENDENT Key datablock, verified: the copy's `shape_keys` is not
        the source's, and each has a single user, so editing one piece can
        never write through to another), vertex-group names, UV layers,
        materials and material indices, and every other mesh attribute.
        `_write_vert_group_to_mesh` then overwrites its geometry with this
        piece's own vertices via `bm.to_mesh()`, which RESIZES the existing
        key blocks and deform data to the written vertices in the BMesh's
        own order (verified directly: after writing a 4-vertex subset into a
        copy of an 8-vertex source, every key block held exactly 4 entries
        carrying the source's own key coordinates for those 4 vertices, with
        `value`, `slider_min` and `relative_key` intact, and each vertex kept
        its original group indices and weights).

        Vertex identity is therefore never re-derived from an index map: the
        BMesh's own deform and shape layers travel WITH each BMVert through
        `bmesh.ops.split_edges` and the per-piece `bmesh.ops.delete`, so a
        vertex duplicated by the edge split inherits its origin vertex's
        weights and key coordinates automatically (verified: after splitting
        a ring, the four new vertices carried the same deform weights and
        the same `Basis`/key coordinates as the originals they were split
        from). That is exactly the "map generated piece vertices to source
        vertex indices" requirement, satisfied by construction rather than
        by a fallible parallel index table.

        Final repair pass 2 (template ordering): `source_mesh` is a
        PRISTINE template -- the source mesh datablock as it was BEFORE the
        split started overwriting it. The caller previously passed the live
        `mesh`, which by the time the first new piece is built has already
        been overwritten by `_write_vert_group_to_mesh` with the first
        piece's (or, on the leftover-shell path, an unrelated shell's)
        geometry. Measured on this build: splitting a 20-vertex source,
        this method was reached with `source_mesh` already reduced to 8
        vertices and its key blocks already resized to 8.

        HONEST SCOPE OF THIS CHANGE. It was checked whether that stale
        template produced any observable difference on the pieces, by
        running the same fixtures through both orderings and diffing
        everything reachable on the results -- vertex counts, groups and
        per-vertex weights, every shape-key block's metadata and per-vertex
        coordinates, UV layers, materials, material indices, custom mesh
        properties, generic and colour attributes. Across equal-sized,
        uneven, three-piece and unrelated-shell splits the two orderings
        produced IDENTICAL piece data on Blender 5.2.1: the subsequent
        `bm.to_mesh()` re-derives the geometry and re-sizes the key blocks
        from the BMesh, which carries the per-vertex shape and deform
        layers itself, so the template's own geometry never survives into
        the piece. Passing the pristine copy is therefore a correctness
        hardening -- the template is what it claims to be, and stops
        depending on `bm.to_mesh()` overwriting every piece of stale state
        -- and NOT a fix for an observed data-loss symptom. The observed
        data loss came from the bare `bpy.data.meshes.new(...)` this method
        no longer uses (see above), which is what the tests kill.
        """
        new_mesh = source_mesh.copy()

        new_obj = source_obj.copy()
        new_obj.data = new_mesh
        for collection in source_obj.users_collection:
            collection.objects.link(new_obj)
        return new_obj

    @staticmethod
    def _discard_created_objects(objects, keep=()):
        """Remove objects THIS operation created, plus the mesh datablocks
        they leave unused. Returns the names actually removed.

        Final repair pass 3. `_new_piece_object` links a real object into
        the scene, and the `_write_vert_group_to_mesh` call that gives it
        its geometry is a separate statement that can raise -- so a split
        that fails on its third piece used to leave the first two behind,
        linked, selected and visible in the outliner, while the operator
        reported a controlled failure. Measured on this build before this
        fix, forcing that write to raise on the third of four pieces: the
        operator returned `{'CANCELLED'}` and the scene was left holding
        two extra partial objects whose meshes carried a full copy of the
        source template's geometry rather than their own piece's.

        SAFETY, which is the whole point of the `objects` list being an
        explicit creation log rather than a scene scan: only objects
        passed in are ever considered, and only `_new_piece_object`'s own
        results are ever passed in. The original source object is never in
        that list (it is never created by the split -- it is mutated in
        place), and neither is any pre-existing object in the file, so
        neither can be removed here however this is called. `keep` names
        objects to spare even though they were created -- used by the
        top-level net so an already-accepted piece is never withdrawn.

        Each removed object's mesh datablock is removed after it, but ONLY
        when nothing else still uses it (`users == 0`). A piece that
        somehow shares its mesh with a surviving object therefore keeps
        that mesh intact. Removing the mesh also releases the `Key`
        datablock shape keys live on, which is owned by the mesh rather
        than independently removable.

        Every step is individually guarded: rollback runs while an
        exception is already in flight, so a failure to remove one object
        must not mask the original error or stop the remaining objects
        from being cleaned up.
        """
        kept = set(keep)
        removed = []
        for obj in objects:
            if obj is None or obj in kept:
                continue
            try:
                name = obj.name
            except ReferenceError:
                # Already gone: nothing left to clean up for this entry.
                continue
            mesh = None
            try:
                data = obj.data
                if isinstance(data, bpy.types.Mesh):
                    mesh = data
            except (ReferenceError, AttributeError):
                mesh = None
            try:
                bpy.data.objects.remove(obj, do_unlink=True)
                removed.append(name)
            except (ReferenceError, RuntimeError, TypeError) as exc:
                print("[Tool3D] could not remove partial piece {}: {}".format(
                    name, exc))
                continue
            if mesh is None:
                continue
            try:
                if mesh.users == 0:
                    bpy.data.meshes.remove(mesh)
            except (ReferenceError, RuntimeError, TypeError) as exc:
                print("[Tool3D] could not remove partial piece mesh for {}: {}".format(
                    name, exc))
        return removed

    def _split_object_by_sharp_loops(self, context, obj, loops):
        """Split obj along the given valid Seam loops into separate objects.

        Marks provenance (BMesh marker layer, same contract as Task 2),
        splits only the loops' own edges via `bmesh.ops.split_edges`, then
        performs the object separation ITSELF, entirely in BMesh +
        `bpy.data`, with no nested `bpy.ops` call at all.

        Final fix pass, two behaviour changes:

        I7 (undo): the old implementation drove the separation through
        `bpy.ops.object.mode_set(EDIT)` + `bpy.ops.mesh.separate(LOOSE)` +
        `mode_set(OBJECT)`. Each of those is its own operator and pushes
        its own undo step, so "one undo reverts the whole thing" could not
        hold. Building the pieces directly from the BMesh removes three
        nested operator calls from the core path (see the class-level note
        on the remaining limitation).

        I3 (unrelated shells): `separate(type='LOOSE')` explodes EVERY
        loose island in the source, including pre-existing shells that have
        no Seam loop and no business being touched. The split result is
        now partitioned by cut provenance instead: a connected component
        that contains at least one cut-marked vertex is a genuine cut
        piece; every component that does not is an unrelated pre-existing
        shell. All unrelated shells are written back together, as ONE
        object (the original `obj`, keeping its name/transform/materials),
        with their geometry untouched and no marker attribute left on them,
        and they are never returned as pieces -- so they are never counted,
        offset, filled or beveled.

        When the source contains no unrelated shell at all (the common
        case), `obj` keeps the first cut piece exactly as before, so the
        object count and the "no objects are joined" property are unchanged.

        Final repair pass 3 (transactional piece creation): this method
        links real objects into the scene as it goes, and the very next
        statement after each link -- `_write_vert_group_to_mesh` -- can
        raise. Previously a failure on, say, the third of four pieces left
        the first two already linked, selectable and visible in the
        outliner, while the operator reported a controlled failure and the
        user was given no indication that partial junk had been created.
        Every object this call creates is now tracked in
        `created_objects`, and on ANY exception they are all removed again
        (with their mesh datablocks, once unused) before the exception is
        re-raised to the caller's own handler. Only objects created by
        THIS call are ever touched: the source object and every
        pre-existing object are untouched by construction, because they
        were never added to the list.

        When the caller is a live operator instance carrying a
        `_run_created_objects` list, every created object is appended to
        that too, so the OPERATOR can clean up after a failure that
        happens LATER -- after this method has already returned
        successfully -- without scanning the scene or diffing object
        names. It is read with `getattr`, never added as a parameter,
        because this method's 4-argument signature is a fixed contract:
        several existing tests call it directly as
        `_split_object_by_sharp_loops(None, context, obj, loops)` and one
        monkeypatches it with a 4-parameter stub, so a fifth parameter
        (even an optional one) would break the monkeypatched call with a
        TypeError. Verified: adding one turned
        `test_i2_failure_inside_split_is_contained_no_edit_mode_leak` from
        FINISHED into CANCELLED.

        Returns (pieces, provenance, failures):
          - pieces: list of resulting mesh Objects (cut pieces only).
          - provenance: {cut_id: {"edge_signatures": [...]}}, captured
            before the split invalidates edge/vertex index identity.
          - failures: list of failure records (see `_failure_record`).
        """
        failures = []
        provenance = {}
        mesh = obj.data
        obj_name = obj.name
        # Created only once the split is certain to produce pieces; the
        # `finally` below removes it, so it must exist as a name from here on.
        template_mesh = None
        # Every NEW object this call links into the scene, in creation
        # order. The source object is deliberately never in here.
        created_objects = []
        # The operator's run-wide creation log, when this was called as a
        # bound method of a live operator (see the docstring on why this is
        # read off `self` rather than taken as a parameter). `self` is None
        # when a test calls this helper directly.
        created_sink = getattr(self, "_run_created_objects", None)

        bm = bmesh.new()
        try:
            bm.from_mesh(mesh)
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()

            edge_layer, vert_layer = (
                TOOL3D_OT_split_mark_sharp._create_cut_layers(bm))
            TOOL3D_OT_split_mark_sharp._mark_cut_provenance(
                bm, loops, edge_layer, vert_layer)

            for loop in loops:
                # M6: only edge signatures are kept. The old
                # "vertex_signatures" entry was written here and then never
                # read by any classification path (`_classify_boundary_edges`
                # matches on edge signatures and the marker layer only), so
                # it was pure dead data computed on every run.
                provenance[loop["cut_id"]] = {
                    "edge_signatures": list(loop["edge_signatures"]),
                }

            # Custom layers are created before any element reference is
            # held: adding a layer invalidates existing Python wrappers of
            # that element type.
            if bm.edges.layers.int.get(_SEAM_FOLD_EDGE) is None:
                bm.edges.layers.int.new(_SEAM_FOLD_EDGE)
            face_role = bm.faces.layers.int.get(_SEAM_FACE_ROLE)
            if face_role is None:
                face_role = bm.faces.layers.int.new(_SEAM_FACE_ROLE)
            for face in bm.faces:
                face[face_role] = 1

            split_edges = [edge for edge in bm.edges if edge[edge_layer] > 0]
            if not split_edges:
                # I2: nothing was changed, so nothing is written back -- the
                # source mesh keeps its exact original data (in particular it
                # never gains the marker attributes).
                failures.append(TOOL3D_OT_split_mark_sharp._failure_record(
                    obj_name, "no marked cut edges found to split"))
                return [], provenance, failures

            try:
                bmesh.ops.split_edges(bm, edges=split_edges)
            except TOOL3D_OT_split_mark_sharp._RECOVERABLE_ERRORS as exc:
                # I2: a failed split must NEVER be written back -- writing
                # the partially-mutated BMesh here would persist a
                # half-split mesh (and the marker attributes) onto the
                # user's object even though the operation failed.
                failures.append(TOOL3D_OT_split_mark_sharp._failure_record(
                    obj_name, "split_edges failed: {}".format(exc)))
                return [], provenance, failures

            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()

            groups = TOOL3D_OT_split_mark_sharp._connected_vert_groups(bm)
            verts = list(bm.verts)

            cut_groups = []
            leftover_ordinals = set()
            for group in groups:
                if any(verts[ordinal][vert_layer] > 0 for ordinal in group):
                    cut_groups.append(group)
                else:
                    leftover_ordinals.update(group)

            if not cut_groups:
                failures.append(TOOL3D_OT_split_mark_sharp._failure_record(
                    obj_name, "split produced no cut-marked pieces"))
                return [], provenance, failures

            # Deterministic order: by each group's lowest ordinal.
            cut_groups.sort(key=lambda group: group[0])

            # Final repair pass 2: take ONE pristine copy of the source mesh
            # datablock BEFORE anything is written back, and build every new
            # piece from that.
            #
            # `_new_piece_object` copies the mesh it is handed. It used to be
            # handed the live `mesh`, which the two `_write_vert_group_to_mesh`
            # calls below overwrite in place before the piece loop runs, so the
            # "source mesh" it copied was already reduced to another piece's
            # geometry (measured: a 20-vertex source reached it as 8 vertices,
            # key blocks resized to 8). The pieces came out correct anyway --
            # `bm.to_mesh()` re-derives geometry and re-sizes the key blocks
            # from the BMesh, which carries the shape/deform layers itself --
            # so this is hardening, not a fix for an observed symptom; see
            # `_new_piece_object` for the measurements behind that statement.
            # The value is that the template now is what its name says, and
            # correctness no longer rests on every piece of stale state
            # happening to be overwritten downstream.
            #
            # `mesh.copy()` is a real datablock, so it is removed again in the
            # `finally` below -- otherwise every run would leave an orphan mesh
            # (and an orphan Key) behind in the blend file.
            template_mesh = mesh.copy()

            pieces = []
            if leftover_ordinals:
                # I3: the source object keeps ALL unrelated pre-existing
                # shells, together, untouched and marker-free. Every cut
                # piece becomes its own new object.
                TOOL3D_OT_split_mark_sharp._write_vert_group_to_mesh(
                    bm, leftover_ordinals, mesh, strip_markers=True)
                groups_for_new_objects = cut_groups
            else:
                # No unrelated shell: the source object keeps the first cut
                # piece, exactly as the old separate()-based path did.
                TOOL3D_OT_split_mark_sharp._write_vert_group_to_mesh(
                    bm, set(cut_groups[0]), mesh)
                pieces.append(obj)
                groups_for_new_objects = cut_groups[1:]

            for group in groups_for_new_objects:
                new_obj = TOOL3D_OT_split_mark_sharp._new_piece_object(
                    obj, template_mesh)
                # Tracked BEFORE the write that can raise, so a failure
                # inside `_write_vert_group_to_mesh` still cleans up the
                # object that was already linked by the line above.
                created_objects.append(new_obj)
                if created_sink is not None:
                    created_sink.append(new_obj)
                TOOL3D_OT_split_mark_sharp._write_vert_group_to_mesh(
                    bm, set(group), new_obj.data)
                pieces.append(new_obj)
        except BaseException:
            # Transactional rollback: this call linked real objects into
            # the scene, and it is not finishing. Remove exactly what it
            # created -- never the source, never anything pre-existing --
            # then let the caller's own boundary handle the exception.
            # `BaseException` deliberately: a KeyboardInterrupt through a
            # long split must not strand partial pieces either.
            TOOL3D_OT_split_mark_sharp._discard_created_objects(created_objects)
            raise
        finally:
            bm.free()
            # The template is scaffolding, never a piece's own data: every
            # piece holds its own `template_mesh.copy()`, so removing it here
            # cannot touch any produced geometry. Guarded because the block
            # above can return before the template is created.
            if template_mesh is not None and template_mesh.users == 0:
                bpy.data.meshes.remove(template_mesh)

        if not pieces:
            failures.append(TOOL3D_OT_split_mark_sharp._failure_record(
                obj_name, "separation produced no mesh pieces"))

        return pieces, provenance, failures

    @staticmethod
    def _classify_boundary_edges(bm, provenance, tolerance):
        """Return {cut_id: [BMEdge, ...]} classifying every boundary edge
        of the already-open `bm` against `provenance`.

        Classification priority: BMesh marker layer value first (only when
        it names a cut_id we actually have provenance for), then endpoint
        signature match against the saved provenance. A boundary edge that
        matches neither is left unclassified -- a pre-existing (non-cut)
        mesh boundary is never reported as a cut boundary.

        Shared by `_remap_cut_boundaries` (which opens a short-lived BMesh
        purely to expose this classification via a simple dict, per its
        Task 3 contract) and Task 4's smart-fill wiring in `execute()`
        (which keeps its own `bm` referenced across this call and the
        capping that follows). IMPORTANT: a returned BMEdge stays valid
        only as long as SOME Python reference to `bm` itself is still
        alive elsewhere -- BMesh elements do not keep their owning BMesh
        alive on their own (confirmed empirically: accessing a BMEdge
        after its BMesh's Python wrapper has been garbage collected raises
        `ReferenceError: BMesh data ... has been removed`, even though the
        BMEdge object itself is still reachable). Any caller that needs
        the result to outlive its own `bm` variable must extract portable
        data (e.g. `_edge_signature(...)`) from these edges before `bm`
        goes out of scope, not hold onto the BMEdge objects themselves.
        """
        edge_layer = bm.edges.layers.int.get(_SHARP_CUT_EDGE_LAYER)

        signature_to_cut_id = {}
        for cut_id, data in provenance.items():
            for signature in data.get("edge_signatures", ()):
                signature_to_cut_id.setdefault(signature, cut_id)

        result = {}
        for edge in bm.edges:
            if not edge.is_boundary:
                continue

            cut_id = None
            if edge_layer is not None:
                marker_value = edge[edge_layer]
                if marker_value > 0 and marker_value in provenance:
                    cut_id = marker_value

            if cut_id is None:
                signature = TOOL3D_OT_split_mark_sharp._edge_signature(
                    edge.verts[0].co, edge.verts[1].co, tolerance)
                cut_id = signature_to_cut_id.get(signature)

            if cut_id is not None:
                result.setdefault(cut_id, []).append(edge)

        return result

    def _remap_cut_boundaries(self, obj, provenance, tolerance):
        """Return {cut_id: [BMEdge, ...]} for boundary edges only.

        Thin wrapper around `_classify_boundary_edges`: opens its own
        BMesh on `obj.data`, classifies, and returns the dict. Signature
        and externally observable return shape are unchanged from Task 3.

        The returned BMEdge references stay valid only while this
        method's own BMesh is alive (it is intentionally not freed here
        so the caller can use the edges immediately after the call) --
        AND, per `_classify_boundary_edges`'s note, only for as long as
        this BMesh's Python wrapper itself is still referenced somewhere;
        holding only the returned BMEdge objects is not enough, since a
        BMesh's local variable going out of scope releases it immediately
        (this method's own `bm` local does exactly that the instant this
        call returns, so a caller that only ever reads `len(...)`/dict
        keys from the result -- as every existing Task 2/3 test does --
        is unaffected, but any caller needing real edge data must retain a
        reference to this call's BMesh some other way; Task 4's
        smart-fill wiring in `execute()` avoids this pitfall entirely by
        calling `_classify_boundary_edges` directly with its own
        already-kept-alive `bm`, never through this method).
        """
        mesh = obj.data
        bm = bmesh.new()
        bm.from_mesh(mesh)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()

        return TOOL3D_OT_split_mark_sharp._classify_boundary_edges(
            bm, provenance, tolerance)

    def _fill_cut_loops(self, obj, cut_boundaries, relative_tolerance):
        """Return (filled_count, failures), preserving unmarked holes.

        `cut_boundaries` is `{cut_id: [edge_signature, ...]}` -- portable
        endpoint signatures (see `_edge_signature`), NOT live BMEdge
        objects. This is deliberate: `_remap_cut_boundaries` intentionally
        leaves its own BMesh open and unfreed so its *caller* can use the
        returned BMEdges immediately, but BMesh elements expose no way
        back to their owning BMesh (confirmed: BMEdge has no `id_data`),
        so a `{cut_id: [BMEdge, ...]}` handed across this method boundary
        could never be safely written back or freed here. Building this
        method's own fresh BMesh on `obj.data` and re-resolving each
        cut_id's boundary edges by signature keeps this method fully
        self-contained (open/mutate/validate/write-back/free all in one
        place, matching every other BMesh-owning helper in this class) at
        the cost of one extra signature lookup per edge -- negligible for
        loop sizes this feature targets.

        Only edges whose signature was actually classified into
        `cut_boundaries` are ever touched, so any other boundary edge on
        `obj` (a pre-existing/unmarked hole) is left completely alone --
        never read, never passed to `_smart_cap_loop`, never filled.
        Processes cut_id in ascending order, independently: each call to
        `_smart_cap_loop` only ever receives that one cut_id's own
        resolved edges. Mesh data is written back (`bm.to_mesh`) only once,
        after every loop has already been individually validated (a
        rejected loop's trial faces are removed by `_smart_cap_loop`
        itself before this method ever sees a result for it), so nothing
        unvalidated is ever persisted.
        """
        failures = []
        filled_count = 0

        if not cut_boundaries:
            return filled_count, failures

        diagonal = TOOL3D_OT_split_mark_sharp._mesh_diagonal(obj)
        cap_tolerance = max(1.0e-8, diagonal * max(relative_tolerance, 1.0e-7))
        signature_tolerance = max(diagonal * 1.0e-6, 1.0e-8)

        mesh = obj.data
        bm = bmesh.new()
        any_change = False
        try:
            bm.from_mesh(mesh)
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()

            signature_to_edges = {}
            for edge in bm.edges:
                if not edge.is_boundary:
                    continue
                signature = TOOL3D_OT_split_mark_sharp._edge_signature(
                    edge.verts[0].co, edge.verts[1].co, signature_tolerance)
                signature_to_edges.setdefault(signature, []).append(edge)

            for cut_id in sorted(cut_boundaries.keys()):
                wanted_signatures = cut_boundaries[cut_id]
                resolved_edges = []
                unresolved = False
                for signature in wanted_signatures:
                    candidates = signature_to_edges.get(signature)
                    if not candidates:
                        unresolved = True
                        break
                    resolved_edges.append(candidates.pop())
                    if not candidates:
                        del signature_to_edges[signature]

                if unresolved or not resolved_edges:
                    # M3/final repair pass 3: built through the shared
                    # helper rather than as a hand-written dict, so every
                    # producer emits the one record shape consumers rely on.
                    failures.append(
                        TOOL3D_OT_split_mark_sharp._failure_record(
                            obj.name,
                            "could not resolve all boundary edges for this cut_id",
                            cut_id=cut_id,
                            edge_count=len(resolved_edges),
                        )
                    )
                    continue

                # Crossing-cut support: one cut_id is one connected Seam
                # NETWORK, and on a piece it can surface as SEVERAL
                # separate closed boundary loops. The user's "cut a cube
                # into four with two crossing rings" case is exactly that:
                # every quarter carries two square cut faces at right
                # angles to each other, both stamped with the same cut_id.
                # Handing all of those edges to `_smart_cap_loop` as one
                # loop made it walk an 8-edge non-planar "loop" that is
                # really two 4-edge squares sharing no edge -- rejected as
                # mixed normals (measured on this build). Each connected
                # boundary loop is capped on its own instead; a cut_id
                # counts as filled only when ALL of its loops are.
                sub_loops = TOOL3D_OT_split_mark_sharp._connected_edge_loops(
                    resolved_edges)
                loop_failures = []
                for sub_loop in sub_loops:
                    result = TOOL3D_OT_split_mark_sharp._smart_cap_loop(
                        bm, sub_loop, cap_tolerance)
                    if result.get("filled"):
                        role = bm.faces.layers.int.get(_SEAM_FACE_ROLE)
                        if role is not None:
                            for face in result["faces"]:
                                face[role] = 0
                        any_change = True
                    else:
                        loop_failures.append((
                            len(sub_loop), result.get("reason", "unknown failure")))

                if not loop_failures:
                    filled_count += 1
                else:
                    for edge_count, reason in loop_failures:
                        failures.append(
                            TOOL3D_OT_split_mark_sharp._failure_record(
                                obj.name,
                                reason,
                                cut_id=cut_id,
                                edge_count=edge_count,
                            )
                        )
        finally:
            if any_change:
                bm.to_mesh(mesh)
                mesh.update()
            bm.free()

        return filled_count, failures

    # ===== Task 5: cut-only offset/bevel, orchestration, reporting =====
    #
    # Everything below is new for Task 5: cut-only vertex offset (never the
    # old whole-mesh `_offset_border_verts`), cut-rim-only bevel selected by
    # portable endpoint signature (never stale `BMEdge`/index references or
    # the old `_bevel_saved_edges`), the per-source settings-application
    # orchestration `execute()` now calls, a concise status-bar report
    # formatter, and marker-layer cleanup so provenance never persists on
    # the final mesh. Nothing here is reachable from the five legacy
    # operators, which keep using their own untouched helpers.

    def _offset_cut_boundary_verts(self, bm, cut_boundaries, offset_value):
        """Move only cut boundary vertices; return bool collision warning.

        `cut_boundaries` is `{cut_id: [BMEdge, ...]}` -- exactly
        `_classify_boundary_edges`'s classified result on the caller's own
        already-open, already-kept-alive `bm`. Only vertices touched by
        one of these edges are ever candidates for movement, and a
        boundary edge with no cut_id (never present in `cut_boundaries`
        at all, e.g. a pre-existing/unmarked hole) can never contribute a
        direction or be moved.

        For each cut vertex, every linked CUT edge's single adjacent face
        contributes an inward vector (that face's center, projected
        perpendicular to the edge -- the same construction the legacy
        per-operator offset helpers use); the per-vertex sum is
        normalized, then the actual displacement is capped to 80% of the
        vertex's distance to its nearest LINKED NON-CUT vertex (a
        neighbor that is not itself part of any classified cut boundary)
        so a cut ring can never be offset far enough to collide with the
        interior geometry it borders. Returns True if any vertex's
        displacement had to be clamped below the requested
        `offset_value`.

        Final fix pass (M9): when a vertex has NO non-cut neighbour at all
        (a piece whose every vertex belongs to the cut ring -- e.g. an
        isolated single-face cap piece), the clamp used to fall back to
        "allow the full requested offset", which lets an arbitrarily large
        offset drag a whole lone piece across the scene with nothing
        bounding it. It now falls back to a finite, geometry-derived cap:
        80% of the shortest edge attached to that vertex (and, failing
        even that, 80% of the piece's own bounding-box diagonal). Hitting
        this fallback is reported as a clamp like any other, so the user
        is told the offset was limited.

        Final fix pass (M8): `bm.normal_update()` is called after the
        vertices move, so any face/vertex normal read afterwards (cap
        orientation checks, bevel direction) reflects the moved geometry
        rather than the pre-offset shape.
        """
        from mathutils import Vector

        if not offset_value or offset_value <= 0.0:
            return False

        cut_edges = [
            edge for edge_list in cut_boundaries.values() for edge in edge_list
        ]
        if not cut_edges:
            return False

        bm.verts.ensure_lookup_table()

        # M9: a finite, geometry-derived last-resort cap for a vertex with
        # no usable neighbour at all -- 80% of this BMesh's own bounding-box
        # diagonal, never `offset_value` itself (which is unbounded input).
        fallback_cap = offset_value
        if bm.verts:
            xs = [v.co.x for v in bm.verts]
            ys = [v.co.y for v in bm.verts]
            zs = [v.co.z for v in bm.verts]
            span = max(
                max(xs) - min(xs),
                max(ys) - min(ys),
                max(zs) - min(zs),
            )
            if span > 0.0:
                fallback_cap = span * 0.8

        cut_vert_indices = set()
        for edge in cut_edges:
            for v in edge.verts:
                cut_vert_indices.add(v.index)

        vert_directions = {}
        for edge in cut_edges:
            if not edge.link_faces:
                continue
            face = edge.link_faces[0]

            face_center = face.calc_center_median()
            edge_mid = (edge.verts[0].co + edge.verts[1].co) / 2.0
            to_center = face_center - edge_mid

            edge_vec = edge.verts[1].co - edge.verts[0].co
            if edge_vec.length <= 1.0e-9:
                continue
            edge_vec.normalize()
            projected = to_center - to_center.dot(edge_vec) * edge_vec

            if projected.length > 1.0e-6:
                inward = projected.normalized()
            elif to_center.length > 1.0e-6:
                inward = to_center.normalized()
            else:
                continue

            for v in edge.verts:
                vert_directions.setdefault(v.index, Vector((0.0, 0.0, 0.0)))
                vert_directions[v.index] += inward

        collision_warned = False
        for v_idx, direction in vert_directions.items():
            if direction.length <= 1.0e-6:
                continue
            direction = direction.normalized()
            vert = bm.verts[v_idx]

            min_dist = float('inf')
            shortest_linked_edge = float('inf')
            for other_edge in vert.link_edges:
                other_v = other_edge.other_vert(vert)
                dist = (other_v.co - vert.co).length
                if dist < shortest_linked_edge:
                    shortest_linked_edge = dist
                if other_v.index in cut_vert_indices:
                    continue  # cap only against non-cut neighbors
                if dist < min_dist:
                    min_dist = dist

            if min_dist < float('inf'):
                max_allowed = min_dist * 0.8
            elif shortest_linked_edge < float('inf') and shortest_linked_edge > 0.0:
                # M9: no non-cut neighbour -- bound the move by this
                # vertex's own shortest edge instead of allowing the full
                # requested offset through an unbounded lone piece.
                max_allowed = shortest_linked_edge * 0.8
            else:
                # Fully isolated vertex (no linked edge at all): fall back to
                # the piece's own overall scale, still finite.
                max_allowed = fallback_cap

            actual_offset = min(offset_value, max_allowed)

            if actual_offset < offset_value - 1.0e-9:
                collision_warned = True

            if actual_offset > 1.0e-6:
                vert.co += direction * actual_offset

        # M8: refresh normals after the vertices moved, so anything that
        # reads a face/vertex normal after this call (cap orientation,
        # bevel) sees the post-offset geometry.
        bm.normal_update()

        return collision_warned

    @staticmethod
    def _closest_is_fold(point, fold_segments, rim_segments):
        def distance(segment):
            start, end = segment
            return _point_segment_distance(point, start, end)

        fold = min(distance(segment) for segment in fold_segments)
        rim = min((distance(segment) for segment in rim_segments), default=float("inf"))
        return fold < rim

    def _bevel_cut_edges(self, context, obj, cut_edge_signatures, width, segments, tolerance,
                         wall=None):
        """Bevel signature-matched cut edges. Returns `(count, reason)`.

        Matches only the CURRENT edges whose freshly recomputed endpoint
        signature is in `cut_edge_signatures` (a `{key: [signature, ...]}`
        mapping -- normally the cut-rim signatures captured right after
        offset). A pre-existing hole's own boundary is never matched, since
        its signatures are never in `cut_edge_signatures`. A fill-created
        cap diagonal is likewise never matched even when auto-fill already
        ran: a diagonal's endpoints are two NON-adjacent rim vertices, so
        its signature never coincides with an original adjacent-pair rim
        edge's signature.

        Final fix pass (M10): the return shape is now ALWAYS
        `(count, reason_or_None)` -- previously this returned a bare int on
        success and a 2-tuple on failure, forcing every caller to
        `isinstance(..., tuple)` before it could read its own result.
        `reason` is None exactly when `count > 0`.

        Final fix pass (I7): the bevel is performed with `bmesh.ops.bevel`
        on a private BMesh instead of the old
        `mode_set(EDIT)` + `bpy.ops.mesh.select_*` + `bpy.ops.mesh.bevel` +
        `mode_set(OBJECT)` sequence. That removes four more nested
        operator calls (and their undo pushes, and their dependence on the
        window context) from the core path, and means this method can no
        longer strand the caller in Edit Mode at all -- it never enters it.
        `context` is retained in the signature for call-site compatibility.

        The no-op guard is kept: `bevel` on an all-boundary (still open,
        unfilled) cut rim is a confirmed silent no-op in this Blender
        build, so the vertex/edge/face counts are compared before and
        after, and a run that changed nothing is reported as a controlled
        failure rather than a false-positive "N beveled" success. Nothing
        is written back to the mesh in that case.
        """
        wanted = set()
        for sig_list in cut_edge_signatures.values():
            wanted.update(sig_list)
        if not wanted:
            return 0, "no cut rim edge signatures supplied"
        # A hollow shell's outer and inner rims are beveled towards each
        # other across the bridge band; past half the band width they meet
        # and bmesh's clamp folds the profile through the wall.
        if wall is not None and width * 2.0 > wall + 1.0e-6:
            return 0, ("bevel width {:.4g} exceeds the wall thickness ({:.4g}); "
                       "reduce Bevel Width or the Inner Scale".format(width, wall))

        mesh = obj.data
        bm = bmesh.new()
        try:
            bm.from_mesh(mesh)
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()

            fold_layer = bm.edges.layers.int.get(_SEAM_FOLD_EDGE)
            face_role = bm.faces.layers.int.get(_SEAM_FACE_ROLE)
            vert_side = bm.verts.layers.int.get(_SEAM_VERT_SIDE)
            if face_role is not None and vert_side is None:
                vert_side = bm.verts.layers.int.new(_SEAM_VERT_SIDE)
                for vert in bm.verts:
                    vert[vert_side] = 1
            matched_edges = []
            fold_segments = []
            rim_segments = []
            for edge in bm.edges:
                segment = (edge.verts[0].co.copy(), edge.verts[1].co.copy())
                if fold_layer is not None and edge[fold_layer]:
                    matched_edges.append(edge)
                    fold_segments.append(segment)
                    continue
                signature = TOOL3D_OT_split_mark_sharp._edge_signature(
                    edge.verts[0].co, edge.verts[1].co, tolerance)
                if signature in wanted:
                    matched_edges.append(edge)
                    rim_segments.append(segment)

            if not matched_edges:
                return 0, "no current edges matched the saved cut rim signatures"

            # User report 2026-10-01 (test.blend tray): `clamp_overlap`
            # limits the WHOLE bevel by its tightest spot, and a fill cap's
            # triangulation can leave a near-zero sliver at the rim (area
            # 8e-5 on one half, none on the other) -- that half came out
            # with a bevel ~300x thinner. Flip the cap's inner diagonals to
            # a beauty triangulation first. Only flat triangle pairs of
            # fill-cap faces (role 0) are touched; rim, fold and every
            # other edge stay put, so the cap's outline is unchanged.
            if face_role is not None:
                rim_set = set(matched_edges)
                flippable = [
                    edge for edge in bm.edges
                    if edge not in rim_set
                    and len(edge.link_faces) == 2
                    and all(len(f.verts) == 3 and f[face_role] == 0
                            for f in edge.link_faces)
                    and edge.link_faces[0].normal.dot(edge.link_faces[1].normal) > 0.9999
                ]
                if flippable:
                    cap_faces = list({f for edge in flippable for f in edge.link_faces})
                    bmesh.ops.beautify_fill(bm, faces=cap_faces, edges=flippable)

            matched_count = len(matched_edges)
            counts_before = (len(bm.verts), len(bm.edges), len(bm.faces))
            degenerate_before = sum(
                1 for face in bm.faces if face.calc_area() <= tolerance * tolerance)

            try:
                bevel_result = bmesh.ops.bevel(
                    bm,
                    geom=matched_edges,
                    offset=width,
                    offset_type='OFFSET',
                    segments=segments,
                    profile=0.5,
                    affect='EDGES',
                    clamp_overlap=True,
                    # User report 2026-10-01 (test.blend Cylinder.005,
                    # hollow): at a chamfered corner the bridge band's
                    # short rim edges (0.056) sit at an angle to the
                    # rungs, and without sliding along them the outer and
                    # inner bevel corners crossed each other (8 + 4
                    # self-intersecting face pairs). `loop_slide` is the
                    # bevel tool's own UI default; with it, 0 crossings.
                    # Hollow shells only (`wall` given): on solid pieces it
                    # made mirrored sphere wedges non-congruent (classes
                    # [4, 8] -> [2, 2, 2, 2, 4]) and solids never crossed.
                    loop_slide=wall is not None,
                )
            except TOOL3D_OT_split_mark_sharp._RECOVERABLE_ERRORS as exc:
                return 0, "bevel failed: {}".format(exc)

            counts_after = (len(bm.verts), len(bm.edges), len(bm.faces))
            if counts_after == counts_before:
                # Confirmed no-op for an all-boundary edge selection (an
                # open, unfilled cut rim). Nothing is written back.
                return 0, (
                    "bevel made no geometry change ({} edge(s) matched but "
                    "vertex/edge/face counts unchanged) -- the cut rim is "
                    "likely still open; fill the cut boundary before "
                    "beveling it".format(matched_count)
                )

            degenerate_after = sum(
                1 for face in bm.faces if face.calc_area() <= tolerance * tolerance)
            if degenerate_after > degenerate_before:
                return 0, "bevel would create degenerate faces; reduce Bevel Width"

            if face_role is not None:
                for face in bevel_result["faces"]:
                    face[face_role] = 0
                uv = (bm.loops.layers.uv.get(mesh.uv_layers.active.name)
                      if mesh.uv_layers.active is not None else None)
                if uv is not None:
                    for face in bm.faces:
                        for loop in face.loops:
                            loop[uv].uv = _SEAM_UV[face[face_role]]
            else:
                uv = (bm.loops.layers.uv.get(mesh.uv_layers.active.name)
                      if mesh.uv_layers.active is not None else None)
                if uv is not None:
                    for face in bevel_result["faces"]:
                        for loop in face.loops:
                            loop[uv].uv = (0.0, 0.0)

            bm.normal_update()
            bm.to_mesh(mesh)
            mesh.update()
            return matched_count, None
        finally:
            bm.free()

    @staticmethod
    def _measure_clamped_bevel_width(piece, bevel_signatures, width, tolerance, wall=None):
        """Dry-run bevel on a private BMesh of `piece` to determine the actual
        clamped bevel width achieved by `bmesh.ops.bevel`.
        Returns float <= width, or None if bevel cannot be applied.
        """
        if width <= 0.0:
            return width
        if wall is not None and width * 2.0 > wall + 1.0e-6:
            return None
        target_width = width
        if target_width <= 1.0e-5:
            return target_width

        wanted = set()
        for sig_list in bevel_signatures.values():
            wanted.update(sig_list)
        if not wanted:
            return target_width

        mesh = piece.data
        bm = bmesh.new()
        try:
            bm.from_mesh(mesh)
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()

            fold_layer = bm.edges.layers.int.get(_SEAM_FOLD_EDGE)
            face_role = bm.faces.layers.int.get(_SEAM_FACE_ROLE)

            matched_edges = []
            segments = []
            for edge in bm.edges:
                segment = (edge.verts[0].co.copy(), edge.verts[1].co.copy())
                if fold_layer is not None and edge[fold_layer]:
                    matched_edges.append(edge)
                    segments.append(segment)
                    continue
                signature = TOOL3D_OT_split_mark_sharp._edge_signature(
                    edge.verts[0].co, edge.verts[1].co, tolerance)
                if signature in wanted:
                    matched_edges.append(edge)
                    segments.append(segment)

            if not matched_edges:
                return target_width

            if face_role is not None:
                rim_set = set(matched_edges)
                flippable = [
                    edge for edge in bm.edges
                    if edge not in rim_set
                    and len(edge.link_faces) == 2
                    and all(len(f.verts) == 3 and f[face_role] == 0
                            for f in edge.link_faces)
                    and edge.link_faces[0].normal.dot(edge.link_faces[1].normal) > 0.9999
                ]
                if flippable:
                    cap_faces = list({f for edge in flippable for f in edge.link_faces})
                    bmesh.ops.beautify_fill(bm, faces=cap_faces, edges=flippable)

            counts_before = (len(bm.verts), len(bm.edges), len(bm.faces))
            degenerate_before = sum(
                1 for face in bm.faces if face.calc_area() <= tolerance * tolerance)
            try:
                bevel_result = bmesh.ops.bevel(
                    bm,
                    geom=matched_edges,
                    offset=target_width,
                    offset_type='OFFSET',
                    segments=1,
                    profile=0.5,
                    affect='EDGES',
                    clamp_overlap=True,
                    loop_slide=wall is not None,
                )
            except Exception:
                return target_width

            counts_after = (len(bm.verts), len(bm.edges), len(bm.faces))
            if counts_after == counts_before or not bevel_result.get("faces"):
                return target_width

            from mathutils.geometry import intersect_point_line
            dists = []
            for v in bevel_result.get("verts", ()):
                min_d = float('inf')
                for p0, p1 in segments:
                    pt, t = intersect_point_line(v.co, p0, p1)
                    if -0.05 <= t <= 1.05:
                        d = (v.co - pt).length
                        if d < min_d:
                            min_d = d
                if 1.0e-5 < min_d < float('inf'):
                    dists.append(min_d)

            achieved = min(target_width, max(dists)) if dists else target_width
            degenerate_after = sum(
                1 for face in bm.faces if face.calc_area() <= tolerance * tolerance)
            if degenerate_after > degenerate_before:
                achieved = achieved * 0.9
            return achieved
        finally:
            bm.free()

    def _apply_mark_sharp_settings(self, context, pieces, provenance, props):
        """Offset/fill/bevel one source's produced `pieces` per
        `provenance`. Returns a dict with offset_warnings, bevel_count,
        fill_count, fill_failures.

        `props` is any object exposing sharp_auto_fill/sharp_auto_bevel/
        sharp_offset_value/sharp_bevel_width/sharp_bevel_segments/
        sharp_fill_tolerance -- `execute()` passes `self`, since the
        operator already carries these as its own bl_options-exposed
        properties (Task 1-2 contract, exercised by every
        `bpy.ops.tool3d.split_mark_sharp(sharp_*=...)` call in the test
        suite). Kept as a separate parameter, rather than hard-coded to
        `self`, so this method is directly callable/testable on its own.

        Per piece: classify this piece's cut boundary edges against
        `provenance` in one live BMesh (never a pre-existing/unmarked
        boundary -- classification only ever returns edges with real cut
        provenance); offset only those classified vertices; write back;
        THEN (if enabled) fill; THEN (if enabled) bevel -- offset before
        fill, bevel after fill, per the brief.

        Final fix pass (I4): the offset MOVES the cut rim's vertices, which
        makes every pre-offset endpoint signature in `provenance` stale --
        they encode the coordinates the rim used to have. The old code
        re-classified after the offset but kept passing the ORIGINAL,
        now-stale `provenance` in, so that second classification could only
        ever succeed through the BMesh marker layer; the signature path,
        which is the documented fallback for exactly the case where the
        marker layer did not survive a round trip, was guaranteed to match
        nothing. This method now REBUILDS `provenance` from the post-offset
        BMesh (`refreshed_provenance`) and uses that for the second
        classification and everything downstream, so the fallback is real.

        Also per I4: if the pre-offset pass DID find cut edges but the
        post-offset classification finds none, that is recorded as a
        failure rather than silently skipped -- it means the rim was lost
        somewhere between the two passes, which the user needs told.
        """
        result = {
            "offset_warnings": 0,
            "bevel_count": 0,
            "fill_count": 0,
            "fill_failures": [],
            "hollow_warnings": 0,
        }
        if not provenance:
            return result

        hollow_on = bool(getattr(props, "sharp_hollow", False))
        shape = getattr(props, "sharp_hollow_shape", 'SURFACE') if hollow_on else 'SURFACE'
        shape_primitive = None
        shape_blocked = None  # reason every piece keeps its cap
        prepared = []
        finish_tasks = []

        # Keep Wall v3 (2026-09-12): the Surface hollow's concave fix is the
        # DEFAULT scaled cavity with the inner face under each dent
        # FLATTENED into one panel, built ONCE here so the cavity is a
        # single solid shared by every piece and therefore meets itself
        # across the cut -- exactly like the shape phase's primitive. It
        # must be decided BEFORE the per-piece loop, because a flattened
        # source goes down the shape route (force cap fill, then carve)
        # while a convex one keeps the old `_hollow_piece` bridge, and a
        # piece can only take the bridge while its cut rim is still open.
        hollow_scale = getattr(props, "sharp_hollow_scale", 0.8)
        # Keep Wall v4 state: the per-piece patch inputs, keyed by piece
        # name, and the shared bookkeeping the console line reports.
        keep_wall_by_piece = {}
        # I2 (final review 2026-09-13): `adopted` is the SET of source cluster
        # indices a patch was actually adopted for, because that -- not the
        # number of per-piece patches -- is what "N concave region(s)" means to
        # the user. A dent straddling a seam is patched once per owner and was
        # reported twice, indistinguishable from a source with two dents. A
        # rolled-back group contributes nothing.
        keep_wall_state = {"records": 0, "adopted": set(), "failures": [], "walls": [],
                           "source": pieces[0].name if pieces else "<source>"}
        # Owner pieces whose patch is built but not yet adopted: their group
        # must resolve first (atomic synchronized rims).
        keep_wall_pending = []
        if (hollow_on and shape == 'SURFACE'
                and bool(getattr(props, "sharp_keep_wall", False))
                and 0.0 < hollow_scale < 1.0):
            source_mesh = getattr(self, "_run_source_mesh", None)
            union_mesh = None
            try:
                if source_mesh is None:
                    # Direct calls (tests pass `self=None`) have no snapshot:
                    # rebuild the source surface from the pieces' role-1
                    # faces, which at this point carry no fill cap yet.
                    source_mesh = union_mesh = (
                        TOOL3D_OT_split_mark_sharp._keep_wall_union_mesh(pieces))
                if source_mesh is not None:
                    # v4 (2026-09-13): the SOURCE analysis is all that is
                    # shared now. Every piece is built by the ordinary
                    # `_hollow_piece` bridge -- the Keep Wall OFF shell --
                    # and only the pieces that actually carry part of a
                    # concave cluster get their inner surface patched, so a
                    # detached piece with no dent comes out identical to OFF
                    # and every piece still meets its neighbour at the cut.
                    # The owner mapping runs HERE, before the offset moves
                    # any rim vertex and while the pieces still match the
                    # source face for face.
                    plan, thickness, _min_depth, _epsilon = (
                        TOOL3D_OT_split_mark_sharp._keep_wall_source_plan(
                            source_mesh, hollow_scale))
                    if plan:
                        assigned, unmapped = (
                            TOOL3D_OT_split_mark_sharp._keep_wall_assign_clusters(
                                pieces, source_mesh, plan))
                        keep_wall_by_piece = assigned
                        keep_wall_state["records"] = len(plan)
                        # Exception B (user decision 2026-09-13): the shared
                        # inner rim vertices every sharer agrees on. Computed
                        # here, before the offset, from the same pre-offset
                        # pieces the ownership came from.
                        keep_wall_moves = (
                            TOOL3D_OT_split_mark_sharp._keep_wall_shared_rim_moves(
                                pieces, assigned))
                        for name, per_cluster in keep_wall_moves.items():
                            for record in keep_wall_by_piece.get(name, ()):
                                record["movable"] = per_cluster.get(record["index"], set())
                        # Group identity -- every piece owning a cluster is one
                        # atomic participant set, and if any of them fails the
                        # whole group rolls back -- is carried by the CLUSTER
                        # INDEX itself: each pending entry lists the clusters
                        # its piece owns, and the resolution below fails every
                        # entry sharing a failed index. A precomputed
                        # `{index: [piece name]}` map was built here and never
                        # read (final review I2); it is not rebuilt, so there
                        # is one representation of the group, not two.
                        for reason in unmapped:
                            # A cluster whose owner cannot be established is
                            # NOT treated as convex: it is reported, and the
                            # pieces keep the plain scaled surface.
                            keep_wall_state["failures"].append(reason)
            except TOOL3D_OT_split_mark_sharp._RECOVERABLE_ERRORS as exc:
                keep_wall_by_piece = {}
                keep_wall_state["failures"].append(
                    "keep wall analysis failed: {}: {}".format(type(exc).__name__, exc))
            finally:
                if union_mesh is not None and union_mesh.users == 0:
                    bpy.data.meshes.remove(union_mesh)

        for piece in pieces:
            if not piece or piece.name not in bpy.data.objects:
                continue

            piece_mesh = piece.data
            classify_tolerance = max(
                TOOL3D_OT_split_mark_sharp._mesh_diagonal(piece) * 1.0e-6, 1.0e-8)

            piece_bm = bmesh.new()
            had_cut_edges = False
            refreshed_provenance = provenance
            try:
                piece_bm.from_mesh(piece_mesh)
                piece_bm.verts.ensure_lookup_table()
                piece_bm.edges.ensure_lookup_table()
                piece_bm.faces.ensure_lookup_table()

                cut_edges_by_id = TOOL3D_OT_split_mark_sharp._classify_boundary_edges(
                    piece_bm, provenance, classify_tolerance)
                had_cut_edges = bool(cut_edges_by_id)

                if had_cut_edges and props.sharp_offset_value and props.sharp_offset_value > 0.0:
                    collided = TOOL3D_OT_split_mark_sharp._offset_cut_boundary_verts(
                        self, piece_bm, cut_edges_by_id, props.sharp_offset_value)
                    if collided:
                        result["offset_warnings"] += 1

                    # I4: refresh provenance from the MOVED rim, straight
                    # from the same still-open BMesh whose vertices were
                    # just displaced -- before the write-back, while the
                    # classified BMEdge objects are still valid. These are
                    # the coordinates the mesh will actually have on disk,
                    # so the signature fallback can match them.
                    refreshed_provenance = {}
                    for cut_id, edge_list in cut_edges_by_id.items():
                        refreshed_provenance[cut_id] = {
                            "edge_signatures": [
                                TOOL3D_OT_split_mark_sharp._edge_signature(
                                    edge.verts[0].co, edge.verts[1].co,
                                    classify_tolerance)
                                for edge in edge_list
                                if edge.is_valid
                            ],
                        }

                    piece_bm.to_mesh(piece_mesh)
                    piece_mesh.update()
            finally:
                piece_bm.free()

            if not had_cut_edges:
                continue

            # Recompute the tolerance AND every cut-rim signature from the
            # mesh's FINAL, already-written-back state (a fresh BMesh
            # opened on `piece_mesh` here), never from the pre-offset/
            # pre-round-trip BMesh above. This is not optional: `_mesh_
            # diagonal` depends on the mesh's own bounding box, and even a
            # small offset measurably shrinks/grows that bbox (e.g.
            # raising a bottom cut ring by 0.01 shortens the height
            # extent) -- `_fill_cut_loops` and `_bevel_cut_edges` each
            # independently recompute their own matching tolerance from
            # whatever the CURRENT mesh looks like when they run, so a
            # signature encoded here with a stale (pre-offset) tolerance
            # would quantize to a different grid than the one they decode
            # against, silently failing every single match. Using this
            # exact same _mesh_diagonal-based formula, applied to the
            # exact same (already offset, already written-back) mesh
            # state, keeps every grid identical end-to-end.
            final_tolerance = max(
                TOOL3D_OT_split_mark_sharp._mesh_diagonal(piece) * 1.0e-6, 1.0e-8)

            # I4: signatures in `refreshed_provenance` were quantized on the
            # pre-write-back grid (`classify_tolerance`). Re-quantize them
            # onto `final_tolerance`'s grid so the signature-only fallback
            # below decodes against the same grid it was encoded with.
            if refreshed_provenance is not provenance:
                requantized = {}
                for cut_id, data in refreshed_provenance.items():
                    requantized[cut_id] = {
                        "edge_signatures": [
                            TOOL3D_OT_split_mark_sharp._requantize_signature(
                                signature, classify_tolerance, final_tolerance)
                            for signature in data.get("edge_signatures", ())
                        ],
                    }
                refreshed_provenance = requantized

            cut_boundary_signatures = {}
            rim_signatures = set()
            verify_bm = bmesh.new()
            try:
                verify_bm.from_mesh(piece_mesh)
                verify_bm.verts.ensure_lookup_table()
                verify_bm.edges.ensure_lookup_table()

                final_cut_edges_by_id = TOOL3D_OT_split_mark_sharp._classify_boundary_edges(
                    verify_bm, refreshed_provenance, final_tolerance)
                for cut_id, edge_list in final_cut_edges_by_id.items():
                    sigs = [
                        TOOL3D_OT_split_mark_sharp._edge_signature(
                            edge.verts[0].co, edge.verts[1].co, final_tolerance)
                        for edge in edge_list
                    ]
                    cut_boundary_signatures[cut_id] = sigs
                    rim_signatures.update(sigs)
            finally:
                verify_bm.free()

            if not cut_boundary_signatures:
                # I4: the pre-offset pass found a real cut rim on this
                # piece but the post-offset pass cannot find it any more.
                # Record it instead of continuing silently.
                result["fill_failures"].append(
                    TOOL3D_OT_split_mark_sharp._failure_record(
                        piece.name,
                        "cut boundary was classified before offset but could "
                        "not be re-classified afterwards (marker layer and "
                        "signature fallback both failed) -- not filled or "
                        "beveled",
                    )
                )
                continue

            bevel_signatures = {"outer": list(rim_signatures)}
            bevel_allowed = True
            wall = None
            # Keep Wall v4 (2026-09-13): SURFACE never force-caps any more.
            # Every piece takes the ordinary bridge, and only a piece that
            # OWNS part of a concave cluster carries a `flatten` payload,
            # which patches its inner surface in place. The shape-key
            # fallback is kept, with its warning: the patch is BMesh-only,
            # but the shape layers of a patched inner surface are not ours
            # to rebuild, so such a piece keeps the plain scaled surface.
            piece_records = keep_wall_by_piece.get(piece.name) or []
            flatten = None
            if piece_records and piece.data.shape_keys is not None:
                piece_records = []
                print("[Tool3D] hollow: {} carries shape keys, so Keep Wall falls "
                      "back to the plain scaled surface for it".format(piece.name))
                result["fill_failures"].append(
                    TOOL3D_OT_split_mark_sharp._failure_record(
                        piece.name,
                        "hollow: keep wall flatten skipped: piece has shape keys; "
                        "hollowed with the plain scaled surface instead"))
            if piece_records:
                flatten = {"records": piece_records, "failures": [],
                           "adopted": set(), "walls": []}
            if shape != 'SURFACE':
                # Shape hollow needs a CLOSED piece: cap first, whatever
                # sharp_auto_fill says. The carve itself runs after this
                # loop, once for the whole source (one shared primitive).
                filled, fill_failures = TOOL3D_OT_split_mark_sharp._fill_cut_loops(
                    self, piece, cut_boundary_signatures, props.sharp_fill_tolerance)
                result["fill_failures"].extend(fill_failures)
                if fill_failures:
                    result["fill_count"] += filled
                    bevel_allowed = False
                else:
                    prepared.append((piece, filled))
                    continue
            elif hollow_on:
                rings, reason, rim_data = TOOL3D_OT_split_mark_sharp._hollow_piece(
                    self, piece, cut_boundary_signatures,
                    getattr(props, "sharp_hollow_scale", 0.8),
                    getattr(props, "sharp_crease_angle", math.radians(15.0)),
                    flatten)
                if rings:
                    result["fill_count"] += rings
                if reason:
                    result["fill_failures"].append(
                        TOOL3D_OT_split_mark_sharp._failure_record(
                            piece.name, "hollow: {}".format(reason)))
                    bevel_allowed = False
                else:
                    bevel_signatures, final_tolerance, wall = rim_data
                if flatten is not None:
                    # ATOMIC GROUP (user decision 2026-09-13): a piece that
                    # took the patch is only finished once every participant
                    # of its synchronized group has also succeeded. Its
                    # result is parked here and resolved after the loop, so a
                    # rollback can restore the unpatched shell BEFORE UV,
                    # bevel and shading ever run on it.
                    keep_wall_pending.append({
                        "piece": piece,
                        "flatten": flatten,
                        "clusters": [record["index"] for record in piece_records],
                        "bevel_signatures": bevel_signatures,
                        "tolerance": final_tolerance,
                        "wall": wall,
                        "bevel_allowed": bevel_allowed,
                    })
                    continue
            elif props.sharp_auto_fill:
                filled, fill_failures = TOOL3D_OT_split_mark_sharp._fill_cut_loops(
                    self, piece, cut_boundary_signatures, props.sharp_fill_tolerance)
                result["fill_count"] += filled
                result["fill_failures"].extend(fill_failures)

            finish_tasks.append((piece, bevel_signatures, final_tolerance,
                                 wall, bevel_allowed))

        # Resolve the synchronized groups before anything downstream sees the
        # pieces: a cluster whose participants did not ALL succeed is rolled
        # back on every one of them, so a shared rim is never left moved on
        # one side only.
        if keep_wall_pending:
            failed_clusters = set()
            for entry in keep_wall_pending:
                if entry["flatten"].get("failures"):
                    failed_clusters.update(entry["clusters"])
            for entry in keep_wall_pending:
                flatten = entry["flatten"]
                piece = entry["piece"]
                fallback = flatten.get("fallback_mesh")
                rolled_back = bool(set(entry["clusters"]) & failed_clusters)
                if rolled_back and fallback is not None:
                    old = piece.data
                    name = old.name
                    piece.data = fallback
                    fallback = None
                    if old.users == 0:
                        bpy.data.meshes.remove(old)
                        piece.data.name = name
                    # The mesh and the metadata describing it move together:
                    # `_hollow_piece` refreshed these from the PATCHED shell
                    # (C1), which this piece no longer has. Finishing it with
                    # those would hand the bevel signatures for geometry that
                    # was just discarded -- measured on the slab as 6 of 8
                    # inner rim edges unnameable and the bevel silently
                    # weakened, on a piece required to equal Keep Wall OFF.
                    prepatch = flatten.get("fallback_rim")
                    if prepatch is not None:
                        (entry["bevel_signatures"], entry["tolerance"],
                         entry["wall"]) = prepatch
                    message = ("Keep Wall could not flatten the concave region of "
                               "{} (another piece sharing this region could not be "
                               "patched, so the whole group was rolled back); it "
                               "keeps the plain scaled surface and may poke "
                               "through".format(piece.name))
                    keep_wall_state["failures"].append(message)
                    result["fill_failures"].append(
                        TOOL3D_OT_split_mark_sharp._failure_record(
                            piece.name, "hollow: {}".format(message)))
                elif not rolled_back:
                    keep_wall_state["adopted"].update(flatten.get("adopted", ()))
                    keep_wall_state["walls"].extend(flatten.get("walls", ()))
                for message in flatten.get("failures", ()):
                    keep_wall_state["failures"].append(message)
                    result["fill_failures"].append(
                        TOOL3D_OT_split_mark_sharp._failure_record(
                            piece.name, "hollow: {}".format(message)))
                if fallback is not None and fallback.users == 0:
                    bpy.data.meshes.remove(fallback)
                flatten.pop("fallback_mesh", None)
                flatten.pop("fallback_rim", None)
                finish_tasks.append((piece, entry["bevel_signatures"],
                                     entry["tolerance"], entry["wall"], entry["bevel_allowed"]))

        if prepared:
            scale = getattr(props, "sharp_hollow_scale", 0.8)
            self_bbox = getattr(self, "_run_source_bbox", None)
            if self_bbox is None:
                from mathutils import Vector
                coords = [v.co for piece, _ in prepared for v in piece.data.vertices]
                self_bbox = (Vector(tuple(min(c[a] for c in coords) for a in range(3))),
                             Vector(tuple(max(c[a] for c in coords) for a in range(3))))
            bbox_min, bbox_max = self_bbox
            if shape == 'HULL':
                coords = [v.co.copy() for piece, _ in prepared for v in piece.data.vertices]
                build = lambda s: TOOL3D_OT_split_mark_sharp._hollow_shape_hull(coords, s)
            else:
                build = lambda s: TOOL3D_OT_split_mark_sharp._hollow_shape_primitive(
                    shape, bbox_min, bbox_max, s)
            try:
                shape_primitive, used = TOOL3D_OT_split_mark_sharp._hollow_shape_fit_scale(
                    build, [piece for piece, _ in prepared], scale)
            except TOOL3D_OT_split_mark_sharp._RECOVERABLE_ERRORS as exc:
                shape_primitive, used = None, scale
                shape_blocked = "shape primitive failed: {}".format(exc)
            if shape_primitive is None and shape_blocked is None:
                shape_blocked = ("shape cannot fit inside the wall at any scale >= 0.1")
            elif shape_primitive is not None and used < scale - 1.0e-9:
                result["hollow_warnings"] += 1
                print("[Tool3D] hollow shape: {} scale {:.3g} -> {:.3g} "
                      "(shape would pierce the wall)".format(
                          prepared[0][0].name, scale, used))
            try:
                for piece, filled in prepared:
                    bevel_signatures = {"outer": []}
                    bevel_allowed = True
                    wall = None
                    tolerance = max(
                        TOOL3D_OT_split_mark_sharp._mesh_diagonal(piece) * 1.0e-6, 1.0e-8)
                    if shape_blocked is not None:
                        result["fill_count"] += filled
                        result["fill_failures"].append(
                            TOOL3D_OT_split_mark_sharp._failure_record(
                                piece.name, "hollow: {}".format(shape_blocked)))
                        bevel_allowed = False
                    else:
                        # Fix pass (review): a recoverable error escaping the
                        # carve is contained PER PIECE -- it becomes this
                        # piece's failure record and the loop moves on, so one
                        # bad piece can no longer abandon the remaining ones
                        # (they would keep their flat cap but lose UV/shading).
                        try:
                            rings, reason, rim_data = TOOL3D_OT_split_mark_sharp._hollow_piece_shape(
                                self, context, piece, shape_primitive)
                            if reason:
                                result["fill_count"] += filled
                                result["fill_failures"].append(
                                    TOOL3D_OT_split_mark_sharp._failure_record(
                                        piece.name, "hollow: {}".format(reason)))
                                bevel_allowed = False
                            else:
                                # Rings opened through the cap; an enclosed void
                                # leaves the flat cap(s) counted as filled instead.
                                result["fill_count"] += rings if rings else filled
                                bevel_signatures, tolerance, wall = rim_data
                                if rings == 0:
                                    # Enclosed void: keep the piece and warn
                                    # (spec asks for nothing more). The bevel
                                    # still runs -- `rim_data` carries the
                                    # outer signatures and `wall is None`, so
                                    # `_bevel_cut_edges` bevels the cut rim and
                                    # skips the `width * 2 > wall` guard.
                                    result["hollow_warnings"] += 1
                                    print("[Tool3D] hollow shape: cavity is fully enclosed in {}".format(
                                        piece.name))
                        except TOOL3D_OT_split_mark_sharp._RECOVERABLE_ERRORS as exc:
                            result["fill_count"] += filled
                            result["fill_failures"].append(
                                TOOL3D_OT_split_mark_sharp._failure_record(
                                    piece.name, "hollow: {}: {}".format(
                                        type(exc).__name__, exc)))
                            bevel_allowed = False
                    finish_tasks.append((piece, bevel_signatures, tolerance,
                                         wall, bevel_allowed))
            finally:
                if shape_primitive is not None and shape_primitive.users == 0:
                    bpy.data.meshes.remove(shape_primitive)

        # Standardize bevel width across all pieces produced from this split
        # (user request 2026-10-05): when one piece reaches its bevel limit
        # (due to clamp_overlap or hollow wall thickness), standardize all
        # other pieces to that same limited bevel width so they match.
        standardized_width = getattr(props, "sharp_bevel_width", 0.01)
        if getattr(props, "sharp_auto_bevel", False) and finish_tasks:
            limits = []
            for piece, b_sigs, tol, w_wall, b_allowed in finish_tasks:
                if b_allowed and b_sigs:
                    achieved = TOOL3D_OT_split_mark_sharp._measure_clamped_bevel_width(
                        piece, b_sigs, standardized_width, tol, wall=w_wall)
                    if achieved is not None and achieved > 1.0e-4:
                        limits.append(achieved)
            if limits:
                min_limit = min(limits)
                if min_limit < standardized_width - 1.0e-6:
                    standardized_width = max(min_limit, 0.0001)
                    print("[Tool3D] standardized bevel width across {} piece(s): {:.4g} -> {:.4g}".format(
                        len(finish_tasks), getattr(props, "sharp_bevel_width", 0.01), standardized_width))

        for piece, b_sigs, tol, w_wall, b_allowed in finish_tasks:
            TOOL3D_OT_split_mark_sharp._hollow_finish_piece(
                self, context, piece, props, result, b_sigs, tol,
                w_wall, b_allowed, width=standardized_width)

        if keep_wall_state["records"] or keep_wall_state["failures"]:
            # One warning per SOURCE, exactly as v3 reported, and the panel
            # wall is the thinnest wall an ADOPTED panel leaves under its
            # dent floor. A run where nothing was adopted prints no "panel
            # wall" line at all: a fallback is never reported as a flatten.
            result["hollow_warnings"] += 1
            if keep_wall_state["adopted"] and keep_wall_state["walls"]:
                print("[Tool3D] hollow: Keep Wall flattened {} concave region(s) "
                      "of {} (panel wall {:.4g}{})".format(
                          len(keep_wall_state["adopted"]), keep_wall_state["source"],
                          min(keep_wall_state["walls"]),
                          ", {} skipped".format(len(keep_wall_state["failures"]))
                          if keep_wall_state["failures"] else ""))
        return result

    def _hollow_finish_piece(self, context, piece, props, result, bevel_signatures,
                             final_tolerance, wall, bevel_allowed, width=None):
        """UV roles -> bevel (if enabled and allowed) -> shading, the tail
        every piece runs regardless of how its cut was closed."""
        TOOL3D_OT_split_mark_sharp._assign_cut_uv(piece)
        if width is None:
            width = props.sharp_bevel_width
        if props.sharp_auto_bevel and bevel_allowed:
            count, reason = TOOL3D_OT_split_mark_sharp._bevel_cut_edges(
                self, context, piece, bevel_signatures,
                width, props.sharp_bevel_segments,
                final_tolerance, wall=wall)
            if count:
                result["bevel_count"] += count
            if reason:
                result["fill_failures"].append(
                    TOOL3D_OT_split_mark_sharp._failure_record(
                        piece.name, "bevel: {}".format(reason)))
        TOOL3D_OT_split_mark_sharp._shade_cut_piece(piece)

    @staticmethod
    def _assign_cut_uv(obj):
        mesh = obj.data
        if mesh.uv_layers.active is None:
            mesh.uv_layers.new(name="UVMap")
        bm = bmesh.new()
        try:
            bm.from_mesh(mesh)
            role = bm.faces.layers.int.get(_SEAM_FACE_ROLE)
            if role is None:
                raise RuntimeError("cut face provenance missing before UV assignment")
            uv = bm.loops.layers.uv.get(mesh.uv_layers.active.name)
            for face in bm.faces:
                coord = _SEAM_UV[face[role]]
                for loop in face.loops:
                    loop[uv].uv = coord
            bm.to_mesh(mesh)
        finally:
            bm.free()
        mesh.update()

    # keep_sharp on the WEIGHTED_NORMAL modifier only keeps a crease that is
    # already marked sharp; 45 degrees is measured (2026-09-12) to sit
    # between a real 90-degree corner and a 3-segment bevel's per-segment
    # turn (30 degrees each) on that same corner, so the bevel profile
    # stays smooth while the corner itself comes out sharp.
    # 44.5 degrees, NOT 45: a UV sphere cut into 16 wedges (meridians every
    # 45 degrees) carries shell edges whose true dihedral angle IS 45
    # degrees, and the instancer's edge signature includes the sharp flag,
    # so a threshold that coincides with a real crease angle flips between
    # congruent rotated copies on ~1e-5 degree floating-point noise and
    # stops them linking (measured 2026-09-12: 44.999991 vs 45.000001).
    # The angle is also quantized to `_SHADE_SHARP_QUANTUM` before the
    # compare, so noise far below the quantum can never straddle it.
    _SHADE_SHARP_ANGLE = math.radians(44.5)
    _SHADE_SHARP_QUANTUM = math.radians(0.1)

    @staticmethod
    def _shade_is_crease(angle):
        """True when a dihedral `angle` (radians) counts as a sharp crease.

        The angle is quantized to `_SHADE_SHARP_QUANTUM` BEFORE the
        compare so congruent pieces (rotated copies of one another) always
        classify a given crease the same way -- the flag is part of the
        instancer's edge signature. `round()` is banker's rounding on an
        exact half-quantum tie (an odd multiple of 0.05 degrees); no
        natural crease of a split/hollowed piece (0, 30, 45, 90 degrees)
        sits there, and the threshold itself is a whole quantum. Keep it
        that way if either constant is ever changed. The ONE place this
        rule lives: the tests call it too, so they can never drift from
        the implementation.
        """
        quantum = TOOL3D_OT_split_mark_sharp._SHADE_SHARP_QUANTUM
        quantized = round(angle / quantum) * quantum
        return quantized > TOOL3D_OT_split_mark_sharp._SHADE_SHARP_ANGLE

    @staticmethod
    def _shade_cut_piece(obj):
        """Shade Smooth every face, then mark real creases sharp.

        Shade Smooth alone smears shading across any genuine 90-degree
        corner a cut piece can carry (boolean-carved cavities, cube
        corners, cut rims: the geometry is correct, only the shading
        reads wrong), and the WEIGHTED_NORMAL modifier's `keep_sharp`
        has nothing to keep unless some edge is actually marked sharp.
        So after the blanket Shade Smooth, every interior edge (exactly
        2 link faces) is marked sharp or not from the dihedral angle
        between its two face normals against `_SHADE_SHARP_ANGLE`;
        boundary and non-manifold edges are left untouched.
        """
        for face in obj.data.polygons:
            face.use_smooth = True

        bm = bmesh.new()
        try:
            bm.from_mesh(obj.data)
            bm.normal_update()
            for edge in bm.edges:
                if len(edge.link_faces) != 2:
                    continue
                face_a, face_b = edge.link_faces
                try:
                    angle = face_a.normal.angle(face_b.normal)
                except ValueError:
                    # Degenerate (zero-length) face normal: no crease can be
                    # measured, so the edge is FORCED smooth -- a stale sharp
                    # flag inherited from the source mesh must not survive
                    # here, because this rule owns the flag on tool-made
                    # pieces (and the flag feeds the instancer's signature).
                    edge.smooth = True
                    continue
                edge.smooth = not TOOL3D_OT_split_mark_sharp._shade_is_crease(angle)
            bm.to_mesh(obj.data)
        finally:
            bm.free()

        name = obj.get(_WEIGHTED_NORMAL_OWNER, "")
        modifier = obj.modifiers.get(name)
        if modifier is None or modifier.type != 'WEIGHTED_NORMAL':
            modifier = obj.modifiers.new("3D tool Face Area", 'WEIGHTED_NORMAL')
            obj[_WEIGHTED_NORMAL_OWNER] = modifier.name
        modifier.mode = 'FACE_AREA'
        modifier.weight = 50
        modifier.keep_sharp = True
        obj.modifiers.move(list(obj.modifiers).index(modifier), len(obj.modifiers) - 1)
        obj.data.update()

    def _hollow_piece(self, obj, cut_boundaries, scale, crease_angle=math.radians(15.0),
                      flatten=None):
        """Return (ring_count, reason, (rim_signatures, tolerance, wall))
        where `wall` is the shortest outer->inner rung, i.e. the bridge band
        width.

        `flatten` is the OPTIONAL Keep Wall v4 input (2026-09-13) and
        defaults to None, which leaves this function exactly the plain
        Keep Wall OFF hollow it has always been -- a piece that owns no
        concave cluster passes None and comes out identical. When given, it
        is `{"records": [...], "failures": [...]}` from
        `_keep_wall_assign_clusters`: the shell is built first, in full, and
        only then is the dent's part of the INNER surface patched by
        `_hollow_inner_flatten_patch` on a copy. A patch that cannot be built
        is rolled back and its reason appended to `flatten["failures"]`, so
        the piece keeps this closed bridge shell and the caller reports it.

        The piece's whole surface is duplicated and the duplicate scaled
        by `scale` (0 < scale < 1) towards the OBJECT ORIGIN in local
        space, with its face winding flipped so the inner surface faces
        the cavity. Each cut boundary edge of the outer surface (and only
        those -- a pre-existing/unmarked hole is left alone, as always) is
        then bridged to its scaled twin with one quad, so the former cut
        face becomes a flat ring between the two surfaces: the shell is
        closed and manifold. No cap is created anywhere.

        The origin is the user's chosen centre: with the source's origin at
        its middle every wall is offset inward along the surface normal
        and the cut bands stay square. A per-piece centroid was tried and
        rejected (2026-09-10): it tilts the inner surface of every piece
        whose centroid is off the object centre. Shape-key layers of the
        new inner vertices are set to their own scaled position.

        The offset itself is the PURE origin scale, unconditionally: the
        Keep Wall fix is not a different cavity but a LOCAL patch applied to
        this shell afterwards, above. (M4, final review 2026-09-13: this
        paragraph still described the v2/v3 architecture -- one eroded
        cavity per SOURCE, built in `_apply_mark_sharp_settings` and carved
        with `_hollow_piece_shape` -- which no longer exists for SURFACE and
        contradicted the `flatten` text above it.) With Keep Wall OFF, on a
        convex source, and for a piece carrying shape keys, `flatten` is
        None and this is the whole story.

        `cut_boundaries` is `{cut_id: [edge_signature, ...]}` in the same
        portable form `_fill_cut_loops` takes, resolved here against the
        piece's current boundary edges. Everything happens in one BMesh
        with a single write-back, and nothing is written when no cut edge
        resolved, so a failure never leaves a half-hollowed piece.
        """
        if not cut_boundaries:
            return 0, "no cut boundaries supplied", None
        if not (0.0 < scale < 1.0):
            return 0, "hollow scale must be strictly between 0 and 1, got {}".format(scale), None

        mesh = obj.data
        diagonal = TOOL3D_OT_split_mark_sharp._mesh_diagonal(obj)
        signature_tolerance = max(diagonal * 1.0e-6, 1.0e-8)

        bm = bmesh.new()
        try:
            bm.from_mesh(mesh)
            bm.verts.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.faces.ensure_lookup_table()

            # All layers first: creating one later would invalidate the
            # element wrappers collected below.
            face_role = bm.faces.layers.int.get(_SEAM_FACE_ROLE)
            if face_role is None:
                face_role = bm.faces.layers.int.new(_SEAM_FACE_ROLE)
            vert_side = bm.verts.layers.int.get(_SEAM_VERT_SIDE)
            if vert_side is None:
                vert_side = bm.verts.layers.int.new(_SEAM_VERT_SIDE)
            fold_layer = bm.edges.layers.int.get(_SEAM_FOLD_EDGE)
            if fold_layer is None:
                fold_layer = bm.edges.layers.int.new(_SEAM_FOLD_EDGE)

            wanted = set()
            for signatures in cut_boundaries.values():
                wanted.update(signatures)
            cut_edges = []
            for edge in bm.edges:
                if not edge.is_boundary:
                    continue
                signature = TOOL3D_OT_split_mark_sharp._edge_signature(
                    edge.verts[0].co, edge.verts[1].co, signature_tolerance)
                if signature in wanted:
                    cut_edges.append(edge)
            if not cut_edges:
                return 0, "no current boundary edge matched the cut signatures", None
            if not bm.faces:
                return 0, "piece has no faces to hollow", None
            outer_faces = list(bm.faces)
            outer_verts = list(bm.verts)
            if any(vert.co.length * (1.0 - scale) <= signature_tolerance
                   for edge in cut_edges for vert in edge.verts):
                return 0, ("a cut vertex sits at the object origin, so scaling about "
                           "the origin cannot separate the inner surface"), None
            for face in outer_faces:
                face[face_role] = 1
            for vert in outer_verts:
                vert[vert_side] = 1

            # Duplicate the whole outer surface, then scale the copy.
            dup = bmesh.ops.duplicate(bm, geom=outer_verts + list(bm.edges) + outer_faces)
            vert_map = dup["vert_map"]
            face_map = dup.get("face_map", {})
            inner_faces = [g for g in dup["geom"] if isinstance(g, bmesh.types.BMFace)]
            inner_verts = [g for g in dup["geom"] if isinstance(g, bmesh.types.BMVert)]
            shape_layers = list(bm.verts.layers.shape.values())
            for face in inner_faces:
                face[face_role] = 2
            for vert in inner_verts:
                vert[vert_side] = 2
                vert.co = vert.co * scale
                for layer in shape_layers:
                    vert[layer] = vert.co.copy()

            # The inner surface faces the cavity: reverse its winding.
            bmesh.ops.reverse_faces(bm, faces=inner_faces)

            # Bridge each outer cut edge to its inner twin with one quad.
            ring_faces = []
            bridge_of = {}
            for edge in cut_edges:
                v0, v1 = edge.verts
                i0, i1 = vert_map.get(v0), vert_map.get(v1)
                if i0 is None or i1 is None:
                    raise RuntimeError("inner twin missing for a cut edge")
                # Winding: continue the outer face's traversal direction
                # across the ring so the ring's normal points outward from
                # the cavity, consistent with both surfaces.
                outer_face = edge.link_faces[0]
                goes_forward = False
                for loop in outer_face.loops:
                    if loop.vert is v0 and loop.link_loop_next.vert is v1:
                        goes_forward = True
                        break
                if goes_forward:
                    quad = (v1, v0, i0, i1)
                else:
                    quad = (v0, v1, i1, i0)
                existing = bm.faces.get(quad)
                if existing is not None:
                    bridge_of[edge] = existing
                    continue
                face = bm.faces.new(quad)
                face[face_role] = 0
                ring_faces.append(face)
                bridge_of[edge] = face

            bm.normal_update()
            bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
            bm.normal_update()

            # A rung (outer rim vertex -> inner twin) is a crease of the
            # bridge band wherever the band changes plane: a ring crossing,
            # or a corner where the rim turns onto another cut plane. Those
            # are beveled together with the rims. Along one planar ring the
            # band is flat, so its rungs stay untouched.
            crease_cos = math.cos(crease_angle)
            rim_edges_of = {}
            for edge in cut_edges:
                for vert in edge.verts:
                    rim_edges_of.setdefault(vert, []).append(edge)
            for vert, edges in rim_edges_of.items():
                crease = len(edges) != 2
                if not crease:
                    quads = [bridge_of.get(edge) for edge in edges]
                    if None not in quads:
                        crease = quads[0].normal.dot(quads[1].normal) < crease_cos
                if crease:
                    rung = bm.edges.get((vert, vert_map[vert]))
                    if rung is not None:
                        rung[fold_layer] = 1
            tolerance = _bbox_tolerance(bm)
            signatures = {"outer": [], "inner": []}
            wall = None
            for edge in cut_edges:
                a, b = edge.verts
                signatures["outer"].append(TOOL3D_OT_split_mark_sharp._edge_signature(
                    a.co, b.co, tolerance))
                signatures["inner"].append(TOOL3D_OT_split_mark_sharp._edge_signature(
                    vert_map[a].co, vert_map[b].co, tolerance))
                for vert in (a, b):
                    rung = (vert.co - vert_map[vert].co).length
                    wall = rung if wall is None else min(wall, rung)
            ring_count = len(TOOL3D_OT_split_mark_sharp._connected_edge_loops(cut_edges))

            # Keep Wall v4: patch the inner surface only, and only after the
            # whole OFF shell exists. The inner twin of each owned outer face
            # comes from the duplicate's own `face_map` -- a real identity,
            # not a nearest-face guess -- and is carried as an INDEX because
            # the patch runs on a copy of this BMesh.
            if flatten and flatten.get("records"):
                bm.faces.ensure_lookup_table()
                # `outer_faces` was taken as `list(bm.faces)` before the
                # duplicate, i.e. in mesh polygon order, so a record's face
                # index into the piece MESH indexes it directly.
                outer_faces_by_index = outer_faces
                records = []
                missing = 0
                for record in flatten["records"]:
                    inner_indices = []
                    for face_index in record["faces"]:
                        if face_index >= len(outer_faces_by_index):
                            missing += 1
                            continue
                        twin = face_map.get(outer_faces_by_index[face_index])
                        if twin is None or not twin.is_valid:
                            missing += 1
                            continue
                        inner_indices.append(twin.index)
                    if inner_indices:
                        local = dict(record)
                        local["inner_faces"] = inner_indices
                        # Exception B: the caller names the movable vertices
                        # by OUTER index (stable from before the offset); the
                        # duplicate's own vertex map turns each into the
                        # INNER twin that may actually be projected.
                        # Carried as INDICES, like `inner_faces`: the patch
                        # runs on a copy of this BMesh, where element order
                        # is preserved but the wrappers are not shared.
                        bm.verts.ensure_lookup_table()
                        movable_twins = set()
                        for outer_index in record.get("movable") or ():
                            if outer_index >= len(outer_verts):
                                continue
                            twin = vert_map.get(outer_verts[outer_index])
                            if twin is not None and twin.is_valid:
                                movable_twins.add(twin.index)
                        local["movable_verts"] = movable_twins
                        records.append(local)
                if missing:
                    flatten["failures"].append(
                        "{} concave face(s) of {} have no inner twin in the "
                        "hollow shell".format(missing, obj.name))
                if records:
                    patched, reason = TOOL3D_OT_split_mark_sharp._hollow_inner_flatten_patch(
                        bm, records, _SEAM_VERT_SIDE, _SEAM_FACE_ROLE)
                    if patched is None:
                        flatten["failures"].append(
                            "Keep Wall could not flatten the concave region of "
                            "{} ({}); it keeps the plain scaled surface and may "
                            "poke through".format(obj.name, reason))
                    else:
                        # C1 (final review 2026-09-13): the rim signatures
                        # captured above describe the UNPATCHED shell, and
                        # exception B MOVES inner rim vertices -- six of the
                        # slab's eight inner rim signatures per piece named
                        # coordinates nothing sat at any more, so the bevel ran
                        # on a partial rim, produced a zero-area face and was
                        # discarded whole (40 edges with Keep Wall OFF, 0 with
                        # it ON). They are read off the PATCHED shell instead,
                        # by topology rather than by the pre-patch wrappers the
                        # copy did not carry over.
                        #
                        # This happens BEFORE the patch is adopted, so a shell
                        # whose rim cannot be read needs no unwinding: the
                        # patch is simply refused, exactly like any other
                        # refusal, and the group rolls back through the one
                        # path that already exists. FAILING CLOSED is the point
                        # -- silently keeping the pre-patch signatures here
                        # would reinstate C1's defect (stale metadata against
                        # patched geometry) while still reporting success.
                        refreshed = TOOL3D_OT_split_mark_sharp._hollow_rim_signatures(
                            patched)
                        if refreshed is None:
                            patched.free()
                            flatten["failures"].append(
                                "Keep Wall could not flatten the concave region of "
                                "{} (the patched shell's cut rim could not be read "
                                "back); it keeps the plain scaled surface and may "
                                "poke through".format(obj.name))
                        else:
                            # Atomic group rollback (user decision
                            # 2026-09-13): this piece may still have to give
                            # the patch back if another participant of its
                            # synchronized group fails, and a seam moved on one
                            # side only would be worse than no patch at all.
                            # The UNPATCHED shell is kept as a scratch
                            # datablock so the caller can restore it exactly;
                            # it is dropped either way once the group is
                            # resolved.
                            fallback = bpy.data.meshes.new("_tool3d_keepwall_fallback")
                            # C2 (final review 2026-09-13): `bm.to_mesh`
                            # carries each face's `material_index` but NOT the
                            # mesh's material SLOT list, so a bare `new()`
                            # restored a piece whose faces all pointed past the
                            # end of an empty list -- the rolled-back piece
                            # rendered untextured. The slots are copied from
                            # the piece's own mesh first, empty ones included
                            # so every index still means what it meant.
                            # `materials.append` only adds a user of the
                            # material; the source mesh is not touched.
                            for slot in mesh.materials:
                                fallback.materials.append(slot)
                            bm.to_mesh(fallback)
                            fallback.update()
                            flatten["fallback_mesh"] = fallback
                            # The metadata describing the shell being parked
                            # travels WITH it (2026-09-13, same wave as C1):
                            # `signatures`/`wall` are about to become the
                            # PATCHED shell's, and a group that rolls back
                            # restores this pre-patch mesh -- so a restored
                            # piece finished with patched-shell metadata is C1
                            # inverted (measured: 6 of the slab's 8 inner rim
                            # edges unnameable, the bevel discarded on a piece
                            # that is supposed to be exactly Keep Wall OFF).
                            flatten["fallback_rim"] = (signatures, tolerance, wall)
                            bm.free()
                            bm = patched
                            # The SOURCE cluster indices this piece adopted
                            # (I2): the caller unions them across pieces, so a
                            # dent straddling a seam counts once however many
                            # owners patch it.
                            adopted = flatten.setdefault("adopted", set())
                            for record in records:
                                adopted.add(record["index"])
                                flatten.setdefault("walls", []).append(
                                    record["level"] - record["floor"])
                            signatures, tolerance, refreshed_wall = refreshed
                            if refreshed_wall is not None:
                                wall = refreshed_wall

            bm.to_mesh(mesh)
            mesh.update()
            return ring_count, None, (signatures, tolerance, wall)
        finally:
            bm.free()

    @staticmethod
    def _hollow_rim_signatures(bm):
        """Return `(signatures, tolerance, wall)` read off a FINISHED hollow
        shell, or None when the shell is not shaped the way this reads it.

        The bridge band is the piece's role-0 faces, and each band quad
        carries exactly one OUTER rim edge (both ends on side 1), one INNER
        rim edge (both ends on side 2) and the rungs between them. So the
        rims -- and `wall`, the shortest rung -- are a property of the mesh
        as it actually is, not of wrappers captured before a patch moved
        anything. Everything is quantized on ONE grid, the final bbox's, and
        that same tolerance is returned so the consumer re-derives identical
        signatures.
        """
        face_role = bm.faces.layers.int.get(_SEAM_FACE_ROLE)
        vert_side = bm.verts.layers.int.get(_SEAM_VERT_SIDE)
        if face_role is None or vert_side is None:
            return None
        tolerance = _bbox_tolerance(bm)
        signatures = {"outer": [], "inner": []}
        wall = None
        seen = set()
        for face in bm.faces:
            if face[face_role] != 0:
                continue
            for edge in face.edges:
                if edge in seen:
                    continue
                seen.add(edge)
                a, b = edge.verts
                sides = (a[vert_side], b[vert_side])
                if sides == (1, 1):
                    signatures["outer"].append(
                        TOOL3D_OT_split_mark_sharp._edge_signature(
                            a.co, b.co, tolerance))
                elif sides == (2, 2):
                    signatures["inner"].append(
                        TOOL3D_OT_split_mark_sharp._edge_signature(
                            a.co, b.co, tolerance))
                else:
                    rung = (a.co - b.co).length
                    wall = rung if wall is None else min(wall, rung)
        if not signatures["outer"] or not signatures["inner"]:
            return None
        return signatures, tolerance, wall

    # ---------- Keep Wall v3: planar flatten cavity (2026-09-12) ----------
    #
    # A face is CONCAVE when its centre sits deeper than this fraction of
    # the wall thickness below the source's convex hull (floored, so a
    # near-flat source cannot be nudged into "concave" by float noise).
    _KEEP_WALL_DEPTH_FRACTION = 0.1
    _KEEP_WALL_MIN_DEPTH = 0.005
    # The cutting plane never lands exactly on a scaled face plane or on the
    # pocket rim: a bisect through coplanar geometry leaves slivers, and a
    # plane through the rim leaves a second boundary loop. Scaled by the
    # source's bbox diagonal, so it means the same thing on any model size.
    _KEEP_WALL_EPSILON_FRACTION = 1.0e-4

    @staticmethod
    def _keep_wall_mean_wall(mesh, scale):
        """The nominal wall thickness `t` an origin scale of `scale` leaves:
        the area-weighted mean over `mesh`'s faces of
        `(1 - scale) * max(0, centre . normal)`.

        `centre . normal` is how far a face sits from the origin along its
        own normal, i.e. exactly the distance the scale removes there; the
        area weighting makes one stray sliver irrelevant."""
        bm = bmesh.new()
        try:
            bm.from_mesh(mesh)
            bm.normal_update()
            numerator = denominator = 0.0
            for face in bm.faces:
                depth = face.calc_center_median().dot(face.normal)
                if depth > 0.0:
                    area = face.calc_area()
                    numerator += area * depth
                    denominator += area
            return (1.0 - scale) * (numerator / denominator if denominator else 1.0)
        finally:
            bm.free()

    @staticmethod
    def _keep_wall_flatten_level(scaled_mean, scaled_rim_max, floor, min_depth,
                                 epsilon):
        """Where the flatten panel's plane sits, along `n_in`, for one
        concave cluster. THE depth policy of Keep Wall v3 -- isolated here
        so it can be changed in one place.

        `max(scaled_mean, scaled_rim_max + epsilon, floor + min_depth)
        + epsilon`:

        - `scaled_mean` -- the area-weighted mean position of the cluster's
          SCALED faces (floor and side walls) along `n_in`. This is the
          user's own hand method: default hollow, select the dent's region
          of the inner face, Flatten at its centre.
        - `scaled_rim_max + epsilon` -- STRICTLY above the highest scaled
          RIM vertex. This is what makes the bisect leave a SINGLE section
          loop: the plane must clear the whole open rim left by deleting the
          pocket, so `clear_inner` removes that rim with everything else
          below it and the hole that remains has one boundary. On every
          current fixture (and on the user's mesh) the mean already sits
          above the rim, so the clamp is inactive -- it is kept as the
          guarantee, not as tuning.
        - `floor + min_depth` -- the poke-through guard. It only bites on a
          dent so deep and narrow that the mean would sit OUTSIDE the outer
          floor; the panel then sits `min_depth` under the floor instead.

        The trailing `epsilon` keeps the panel off any scaled face plane.
        ALTERNATIVE (one-line switch, kept documented because the user may
        prefer it after comparing renders): `return floor + thickness` -- a
        uniform nominal wall, which gives a larger, deeper disc (0.195 on
        the user's mesh against this rule's 0.116)."""
        return max(scaled_mean, scaled_rim_max + epsilon,
                   floor + min_depth) + epsilon

    @staticmethod
    def _keep_wall_concave_clusters(mesh, min_depth):
        """Return one dict per edge-connected cluster of faces whose centre
        lies deeper than `min_depth` below the convex hull of `mesh`:

            {"faces": [face index, ...],          # into `mesh`
             "n_in": Vector,                      # unit, points INTO the solid
             "floor": float,                      # max v.co . n_in, UNSCALED
             "mean_offset": float,                # area-weighted mean centre . n_in
             "rim_offset": float}                 # max rim vert . n_in

        `mean_offset` and `rim_offset` are UNSCALED (the caller multiplies
        by the hollow scale) and `n_in` is the inward normal of the cluster:
        the negated area-weighted mean face normal, or -- if that cancels
        out -- the radial direction from the cluster's area-weighted centre
        toward the origin. A cluster that can define neither is DEGENERATE
        and is dropped here, so it is skipped rather than aborting the
        source.

        The hull is the source's own `_hollow_shape_hull(coords, 1.0)`,
        queried through a BVH: `find_nearest`'s distance from a face centre
        to the hull is 0 on a convex surface and equal to the dent depth
        inside a cavity. A convex source therefore yields NO cluster, which
        is what keeps the legacy hollow behaviour exact.
        """
        from mathutils import Vector
        from mathutils.bvhtree import BVHTree
        coords = [vert.co.copy() for vert in mesh.vertices]
        if not coords:
            return []
        hull = TOOL3D_OT_split_mark_sharp._hollow_shape_hull(coords, 1.0)
        try:
            hull_bm = bmesh.new()
            try:
                hull_bm.from_mesh(hull)
                tree = BVHTree.FromBMesh(hull_bm)
            finally:
                hull_bm.free()
        finally:
            if hull.users == 0:
                bpy.data.meshes.remove(hull)

        bm = bmesh.new()
        try:
            bm.from_mesh(mesh)
            bm.faces.ensure_lookup_table()
            concave = set()
            ordered = []
            for face in bm.faces:
                _location, _normal, _index, distance = tree.find_nearest(
                    face.calc_center_median())
                if distance is not None and distance > min_depth:
                    concave.add(face)
                    ordered.append(face)
            clusters = []
            seen = set()
            # `ordered`, not `concave`: a set of BMFace hashes by memory
            # address, so iterating it would visit the faces in a different
            # order on every run. That order becomes the cluster index, the
            # cluster tag, and the order the flatten planes are applied in,
            # so a permutation could change which plane cuts first and move
            # the cavity's topology run to run (a tight bevel then turns
            # intermittently degenerate). Mesh face order is stable, so this
            # keeps the whole flatten reproducible.
            for start in ordered:
                if start in seen:
                    continue
                stack = [start]
                component = []
                while stack:
                    face = stack.pop()
                    if face in seen:
                        continue
                    seen.add(face)
                    component.append(face)
                    for edge in face.edges:
                        for other in edge.link_faces:
                            if other in concave and other not in seen:
                                stack.append(other)
                component.sort(key=lambda f: f.index)
                normal_sum = Vector((0.0, 0.0, 0.0))
                centre_sum = Vector((0.0, 0.0, 0.0))
                area_sum = 0.0
                for face in component:
                    area = face.calc_area()
                    normal_sum += face.normal * area
                    centre_sum += face.calc_center_median() * area
                    area_sum += area
                if area_sum <= 0.0:
                    continue
                if normal_sum.length > 1.0e-6:
                    n_in = (-normal_sum).normalized()
                else:
                    centroid = centre_sum / area_sum
                    if centroid.length <= 1.0e-9:
                        continue
                    n_in = (-centroid).normalized()
                # The pocket's RIM: edges of the cluster that also border a
                # face outside it. `_keep_wall_cavity` fills the pocket by
                # deleting these faces and closing the hole across exactly
                # this rim, so the level rule needs its extent.
                doomed = set(component)
                rim_verts = {vert for face in component for edge in face.edges
                             if any(other not in doomed for other in edge.link_faces)
                             for vert in edge.verts}
                if not rim_verts:
                    continue
                clusters.append({
                    "faces": [face.index for face in component],
                    "n_in": n_in,
                    "floor": max(vert.co.dot(n_in) for face in component
                                 for vert in face.verts),
                    "mean_offset": sum(face.calc_area()
                                       * face.calc_center_median().dot(n_in)
                                       for face in component) / area_sum,
                    "rim_offset": max(vert.co.dot(n_in) for vert in rim_verts),
                })
            return clusters
        finally:
            bm.free()

    @staticmethod
    def _keep_wall_flatten_pocket(bm, cluster_tag, cluster_id, n_in, level,
                                  epsilon):
        """Flatten one concave cluster on a COPY of `bm`, returning
        `(new_bmesh, None)` on success and `(None, reason)` when it could
        not be closed -- `bm` itself is never touched.

        Pure BMesh -- no boolean. Per cluster:

        1. delete the cluster's faces (tagged `cluster_id + 1`), opening the
           dent's pocket;
        2. `bisect_plane(..., clear_inner=True)` cuts at `level` and drops
           everything below it, the open pocket rim included (which is why
           `_keep_wall_flatten_level` holds `level` strictly above the
           scaled rim: what is left is then ONE boundary loop, the section);
        3. `holes_fill` closes that loop -- this single face IS the panel,
           so it is stamped role 2 (`_hollow_piece_shape` recognises the
           cavity by that role, and an unstamped panel reaches the piece as
           role 0, i.e. invisible to the cavity detection);
        4. normals recalculated over every face.

        Refused, with the reason returned, when:

        - the scaled source is not closed to begin with (review fix: the
          fill would otherwise seal the source's own holes and hand the
          call site a "closed" cavity its guard cannot see through);
        - the plane would remove geometry that is NOT connected to this
          dent's pocket through the region below the plane (review fix: the
          plane is global, so a separate lobe of the source lying below it
          would be amputated and its piece left solid without a word);
        - the fill is empty, an edge ends up with other than two faces, a
          vertex remains below the plane, or the panel is not planar.

        The clip is BMesh rather than an EXACT boolean because the boolean
        was measured to silently no-op on this input: DIFFERENCE of the
        pocket-filled cavity minus a big half-space box split 28 faces at
        the plane, left the volume identical and 42-52 verts still below it,
        and put no face on the plane at all.
        """
        trial = bm.copy()
        try:
            tag_layer = trial.faces.layers.int.get(cluster_tag)
            role_layer = trial.faces.layers.int.get(_SEAM_FACE_ROLE)
            if tag_layer is None or role_layer is None:
                trial.free()
                return None, "cluster or role layer missing"
            if any(edge.is_boundary for edge in trial.edges):
                trial.free()
                return None, "the source surface is not closed"
            doomed = [face for face in trial.faces if face[tag_layer] == cluster_id + 1]
            if not doomed:
                trial.free()
                return None, "no face carries this concave region"
            bmesh.ops.delete(trial, geom=doomed, context='FACES')
            # Everything the plane will remove must hang together with the
            # pocket rim (the only boundary right now, and below the plane
            # by the level rule): walk the below-plane vertices from the
            # rim, and refuse if any of them is unreachable -- that is a
            # separate lobe this dent has no business cutting.
            below = {vert for vert in trial.verts
                     if vert.co.dot(n_in) < level - epsilon}
            reached = {vert for vert in below
                       if any(edge.is_boundary for edge in vert.link_edges)}
            stack = list(reached)
            while stack:
                vert = stack.pop()
                for edge in vert.link_edges:
                    other = edge.other_vert(vert)
                    if other in below and other not in reached:
                        reached.add(other)
                        stack.append(other)
            if len(reached) != len(below):
                trial.free()
                return None, ("the plane would cut geometry unrelated to this "
                              "dent ({} vertices)".format(len(below) - len(reached)))
            geometry = trial.verts[:] + trial.edges[:] + trial.faces[:]
            bmesh.ops.bisect_plane(
                trial, geom=geometry, dist=1.0e-6, plane_co=n_in * level,
                plane_no=n_in, clear_inner=True, clear_outer=False)
            # Only the SECTION loop is filled -- every boundary vertex on the
            # plane. Anything else left open is not ours to close, and the
            # two-faces-per-edge check below then rolls the cluster back.
            on_plane = 2.0 * epsilon
            boundary = [edge for edge in trial.edges if edge.is_boundary
                        and all(abs(vert.co.dot(n_in) - level) <= on_plane
                                for vert in edge.verts)]
            if not boundary:
                trial.free()
                return None, "the plane leaves no section to close"
            filled = bmesh.ops.holes_fill(trial, edges=boundary, sides=0)
            # Kept as the single ngon the fill returns: triangulating it
            # gained nothing in the prototype and only added geometry.
            new_faces = [face for face in filled.get("faces", []) if face.is_valid]
            if not new_faces:
                trial.free()
                return None, "the section could not be filled"
            for face in new_faces:
                face[role_layer] = 2
                face[tag_layer] = 0
            bmesh.ops.recalc_face_normals(trial, faces=trial.faces[:])
            trial.normal_update()
            if any(len(edge.link_faces) != 2 for edge in trial.edges):
                trial.free()
                return None, "the flattened cavity is not closed"
            if any(vert.co.dot(n_in) < level - on_plane for vert in trial.verts):
                trial.free()
                return None, "a vertex is left below the panel"
            if any(face.calc_area() <= 0.0 or abs(face.normal.dot(n_in)) < 0.99
                   for face in new_faces):
                trial.free()
                return None, "the panel is not planar"
            return trial, None
        except BaseException:
            trial.free()
            raise

    @staticmethod
    def _hollow_inner_flatten_patch(bm, records, vert_side_layer, face_role_layer):
        """Flatten this piece's share of each concave cluster on a COPY of
        `bm` -- the ordinary `_hollow_piece` bridge shell -- returning
        `(new_bmesh, None)` or `(None, reason)`. `bm` itself is never
        touched, so a refusal leaves the caller holding the plain OFF shell.

        The patch is LOCAL by construction, which is the whole point of v4
        (2026-09-13): the shell is built exactly as Keep Wall OFF builds it,
        role-1 (outer) and role-0 (cut band) faces are never touched, and
        only role-2 (inner) faces under this piece's own cluster faces are
        replaced. A piece owning no cluster face never reaches here at all,
        so it stays byte-for-byte the OFF piece.

        Per cluster record:

        1. the DOOMED inner faces are this piece's inner twins of the
           cluster's outer faces (`record["inner_faces"]`, resolved by the
           caller from the duplicate's own face map, not by a
           nearest-point guess) grown across the connected region that lies
           BELOW the plane, so the whole pocket goes and nothing else does;
        2. PINNED vertices -- any vertex of a role-0 face -- are never moved,
           never deleted and never subdivided: they are the piece's contact
           with its neighbour, and requirement 3 is that they stay exactly
           where Keep Wall OFF put them. A pinned vertex inside the doomed
           region is kept as a COLLAR anchor instead;
        3. the doomed faces are deleted, which opens one hole bounded by the
           surviving inner surface (and, where the pocket reached the cut,
           by pinned rim vertices);
        4. the hole's boundary loop is walked in order. Free (unpinned)
           boundary vertices are MOVED onto the panel plane along `n_in`;
           pinned ones stay put. The loop, now planar except at the pinned
           anchors, is filled as the panel, and each pinned anchor is joined
           to its own projection by a collar face, so the collar -- not the
           panel -- carries the step down to the pinned rim.

        Refused (and rolled back) when the doomed region cannot be found,
        when it would take a pinned vertex with it, when the hole is not a
        single loop, or when the fill leaves the shell open.
        """
        from mathutils import Vector
        trial = bm.copy()
        try:
            side = trial.verts.layers.int.get(vert_side_layer)
            role = trial.faces.layers.int.get(face_role_layer)
            if side is None or role is None:
                trial.free()
                return None, "the role layers are missing from the shell"
            trial.verts.ensure_lookup_table()
            trial.faces.ensure_lookup_table()
            if any(edge.is_boundary for edge in trial.edges):
                trial.free()
                return None, "the hollow shell is not closed"
            pinned = {vert for face in trial.faces if face[role] == 0
                      for vert in face.verts}
            # The inner twins are addressed by INDEX: `inner_of_outer` was
            # built on the shell before this copy, and `bm.copy()` preserves
            # element order, so index is a stable identity here (BMesh
            # wrappers themselves are not shared across a copy).
            #
            # EVERY record's seeds are resolved NOW, before any cluster is
            # patched: the first patch deletes faces, which renumbers every
            # later face, so a second cluster resolved afterwards would index
            # the wrong faces (measured 2026-09-13 on the two-dent sphere:
            # "the inner twin map points at a non-inner face", 44 inner faces
            # left with a sample outside the source). BMFace wrappers stay
            # valid across an unrelated delete, so they are held instead.
            seeds_of = {}
            movable_of = {}
            for record in records:
                seeds = []
                for inner_index in record["inner_faces"]:
                    if inner_index >= len(trial.faces):
                        trial.free()
                        return None, "the inner twin map does not fit the shell"
                    face = trial.faces[inner_index]
                    if face[role] != 2:
                        trial.free()
                        return None, "the inner twin map points at a non-inner face"
                    seeds.append(face)
                if not seeds:
                    trial.free()
                    return None, "this piece carries no inner face of the region"
                seeds_of[record["index"]] = seeds
                # Exception B's movable vertices are resolved NOW too, for
                # the same reason: a delete renumbers vertices, but a BMVert
                # wrapper stays valid.
                trial.verts.ensure_lookup_table()
                movable_of[record["index"]] = {
                    trial.verts[index]
                    for index in (record.get("movable_verts") or ())
                    if index < len(trial.verts)}
            for record in records:
                n_in = record["n_in"]
                level = record["level"]
                epsilon = record["epsilon"]
                on_plane = 2.0 * epsilon
                seeds = [face for face in seeds_of[record["index"]] if face.is_valid]
                if not seeds:
                    trial.free()
                    return None, ("another region's patch consumed this region's "
                                  "inner faces")
                # Grow the pocket across inner faces BELOW the plane: those
                # are the ones the panel replaces. The seeds themselves go
                # whether or not their centre is below (a shallow dent's
                # floor may sit within epsilon of the plane).
                #
                # The growth is bounded LATERALLY by the seeds' own extent
                # about the cluster axis. Without that bound one vertex
                # dipping below the plane drags a whole unrelated wall in:
                # measured 2026-09-13 on the dented slab, where the far
                # side walls each have a corner on the dent's side of the
                # plane and the pocket grew to 8 of the 10 inner faces,
                # putting the panel's boundary out at the slab's corners.
                # This is the extent of THIS dent's own pocket, not a guess
                # at which piece owns it -- ownership is already settled by
                # the source face identities.
                def lateral(co):
                    return (co - n_in * co.dot(n_in)).length

                reach = max(lateral(vert.co) for face in seeds
                            for vert in face.verts)
                reach = reach + max(reach, 1.0) * 0.5
                doomed = set(seeds)
                stack = list(seeds)
                while stack:
                    face = stack.pop()
                    for edge in face.edges:
                        for other in edge.link_faces:
                            if other in doomed or other[role] != 2:
                                continue
                            # ANY vertex below the plane, not all of them: a
                            # face straddling the plane leaves a sliver of
                            # the scaled dent standing beside the panel
                            # otherwise (measured 2026-09-13 on the dented
                            # sphere: four quads at -0.6485 against level
                            # -0.6499, which `_assert_one_flat_panel`
                            # correctly calls "off the panel plane"). Its
                            # above-plane vertices then become the collar's
                            # anchors.
                            if (any(vert.co.dot(n_in) < level - on_plane
                                    for vert in other.verts)
                                    and all(lateral(vert.co) <= reach
                                            for vert in other.verts)):
                                doomed.add(other)
                                stack.append(other)
                # A vertex used ONLY by doomed faces disappears with them.
                # Requirement 3: a pinned one must not, so it is kept as a
                # collar anchor and its faces are cut back to it.
                # `FACES_ONLY` removes the faces and leaves every vertex and
                # edge standing, so a pinned vertex survives the delete by
                # construction and the collar re-attaches it below. Loose
                # geometry that no face needs any more is swept afterwards.
                #
                # A plane BISECT of the pocket was tried here first
                # (2026-09-13) so the section would land exactly on the
                # plane: it left TWO boundary loops on every fixture (the
                # clipped pocket wall keeps its own rim), which this patch
                # cannot close into one panel, so the pocket is removed whole
                # and its boundary ring is projected instead.
                bmesh.ops.delete(trial, geom=list(doomed), context='FACES_ONLY')
                if any(not vert.is_valid for vert in pinned):
                    trial.free()
                    return None, "the patch would delete a pinned cut vertex"
                boundary = [edge for edge in trial.edges if edge.is_boundary]
                if not boundary:
                    trial.free()
                    return None, "the pocket left no boundary to close"
                loops = TOOL3D_OT_split_mark_sharp._connected_edge_loops(boundary)
                if len(loops) != 1:
                    trial.free()
                    return None, ("the pocket left {} boundary loops, not one"
                                  .format(len(loops)))
                ring = TOOL3D_OT_split_mark_sharp._ordered_boundary_ring(loops[0])
                if ring is None:
                    trial.free()
                    return None, "the pocket boundary is not a simple ring"
                # The panel is built on the PROJECTED ring, so it is planar by
                # construction rather than by hope. A ring vertex is ANCHORED
                # -- kept exactly where the OFF shell put it, and joined to
                # the panel by the collar -- when either
                #
                # - it is PINNED (a role-0 cut band vertex): requirement 3,
                #   the piece must still meet its neighbour there; or
                # - it already sits deeper than the plane, so projecting it
                #   would move it OUTWARD, toward the outer wall. That is the
                #   poke-through this option exists to stop, and it is what
                #   the slab's rim corners do (measured 2026-09-13: 2 of them
                #   at -0.8 against level -0.6317).
                #
                # Everything else is free inner surface and is projected onto
                # the plane, which is the local boundary change the user
                # approved.
                # Exception B (user decision 2026-09-13): a pinned vertex the
                # caller listed in `movable` MAY be projected, because every
                # piece meeting there owns this same cluster and computes the
                # identical projection from the identical source-global plane
                # in the one shared object frame -- so the pieces still meet
                # exactly. Everything else stays anchored.
                movable = {vert for vert in movable_of.get(record["index"], ())
                           if vert.is_valid}
                anchored = {vert for vert in ring
                            if (vert in pinned and vert not in movable)
                            or vert.co.dot(n_in) > level + on_plane}
                # Each ring vertex contributes ONE panel corner. An anchored
                # vertex contributes a CLONE on the plane (it may not move
                # itself) unless it already lies on the plane, in which case
                # it joins the panel directly -- cloning it would only make a
                # zero-area collar face. Clones are shared by position, so a
                # clone that lands exactly where another ring vertex was
                # projected is the SAME vertex: distinct vertices at one point
                # would leave the collar open (measured on the dented slab).
                projected = []
                collar = []
                clones = {}

                def plane_key(point):
                    return (round(point.x / on_plane), round(point.y / on_plane),
                            round(point.z / on_plane))

                for vert in ring:
                    target = vert.co - n_in * (vert.co.dot(n_in) - level)
                    if vert not in anchored:
                        vert.co = target
                        clones[plane_key(target)] = vert
                for vert in ring:
                    target = vert.co - n_in * (vert.co.dot(n_in) - level)
                    if vert not in anchored:
                        projected.append(vert)
                        continue
                    if (target - vert.co).length <= on_plane:
                        projected.append(vert)
                        clones.setdefault(plane_key(target), vert)
                        continue
                    key = plane_key(target)
                    clone = clones.get(key)
                    if clone is None:
                        clone = trial.verts.new(target)
                        clone[side] = 2
                        clones[key] = clone
                    projected.append(clone)
                    collar.append((vert, clone))
                trial.verts.ensure_lookup_table()
                # Shared clones can make one vertex appear twice in a row
                # around the ring; the panel keeps each corner once, in ring
                # order.
                panel_corners = []
                for vert in projected:
                    if panel_corners and panel_corners[-1] is vert:
                        continue
                    panel_corners.append(vert)
                if len(panel_corners) > 1 and panel_corners[0] is panel_corners[-1]:
                    panel_corners.pop()
                if len(panel_corners) < 3:
                    trial.free()
                    return None, ("the panel collapsed to {} corner(s)".format(
                        len(panel_corners)))
                try:
                    panel = trial.faces.new(panel_corners)
                except ValueError as exc:
                    trial.free()
                    return None, "the panel could not be built ({})".format(exc)
                panel[role] = 2
                # Collar: one face per boundary edge with an anchored end,
                # walking the ring in ITS OWN ORDER so the strip follows the
                # topology -- never nearest-point pairing. A quad where both
                # ends were cloned, a triangle at the transition to a
                # projected vertex.
                count = len(ring)
                collar_faces = []
                for position in range(count):
                    a_old, b_old = ring[position], ring[(position + 1) % count]
                    a_new, b_new = projected[position], projected[(position + 1) % count]
                    if a_new is a_old and b_new is b_old:
                        continue
                    # Deduplicate by POSITION, not identity: a projected
                    # neighbour can land exactly on an anchored vertex's
                    # clone, which is a distinct BMVert at the same point and
                    # would make a zero-area collar face (measured on the
                    # dented slab: 4 of them at (-0.8, 0.632, 0)).
                    #
                    # M2 (final review 2026-09-13), RESIDUAL RISK, accepted
                    # and bounded rather than fixed: the threshold is
                    # `on_plane` = 2 * epsilon, epsilon being 1e-4 of the
                    # SOURCE bbox diagonal, so two genuinely distinct ring
                    # vertices closer together than that would collapse into
                    # one collar corner. A topological rule cannot replace it
                    # here -- the collision it exists to fix is between a
                    # vertex and a CLONE that has no topological relation to
                    # it yet -- and tightening the tolerance independently of
                    # `epsilon` would desynchronize this test from the
                    # `plane_key` weld above, which must agree with it or the
                    # collar opens. The failure mode is contained: a collapsed
                    # corner drops a collar face, which leaves an edge with
                    # one face, which the "the patched shell is not closed"
                    # check below refuses -- so the patch is rolled back and
                    # reported, never adopted as bad geometry. No fixture
                    # reaches it; a source whose features are finer than 2e-4
                    # of its own bbox diagonal would.
                    corners = []
                    for vert in (a_old, b_old, b_new, a_new):
                        if any((vert.co - kept.co).length <= on_plane
                               for kept in corners):
                            continue
                        corners.append(vert)
                    if len(corners) < 3:
                        continue
                    try:
                        face = trial.faces.new(corners)
                    except ValueError:
                        continue
                    face[role] = 2
                    collar_faces.append(face)
                # The collar is NOT checked by face count: a ring edge whose
                # corners collapse to one point contributes no face and must
                # not, and an anchored vertex already on the plane needs no
                # clone at all. What matters is that nothing was left open,
                # which the two-faces-per-edge check below decides for the
                # whole shell.
                if collar and not collar_faces:
                    trial.free()
                    return None, ("the collar could not be built over {} anchored "
                                  "boundary vertices".format(len(collar)))
                record["collar"] = len(collar_faces)
                bmesh.ops.recalc_face_normals(
                    trial, faces=[panel] + collar_faces)
                # `FACES_ONLY` leaves the pocket's interior vertices and
                # edges behind with nothing using them; sweep exactly those,
                # never anything a face still holds.
                loose_edges = [edge for edge in trial.edges if not edge.link_faces]
                if loose_edges:
                    bmesh.ops.delete(trial, geom=loose_edges, context='EDGES')
                loose_verts = [vert for vert in trial.verts if not vert.link_faces]
                if loose_verts:
                    bmesh.ops.delete(trial, geom=loose_verts, context='VERTS')
                trial.verts.ensure_lookup_table()
                trial.faces.ensure_lookup_table()
            bmesh.ops.recalc_face_normals(trial, faces=trial.faces[:])
            trial.normal_update()
            if any(len(edge.link_faces) != 2 for edge in trial.edges):
                trial.free()
                return None, "the patched shell is not closed"
            degenerate = [face for face in trial.faces if face.calc_area() <= 0.0]
            if degenerate:
                # The detail is built BEFORE the free: reading a BMFace after
                # `trial.free()` raises ReferenceError.
                sample = degenerate[0]
                sample_role = sample[role]
                detail = ", ".join(
                    "({:.3g}, {:.3g}, {:.3g})".format(vert.co.x, vert.co.y, vert.co.z)
                    for vert in list(sample.verts)[:4])
                count = len(degenerate)
                trial.free()
                return None, ("the patch left {} zero-area face(s), e.g. role {} "
                              "at {}".format(count, sample_role, detail))
            return trial, None
        except BaseException:
            trial.free()
            raise

    @staticmethod
    def _ordered_boundary_ring(edges):
        """Walk `edges` (one connected boundary loop) into a vertex ring in
        traversal order, or None when it is not a simple closed ring (a
        vertex of degree other than two, or the walk not closing)."""
        neighbours = {}
        for edge in edges:
            a, b = edge.verts
            neighbours.setdefault(a, []).append(b)
            neighbours.setdefault(b, []).append(a)
        if any(len(linked) != 2 for linked in neighbours.values()):
            return None
        # M1 (final review 2026-09-13): start at the ring's lowest CORNER by
        # position rather than at `next(iter(neighbours))`. Dict order here
        # follows insertion, which follows BMesh edge order -- deterministic
        # in practice, but incidental, and `_keep_wall_concave_clusters`
        # documents why this codebase does not rely on that. Position is used
        # rather than `index` because this runs straight after a delete, when
        # element indices are dirty. The ring is a CYCLE, so where the walk
        # starts changes no geometry: the panel takes the same corners and
        # the collar the same edges, rotated. Direction is still whichever
        # neighbour comes first, which is what keeps the panel's winding the
        # same as before this change.
        start = min(neighbours, key=lambda vert: (vert.co.x, vert.co.y, vert.co.z))
        ring = [start]
        previous, current = None, start
        while True:
            options = [vert for vert in neighbours[current] if vert is not previous]
            if not options:
                return None
            following = options[0]
            if following is start:
                break
            ring.append(following)
            previous, current = current, following
            if len(ring) > len(edges):
                return None
        if len(ring) != len(neighbours):
            return None
        return ring

    @staticmethod
    def _keep_wall_source_plan(source_mesh, scale):
        """The SOURCE-level analysis both Keep Wall routes share: one record
        per concave cluster, with everything a per-piece patch needs and
        nothing that depends on how the cavity is built.

            {"index", "faces", "n_in", "floor", "level", "epsilon",
             "min_depth", "thickness"}

        `faces` are indices into `source_mesh`, `level` is
        `_keep_wall_flatten_level`'s depth policy (unchanged), and `epsilon`
        is the source's own bbox-relative tolerance. An empty list means the
        source is CONVEX, so the plain origin scale gets nothing wrong and
        every piece keeps the untouched `_hollow_piece` bridge.
        """
        from mathutils import Vector
        thickness = TOOL3D_OT_split_mark_sharp._keep_wall_mean_wall(source_mesh, scale)
        min_depth = max(
            TOOL3D_OT_split_mark_sharp._KEEP_WALL_DEPTH_FRACTION * thickness,
            TOOL3D_OT_split_mark_sharp._KEEP_WALL_MIN_DEPTH)
        clusters = TOOL3D_OT_split_mark_sharp._keep_wall_concave_clusters(
            source_mesh, min_depth)
        if not clusters:
            return [], thickness, min_depth, 0.0
        coords = [vert.co.copy() for vert in source_mesh.vertices]
        low = Vector(tuple(min(co[axis] for co in coords) for axis in range(3)))
        high = Vector(tuple(max(co[axis] for co in coords) for axis in range(3)))
        epsilon = (TOOL3D_OT_split_mark_sharp._KEEP_WALL_EPSILON_FRACTION
                   * (high - low).length)
        plan = []
        for index, cluster in enumerate(clusters):
            level = TOOL3D_OT_split_mark_sharp._keep_wall_flatten_level(
                scale * cluster["mean_offset"], scale * cluster["rim_offset"],
                cluster["floor"], min_depth, epsilon)
            plan.append({
                "index": index,
                "faces": list(cluster["faces"]),
                "n_in": cluster["n_in"].copy(),
                "floor": cluster["floor"],
                "level": level,
                "epsilon": epsilon,
                "min_depth": min_depth,
                "thickness": thickness,
            })
        return plan, thickness, min_depth, epsilon

    @staticmethod
    def _polygon_cycle_key(coords, tolerance):
        """A polygon's identity: its vertex positions quantized to
        `tolerance` and rotated to the smallest cycle, folded together with
        the reversed traversal.

        The COMPLETE polygon, never its centre: a face centre collides (a
        quad and its own two triangles share one, and so do the two faces a
        split leaves on either side of a cut), which would hand a cluster to
        the wrong piece. Direction-insensitive because a split may re-enter a
        face from either side.
        """
        keys = [(round(co.x / tolerance), round(co.y / tolerance),
                 round(co.z / tolerance)) for co in coords]
        count = len(keys)
        best = None
        for order in (keys, list(reversed(keys))):
            for start in range(count):
                candidate = tuple(order[start:] + order[:start])
                if best is None or candidate < best:
                    best = candidate
        return best

    @staticmethod
    def _keep_wall_assign_clusters(pieces, source_mesh, plan):
        """Map each concave cluster onto the piece(s) that actually carry its
        SOURCE faces, returning `({piece name: [record, ...]}, [reason, ...])`.

        Identity is the complete polygon (`_polygon_cycle_key`) of the
        piece's own faces against the cluster's source faces -- never a
        bounding box, a plane intersection, a face count or a name. A cluster
        cut by a seam therefore has MORE THAN ONE owner, which is exactly
        what it needs: each owner flattens its share at the one shared level.

        Must run BEFORE the offset moves any cut rim vertex: after that the
        piece's rim faces no longer match the source. A cluster whose faces
        cannot all be accounted for is returned as a reason instead, so it is
        reported rather than silently treated as convex.
        """
        if not plan:
            return {}, []
        from mathutils import Vector
        coords = [vert.co for vert in source_mesh.vertices]
        if coords:
            low = Vector(tuple(min(co[axis] for co in coords) for axis in range(3)))
            high = Vector(tuple(max(co[axis] for co in coords) for axis in range(3)))
            diagonal = (high - low).length
        else:
            diagonal = 1.0
        tolerance = max((diagonal if diagonal > 0.0 else 1.0) * 1.0e-6, 1.0e-8)
        owner_of = {}
        for record in plan:
            for face_index in record["faces"]:
                polygon = source_mesh.polygons[face_index]
                key = TOOL3D_OT_split_mark_sharp._polygon_cycle_key(
                    [source_mesh.vertices[i].co for i in polygon.vertices], tolerance)
                owner_of[key] = record["index"]
        assigned = {}
        found = {record["index"]: 0 for record in plan}
        for piece in pieces:
            if not piece or piece.name not in bpy.data.objects:
                continue
            mesh = piece.data
            per_cluster = {}
            for polygon in mesh.polygons:
                key = TOOL3D_OT_split_mark_sharp._polygon_cycle_key(
                    [mesh.vertices[i].co for i in polygon.vertices], tolerance)
                index = owner_of.get(key)
                if index is None:
                    continue
                per_cluster.setdefault(index, []).append(polygon.index)
            if not per_cluster:
                continue
            records = []
            for index, face_indices in sorted(per_cluster.items()):
                found[index] += len(face_indices)
                source = plan[index]
                records.append({
                    "index": index,
                    "faces": face_indices,
                    "n_in": source["n_in"].copy(),
                    "level": source["level"],
                    "floor": source["floor"],
                    "epsilon": source["epsilon"],
                    "applied": False,
                    "reason": None,
                })
            assigned[piece.name] = records
        reasons = []
        for record in plan:
            expected = len(record["faces"])
            if found[record["index"]] != expected:
                reasons.append(
                    "concave region {} could not be mapped onto its pieces "
                    "({} of {} faces found)".format(
                        record["index"] + 1, found[record["index"]], expected))
        return assigned, reasons

    @staticmethod
    def _mesh_boundary_verts(mesh):
        """The vertex indices on `mesh`'s BOUNDARY: the ends of every edge
        exactly one polygon uses along its own loop.

        I3 (final review 2026-09-13): this was
        `sum(1 for polygon in mesh.polygons if v0 in polygon.vertices and v1
        in polygon.vertices)` per edge -- O(edges x polygons), measured at
        16.1 s on a 5118-face piece against 0.009 s for this rule, ~1800x,
        and it runs once per piece inside a modal operator. Membership was
        also the wrong question: a CHORD, whose two endpoints both belong to
        a polygon it is not a loop edge of, counted as used. Walking each
        polygon's own loops once answers exactly "how many faces use this
        edge" in O(total loops).
        """
        used = {}
        for polygon in mesh.polygons:
            for key in polygon.edge_keys:
                pair = (key[0], key[1]) if key[0] < key[1] else (key[1], key[0])
                used[pair] = used.get(pair, 0) + 1
        boundary = set()
        for edge in mesh.edges:
            a, b = edge.vertices
            pair = (a, b) if a < b else (b, a)
            if used.get(pair, 0) == 1:
                boundary.update((a, b))
        return boundary

    @staticmethod
    def _keep_wall_shared_rim_moves(pieces, assigned):
        """Decide which INNER rim vertices the synchronized-rim exception may
        move, returning `{piece name: {cluster index: set(outer vertex
        index)}}`.

        User decision 2026-09-13 ("Chỉnh đồng bộ"). The plain rule is: a
        piece's cut rim is shared with its neighbours, and the inner twin of
        a shared rim vertex may be moved onto the panel plane ONLY when
        EVERY piece meeting at that rim vertex owns the SAME concave cluster.
        Then all of them compute the identical projection from the identical
        source-global plane in the one shared object frame, so they still
        meet exactly. Where even one sharer owns no part of the cluster --
        the three-ring sphere, whose dent sits inside a single band half --
        nothing moves and that neighbour stays byte-identical to Keep Wall
        OFF.

        Returned as OUTER vertex indices because those are stable from here
        through the offset and into `_hollow_piece` (the hollow duplicates
        the outer surface, so outer indices keep their order); the caller
        resolves each one to its inner twin through the duplicate's own
        vertex map. The OUTER seam itself is never a candidate: only the
        inner twin of a shared vertex can move.
        """
        from mathutils import Vector
        live = [piece for piece in pieces
                if piece and piece.name in bpy.data.objects]
        # I1 (final review 2026-09-13): ONE grid for every piece. The key is
        # compared ACROSS pieces, so deriving its tolerance from each piece's
        # own bbox quantized the same physical point onto different grids and
        # a genuine sharer could vanish from `incidence`. That direction is
        # PERMISSIVE -- a lost non-owner makes the set look like owners-only
        # and the vertex becomes movable, splitting the very seam this
        # exception exists to keep matched (measured: two owners at 1.414e-06
        # keyed (2121320, 3535534, 0), the non-owner at 7.436e-06 keyed
        # (403458, 672429, 0); on the three-ring sphere the six pieces had 4
        # distinct grids, finding 36 shared positions where one grid finds
        # 92). The union bbox of the whole piece set is the same quantity
        # `_keep_wall_assign_clusters` derives from the source, so producer
        # and consumer speak one language.
        coords = [vert.co for piece in live for vert in piece.data.vertices]
        if coords:
            low = Vector(tuple(min(co[a] for co in coords) for a in range(3)))
            high = Vector(tuple(max(co[a] for co in coords) for a in range(3)))
            diagonal = (high - low).length
        else:
            diagonal = 1.0
        tolerance = max((diagonal if diagonal > 0.0 else 1.0) * 1.0e-6, 1.0e-8)
        incidence = {}
        per_piece = {}
        for piece in live:
            mesh = piece.data
            boundary = TOOL3D_OT_split_mark_sharp._mesh_boundary_verts(mesh)
            keys = {}
            for index in boundary:
                key = (round(mesh.vertices[index].co.x / tolerance),
                       round(mesh.vertices[index].co.y / tolerance),
                       round(mesh.vertices[index].co.z / tolerance))
                keys[index] = key
                incidence.setdefault(key, set()).add(piece.name)
            per_piece[piece.name] = keys
        moves = {}
        for name, keys in per_piece.items():
            records = assigned.get(name) or []
            for record in records:
                owners = {other for other, other_records in assigned.items()
                          if any(item["index"] == record["index"]
                                 for item in other_records)}
                movable = set()
                for index, key in keys.items():
                    sharers = incidence.get(key, set())
                    # Shared with at least one other piece, and every single
                    # sharer owns this cluster.
                    if len(sharers) > 1 and sharers <= owners:
                        movable.add(index)
                if movable:
                    moves.setdefault(name, {})[record["index"]] = movable
        return moves

    @staticmethod
    def _keep_wall_cavity(context, source_mesh, scale):
        """Return `(cavity_mesh, flattened_count, wall, skipped)` -- the
        DEFAULT hollow's cavity (`source_mesh` scaled about the origin by
        `scale`) with the dent's part of the inner surface FLATTENED, as ONE
        role-2 mesh datablock shared by every piece of this source (so it
        meets itself across the cut, exactly like the shape-phase primitive).

        `wall` is the thinnest wall a panel leaves under its dent floor
        (`level - floor`, the number the console reports); `skipped` lists
        one reason string per concave region that could NOT be flattened
        and therefore keeps the plain scaled surface (it may poke through
        -- the caller records every entry as a failure so it is never
        silent).

        `(None, 0, t, [])` means the source is CONVEX: no concave cluster,
        so there is nothing the pure origin scale gets wrong and the caller
        keeps the old `_hollow_piece` bridge path byte for byte.
        `(None, 0, t, skipped)` with a non-empty list means every region
        was skipped: the caller takes the same bridge path, but reported.
        `t` is then the nominal mean wall.

        `context` is unused since v3 (nothing here evaluates the depsgraph)
        and is kept for the call-site contract.

        Per concave cluster (v3, 2026-09-12 -- the user rejected v2's
        erosion block with its tall side walls, and asked for "cut like the
        default hollow, but flatten the dent's part of the inner face"),
        `_keep_wall_flatten_pocket` deletes the dent's pocket, bisects at
        `_keep_wall_flatten_level` and fills the section as ONE panel. A
        cluster that cannot be flattened is rolled back to the pure scaled
        surface and reported as skipped; the source is never abandoned.

        This is all BMesh: the boolean clip it replaces was measured to
        silently no-op on a pocket-filled cavity (see
        `_keep_wall_flatten_pocket`). The piece carve still runs through
        `_hollow_piece_shape`, which has been reliable throughout.

        GUARANTEE: every point kept satisfies `p . n_in >= level > floor`
        while the dent's air lies entirely at `p . n_in <= floor` (`floor`
        being the dent's deepest UNSCALED point along `n_in`), so with the
        normal `floor < 0` no inner vertex can end up outside the source.
        """
        from mathutils import Vector
        thickness = TOOL3D_OT_split_mark_sharp._keep_wall_mean_wall(source_mesh, scale)
        min_depth = max(
            TOOL3D_OT_split_mark_sharp._KEEP_WALL_DEPTH_FRACTION * thickness,
            TOOL3D_OT_split_mark_sharp._KEEP_WALL_MIN_DEPTH)
        clusters = TOOL3D_OT_split_mark_sharp._keep_wall_concave_clusters(
            source_mesh, min_depth)
        if not clusters:
            return None, 0, thickness, []

        coords = [vert.co.copy() for vert in source_mesh.vertices]
        low = Vector(tuple(min(co[axis] for co in coords) for axis in range(3)))
        high = Vector(tuple(max(co[axis] for co in coords) for axis in range(3)))
        epsilon = (TOOL3D_OT_split_mark_sharp._KEEP_WALL_EPSILON_FRACTION
                   * (high - low).length)

        cavity = source_mesh.copy()
        cavity.name = "_tool3d_hollow_erosion"
        try:
            applied = 0
            skipped = []
            panel_wall = None
            bm = bmesh.new()
            try:
                bm.from_mesh(cavity)
                # Every layer BEFORE any element wrapper is held (BMesh
                # rule), and the cluster tag before any delete: deleting
                # faces shifts every later face index, so the cluster
                # membership cannot be carried by index past the first fill.
                role = bm.faces.layers.int.get(_SEAM_FACE_ROLE)
                if role is None:
                    role = bm.faces.layers.int.new(_SEAM_FACE_ROLE)
                # get-or-new: `new()` alone raises if the source already
                # carries the scratch layer (a mesh saved mid-run, say).
                tag = bm.faces.layers.int.get(_KEEP_WALL_CLUSTER_TAG)
                if tag is None:
                    tag = bm.faces.layers.int.new(_KEEP_WALL_CLUSTER_TAG)
                bm.faces.ensure_lookup_table()
                for vert in bm.verts:
                    vert.co = vert.co * scale
                for face in bm.faces:
                    face[role] = 2
                    face[tag] = 0
                for index, cluster in enumerate(clusters):
                    for face_index in cluster["faces"]:
                        bm.faces[face_index][tag] = index + 1
                for index, cluster in enumerate(clusters):
                    level = TOOL3D_OT_split_mark_sharp._keep_wall_flatten_level(
                        scale * cluster["mean_offset"], scale * cluster["rim_offset"],
                        cluster["floor"], min_depth, epsilon)
                    flattened, reason = TOOL3D_OT_split_mark_sharp._keep_wall_flatten_pocket(
                        bm, _KEEP_WALL_CLUSTER_TAG, index, cluster["n_in"],
                        level, epsilon)
                    if flattened is None:
                        # This dent stays the plain scaled surface (it may
                        # still poke); the other clusters are unaffected.
                        # Review fix: reported, never silent.
                        skipped.append(
                            "concave region {} of {} could not be flattened "
                            "({}); it keeps the plain scaled surface and may "
                            "poke through the outer wall".format(
                                index + 1, len(clusters), reason))
                        continue
                    bm.free()
                    bm = flattened
                    applied += 1
                    wall = level - cluster["floor"]
                    panel_wall = wall if panel_wall is None else min(panel_wall, wall)
                stale = bm.faces.layers.int.get(_KEEP_WALL_CLUSTER_TAG)
                if stale is not None:
                    bm.faces.layers.int.remove(stale)
                bm.to_mesh(cavity)
                cavity.update()
            finally:
                bm.free()
            if not applied:
                # Nothing could be flattened: the caller keeps the old
                # bridge path rather than carving a pure scaled cavity --
                # and `skipped` tells it (and the user) why.
                if cavity.users == 0:
                    bpy.data.meshes.remove(cavity)
                return None, 0, thickness, skipped
            result = cavity
            cavity = None
            return result, applied, panel_wall, skipped
        except BaseException:
            if cavity is not None and cavity.users == 0:
                bpy.data.meshes.remove(cavity)
            raise

    @staticmethod
    def _keep_wall_union_mesh(pieces, name="_tool3d_hollow_source"):
        """Rebuild the source surface from the pieces' role-1 (outer) faces
        as one new mesh datablock, or None when that cannot be closed.

        Used only when no `self._run_source_mesh` snapshot exists -- direct
        calls into `_apply_mark_sharp_settings` (the tests pass `self=None`)
        never go through `execute`. The split duplicates the cut ring's
        vertices into both pieces, so the welded copies are merged back
        together; when they cannot be (an Offset has pulled the rims apart,
        say) the union stays open and the caller falls back to the old
        bridge path rather than eroding against a hole.
        """
        from mathutils import Vector
        bm = bmesh.new()
        mesh = None
        try:
            for piece in pieces:
                if not piece or piece.name not in bpy.data.objects:
                    continue
                piece_bm = bmesh.new()
                try:
                    piece_bm.from_mesh(piece.data)
                    role = piece_bm.faces.layers.int.get(_SEAM_FACE_ROLE)
                    for face in piece_bm.faces:
                        if role is not None and face[role] != 1:
                            continue
                        verts = [bm.verts.new(Vector(vert.co)) for vert in face.verts]
                        try:
                            bm.faces.new(verts)
                        except ValueError:
                            pass
                finally:
                    piece_bm.free()
            if not bm.faces:
                return None
            bmesh.ops.remove_doubles(bm, verts=list(bm.verts), dist=_bbox_tolerance(bm))
            if not bm.faces or any(len(e.link_faces) != 2 for e in bm.edges):
                return None
            bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
            mesh = bpy.data.meshes.new(name)
            bm.to_mesh(mesh)
            mesh.update()
            return mesh
        except BaseException:
            if mesh is not None and mesh.users == 0:
                bpy.data.meshes.remove(mesh)
            raise
        finally:
            bm.free()

    @staticmethod
    def _keep_wall_is_closed(mesh):
        """True when `mesh` is a closed manifold with faces -- an open
        boolean result would carve garbage out of the pieces."""
        bm = bmesh.new()
        try:
            bm.from_mesh(mesh)
            return bool(bm.faces) and all(len(e.link_faces) == 2 for e in bm.edges)
        finally:
            bm.free()

    @staticmethod
    def _hollow_shape_stamp(bm, name="_tool3d_hollow_shape"):
        """Write `bm` to a new mesh datablock with every face role 2."""
        role = bm.faces.layers.int.get(_SEAM_FACE_ROLE)
        if role is None:
            role = bm.faces.layers.int.new(_SEAM_FACE_ROLE)
        for face in bm.faces:
            face[role] = 2
        mesh = bpy.data.meshes.new(name)
        bm.to_mesh(mesh)
        mesh.update()
        return mesh

    @staticmethod
    def _hollow_shape_primitive(shape, bbox_min, bbox_max, scale):
        """Return a new mesh datablock: a BOX/CYLINDER/SPHERE fitted to the
        local bounding box [bbox_min, bbox_max], then scaled by `scale`
        about the object ORIGIN (same centre `_hollow_piece` uses, so the
        cavity meets itself across the cut between pieces). Faces carry
        role 2. The caller owns (and removes) the datablock.

        CYLINDER: axis = longest bbox side (tie -> Z, then Y, then X);
        radius = half the shorter of the two other sides; ngon caps.
        SPHERE: radius = half the shortest side, centred on the bbox.
        """
        from mathutils import Matrix, Vector
        lo = Vector(bbox_min)
        hi = Vector(bbox_max)
        size = hi - lo
        centre = (lo + hi) * 0.5
        bm = bmesh.new()
        try:
            if shape == 'BOX':
                bmesh.ops.create_cube(bm, size=1.0)
                for vert in bm.verts:
                    vert.co = Vector((vert.co.x * size.x, vert.co.y * size.y,
                                      vert.co.z * size.z)) + centre
            elif shape == 'CYLINDER':
                axis = max(range(3), key=lambda i: (size[i], i))
                others = [i for i in range(3) if i != axis]
                radius = 0.5 * min(size[i] for i in others)
                rotation = {0: Matrix.Rotation(math.pi / 2.0, 4, 'Y'),
                            1: Matrix.Rotation(math.pi / 2.0, 4, 'X'),
                            2: Matrix.Identity(4)}[axis]
                bmesh.ops.create_cone(
                    bm, cap_ends=True, cap_tris=False,
                    segments=_HOLLOW_SHAPE_SEGMENTS, radius1=radius, radius2=radius,
                    depth=size[axis], matrix=Matrix.Translation(centre) @ rotation)
            elif shape == 'SPHERE':
                bmesh.ops.create_uvsphere(
                    bm, u_segments=_HOLLOW_SHAPE_SEGMENTS,
                    v_segments=_HOLLOW_SHAPE_SEGMENTS // 2,
                    radius=0.5 * min(size), matrix=Matrix.Translation(centre))
            else:
                raise ValueError("unknown hollow shape {!r}".format(shape))
            for vert in bm.verts:
                vert.co *= scale
            bm.normal_update()
            return TOOL3D_OT_split_mark_sharp._hollow_shape_stamp(bm)
        finally:
            bm.free()

    @staticmethod
    def _hollow_shape_hull(coords, scale):
        """Convex hull of `coords` (local-space Vectors), scaled by `scale`
        about the origin, as a new role-2 mesh datablock."""
        bm = bmesh.new()
        try:
            for co in coords:
                bm.verts.new(co)
            hull = bmesh.ops.convex_hull(bm, input=list(bm.verts), use_existing_faces=False)
            junk = {g for g in hull["geom_interior"] + hull["geom_unused"]
                    if isinstance(g, bmesh.types.BMVert)}
            if junk:
                bmesh.ops.delete(bm, geom=list(junk), context='VERTS')
            if not bm.faces:
                raise ValueError("convex hull has no faces (degenerate source)")
            for vert in bm.verts:
                vert.co *= scale
            bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
            return TOOL3D_OT_split_mark_sharp._hollow_shape_stamp(bm)
        finally:
            bm.free()

    @staticmethod
    def _hollow_shape_outer_bvh(pieces):
        """BVHTree of every role-1 (outer surface) face of `pieces`, in the
        pieces' shared local space. Caps (role 0) are excluded: the cavity
        is meant to open through them."""
        from mathutils.bvhtree import BVHTree
        verts, polys = [], []
        for piece in pieces:
            bm = bmesh.new()
            try:
                bm.from_mesh(piece.data)
                role = bm.faces.layers.int.get(_SEAM_FACE_ROLE)
                for face in bm.faces:
                    if role is not None and face[role] != 1:
                        continue
                    base = len(verts)
                    verts.extend(v.co.copy() for v in face.verts)
                    polys.append(tuple(range(base, base + len(face.verts))))
            finally:
                bm.free()
        if not polys:
            return None
        return BVHTree.FromPolygons(verts, polys, all_triangles=False)

    @staticmethod
    def _hollow_shape_fit_scale(build, pieces, requested, step=0.02, floor=0.1):
        """Return (mesh, used_scale): the first primitive from `build(scale)`
        that does not intersect any piece's outer surface, trying
        `requested` then `requested - k*step` down to `floor`. Rejected
        meshes are freed here. (None, floor) when nothing fits."""
        from mathutils.bvhtree import BVHTree
        outer = TOOL3D_OT_split_mark_sharp._hollow_shape_outer_bvh(pieces)
        scale = requested
        while scale >= floor - 1.0e-9:
            mesh = build(scale)
            try:
                if outer is None:
                    return mesh, scale
                bm = bmesh.new()
                try:
                    bm.from_mesh(mesh)
                    tree = BVHTree.FromBMesh(bm)
                finally:
                    bm.free()
                if not outer.overlap(tree):
                    return mesh, scale
            except BaseException:
                # Fix pass (review): the datablock `build` just made is live,
                # and this call is not finishing. The caller's `finally` only
                # frees the primitive it was HANDED -- an exception hands it
                # none -- so a raise from `from_mesh`/`FromBMesh`/`overlap`
                # used to strand a `_tool3d_hollow_shape` mesh. Free it here,
                # then let the caller's boundary handle the exception.
                if mesh is not None and mesh.users == 0:
                    bpy.data.meshes.remove(mesh)
                raise
            bpy.data.meshes.remove(mesh)
            scale = round(scale - step, 6)
        return None, floor

    def _hollow_piece_shape(self, context, piece, primitive_mesh):
        """Carve `primitive_mesh` (role-2 faces, already scaled) out of the
        CLOSED piece with a Boolean DIFFERENCE. Returns (ring_count,
        reason, (signatures, tolerance, wall)) -- the same 3-tuple shape
        `_hollow_piece` returns, so `_apply_mark_sharp_settings` consumes
        both through one unpack.

        The boolean runs on a TEMPORARY object linked to the scene (the
        depsgraph evaluates nothing that is not linked) holding a copy of
        the piece's mesh and exactly one Boolean modifier -- never on the
        piece itself, whose own modifiers would leak into the result.
        Both temporaries and the copy are removed in `finally`. No
        `bpy.ops` is used, so one undo still reverts the whole operator.

        Fix pass (review): the clamped point-to-segment distance and the
        bbox tolerance are now the shared `_point_segment_distance` /
        `_bbox_tolerance` helpers (identical arithmetic, no tolerance
        changed); a cavity that reaches the outer surface with no cap rim
        is reported as a failure instead of masquerading as an enclosed
        void; and the material count is filtered to role-1 faces.
        """
        mesh = piece.data
        if mesh.shape_keys is not None:
            return 0, "hollow shape does not support shape keys; piece kept solid", None
        if not mesh.polygons:
            return 0, "piece has no faces to hollow", None

        scene = context.scene
        holder = operand = None
        holder_mesh = mesh.copy()
        carved = None
        try:
            holder = bpy.data.objects.new("_tool3d_hollow_holder", holder_mesh)
            operand = bpy.data.objects.new("_tool3d_hollow_operand", primitive_mesh)
            scene.collection.objects.link(holder)
            scene.collection.objects.link(operand)
            # Cavity faces take their material from the operand: give it the
            # piece's most common OUTER material index. Fix pass: the count
            # is restricted to role-1 (outer surface) polygons, so a piece
            # whose cap happens to outnumber its outer faces cannot hand
            # the cavity the cap's material. Falls back to every polygon
            # when the role attribute is absent (pre-3.0 `Mesh.attributes`,
            # or a piece that never went through the seam pipeline) or when
            # it marks no outer face at all.
            attributes = getattr(mesh, "attributes", None)
            role_attribute = None
            if attributes is not None:
                try:
                    role_attribute = attributes.get(_SEAM_FACE_ROLE)
                except (AttributeError, TypeError, KeyError):
                    role_attribute = None
            # Same domain guard as `_instance_int_attribute`: a mesh that
            # carries `_seam_surface_role` on a non-FACE domain would index
            # `role_attribute.data[poly.index]` out of range, and IndexError
            # is not in `_RECOVERABLE_ERRORS`, so it would escape every
            # handler and cancel the whole operator run. Dropping the
            # attribute here hands the count to the all-polygon fallback.
            if role_attribute is not None and role_attribute.domain != 'FACE':
                role_attribute = None
            counts = {}
            if role_attribute is not None:
                for poly in mesh.polygons:
                    if role_attribute.data[poly.index].value == 1:
                        counts[poly.material_index] = counts.get(poly.material_index, 0) + 1
            if not counts:
                for poly in mesh.polygons:
                    counts[poly.material_index] = counts.get(poly.material_index, 0) + 1
            common = max(counts, key=counts.get) if counts else 0
            for material in mesh.materials:
                primitive_mesh.materials.append(material)
            for poly in primitive_mesh.polygons:
                poly.material_index = common
            modifier = holder.modifiers.new("_tool3d_hollow", 'BOOLEAN')
            modifier.solver = 'EXACT'
            modifier.operation = 'DIFFERENCE'
            modifier.operand_type = 'OBJECT'
            modifier.object = operand
            modifier.material_mode = 'INDEX'
            depsgraph = context.evaluated_depsgraph_get()
            evaluated = holder.evaluated_get(depsgraph)
            carved = bpy.data.meshes.new_from_object(
                evaluated, preserve_all_data_layers=True, depsgraph=depsgraph)
        except TOOL3D_OT_split_mark_sharp._RECOVERABLE_ERRORS as exc:
            return 0, "boolean failed: {}".format(exc), None
        finally:
            # Order matters (fix pass). The shared primitive is restored
            # FIRST, so the next piece starts from a clean slot list even
            # if an object removal below were to raise something the guard
            # does not cover. Each object removal is then guarded on its
            # own, so a failure on the holder cannot skip the operand.
            # `holder_mesh` is removed last, since its user count only
            # drops to 0 once the holder object is gone.
            primitive_mesh.materials.clear()
            try:
                if holder is not None:
                    bpy.data.objects.remove(holder)
            except ReferenceError:
                pass
            try:
                if operand is not None:
                    bpy.data.objects.remove(operand)
            except ReferenceError:
                pass
            if holder_mesh.users == 0:
                bpy.data.meshes.remove(holder_mesh)

        try:
            bm = bmesh.new()
            try:
                bm.from_mesh(carved)
                # Layers FIRST: creating one later invalidates every element
                # wrapper already held (same rule as `_hollow_piece`).
                side = bm.verts.layers.int.get(_SEAM_VERT_SIDE)
                if side is None:
                    side = bm.verts.layers.int.new(_SEAM_VERT_SIDE)
                role = bm.faces.layers.int.get(_SEAM_FACE_ROLE)
                if role is None:
                    return 0, "boolean result lost the face role layer", None
                cavity = [f for f in bm.faces if f[role] == 2]
                if not cavity:
                    return 0, "cavity does not reach this piece", None
                if any(len(e.link_faces) != 2 for e in bm.edges):
                    return 0, "boolean produced a non-manifold result", None

                for vert in bm.verts:
                    vert[side] = 1
                for face in cavity:
                    for vert in face.verts:
                        vert[side] = 2

                outer_rim, inner_rim = [], []
                breaks_out = False
                for edge in bm.edges:
                    roles = sorted(f[role] for f in edge.link_faces)
                    if roles == [0, 1]:
                        outer_rim.append(edge)
                    elif roles == [0, 2]:
                        inner_rim.append(edge)
                    elif roles == [1, 2]:
                        breaks_out = True
                # Fix pass: a cavity that meets the OUTER surface directly,
                # with no cap ring anywhere, is not an enclosed void -- it
                # is an open hole through the shell, and reporting it as a
                # silent success would hand the caller `wall is None` for a
                # piece that has no wall at all. Only the genuine enclosed
                # void (no [1,2] and no [0,2] edges) keeps the success
                # contract below.
                if not inner_rim and breaks_out:
                    return 0, "cavity breaks through the outer surface without a cap rim", None
                tolerance = _bbox_tolerance(bm)
                signatures = {
                    "outer": [TOOL3D_OT_split_mark_sharp._edge_signature(
                        e.verts[0].co, e.verts[1].co, tolerance) for e in outer_rim],
                    "inner": [TOOL3D_OT_split_mark_sharp._edge_signature(
                        e.verts[0].co, e.verts[1].co, tolerance) for e in inner_rim],
                }
                wall = None
                outer_segments = [(e.verts[0].co.copy(), e.verts[1].co.copy()) for e in outer_rim]
                for edge in inner_rim:
                    for vert in edge.verts:
                        for start, end in outer_segments:
                            distance = _point_segment_distance(vert.co, start, end)
                            wall = distance if wall is None else min(wall, distance)
                ring_count = len(TOOL3D_OT_split_mark_sharp._connected_edge_loops(inner_rim))
                bm.to_mesh(mesh)
                mesh.update()
                return ring_count, None, (signatures, tolerance, wall)
            finally:
                bm.free()
        finally:
            if carved is not None and carved.users == 0:
                bpy.data.meshes.remove(carved)

    @staticmethod
    def _requantize_signature(signature, from_tolerance, to_tolerance):
        """Re-express an edge signature quantized on `from_tolerance`'s
        grid onto `to_tolerance`'s grid.

        A signature is `tuple(sorted((q0, q1)))` of integer grid cells
        (see `_edge_signature`). Multiplying a cell back by the grid it was
        made with recovers the coordinate to within that grid's own
        resolution, which is then re-rounded onto the target grid. Used by
        I4's provenance refresh, where the signatures are captured with the
        pre-write-back tolerance but must be matched against the
        post-write-back one.
        """
        if from_tolerance <= 0:
            from_tolerance = 1.0e-8
        if to_tolerance <= 0:
            to_tolerance = 1.0e-8
        if from_tolerance == to_tolerance:
            return signature
        scale = from_tolerance / to_tolerance
        return tuple(sorted(
            tuple(int(round(component * scale)) for component in point)
            for point in signature
        ))

    def _format_result_report(self, result):
        """Return the concise status-bar report string.

        Final fix pass (M3): the required wording
        `Processed N objects, created M pieces, filled K cut loops.` is now
        the leading sentence, verbatim, so the status bar always states
        the three headline numbers in the agreed form. Everything else
        (valid loops, ignored components, skipped sources, offset clamps,
        beveled edges, failure count) follows as an optional detail
        clause, and the full per-failure detail goes to the console via
        `_print_failure_details`.
        """
        message = "Processed {} objects, created {} pieces, filled {} cut loops.".format(
            result.get("processed_objects", 0),
            result.get("pieces", 0),
            result.get("filled_loops", 0),
        )

        parts = ["{} valid loop(s)".format(result.get("valid_loops", 0))]
        if result.get("ignored_components"):
            parts.append("{} ignored component(s)".format(result["ignored_components"]))
        if result.get("skipped_objects"):
            parts.append("{} skipped".format(result["skipped_objects"]))
        if result.get("offset_warnings"):
            parts.append("{} offset warning(s)".format(result["offset_warnings"]))
        if result.get("beveled_edges"):
            parts.append("{} beveled edge(s)".format(result["beveled_edges"]))
        if result.get("hollow_warnings"):
            parts.append("{} hollow warning(s)".format(result["hollow_warnings"]))
        if result.get("linked_pieces"):
            parts.append("{} linked instance(s)".format(result["linked_pieces"]))
        if result.get("approximate_linked"):
            parts.append("{} approximate (max deviation {:.2f}%; shape/joint gaps may change)".format(
                result["approximate_linked"], result["instance_max_error_percent"]))
        failed_loops = result.get("failed_loops") or []
        if failed_loops:
            parts.append("{} failure(s) -- see Console".format(len(failed_loops)))

        return "{} ({} of {} selected; {}.)".format(
            message,
            result.get("processed_objects", 0),
            result.get("selected_objects", 0),
            ", ".join(parts),
        )

    @staticmethod
    def _clear_cut_seams(obj):
        """Clear `use_seam` on every edge of `obj`'s mesh (user request
        2026-09-23: the Seam marks are the cut instruction and are spent
        once the pieces exist). Sharp flags are deliberately left alone --
        `_shade_cut_piece` owns them. Object-mode data only; a no-op on a
        mesh with no seam, and never touches a mesh that is not a MESH."""
        mesh = getattr(obj, "data", None)
        if mesh is None or not hasattr(mesh, "edges"):
            return 0
        cleared = 0
        for edge in mesh.edges:
            if edge.use_seam:
                edge.use_seam = False
                cleared += 1
        if cleared:
            mesh.update()
        return cleared

    @staticmethod
    def _strip_cut_marker_layers(obj):
        """Remove the temporary cut_id marker attributes from `obj`'s mesh
        data if present, so provenance is never persisted on the final
        mesh (binding constraint). Safe to call on a piece that never
        carried them (e.g. because classification found nothing there).

        Final fix pass (I6): `Mesh.attributes` only exists from Blender
        3.0 onward, while this add-on's `bl_info` declares a
        `(2, 80, 0)` floor -- so on any 2.8x/2.9x Blender the previous
        unguarded `mesh.attributes.get(...)` raised AttributeError and
        took the whole operator down at its very last step, after all the
        geometry work had already succeeded. The attribute path is now
        probed with `getattr`, and a BMesh round trip is used as the
        fallback removal route on builds that predate it (BMesh custom
        data layers exist in 2.80). If neither route is available the
        function no-ops rather than raising: leaving a stray integer
        layer behind is far less harmful than failing the operation.
        """
        mesh = obj.data

        attributes = getattr(mesh, "attributes", None)
        if attributes is not None:
            removed = False
            for name in (_SHARP_CUT_EDGE_LAYER, _SHARP_CUT_VERT_LAYER,
                         _SEAM_FACE_ROLE, _SEAM_VERT_SIDE, _SEAM_FOLD_EDGE):
                try:
                    attr = attributes.get(name)
                except (AttributeError, TypeError, KeyError):
                    attr = None
                if attr is not None:
                    attributes.remove(attr)
                    removed = True
            if removed:
                mesh.update()
            return

        # Pre-3.0 fallback: drop the layers through BMesh instead.
        bm = bmesh.new()
        try:
            bm.from_mesh(mesh)
            removed = False
            edge_layer = bm.edges.layers.int.get(_SHARP_CUT_EDGE_LAYER)
            if edge_layer is not None:
                bm.edges.layers.int.remove(edge_layer)
                removed = True
            vert_layer = bm.verts.layers.int.get(_SHARP_CUT_VERT_LAYER)
            if vert_layer is not None:
                bm.verts.layers.int.remove(vert_layer)
                removed = True
            for layers, name in ((bm.faces.layers.int, _SEAM_FACE_ROLE),
                                 (bm.verts.layers.int, _SEAM_VERT_SIDE),
                                 (bm.edges.layers.int, _SEAM_FOLD_EDGE)):
                layer = layers.get(name)
                if layer is not None:
                    layers.remove(layer)
                    removed = True
            if removed:
                bm.to_mesh(mesh)
                mesh.update()
        except TOOL3D_OT_split_mark_sharp._RECOVERABLE_ERRORS as exc:
            print(
                "[Tool3D] marker layer cleanup fallback failed on {}: {}".format(
                    getattr(obj, "name", "<unknown>"), exc)
            )
        finally:
            bm.free()


# ========== INTERSECTION DETECTOR ==========

class TOOL3D_OT_detect_intersections(bpy.types.Operator):
    """Phat hien va hien thi vung mesh bi giao nhau (intersect) giua cac mesh"""
    bl_idname = "tool3d.detect_intersections"
    bl_label = "Detect Intersections"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        selected = [o for o in context.selected_objects if o.type == 'MESH']
        return len(selected) >= 2
    
    def execute(self, context):
        from mathutils.bvhtree import BVHTree
        
        selected = [o for o in context.selected_objects if o.type == 'MESH']
        if len(selected) < 2:
            self.report({'WARNING'}, "Chon it nhat 2 mesh!")
            return {'CANCELLED'}
        
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        
        # Moi mesh object duoc coi la 1 don vi rieng (combined mesh = 1 don vi)
        # Chi kiem tra intersection GIUA cac object khac nhau
        # Khong kiem tra self-intersection ben trong 1 object
        
        depsgraph = context.evaluated_depsgraph_get()
        bvh_trees = {}
        mesh_data = {}
        
        for obj in selected:
            obj_eval = obj.evaluated_get(depsgraph)
            me = obj_eval.to_mesh()
            
            mat = obj.matrix_world
            verts = [(mat @ v.co).to_tuple() for v in me.vertices]
            polys = [tuple(p.vertices) for p in me.polygons]
            
            obj_eval.to_mesh_clear()
            
            if not verts or not polys:
                continue
            
            try:
                bvh = BVHTree.FromPolygons(verts, polys, all_triangles=False, epsilon=0.0001)
            except Exception as e:
                print("BVHTree error for {}: {}".format(obj.name, str(e)))
                continue
            
            bvh_trees[obj.name] = bvh
            mesh_data[obj.name] = (obj, verts, polys)
        
        if len(bvh_trees) < 2:
            self.report({'WARNING'}, "Khong du mesh hop le!")
            return {'CANCELLED'}
        
        # Chi kiem tra overlap GIUA cac object khac nhau
        # (combined mesh = 1 object -> khong bi tinh noi bo)
        # BVHTree.overlap() tra ve cac cap polygon co bounding box giao nhau
        # Can loc them: chi giu cac cap polygon THAT SU intersect (khong chi bbox)
        total_overlaps = 0
        overlap_pairs = []
        
        mesh_names = list(bvh_trees.keys())
        for i in range(len(mesh_names)):
            for j in range(i + 1, len(mesh_names)):
                name_a = mesh_names[i]
                name_b = mesh_names[j]
                try:
                    overlaps = bvh_trees[name_a].overlap(bvh_trees[name_b])
                except Exception as e:
                    print("Overlap error {}-{}: {}".format(name_a, name_b, str(e)))
                    continue
                if overlaps:
                    # Loc: chi giu cac cap polygon that su giao nhau
                    _, verts_a, polys_a = mesh_data[name_a]
                    _, verts_b, polys_b = mesh_data[name_b]
                    real_overlaps = self._filter_real_intersections(
                        overlaps, verts_a, polys_a, verts_b, polys_b
                    )
                    if real_overlaps:
                        total_overlaps += len(real_overlaps)
                        overlap_pairs.append((name_a, name_b, real_overlaps))
        
        if total_overlaps == 0:
            tool3d_clear_intersection_geometry()
            self.report({'INFO'}, "Khong co intersection nao giua cac mesh!")
            return {'FINISHED'}
        
        # Gioi han so luong faces hien thi (tranh qua nang)
        max_display = 5000
        if total_overlaps > max_display:
            self.report({'WARNING'}, "Qua nhieu ({}) overlaps! Chi hien thi {} dau tien.".format(
                total_overlaps, max_display))
        
        # Tao mesh hien thi vung intersection
        self._create_intersection_visual(context, overlap_pairs, mesh_data, max_display)
        
        self.report({'WARNING'}, "Phat hien {} vung intersection giua {} cap mesh!".format(
            total_overlaps, len(overlap_pairs)))
        return {'FINISHED'}
    
    @staticmethod
    def _filter_real_intersections(overlaps, verts_a, polys_a, verts_b, polys_b):
        """Loc chi giu cac cap polygon THAT SU intersect (khong chi bounding box overlap)"""
        from mathutils import Vector
        from mathutils.geometry import intersect_tri_tri_2d, intersect_line_plane
        
        real = []
        for fi_a, fi_b in overlaps:
            if fi_a >= len(polys_a) or fi_b >= len(polys_b):
                continue
            
            poly_a = polys_a[fi_a]
            poly_b = polys_b[fi_b]
            
            # Lay vertices cua 2 polygon
            va = [Vector(verts_a[i]) for i in poly_a]
            vb = [Vector(verts_b[i]) for i in poly_b]
            
            # Kiem tra co that su giao nhau khong
            # Bang cach triangulate va test tung cap triangle
            if TOOL3D_OT_detect_intersections._polys_intersect(va, vb):
                real.append((fi_a, fi_b))
        
        return real
    
    @staticmethod
    def _polys_intersect(verts_a, verts_b):
        """Kiem tra 2 polygon co that su giao nhau khong (triangle-based)"""
        from mathutils.geometry import intersect_tri_tri_2d
        from mathutils import Vector
        
        # Triangulate polygon A (fan triangulation)
        tris_a = []
        for i in range(1, len(verts_a) - 1):
            tris_a.append((verts_a[0], verts_a[i], verts_a[i + 1]))
        
        # Triangulate polygon B
        tris_b = []
        for i in range(1, len(verts_b) - 1):
            tris_b.append((verts_b[0], verts_b[i], verts_b[i + 1]))
        
        # Kiem tra tung cap tri-tri co giao nhau khong
        for ta in tris_a:
            for tb in tris_b:
                if TOOL3D_OT_detect_intersections._tri_tri_intersect_3d(
                        ta[0], ta[1], ta[2], tb[0], tb[1], tb[2]):
                    return True
        return False
    
    @staticmethod
    def _tri_tri_intersect_3d(v0, v1, v2, u0, u1, u2):
        """Kiem tra 2 tam giac trong 3D co giao nhau khong"""
        from mathutils import Vector
        from mathutils.geometry import intersect_line_plane
        
        # Normal cua triangle 1
        n1 = (v1 - v0).cross(v2 - v0)
        if n1.length < 1e-8:
            return False
        n1.normalize()
        d1 = -n1.dot(v0)
        
        # Khoang cach cac dinh cua tri2 den mat phang tri1
        du0 = n1.dot(u0) + d1
        du1 = n1.dot(u1) + d1
        du2 = n1.dot(u2) + d1
        
        # Tolerance
        tol = 1e-6
        if abs(du0) < tol: du0 = 0
        if abs(du1) < tol: du1 = 0
        if abs(du2) < tol: du2 = 0
        
        # Neu tat ca cac dinh cua tri2 cung phia -> khong giao
        if du0 * du1 > 0 and du0 * du2 > 0:
            return False
        
        # Normal cua triangle 2
        n2 = (u1 - u0).cross(u2 - u0)
        if n2.length < 1e-8:
            return False
        n2.normalize()
        d2 = -n2.dot(u0)
        
        # Khoang cach cac dinh cua tri1 den mat phang tri2
        dv0 = n2.dot(v0) + d2
        dv1 = n2.dot(v1) + d2
        dv2 = n2.dot(v2) + d2
        
        if abs(dv0) < tol: dv0 = 0
        if abs(dv1) < tol: dv1 = 0
        if abs(dv2) < tol: dv2 = 0
        
        if dv0 * dv1 > 0 and dv0 * dv2 > 0:
            return False
        
        # 2 triangles cat nhau (hoac co-planar)
        return True
    
    @staticmethod
    def _create_intersection_visual(context, overlap_pairs, mesh_data, max_faces=5000):
        """Tao object hien thi highlight vung intersection"""
        all_verts = []
        all_faces = []
        vert_offset = 0
        face_count = 0
        
        for name_a, name_b, overlaps in overlap_pairs:
            obj_a, verts_a, polys_a = mesh_data[name_a]
            obj_b, verts_b, polys_b = mesh_data[name_b]
            
            for face_idx_a, face_idx_b in overlaps:
                if face_count >= max_faces:
                    break
                
                # Face tu mesh A
                if face_idx_a < len(polys_a):
                    poly = polys_a[face_idx_a]
                    face_verts = []
                    for vi in poly:
                        all_verts.append(verts_a[vi])
                        face_verts.append(vert_offset)
                        vert_offset += 1
                    all_faces.append(face_verts)
                    face_count += 1
                
                if face_count >= max_faces:
                    break
                
                # Face tu mesh B
                if face_idx_b < len(polys_b):
                    poly = polys_b[face_idx_b]
                    face_verts = []
                    for vi in poly:
                        all_verts.append(verts_b[vi])
                        face_verts.append(vert_offset)
                        vert_offset += 1
                    all_faces.append(face_verts)
                    face_count += 1
            
            if face_count >= max_faces:
                break
        
        if not all_verts:
            tool3d_clear_intersection_geometry()
            return
        
        # Tai su dung display object de realtime update khong tao object rac.
        display_obj = bpy.data.objects.get(_TOOL3D_INTERSECTION_DISPLAY)
        if display_obj:
            mesh = display_obj.data
            if hasattr(mesh, "clear_geometry"):
                mesh.clear_geometry()
            else:
                old_mesh = mesh
                mesh = bpy.data.meshes.new(_TOOL3D_INTERSECTION_MESH)
                display_obj.data = mesh
                if old_mesh.users == 0:
                    bpy.data.meshes.remove(old_mesh)
        else:
            mesh = bpy.data.meshes.new(_TOOL3D_INTERSECTION_MESH)
            display_obj = bpy.data.objects.new(
                _TOOL3D_INTERSECTION_DISPLAY, mesh)
            context.scene.collection.objects.link(display_obj)

        mesh.from_pydata(all_verts, [], all_faces)
        mesh.update()
        
        # Tao material do de hien thi ro
        mat = bpy.data.materials.get(_TOOL3D_INTERSECTION_MATERIAL)
        if not mat:
            mat = bpy.data.materials.new(
                name=_TOOL3D_INTERSECTION_MATERIAL)
            mat.diffuse_color = (1.0, 0.0, 0.0, 0.6)
            mat.use_backface_culling = False
        
        if not display_obj.data.materials:
            display_obj.data.materials.append(mat)
        display_obj.display_type = 'SOLID'
        display_obj.show_in_front = True
        display_obj.hide_select = True
        display_obj.hide_render = True


def tool3d_clear_intersection_geometry(remove_object=False):
    """Xoa ket qua cu; mac dinh giu display object de tai su dung."""
    display_obj = bpy.data.objects.get(_TOOL3D_INTERSECTION_DISPLAY)
    if not display_obj:
        return

    if remove_object:
        mesh = display_obj.data
        bpy.data.objects.remove(display_obj, do_unlink=True)
        if mesh and mesh.users == 0:
            bpy.data.meshes.remove(mesh)
        return

    mesh = display_obj.data
    if hasattr(mesh, "clear_geometry"):
        mesh.clear_geometry()
        mesh.update()
    else:
        old_mesh = mesh
        new_mesh = bpy.data.meshes.new(_TOOL3D_INTERSECTION_MESH)
        display_obj.data = new_mesh
        if old_mesh.users == 0:
            bpy.data.meshes.remove(old_mesh)


def tool3d_rebuild_live_intersections():
    """Tinh lai intersection cho nhom object duoc ghi nho khi Start."""
    from mathutils.bvhtree import BVHTree

    scene = bpy.context.scene
    if not scene or not getattr(scene, "tool3d_live_intersection", False):
        return

    objects = []
    stale_names = []
    for name in _tool3d_live_object_names:
        obj = bpy.data.objects.get(name)
        if obj and obj.type == 'MESH':
            objects.append(obj)
        else:
            stale_names.append(name)
    for name in stale_names:
        _tool3d_live_object_names.discard(name)

    if len(objects) < 2:
        tool3d_clear_intersection_geometry()
        return

    depsgraph = bpy.context.evaluated_depsgraph_get()
    bvh_trees = {}
    mesh_data = {}

    for obj in objects:
        obj_eval = obj.evaluated_get(depsgraph)
        me = obj_eval.to_mesh()
        try:
            # Dung matrix cua evaluated object de ho tro constraint/animation.
            mat = obj_eval.matrix_world
            verts = [(mat @ vertex.co).to_tuple() for vertex in me.vertices]
            polys = [tuple(poly.vertices) for poly in me.polygons]
        finally:
            obj_eval.to_mesh_clear()

        if not verts or not polys:
            continue

        try:
            bvh_trees[obj.name] = BVHTree.FromPolygons(
                verts, polys, all_triangles=False, epsilon=0.0001)
            mesh_data[obj.name] = (obj, verts, polys)
        except Exception as exc:
            print("Live BVHTree error for {}: {}".format(obj.name, exc))

    overlap_pairs = []
    total_overlaps = 0
    mesh_names = list(bvh_trees.keys())

    for index_a in range(len(mesh_names)):
        for index_b in range(index_a + 1, len(mesh_names)):
            name_a = mesh_names[index_a]
            name_b = mesh_names[index_b]
            try:
                overlaps = bvh_trees[name_a].overlap(bvh_trees[name_b])
            except Exception as exc:
                print("Live overlap error {}-{}: {}".format(
                    name_a, name_b, exc))
                continue

            if not overlaps:
                continue

            _, verts_a, polys_a = mesh_data[name_a]
            _, verts_b, polys_b = mesh_data[name_b]
            real_overlaps = (
                TOOL3D_OT_detect_intersections._filter_real_intersections(
                    overlaps, verts_a, polys_a, verts_b, polys_b))
            if real_overlaps:
                total_overlaps += len(real_overlaps)
                overlap_pairs.append((name_a, name_b, real_overlaps))

    if total_overlaps == 0:
        tool3d_clear_intersection_geometry()
    else:
        TOOL3D_OT_detect_intersections._create_intersection_visual(
            bpy.context, overlap_pairs, mesh_data, max_faces=5000)


def tool3d_live_intersection_timer():
    """One-shot debounce timer. None means Blender must unregister it."""
    global _tool3d_live_dirty
    global _tool3d_live_timer_registered
    global _tool3d_live_updating

    _tool3d_live_timer_registered = False

    scene = bpy.context.scene
    if not scene or not getattr(scene, "tool3d_live_intersection", False):
        return None
    if not _tool3d_live_dirty or _tool3d_live_updating:
        return None

    _tool3d_live_dirty = False
    _tool3d_live_updating = True
    try:
        tool3d_rebuild_live_intersections()
    except Exception as exc:
        print("Live Intersection update error: {}".format(exc))
    finally:
        _tool3d_live_updating = False

    return None


def tool3d_live_intersection_handler(scene, depsgraph):
    """Theo doi transform/geometry cua cac object dang duoc live check."""
    global _tool3d_live_dirty
    global _tool3d_live_timer_registered

    if not getattr(scene, "tool3d_live_intersection", False):
        return
    if _tool3d_live_updating or not _tool3d_live_object_names:
        return

    watched_meshes = set()
    for name in _tool3d_live_object_names:
        obj = bpy.data.objects.get(name)
        if obj and obj.data:
            watched_meshes.add(obj.data.name)

    relevant_update = False
    for update in depsgraph.updates:
        update_id = update.id
        if isinstance(update_id, bpy.types.Object):
            relevant_update = update_id.name in _tool3d_live_object_names
        elif isinstance(update_id, bpy.types.Mesh):
            relevant_update = update_id.name in watched_meshes
        if relevant_update:
            break

    if not relevant_update:
        return

    _tool3d_live_dirty = True
    if not _tool3d_live_timer_registered:
        _tool3d_live_timer_registered = True
        bpy.app.timers.register(
            tool3d_live_intersection_timer, first_interval=0.12)


def tool3d_ensure_live_handler():
    handlers = bpy.app.handlers.depsgraph_update_post
    if tool3d_live_intersection_handler not in handlers:
        handlers.append(tool3d_live_intersection_handler)


def tool3d_remove_live_handler():
    handlers = bpy.app.handlers.depsgraph_update_post
    if tool3d_live_intersection_handler in handlers:
        handlers.remove(tool3d_live_intersection_handler)


class TOOL3D_OT_start_live_intersections(bpy.types.Operator):
    """Bat kiem tra intersection realtime cho cac mesh dang chon"""
    bl_idname = "tool3d.start_live_intersections"
    bl_label = "Start Live Check"

    @classmethod
    def poll(cls, context):
        selected = [
            obj for obj in context.selected_objects
            if obj.type == 'MESH'
            and obj.name != _TOOL3D_INTERSECTION_DISPLAY
        ]
        return context.mode == 'OBJECT' and len(selected) >= 2

    def execute(self, context):
        global _tool3d_live_dirty

        selected = [
            obj for obj in context.selected_objects
            if obj.type == 'MESH'
            and obj.name != _TOOL3D_INTERSECTION_DISPLAY
        ]
        if len(selected) < 2:
            self.report({'WARNING'}, "Chon it nhat 2 mesh!")
            return {'CANCELLED'}

        _tool3d_live_object_names.clear()
        _tool3d_live_object_names.update(obj.name for obj in selected)
        context.scene.tool3d_live_intersection = True
        _tool3d_live_dirty = False
        tool3d_ensure_live_handler()
        tool3d_rebuild_live_intersections()

        self.report({'INFO'}, "Live Intersection: {} objects.".format(
            len(selected)))
        return {'FINISHED'}


class TOOL3D_OT_stop_live_intersections(bpy.types.Operator):
    """Dung kiem tra intersection realtime va xoa vung hien thi"""
    bl_idname = "tool3d.stop_live_intersections"
    bl_label = "Stop Live Check"

    def execute(self, context):
        global _tool3d_live_dirty
        global _tool3d_live_timer_registered

        context.scene.tool3d_live_intersection = False
        _tool3d_live_object_names.clear()
        _tool3d_live_dirty = False
        _tool3d_live_timer_registered = False
        tool3d_remove_live_handler()
        tool3d_clear_intersection_geometry(remove_object=True)

        self.report({'INFO'}, "Live Intersection stopped.")
        return {'FINISHED'}


class TOOL3D_OT_clear_intersections(bpy.types.Operator):
    """Xoa hien thi intersection"""
    bl_idname = "tool3d.clear_intersections"
    bl_label = "Clear Intersection Display"
    
    def execute(self, context):
        # Clear Display chi xoa ket qua. Neu Live dang bat, ket qua se duoc
        # tao lai o lan transform tiep theo.
        tool3d_clear_intersection_geometry(remove_object=True)
        self.report({'INFO'}, "Intersection display cleared.")
        return {'FINISHED'}


class TOOL3D_OT_select_intersecting_faces(bpy.types.Operator):
    """Chon cac faces bi intersection tren mesh goc"""
    bl_idname = "tool3d.select_intersecting_faces"
    bl_label = "Select Intersecting Faces"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        selected = [o for o in context.selected_objects if o.type == 'MESH']
        return len(selected) >= 2
    
    def execute(self, context):
        from mathutils.bvhtree import BVHTree
        from mathutils import Vector
        
        selected = [o for o in context.selected_objects if o.type == 'MESH']
        if len(selected) < 2:
            self.report({'WARNING'}, "Chon it nhat 2 mesh!")
            return {'CANCELLED'}
        
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        
        # Tao BVHTree cho tung mesh
        depsgraph = context.evaluated_depsgraph_get()
        bvh_trees = {}
        mesh_data = {}
        for obj in selected:
            obj_eval = obj.evaluated_get(depsgraph)
            me = obj_eval.to_mesh()
            mat = obj.matrix_world
            verts = [(mat @ v.co).to_tuple() for v in me.vertices]
            polys = [tuple(p.vertices) for p in me.polygons]
            obj_eval.to_mesh_clear()
            
            if not verts or not polys:
                continue
            try:
                bvh = BVHTree.FromPolygons(verts, polys, all_triangles=False, epsilon=0.0001)
                bvh_trees[obj.name] = bvh
                mesh_data[obj.name] = (obj, verts, polys)
            except Exception as e:
                print("BVHTree error for {}: {}".format(obj.name, str(e)))
                continue
        
        if len(bvh_trees) < 2:
            self.report({'WARNING'}, "Khong du mesh hop le!")
            return {'CANCELLED'}
        
        # Tim overlap giua tung cap - loc chi lay cac intersection that su
        faces_to_select = {}
        for obj in selected:
            faces_to_select[obj.name] = set()
        
        mesh_names = list(bvh_trees.keys())
        for i in range(len(mesh_names)):
            for j in range(i + 1, len(mesh_names)):
                name_a = mesh_names[i]
                name_b = mesh_names[j]
                try:
                    overlaps = bvh_trees[name_a].overlap(bvh_trees[name_b])
                except:
                    continue
                if overlaps:
                    _, verts_a, polys_a = mesh_data[name_a]
                    _, verts_b, polys_b = mesh_data[name_b]
                    for fi_a, fi_b in overlaps:
                        if fi_a >= len(polys_a) or fi_b >= len(polys_b):
                            continue
                        poly_a = polys_a[fi_a]
                        poly_b = polys_b[fi_b]
                        va = [Vector(verts_a[k]) for k in poly_a]
                        vb = [Vector(verts_b[k]) for k in poly_b]
                        if self._polys_really_intersect(va, vb):
                            faces_to_select[name_a].add(fi_a)
                            faces_to_select[name_b].add(fi_b)
        
        # Select faces tren mesh goc
        total_selected = 0
        for obj in selected:
            face_indices = faces_to_select.get(obj.name, set())
            if not face_indices:
                continue
            
            # Deselect all polygon tren object nay
            for p in obj.data.polygons:
                p.select = False
            
            # Select cac face bi overlap
            for fi in face_indices:
                if fi < len(obj.data.polygons):
                    obj.data.polygons[fi].select = True
                    total_selected += 1
        
        # Chuyen sang edit mode de thay selection
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_mode(type='FACE')
        
        if total_selected > 0:
            self.report({'WARNING'}, "Selected {} intersecting faces.".format(total_selected))
        else:
            self.report({'INFO'}, "Khong co intersection.")
        
        return {'FINISHED'}
    
    def _polys_really_intersect(self, verts_a, verts_b):
        """Kiem tra 2 polygon co that su giao nhau khong"""
        from mathutils import Vector
        
        # Triangulate polygon A (fan)
        tris_a = []
        for i in range(1, len(verts_a) - 1):
            tris_a.append((verts_a[0], verts_a[i], verts_a[i + 1]))
        
        # Triangulate polygon B (fan)
        tris_b = []
        for i in range(1, len(verts_b) - 1):
            tris_b.append((verts_b[0], verts_b[i], verts_b[i + 1]))
        
        for ta in tris_a:
            for tb in tris_b:
                if self._tri_tri_test(ta[0], ta[1], ta[2], tb[0], tb[1], tb[2]):
                    return True
        return False
    
    def _tri_tri_test(self, v0, v1, v2, u0, u1, u2):
        """Tri-tri intersection test 3D"""
        n1 = (v1 - v0).cross(v2 - v0)
        if n1.length < 1e-8:
            return False
        n1.normalize()
        d1 = -n1.dot(v0)
        
        du0 = n1.dot(u0) + d1
        du1 = n1.dot(u1) + d1
        du2 = n1.dot(u2) + d1
        
        tol = 1e-6
        if abs(du0) < tol: du0 = 0
        if abs(du1) < tol: du1 = 0
        if abs(du2) < tol: du2 = 0
        
        if du0 * du1 > 0 and du0 * du2 > 0:
            return False
        
        n2 = (u1 - u0).cross(u2 - u0)
        if n2.length < 1e-8:
            return False
        n2.normalize()
        d2 = -n2.dot(u0)
        
        dv0 = n2.dot(v0) + d2
        dv1 = n2.dot(v1) + d2
        dv2 = n2.dot(v2) + d2
        
        if abs(dv0) < tol: dv0 = 0
        if abs(dv1) < tol: dv1 = 0
        if abs(dv2) < tol: dv2 = 0
        
        if dv0 * dv1 > 0 and dv0 * dv2 > 0:
            return False
        
        return True


class TOOL3D_OT_detect_self_intersect(bpy.types.Operator):
    """Join tam tat ca mesh thanh 1 de hien thi intersection realtime qua overlay"""
    bl_idname = "tool3d.detect_self_intersect"
    bl_label = "Enable Overlay"
    
    @classmethod
    def poll(cls, context):
        return any(o.type == 'MESH' for o in context.selected_objects)
    
    def execute(self, context):
        selected_meshes = [o for o in context.selected_objects if o.type == 'MESH']
        
        if not selected_meshes:
            self.report({'WARNING'}, "Chon mesh truoc!")
            return {'CANCELLED'}
        
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        
        # Xoa temp cu neu co
        old_temp = bpy.data.objects.get("_Intersect_Overlay_Temp")
        if old_temp:
            bpy.data.objects.remove(old_temp, do_unlink=True)
        
        # Duplicate tat ca mesh da chon
        bpy.ops.object.select_all(action='DESELECT')
        for obj in selected_meshes:
            obj.select_set(True)
        context.view_layer.objects.active = selected_meshes[0]
        
        bpy.ops.object.duplicate()
        duplicates = [o for o in context.selected_objects]
        
        # Join tat ca duplicates thanh 1 object
        context.view_layer.objects.active = duplicates[0]
        bpy.ops.object.join()
        
        # Doi ten object tam
        temp_obj = context.active_object
        temp_obj.name = "_Intersect_Overlay_Temp"
        
        # An cac mesh goc
        for obj in selected_meshes:
            obj.hide_set(True)
        
        # Vao Edit mode tren object da join
        bpy.ops.object.mode_set(mode='EDIT')
        
        # Bat Mesh Analysis overlay - INTERSECT
        try:
            context.scene.tool_settings.statvis.type = 'INTERSECT'
        except:
            pass
        
        # Bat show_statvis tren viewport
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.spaces.active.overlay.show_statvis = True
                break
        
        self.report({'INFO'}, 
            "Overlay ON: {} mesh joined tam de hien thi intersection. Nhan Disable de ket thuc.".format(
                len(selected_meshes)))
        return {'FINISHED'}


class TOOL3D_OT_disable_self_intersect(bpy.types.Operator):
    """Tat overlay va xoa object tam, hien lai mesh goc"""
    bl_idname = "tool3d.disable_self_intersect"
    bl_label = "Disable Overlay"
    
    def execute(self, context):
        # Tat overlay
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.spaces.active.overlay.show_statvis = False
                break
        
        # Thoat edit mode neu dang trong
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        
        # Xoa object tam
        temp_obj = bpy.data.objects.get("_Intersect_Overlay_Temp")
        if temp_obj:
            bpy.data.objects.remove(temp_obj, do_unlink=True)
        
        # Hien lai tat ca mesh da bi an
        for obj in context.view_layer.objects:
            if obj.type == 'MESH' and obj.hide_get():
                obj.hide_set(False)
        
        self.report({'INFO'}, "Overlay OFF - mesh goc da duoc hien lai.")
        return {'FINISHED'}


# ========== PROPERTIES ==========

def tool3d_save_settings(self, context):
    addon = context.preferences.addons.get(__package__)
    if addon:
        prefs = addon.preferences
        prefs.offset_value = self.offset_value
        prefs.bevel_width = self.bevel_width
        prefs.bevel_segments = self.bevel_segments


class Tool3DProperties(bpy.types.PropertyGroup):
    auto_separate: BoolProperty(name="Separate", default=True)
    auto_fill: BoolProperty(name="Fill Holes", default=True)
    auto_bevel: BoolProperty(name="Bevel", default=False)

    offset_value: FloatProperty(
        name="Offset",
        default=0.0,
        min=0.0,
        max=20.0,
        precision=3,
        update=tool3d_save_settings
    )

    bevel_width: FloatProperty(
        name="Bevel Width",
        default=0.1,
        min=0.001,
        max=5.0,
        precision=3,
        update=tool3d_save_settings
    )

    bevel_segments: IntProperty(
        name="Bevel Segments",
        default=1,
        min=1,
        max=20,
        update=tool3d_save_settings
    )

    uv_preset: EnumProperty(
        name="UV Preset",
        description="Chon toa do UV",
        items=[
            ('0', "1 X0 Y0", "Toa do UV (0.0, 0.0)"),
            ('1', "2 X0.5 Y0", "Toa do UV (0.5, 0.0)"),
            ('2', "3 X1 Y0", "Toa do UV (1.0, 0.0)"),
        ],
        default='0'
    )

    # ===== Task 5: independent Seam-cut settings =====
    #
    # Deliberately separate fields from auto_fill/auto_bevel/offset_value/
    # bevel_width/bevel_segments above: TOOL3D_OT_split_mark_sharp reads
    # its own runtime configuration from its OWN identically-named
    # operator properties (self.sharp_auto_fill, self.sharp_offset_value,
    # ...; Task 1-2 contract, unchanged -- exercised by every
    # bpy.ops.tool3d.split_mark_sharp(sharp_*=...) call throughout the
    # test suite), never from these. These six exist purely as the
    # Scene-level settings surface the "MARK SEAM CUT" UI box below
    # edits/displays. Changing one of these must never change (and is
    # never changed by) any of the five legacy fields above, or vice
    # versa -- verified by test_sharp_scene_properties_independent_
    # from_legacy. Per the brief: deliberately NOT wired to
    # tool3d_save_settings.
    #
    # Defaults (user request 2026-09-11): the Split Mark Seam box starts
    # with Auto Bevel Cuts ON, Hollow ON and Seam Bevel Width 0.1. Only
    # these Scene-level fields changed -- the operator's identically-named
    # properties keep their conservative defaults (bevel/hollow off,
    # width 0.01), so bpy.ops.tool3d.split_mark_sharp() called without
    # arguments (every test, any script) still produces flat caps.
    sharp_auto_fill: BoolProperty(name="Auto Fill Cuts", default=True)
    sharp_auto_bevel: BoolProperty(name="Auto Bevel Cuts", default=True)
    sharp_offset_value: FloatProperty(
        name="Seam Offset", default=0.0, min=0.0, max=20.0, precision=3
    )
    sharp_bevel_width: FloatProperty(
        name="Seam Bevel Width", default=0.1, min=0.001, max=5.0, precision=3
    )
    sharp_bevel_segments: IntProperty(
        name="Seam Bevel Segments", default=1, min=1, max=20
    )
    sharp_fill_tolerance: FloatProperty(
        name="Seam Fill Tolerance", default=0.0001, min=0.000001, max=0.1, precision=6
    )
    # Hollow shell (2026-09-09): see TOOL3D_OT_split_mark_sharp.sharp_hollow.
    # Scene default ON since 2026-09-11 (operator default stays False).
    sharp_hollow: BoolProperty(name="Hollow", default=True)
    sharp_hollow_scale: FloatProperty(
        name="Inner Scale", default=0.8, min=0.1, max=0.99, precision=3
    )
    sharp_crease_angle: FloatProperty(
        name="Crease Angle", default=math.radians(15.0), min=0.0,
        max=math.radians(180.0), subtype='ANGLE',
    )
    sharp_hollow_shape: EnumProperty(
        name="Hollow Shape", items=_HOLLOW_SHAPE_ITEMS, default='SURFACE',
    )
    # Keep Wall (2026-09-12): see TOOL3D_OT_split_mark_sharp.sharp_keep_wall.
    sharp_keep_wall: BoolProperty(
        name="Keep Wall",
        description="Surface hollow: cut the cavity like the default hollow, but "
                    "FLATTEN the inner face under each dent into one panel, "
                    "instead of a scaled copy that would break through the dent",
        default=False,
    )
    sharp_instance_approximate: BoolProperty(
        name="Instance gần giống", default=True,
        description="Share nearly matching meshes; may change shape and gaps at cut joints",
    )
    sharp_instance_tolerance: FloatProperty(
        name="Sai số (%)", default=2.0, min=0.0, max=5.0, precision=2,
        description="Maximum vertex displacement as a percentage of the reference piece radius",
    )


# ========== PANEL ==========

class TOOL3D_PT_main_panel(bpy.types.Panel):
    bl_label = "3D tool"
    bl_idname = "TOOL3D_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "3D tool"

    def draw(self, context):
        pass


class TOOL3D_PT_split_panel(bpy.types.Panel):
    bl_label = "Split Mark Seam"
    bl_idname = "TOOL3D_PT_split_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "3D tool"
    bl_parent_id = "TOOL3D_PT_main_panel"
    bl_order = 0

    def draw(self, context):
        layout = self.layout
        props = context.scene.tool3d_props

        # ============ SPLIT MARK SEAM ============
        box = layout.box()
        box.label(text="SPLIT MARK SEAM", icon='MESH_DATA')

        col = box.column(align=True)
        mark_sharp_op = col.operator(
            "tool3d.split_mark_sharp",
            text="Split Mark Seam + Fill Cuts",
            icon='MOD_EXPLODE',
        )
        # Fix Pass (reviewer-requested): preset this button's own
        # invocation properties from the independent Scene-level sharp_*
        # settings drawn in the "MARK SEAM CUT" box below, so the
        # sliders/checkboxes the user sees actually affect the operation
        # this specific button runs. This does NOT change the operator's
        # own property contract (TOOL3D_OT_split_mark_sharp keeps its
        # own identically-named bl_options-exposed properties, with the
        # same class defaults, unchanged) -- it only presets the values
        # for THIS button's click, exactly like Blender's own "operator
        # button with preset args" idiom. Calling the operator directly
        # via bpy.ops.tool3d.split_mark_sharp(...) (every test in the
        # suite, any script, the redo-last panel) is completely
        # unaffected: this assignment only runs while the panel is being
        # drawn, not when the operator itself executes.
        mark_sharp_op.sharp_auto_fill = props.sharp_auto_fill
        mark_sharp_op.sharp_auto_bevel = props.sharp_auto_bevel
        mark_sharp_op.sharp_offset_value = props.sharp_offset_value
        mark_sharp_op.sharp_bevel_width = props.sharp_bevel_width
        mark_sharp_op.sharp_bevel_segments = props.sharp_bevel_segments
        mark_sharp_op.sharp_fill_tolerance = props.sharp_fill_tolerance
        mark_sharp_op.sharp_hollow = props.sharp_hollow
        mark_sharp_op.sharp_hollow_scale = props.sharp_hollow_scale
        mark_sharp_op.sharp_crease_angle = props.sharp_crease_angle
        mark_sharp_op.sharp_hollow_shape = props.sharp_hollow_shape
        mark_sharp_op.sharp_keep_wall = props.sharp_keep_wall
        mark_sharp_op.sharp_instance_approximate = props.sharp_instance_approximate
        mark_sharp_op.sharp_instance_tolerance = props.sharp_instance_tolerance

        sharp_box = box.box()
        sharp_box.label(text="MARK SEAM CUT", icon='MESH_DATA')
        sharp_box.prop(props, "sharp_auto_fill")
        sharp_box.prop(props, "sharp_auto_bevel")
        sharp_box.prop(props, "sharp_offset_value")
        sharp_box.prop(props, "sharp_bevel_width")
        sharp_box.prop(props, "sharp_bevel_segments")
        sharp_box.prop(props, "sharp_instance_approximate")
        if props.sharp_instance_approximate:
            sharp_box.prop(props, "sharp_instance_tolerance")
        sharp_box.prop(props, "sharp_hollow")
        sharp_box.prop(props, "sharp_hollow_scale")
        if props.sharp_hollow:
            sharp_box.prop(props, "sharp_hollow_shape")
            if props.sharp_hollow_shape == 'SURFACE':
                sharp_box.prop(props, "sharp_keep_wall")
                sharp_box.prop(props, "sharp_crease_angle")


class TOOL3D_PT_multicut_panel(bpy.types.Panel):
    bl_label = "Multi-Cut Extended"
    bl_idname = "TOOL3D_PT_multicut_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "3D tool"
    bl_parent_id = "TOOL3D_PT_main_panel"
    bl_order = 1
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        props = context.scene.tool3d_props

        # Multi-Cut Section
        box = layout.box()
        box.label(text="MULTI-CUT EXTENDED", icon='MOD_EDGESPLIT')

        col = box.column(align=True)
        col.operator("tool3d.knife_cut_pipeline", text="Knife Cut (Auto Split)", icon='GREASEPENCIL')
        col.operator("tool3d.split_by_edges", text="Split By Selected Edges", icon='MOD_EXPLODE')
        col.operator("tool3d.separate_and_process", text="Separate Loose + Process", icon='MESH_DATA')

        box.separator()

        # Settings
        row = box.row(align=True)
        row.prop(props, "auto_separate")
        row.prop(props, "auto_fill")
        row.prop(props, "auto_bevel")

        box.prop(props, "offset_value")
        box.prop(props, "bevel_width")
        box.prop(props, "bevel_segments")

        box.separator()

        # Manual
        row = box.row(align=True)
        row.operator("tool3d.fill_holes", text="Fill Holes", icon='FACE_MAPS')
        row.operator("tool3d.bevel_borders", text="Bevel Borders", icon='MOD_BEVEL')


# ========== UV OPERATOR & PANEL ==========

class TOOL3D_OT_set_uv(bpy.types.Operator):
    """Gan toa do UV cho cac face dang chon (Edit mode) hoac toan bo mesh (Object mode)"""
    bl_idname = "tool3d.set_uv"
    bl_label = "Set UV"
    bl_options = {'REGISTER', 'UNDO'}

    uv_coord: EnumProperty(
        name="UV Coordinate",
        items=[
            ('DEFAULT', "From Preset", "Dung preset dang chon trong panel"),
            ('0', "1 X0 Y0", "Toa do UV (0.0, 0.0)"),
            ('1', "2 X0.5 Y0", "Toa do UV (0.5, 0.0)"),
            ('2', "3 X1 Y0", "Toa do UV (1.0, 0.0)"),
        ],
        default='DEFAULT'
    )
    u: FloatProperty(name="U", default=-1.0)
    v: FloatProperty(name="V", default=-1.0)

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        if obj and obj.type == 'MESH':
            return True
        return any(o.type == 'MESH' for o in context.selected_objects)

    def execute(self, context):
        props = getattr(context.scene, "tool3d_props", None)
        if self.u >= 0.0 and self.v >= 0.0:
            target_uv = (self.u, self.v)
        else:
            val = self.uv_coord if self.uv_coord != 'DEFAULT' else (props.uv_preset if props else '0')
            if props and self.uv_coord != 'DEFAULT':
                props.uv_preset = self.uv_coord
            uv_map = {
                '0': (0.0, 0.0),
                '1': (0.5, 0.0),
                '2': (1.0, 0.0),
            }
            target_uv = uv_map.get(val, (0.0, 0.0))

        if context.mode == 'EDIT_MESH':
            objects = [o for o in context.objects_in_mode if o.type == 'MESH']
            if not objects and context.active_object and context.active_object.type == 'MESH':
                objects = [context.active_object]

            total_faces = 0
            for obj in objects:
                if obj.data.uv_layers.active is None:
                    obj.data.uv_layers.new(name="UVMap")
                bm = bmesh.from_edit_mesh(obj.data)
                uv_layer = bm.loops.layers.uv.get(obj.data.uv_layers.active.name) or bm.loops.layers.uv.verify()
                selected_faces = [f for f in bm.faces if f.select]
                target_faces = selected_faces if selected_faces else bm.faces
                for f in target_faces:
                    for loop in f.loops:
                        loop[uv_layer].uv = target_uv
                total_faces += len(target_faces)
                bmesh.update_edit_mesh(obj.data)
        else:
            objects = [o for o in context.selected_objects if o.type == 'MESH']
            if not objects and context.active_object and context.active_object.type == 'MESH':
                objects = [context.active_object]

            total_faces = 0
            for obj in objects:
                if obj.data.uv_layers.active is None:
                    obj.data.uv_layers.new(name="UVMap")
                bm = bmesh.new()
                bm.from_mesh(obj.data)
                uv_layer = bm.loops.layers.uv.get(obj.data.uv_layers.active.name) or bm.loops.layers.uv.verify()
                for f in bm.faces:
                    for loop in f.loops:
                        loop[uv_layer].uv = target_uv
                total_faces += len(bm.faces)
                bm.to_mesh(obj.data)
                bm.free()
                obj.data.update()

        self.report({'INFO'}, f"Set UV {target_uv} on {total_faces} face(s).")
        return {'FINISHED'}


class TOOL3D_PT_uv_panel(bpy.types.Panel):
    bl_label = "UV"
    bl_idname = "TOOL3D_PT_uv_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "3D tool"
    bl_parent_id = "TOOL3D_PT_main_panel"
    bl_order = 2

    def draw(self, context):
        layout = self.layout
        props = context.scene.tool3d_props

        box = layout.box()
        box.label(text="UV PRESETS", icon='UV')

        row = box.row(align=True)
        for key, text in (('0', "1 X0 Y0"), ('1', "2 X0.5 Y0"), ('2', "3 X1 Y0")):
            op = row.operator(
                "tool3d.set_uv",
                text=text,
                depress=(props.uv_preset == key)
            )
            op.uv_coord = key


# ========== REGISTER ==========

classes = (
    Tool3DAddonPreferences,
    Tool3DProperties,
    TOOL3D_OT_split_by_edges,
    TOOL3D_OT_knife_cut_pipeline,
    TOOL3D_OT_separate_and_process,
    TOOL3D_OT_fill_holes,
    TOOL3D_OT_bevel_borders,
    TOOL3D_OT_split_mark_sharp,
    TOOL3D_OT_detect_intersections,
    TOOL3D_OT_start_live_intersections,
    TOOL3D_OT_stop_live_intersections,
    TOOL3D_OT_clear_intersections,
    TOOL3D_OT_select_intersecting_faces,
    TOOL3D_OT_detect_self_intersect,
    TOOL3D_OT_disable_self_intersect,
    TOOL3D_OT_set_uv,
    TOOL3D_PT_main_panel,
    TOOL3D_PT_split_panel,
    TOOL3D_PT_multicut_panel,
    TOOL3D_PT_uv_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.tool3d_props = bpy.props.PointerProperty(
        type=Tool3DProperties
    )
    bpy.types.Scene.tool3d_live_intersection = BoolProperty(
        name="Live Intersection",
        default=False,
        options={'SKIP_SAVE'}
    )

    try:
        addon = bpy.context.preferences.addons.get(__package__)
        if addon:
            prefs = addon.preferences

            for scene in bpy.data.scenes:
                scene.tool3d_props.offset_value = prefs.offset_value
                scene.tool3d_props.bevel_width = prefs.bevel_width
                scene.tool3d_props.bevel_segments = prefs.bevel_segments
    except:
        pass


def unregister():
    tool3d_remove_live_handler()
    if bpy.app.timers.is_registered(tool3d_live_intersection_timer):
        bpy.app.timers.unregister(tool3d_live_intersection_timer)
    _tool3d_live_object_names.clear()
    tool3d_clear_intersection_geometry(remove_object=True)

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.tool3d_live_intersection
    del bpy.types.Scene.tool3d_props


if __name__ == "__main__":
    register()
