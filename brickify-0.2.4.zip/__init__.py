bl_info = {
    "name": "Brickify",
    "author": "Tool3D",
    "version": (0, 1, 0),
    "blender": (5, 2, 0),
    "location": "View3D > Sidebar > Brickify",
    "description": "Live castle-style brick walls from blockout meshes",
    "category": "Object",
}

import hashlib
import math
import random
import traceback
from collections import Counter, namedtuple
from dataclasses import dataclass, replace

import bmesh
import bpy
import numpy as np
from mathutils import Matrix, Vector


# ---- bricks

Brick = namedtuple("Brick", "center tangent up length height depth shape sides outline lean ends",
                   defaults=("box", 4, (), 0.0, (0.0, 0.0)))
"""`shape`: 'box' (bevelled box), 'pyramid' (base inside length x depth, tip at the top),
'prism' (vertical N-sided slab inside length x depth) or 'wedge' (Task 26: a wall brick cut to
an arch, or the keystone — the profile `outline` in the brick's local (X = length, Z = height)
plane, extruded by `depth` along Y) or 'arc' (Task 16, user 2026-10-21: the bevelled box bent along a curved
wall; `outline` = (R,), the SIGNED radius of its centre line, centre of curvature at local
(0, R), so R > 0 turns left; `length` is the arc length along that centre line and
abs(R) > depth / 2) or 'cut' (user 2026-10-23: the top of a cone / sphere as ONE piece of
the source solid itself; `outline` = (digest,) naming its geometry in `_CUT_SHAPES`,
length / depth / height its bounding box) or 'plan' (outline = N plan points, or 2N = bottom
ring + top ring, Task 25); `sides` = N for the n-gon shapes (0 for an arc)."""


def brick_matrix(brick):
    """Brick local -> scaled-local space. X = tangent, Z = up, Y = up x tangent."""
    x = Vector(brick.tangent).normalized()
    z = Vector(brick.up).normalized()
    y = z.cross(x)
    m = Matrix((x, y, z)).transposed().to_4x4()
    m.translation = Vector(brick.center)
    return m


def _ngon(sides, length, depth):
    """Base outline of a non-box shape: the box rectangle for 4 sides, else a regular N-gon
    inscribed in the circle of diameter min(length, depth), one edge parallel to X (facing -Y,
    like a wall brick's outer face)."""
    if sides == 4:
        hl, hd = length / 2, depth / 2
        return [(-hl, -hd), (hl, -hd), (hl, hd), (-hl, hd)]
    r = min(length, depth) / 2
    a0 = -math.pi / 2 - math.pi / sides
    return [(r * math.cos(a0 + k * math.tau / sides), r * math.sin(a0 + k * math.tau / sides))
            for k in range(sides)]


def shape_geometry(length, height, depth, bevel, segments, shape="box", sides=4, outline=(), lean=0.0,
                   ends=(0.0, 0.0)):
    """(verts, faces, loop normals) of a bevelled shape centred at the origin (X = length,
    Y = depth, Z = height). Loop normals are weighted-normal style: every corner of a main
    (pre-bevel) face, and every chamfer corner on a single main face, takes that main face's
    normal, so the large faces shade flat and the chamfers blend between them.

    `outline` is the (x, z) profile of a 'wedge' (Task 12), extruded by `depth` along Y, or
    (R,) for an 'arc' (Task 16): the box is built straight, flat faces are detected on it, and
    only then are positions and loop normals bent onto the circle (see `_bend`)."""
    bm = bmesh.new()
    bend = None
    try:
        if shape in ("box", "arc", "path"):
            bmesh.ops.create_cube(bm, size=1.0)
            bmesh.ops.scale(bm, vec=(length, depth, height), verts=bm.verts)
        elif shape == "wedge":
            prof = [(float(x), float(z)) for x, z in outline]
            lo = [bm.verts.new((x, -depth / 2, z)) for x, z in prof]
            hi = [bm.verts.new((x, depth / 2, z)) for x, z in prof]
            bm.faces.new(lo)
            bm.faces.new(hi[::-1])
            for i in range(len(prof)):
                j = (i + 1) % len(prof)
                bm.faces.new((lo[i], lo[j], hi[j], hi[i]))
            bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
            # A wedge's chamfered end can be much shorter than its nominal length: clamp the
            # bevel on the smallest profile edge too, so a thin tip is not eaten away.
            edge = min(math.dist(prof[i - 1], prof[i]) for i in range(len(prof)))
            bevel = min(bevel, 0.49 * edge)
        elif shape == "frustum":
            # Task 20: a brick leaning with a battered face — its own bottom and top plan
            # outlines (4 points each, same order), joined by four side faces.
            lo_xy = [(float(x), float(y)) for x, y in outline[:4]]
            hi_xy = [(float(x), float(y)) for x, y in outline[4:8]]
            lo = [bm.verts.new((x, y, -height / 2)) for x, y in lo_xy]
            hi = [bm.verts.new((x, y, height / 2)) for x, y in hi_xy]
            bm.faces.new(lo[::-1])
            bm.faces.new(hi)
            for i in range(4):
                j = (i + 1) % 4
                bm.faces.new((lo[i], lo[j], hi[j], hi[i]))
            edge = min(min(math.dist(q[i - 1], q[i]) for i in range(4)) for q in (lo_xy, hi_xy))
            bevel = min(bevel, 0.49 * edge)
        else:
            # A 'miter' (Task 16b) or a 'plan' prism (Task 18, a corner quoin's L) carries its
            # own plan outline; the n-gon shapes derive one. Task 25 (user 2026-10-27): a
            # 'plan' outline of 2N points is a BOTTOM ring and a TOP ring (same order), so a
            # quoin layer can lean its outer faces with a battered block like a frustum.
            outline = ([(float(x), float(y)) for x, y in outline] if shape in ("miter", "plan")
                       else _ngon(sides, length, depth))
            lo_xy, hi_xy = outline, outline
            if shape == "plan" and len(outline) == 2 * sides:
                lo_xy, hi_xy = outline[:sides], outline[sides:]
            if shape in ("miter", "plan"):
                edge = min(min(math.dist(q[i - 1], q[i]) for i in range(len(q))) for q in (lo_xy, hi_xy))
                bevel = min(bevel, 0.49 * edge)
            lo = [bm.verts.new((x, y, -height / 2)) for x, y in lo_xy]
            bm.faces.new(lo[::-1])
            if shape == "pyramid":
                tip = bm.verts.new((0.0, 0.0, height / 2))
                for i in range(len(lo)):
                    bm.faces.new((lo[i], lo[(i + 1) % len(lo)], tip))
            else:
                hi = [bm.verts.new((x, y, height / 2)) for x, y in hi_xy]
                bm.faces.new(hi)
                for i in range(len(lo)):
                    j = (i + 1) % len(lo)
                    bm.faces.new((lo[i], lo[j], hi[j], hi[i]))
        bm.normal_update()
        planes = [f.normal.copy() for f in bm.faces]
        width = min(bevel, 0.49 * min(length, height, depth))
        geom = list(bm.verts) + list(bm.edges)
        if shape == "pyramid":
            # Only the base ring: bevelling the side edges would cut the tip off.
            ring = [e for e in bm.edges if all(abs(v.co.z + height / 2) < 1e-9 for v in e.verts)]
            geom = list({v for e in ring for v in e.verts}) + ring
            width = min(width, 0.2 * min(length, height, depth))
        if width > 1e-6 and segments > 0:
            bmesh.ops.bevel(bm, geom=geom, offset=width,
                            offset_type='OFFSET', segments=segments, profile=0.5,
                            affect='EDGES', clamp_overlap=True)
        if shape == "path":
            # Task 16c (user 2026-10-21 "khít với nhau"): a brick that follows the wall's real
            # centerline. Cut the straight box at every sample of its path so each slice maps
            # linearly (`_follow`), exactly like the arc's slices.
            bend = "path"
            # A cut on (or a hair from) an existing vertex loop — the bevel's own loops near
            # the ends — leaves zero-width sliver faces that shade as a broken bevel (user
            # 2026-10-22 "góc bevel cạnh đó đang lỗi"); such samples are skipped, the slice
            # just spans one more segment of the path there.
            for x, *_rest in outline[1:-1]:
                x = float(x)
                if any(abs(v.co.x - x) < max(0.02, 1.5 * bevel) for v in bm.verts):
                    continue
                geom = bm.verts[:] + bm.edges[:] + bm.faces[:]
                bmesh.ops.bisect_plane(bm, geom=geom, plane_co=(x, 0.0, 0.0),
                                       plane_no=(1.0, 0.0, 0.0))
        if shape == "arc" and abs(float(outline[0])) > 1e-9:
            # Task 16 (user 2026-10-21): a brick bent along a curved wall like the reference
            # tower in test.blend. Cut the bevelled box into ARC_SEGMENTS slices along X so
            # the long faces can follow the arc; the cut pieces stay parallel to the original
            # faces, so the `main` detection below still works on this straight box.
            bend = float(outline[0])
            for i in range(1, ARC_SEGMENTS):
                x = length * (i / ARC_SEGMENTS - 0.5)
                geom = bm.verts[:] + bm.edges[:] + bm.faces[:]
                bmesh.ops.bisect_plane(bm, geom=geom, plane_co=(x, 0.0, 0.0),
                                       plane_no=(1.0, 0.0, 0.0))
        bm.verts.index_update()
        bm.normal_update()
        # Bevel rebuilds the faces: the main ones are those still parallel to an original face.
        main = {f for f in bm.faces if any(f.normal.dot(p) > 1 - 1e-6 for p in planes)}
        verts = np.array([v.co[:] for v in bm.verts], dtype=np.float64)
        faces = [tuple(v.index for v in f.verts) for f in bm.faces]
        normals = []
        for f in bm.faces:
            for v in f.verts:
                if f in main:
                    normals.append(f.normal[:])
                    continue
                own = [g for g in v.link_faces if g in main]
                # An arc brick's slicing splits one main face into coplanar pieces: a chamfer
                # corner on a cut line touches two of them, still ONE main plane.
                one = own and all(g.normal.dot(own[0].normal) > 1 - 1e-6 for g in own)
                normals.append((own[0].normal if one else v.normal)[:])
    finally:
        bm.free()
    normals = np.array(normals, dtype=np.float64).reshape(-1, 3)
    if abs(ends[0]) > 1e-9 or abs(ends[1]) > 1e-9:
        # Task 20 (user 2026-10-22: a bent brick's end at a sharp corner did not lean): the
        # brick's two ends move along it by `ends` = (start, end) at the TOP (+x), minus that
        # at the bottom, blended linearly along the length, so a corner end follows the other
        # face's slope. x' = x + (2z/h) * ((1-t) * s0 + t * s1), t = (x + L/2) / L; normals
        # by the inverse-transpose of the Jacobian.
        loop_v = np.array([i for f in faces for i in f], dtype=np.int64)
        x, z = verts[:, 0].copy(), verts[:, 2].copy()
        s0, s1 = float(ends[0]), float(ends[1])
        t = (x + length / 2) / length
        verts[:, 0] = x + (2 * z / height) * ((1 - t) * s0 + t * s1)
        a = (1 + (2 * z / height) * (s1 - s0) / length)[loop_v]
        c = ((2 / height) * ((1 - t) * s0 + t * s1))[loop_v]
        nx = normals[:, 0] / a
        nz = normals[:, 2] - c * normals[:, 0] / a
        normals[:, 0], normals[:, 2] = nx, nz
        normals /= np.linalg.norm(normals, axis=1)[:, None]
    if abs(lean) > 1e-9:
        # Task 20 (user 2026-10-22, curved faces too): the OUTER face leans by `lean` from
        # the bottom to the top (positive = in toward the solid going up) while the inner face
        # stays vertical: y' = y + lean * (z / height) * (depth/2 - y) / depth, applied to the
        # straight brick before it is bent, so arc and path bricks lean along their own curve.
        # Loop normals follow by the inverse-transpose of that map's Jacobian.
        loop_v = np.array([i for f in faces for i in f], dtype=np.int64)
        y, z = verts[:, 1].copy(), verts[:, 2].copy()
        k = lean / (height * depth)
        verts[:, 1] = y + k * z * (depth / 2 - y)
        a = (1 - k * z)[loop_v]
        bb = (k * (depth / 2 - y))[loop_v]
        ny = normals[:, 1] / a
        nz = normals[:, 2] - bb * normals[:, 1] / a
        normals[:, 1], normals[:, 2] = ny, nz
        normals /= np.linalg.norm(normals, axis=1)[:, None]
    if bend == "path":
        loop_v = np.array([i for f in faces for i in f], dtype=np.int64)
        x, y, a = _follow(verts[:, 0], verts[:, 1], outline)
        verts[:, 0], verts[:, 1] = x, y
        c, s = np.cos(a[loop_v]), np.sin(a[loop_v])
        nx, ny = normals[:, 0].copy(), normals[:, 1].copy()
        normals[:, 0], normals[:, 1] = nx * c - ny * s, nx * s + ny * c
    elif bend is not None:
        # Rotate each loop normal about Z by the bend angle at its vertex: the bend is
        # conformal in XY, so a straight-frame normal maps exactly onto the bent surface.
        loop_v = np.array([i for f in faces for i in f], dtype=np.int64)
        x, y, a = _bend(verts[:, 0], verts[:, 1], bend)
        verts[:, 0], verts[:, 1] = x, y
        c, s = np.cos(a[loop_v]), np.sin(a[loop_v])
        nx, ny = normals[:, 0].copy(), normals[:, 1].copy()
        normals[:, 0], normals[:, 1] = nx * c - ny * s, nx * s + ny * c
    return verts, faces, normals

def _follow(x, y, path):
    """Local (x, y) of a straight brick -> laid along `path` = ((x_k, px, py, nx, ny), ...),
    the brick's centre line sampled at x_k in its own frame with the offset vector N at each
    sample (Task 16c). Between samples P and N are linear, so a point y off the centre line
    lands at P(x) + y * N(x): N is a miter vector (N . n = 1 for the segment's unit normal n),
    which keeps the faces at exactly +-y from the centre line. Returns (x', y', angle), the
    angle being the local tangent's, for rotating the loop normals."""
    k = np.array(path, dtype=np.float64)
    # Past either end the path is EXTENDED along its end segment, not clamped: a brick end
    # leaned out past its sample (Task 20 `ends`) would otherwise collapse onto the end
    # sample and fold the bevel there (user 2026-10-22 "góc bevel cạnh đó đang lỗi").
    far = 1e3
    head = k[0] + (k[0] - k[1]) * far / max(k[1, 0] - k[0, 0], 1e-12)
    tail = k[-1] + (k[-1] - k[-2]) * far / max(k[-1, 0] - k[-2, 0], 1e-12)
    head[3:], tail[3:] = k[0, 3:], k[-1, 3:]
    k = np.vstack([head, k, tail])
    xs = k[:, 0]
    px, py = np.interp(x, xs, k[:, 1]), np.interp(x, xs, k[:, 2])
    nx, ny = np.interp(x, xs, k[:, 3]), np.interp(x, xs, k[:, 4])
    ox, oy = px + y * nx, py + y * ny
    return ox, oy, np.arctan2(-nx, ny)

def _bend(x, y, r):
    """Local (x, y) of a straight brick -> bent onto the circle of signed radius r whose
    centre is (0, r) (Task 16): x is arc length along the centre line (y = 0), y the radial
    offset from it, so the centre line keeps its length. Returns (x', y', angle)."""
    a = x / r
    rho = r - y
    return rho * np.sin(a), r - rho * np.cos(a), a


def brick_geometry(length, height, depth, bevel, segments):
    """Bevelled box centred at the origin: X = length, Y = depth, Z = height."""
    verts, faces, _ = shape_geometry(length, height, depth, bevel, segments)
    return verts, faces


class BrickMeshCache:
    """One bevelled shape per rounded (length, height, depth) (+ shape, sides if not a box).

    A 'wedge' (Task 12) carries its whole rounded (x, z) profile in the key, so each distinct
    wedge gets its own mesh: wedges are per-window custom pieces and are NOT expected to share
    (2-6 per arched window). Boxes keep the plain 3-tuple key and still instance."""

    def __init__(self, bevel, segments):
        self.bevel = bevel
        self.segments = segments
        self._shapes = {}

    @staticmethod
    def key(brick):
        k = (round(brick.length, 3), round(brick.height, 3), round(brick.depth, 3))
        if brick.shape == "box":
            return k
        k += (brick.shape, brick.sides)
        if brick.shape in ("wedge", "miter", "plan", "frustum"):
            k += (tuple((round(x, 3), round(z, 3)) for x, z in brick.outline),)
        elif brick.shape == "path":
            k += (tuple(tuple(round(v, 4) for v in q) for q in brick.outline),)
        elif brick.shape == "arc":
            # Task 16: arc bricks of one course share a radius, so they still instance.
            k += (round(float(brick.outline[0]), 3),)
        elif brick.shape == "cut":
            k += (str(brick.outline[0]),)
        if abs(getattr(brick, "lean", 0.0)) > 1e-6 or any(abs(e) > 1e-6 for e in brick.ends):
            # Task 20: one course of a cone shares its lean too.
            k += (round(float(brick.lean), 4),)
            if any(abs(e) > 1e-6 for e in brick.ends):
                k += (tuple(round(float(e), 4) for e in brick.ends),)
        return k

    def shape(self, key):
        """(verts, faces, loop normals) of the shape for `key`."""
        if key not in self._shapes:
            if len(key) > 3 and key[3] == "cut":
                self._shapes[key] = _CUT_SHAPES[key[5]]
            elif len(key) > 3 and key[3] == "arc":
                self._shapes[key] = shape_geometry(*key[:3], self.bevel, self.segments,
                                                   "arc", key[4], (key[5],),
                                                   key[6] if len(key) > 6 else 0.0,
                                                   key[7] if len(key) > 7 else (0.0, 0.0))
            elif len(key) > 3 and key[3] == "path" and len(key) > 6:
                self._shapes[key] = shape_geometry(*key[:3], self.bevel, self.segments,
                                                   "path", key[4], key[5], key[6],
                                                   key[7] if len(key) > 7 else (0.0, 0.0))
            else:
                self._shapes[key] = shape_geometry(*key[:3], self.bevel, self.segments, *key[3:])
        return self._shapes[key]


def write_output(bricks, cache, mesh, uv=(0.5, 0.5)):
    """Replace the geometry of `mesh` with all bricks (numpy, no bpy.ops). Corner normals are
    written as a float `custom_normal` attribute (flat main faces, see shape_geometry)."""
    groups = {}
    for brick in bricks:
        groups.setdefault(cache.key(brick), []).append(brick)
    co_parts, loop_parts, nrm_parts, sizes, base = [], [], [], [], 0
    for key, members in groups.items():
        verts, faces, normals = cache.shape(key)
        rot = np.empty((len(members), 3, 3))
        pos = np.empty((len(members), 3))
        for i, brick in enumerate(members):
            rot[i] = np.array(brick_matrix(brick).to_3x3())
            pos[i] = brick.center
        world = np.einsum('nij,vj->nvi', rot, verts) + pos[:, None, :]
        co_parts.append(world.reshape(-1, 3))
        nrm_parts.append(np.einsum('nij,lj->nli', rot, normals).reshape(-1, 3))
        flat = np.array([i for f in faces for i in f], dtype=np.int32)
        offsets = base + np.arange(len(members), dtype=np.int32)[:, None] * len(verts)
        loop_parts.append((flat[None, :] + offsets).ravel())
        sizes.extend([len(f) for f in faces] * len(members))
        base += len(members) * len(verts)
    mesh.clear_geometry()
    old = mesh.attributes.get("custom_normal")
    if old is not None:
        mesh.attributes.remove(old)
    if not bricks:
        mesh.update()
        return
    co = np.concatenate(co_parts).astype(np.float32)
    loops = np.concatenate(loop_parts).astype(np.int32)
    sizes = np.array(sizes, dtype=np.int32)
    starts = np.zeros(len(sizes), dtype=np.int32)
    starts[1:] = np.cumsum(sizes)[:-1]
    mesh.vertices.add(len(co))
    mesh.vertices.foreach_set("co", co.ravel())
    mesh.loops.add(len(loops))
    mesh.loops.foreach_set("vertex_index", loops)
    mesh.polygons.add(len(sizes))
    mesh.polygons.foreach_set("loop_start", starts)
    mesh.polygons.foreach_set("use_smooth", np.ones(len(sizes), dtype=bool))
    layer = mesh.uv_layers.get("UVMap") or mesh.uv_layers.new(name="UVMap")
    layer.data.foreach_set("uv", np.tile(np.array(uv, dtype=np.float32), len(loops)))
    mesh.update(calc_edges=True)
    attr = mesh.attributes.new("custom_normal", 'FLOAT_VECTOR', 'CORNER')
    attr.data.foreach_set("vector", np.concatenate(nrm_parts).astype(np.float32).ravel())


# ---- slicing

@dataclass
class Contour:
    """Horizontal outline; walking along `points` keeps the solid on the LEFT."""
    points: list
    closed: bool

    def signed_area(self):
        if not self.closed:
            return 0.0
        p = self.points
        return 0.5 * sum(p[i - 1][0] * p[i][1] - p[i][0] * p[i - 1][1] for i in range(len(p)))

    def perimeter(self):
        p = self.points
        pairs = zip(p, p[1:] + p[:1]) if self.closed else zip(p, p[1:])
        return sum(math.dist(a, b) for a, b in pairs)


Slices = namedtuple("Slices", "z_min course_h courses skipped z_top")
"""`z_top` = top of the source solid; the courses stop at the last WHOLE brick below it."""


def read_source_mesh(obj, depsgraph):
    """Evaluated, triangulated mesh in scaled-local space."""
    evaluated = obj.evaluated_get(depsgraph)
    tmp = evaluated.to_mesh()
    bm = bmesh.new()
    try:
        try:
            bm.from_mesh(tmp)
            # bmesh keeps the mesh's vertex order and triangulate adds no vertices, so the
            # mesh's coordinates (bulk-read) line up with bm.verts indices.
            co = np.empty(len(tmp.vertices) * 3, dtype=np.float32)
            tmp.vertices.foreach_get("co", co)
        finally:
            evaluated.to_mesh_clear()
        bmesh.ops.triangulate(bm, faces=bm.faces[:])
        bm.verts.index_update()
        scale = np.array(obj.matrix_world.to_scale())
        verts = co.astype(np.float64).reshape(-1, 3) * scale
        faces = [tuple(v.index for v in f.verts) for f in bm.faces]
        if np.prod(scale) < 0:
            faces = [f[::-1] for f in faces]
        closed = bool(bm.edges) and all(len(e.link_faces) == 2 for e in bm.edges)
    finally:
        bm.free()
    return verts, faces, closed


def _simplify(points, closed, eps=1e-5):
    pts = []
    for p in points:
        if not pts or math.dist(p, pts[-1]) > eps:
            pts.append(p)
    if closed and len(pts) > 1 and math.dist(pts[0], pts[-1]) <= eps:
        pts.pop()
    # Repeatedly delete the FIRST point (lowest index) that is a duplicate or a straight
    # continuation. A deletion at i only changes the triples at i-1 and the new i (plus
    # index 0's when the last point goes), and every index below the first hit already
    # failed, so resuming at i-1 finds the same next point as a rescan from the start.
    first = 0 if closed else 1
    i = first
    while len(pts) > (3 if closed else 2):
        n = len(pts)
        if i >= (n if closed else n - 1):
            break
        a, b, c = pts[i - 1], pts[i], pts[(i + 1) % n]
        ux, uy, vx, vy = b[0] - a[0], b[1] - a[1], c[0] - b[0], c[1] - b[1]
        lu, lv = math.hypot(ux, uy), math.hypot(vx, vy)
        if lu * lv == 0 or (abs(ux * vy - uy * vx) / (lu * lv) < 1e-4 and ux * vx + uy * vy > 0):
            del pts[i]
            i = first if i == n - 1 else max(first, i - 1)
        else:
            i += 1
    return pts


_SlicePrep = namedtuple("_SlicePrep", "verts vz tris tri_lo tri_hi nx ny eps")


def _prepare_slicing(verts, faces):
    """Per-mesh data shared by every plane: int triangles, z-range, normals, nudge eps."""
    tris = np.asarray(faces, dtype=np.int64).reshape(-1, 3)
    vz = verts[:, 2]
    eps = None
    if len(verts):
        extent = float(np.max(verts.max(axis=0) - verts.min(axis=0)))
        eps = 1e-6 * max(1.0, extent)
    if len(tris):
        tz = vz[tris]
        a = verts[tris[:, 0]]
        normal = np.cross(verts[tris[:, 1]] - a, verts[tris[:, 2]] - a)
        tri_lo, tri_hi, nx, ny = tz.min(axis=1), tz.max(axis=1), normal[:, 0], normal[:, 1]
    else:
        tri_lo = tri_hi = nx = ny = np.empty(0)
    return _SlicePrep(verts, vz, tris, tri_lo, tri_hi, nx, ny, eps)


def _slice_prepared(prep, z):
    """slice_plane on precomputed data; only plane-straddling triangles are visited."""
    verts, vz = prep.verts, prep.vz
    if prep.eps is not None:
        eps = prep.eps
        # Simulation-of-simplicity: a plane through a vertex produces coincident/degenerate
        # crossings (crossings are keyed by vertex-index pair), so nudge z off any vertex
        # height before classifying -- invisible at brick scale.
        for _ in range(64):
            if not np.any(np.abs(vz - z) < eps):
                break
            z += eps
    # A triangle crosses iff some vertex is >= z and some is < z (face order kept).
    hit = np.nonzero((prep.tri_lo < z) & (prep.tri_hi >= z))[0]
    point_of, segs, targets_seen = {}, {}, set()
    if len(hit):
        tri = prep.tris[hit]
        up = vz[tri] >= z
        # Edge e = (tri[e], tri[e+1]); exactly two of the three edges cross.
        cut = up != np.roll(up, -1, axis=1)
        first = np.where(cut[:, 0], 0, 1)
        second = np.where(cut[:, 0] & ~cut[:, 1], 2, first + 1)
        rows = np.arange(len(hit))
        nxt = np.roll(tri, -1, axis=1)
        # Occurrences in call order: (tri 0 k1, tri 0 k2, tri 1 k1, ...).
        src = np.stack([tri[rows, first], tri[rows, second]], axis=1).ravel()
        dst = np.stack([nxt[rows, first], nxt[rows, second]], axis=1).ravel()
        lo, hi = np.minimum(src, dst), np.maximum(src, dst)
        # A shared edge's point is computed from its FIRST occurrence's direction.
        _, first_at, inverse = np.unique(lo * len(verts) + hi, return_index=True, return_inverse=True)
        a, b = verts[src[first_at]], verts[dst[first_at]]
        t = (z - a[:, 2]) / (b[:, 2] - a[:, 2])
        ux = a[:, 0] + t * (b[:, 0] - a[:, 0])
        uy = a[:, 1] + t * (b[:, 1] - a[:, 1])
        px, py = ux[inverse.ravel()].reshape(-1, 2), uy[inverse.ravel()].reshape(-1, 2)
        # Solid on the left: walking direction . (-ny, nx) > 0.
        swap = ((px[:, 1] - px[:, 0]) * -prep.ny[hit] + (py[:, 1] - py[:, 0]) * prep.nx[hit] < 0).tolist()
        keys = list(zip(lo.tolist(), hi.tolist()))
        ulo, uhi = lo[first_at].tolist(), hi[first_at].tolist()
        point_of = dict(zip(zip(ulo, uhi), zip(ux, uy)))
        for c, flip in enumerate(swap):
            k1, k2 = keys[2 * c], keys[2 * c + 1]
            if flip:
                k1, k2 = k2, k1
            if k1 in segs or k2 in targets_seen:
                return [], False
            segs[k1] = k2
            targets_seen.add(k2)

    targets = set(segs.values())
    visited, contours = set(), []

    def walk(start):
        pts, cur = [], start
        while cur in segs and cur not in visited:
            visited.add(cur)
            pts.append(point_of[cur])
            cur = segs[cur]
        return pts, cur

    for start in [k for k in segs if k not in targets]:
        pts, last = walk(start)
        pts.append(point_of[last])
        pts = _simplify(pts, False)
        if len(pts) >= 2:
            contours.append(Contour(pts, False))
    for start in list(segs):
        if start in visited:
            continue
        pts, last = walk(start)
        if last != start:
            return [], False
        pts = _simplify(pts, True)
        if len(pts) >= 3:
            contours.append(Contour(pts, True))
    return contours, True


def slice_plane(verts, faces, z):
    """Cut the triangle mesh at height z into oriented contours."""
    return _slice_prepared(_prepare_slicing(verts, faces), z)


def slice_courses(verts, faces, height, prep=None):
    if len(verts) == 0:
        return Slices(0.0, height, [], 0, 0.0)
    z_min, z_max = float(verts[:, 2].min()), float(verts[:, 2].max())
    total = z_max - z_min
    # Task 11: a course is EXACTLY brick_height (so every brick shares one mesh height) and
    # the remainder of the block is left empty at the TOP instead of stretching the courses.
    if total < height:
        return Slices(z_min, height, [], 0, z_max)
    n = max(1, int(total / height + 1e-6))
    course_h = height
    courses, skipped = [], 0
    prep = prep or _prepare_slicing(verts, faces)
    for k in range(n):
        contours, ok = _slice_prepared(prep, z_min + (k + 0.5) * course_h)
        if not ok:
            skipped += 1
            contours = []
        courses.append(contours)
    return Slices(z_min, course_h, courses, skipped, z_max)


# ---- runs

@dataclass
class Params:
    brick_length: float = 1.6
    brick_height: float = 0.76
    brick_depth: float = 0.78
    gap: float = 0.001
    size_step: float = 0.1
    length_steps: tuple = (1.0, 2.0)
    alternate_steps: bool = True
    seed: int = 0
    stagger: bool = True
    corner_angle: float = math.radians(30.0)
    min_piece: float = 0.3
    bevel_width: float = 0.1
    bevel_segments: int = 1
    cap_top: bool = False
    cap_lift: float = 0.0
    crenels: bool = False
    merlon_bricks: int = 1
    crenel_gap_bricks: int = 1   # internal: the automatic count keeps gaps >= 1 block (Khe (viên) removed 2026-10-22)
    crenel_courses: int = 1
    crenel_own_size: bool = False
    crenel_brick_height: float = 0.76
    crenel_brick_depth: float = 0.78
    crenel_proud: float = 0.0
    crenel_count: int = 0
    quoins: bool = False
    quoin_width: float = 0.9
    quoin_height: float = 0.76
    quoin_proud: float = 0.1
    quoin_proud_step: float = 0.0
    quoin_alternate: bool = True
    slope_fit: bool = True
    single_leaf: bool = False
    solid: bool = False
    solid_fill: float = 1.0
    solid_from_core: bool = False
    apex_bricks: int = 4
    vertical: bool = False
    vertical_axis: str = "AUTO"
    max_bricks: int = 1000

    @property
    def min_len(self):
        return self.min_piece * self.brick_length


def course_rng(params, *keys):
    return random.Random(":".join(str(k) for k in (params.seed,) + keys))


def _norm(x, y):
    n = math.hypot(x, y)
    return (x / n, y / n) if n > 1e-12 else (0.0, 0.0)


def offset_polyline(points, closed, dist, prune=False, min_edge=0.0):
    """Miter-offset to the LEFT of the walking direction (into the solid).

    `prune` (closed outlines only, user 2026-10-26): where the plain offset folds because a
    SHORT face collapsed (a chamfer shrinking to nothing), drop that face and carry on with
    its neighbours (`_inset_pruned`), like a real inset does, instead of giving up. The
    solid fill needs it: a chamfered pentagon folds at 1.43 m but its core is 3.6 m in.
    `min_edge` (with `prune`) = a ring's depth: a CHAMFER (a face much shorter than both its
    neighbours) also goes once its inset is too short for the mitred bricks either side of
    it to meet without crossing, `depth/2 * (tan(a/2) + tan(b/2))` for its two corner turns
    a, b (2026-10-26: at 0.02 m the two mitres overlapped by 0.1 m). Faces of a plain polygon
    are never chamfers, so its innermost ring is untouched."""
    n = len(points)
    if n < 2:
        return None
    if prune and closed:
        plain = offset_polyline(points, closed, dist)
        if plain is not None and min_edge <= 0:
            return plain
        pruned = _inset_pruned(points, dist, min_edge)
        # Nothing dropped: the plain miter inset IS the answer, vertex for vertex (the pruned
        # one meets the face lines afresh and starts one vertex round, which moved every
        # brick of a round ring a hair and broke byte-identity on cylinders).
        if plain is not None and (pruned is None or len(pruned) == len(plain)):
            return plain
        return pruned
    out = []
    for i in range(n):
        has_prev = closed or i > 0
        has_next = closed or i < n - 1
        p = points[i]
        dirs = []
        if has_prev:
            dirs.append(_norm(p[0] - points[i - 1][0], p[1] - points[i - 1][1]))
        if has_next:
            q = points[(i + 1) % n]
            dirs.append(_norm(q[0] - p[0], q[1] - p[1]))
        lefts = [(-dy, dx) for dx, dy in dirs]
        mx, my = _norm(sum(l[0] for l in lefts), sum(l[1] for l in lefts))
        cos_half = mx * lefts[0][0] + my * lefts[0][1]
        scale = dist / max(cos_half, 0.25)
        out.append((p[0] + mx * scale, p[1] + my * scale))
    if closed:
        before = Contour(list(points), True).signed_area()
        after = Contour(out, True).signed_area()
        if before * after <= 0 or abs(after) < 1e-9:
            return None
        # Any edge that flipped direction means the outline folded over.
        for i in range(n):
            a0, a1 = points[i], points[(i + 1) % n]
            b0, b1 = out[i], out[(i + 1) % n]
            if (a1[0] - a0[0]) * (b1[0] - b0[0]) + (a1[1] - a0[1]) * (b1[1] - b0[1]) <= 0:
                return None
        # Necks can fold the outline without flipping any edge; convex outlines cannot.
        if any(_turn(points, i) < -1e-9 for i in range(n)) and _self_intersects(out):
            return None
    return out


def _inset_pruned(points, dist, min_edge=0.0):
    """Closed outline inset by `dist` with every face whose inset collapsed removed: each
    face's line moves `dist` into the solid, a vertex is where two neighbouring lines meet,
    and a face whose new segment runs backwards (shorter than nothing) is dropped and its two
    neighbours are met directly, repeatedly. Exact for convex outlines (their inset is that
    of the surviving faces); a concave one still has to pass the fold / self-intersection
    checks. None when fewer than three faces survive or the result folds."""
    pts = [(float(x), float(y)) for x, y in points]
    if len(pts) < 3:
        return None
    area0 = Contour(pts, True).signed_area()
    lines = []
    for i in range(len(pts)):
        a, b = pts[i], pts[(i + 1) % len(pts)]
        e = _norm(b[0] - a[0], b[1] - a[1])
        if e == (0.0, 0.0):
            continue
        nrm = (-e[1], e[0])
        lines.append(((a[0] + nrm[0] * dist, a[1] + nrm[1] * dist), e))

    def meet(l0, l1):
        (p0, e0), (p1, e1) = l0, l1
        cr = e0[0] * e1[1] - e0[1] * e1[0]
        if abs(cr) < 1e-12:
            return None
        t = ((p1[0] - p0[0]) * e1[1] - (p1[1] - p0[1]) * e1[0]) / cr
        return (p0[0] + e0[0] * t, p0[1] + e0[1] * t)

    while len(lines) >= 3:
        verts = [meet(lines[i - 1], lines[i]) for i in range(len(lines))]
        if any(v is None for v in verts):
            # Two neighbouring faces parallel (a face between them already gone): the one
            # running back over the other has collapsed, drop the later one.
            k = next(i for i, v in enumerate(verts) if v is None)
            lines.pop(k)
            continue
        # Face i runs from verts[i] to verts[i+1]; it collapsed when that runs backwards.
        m = len(lines)
        span = [(verts[(i + 1) % m][0] - verts[i][0]) * lines[i][1][0]
                + (verts[(i + 1) % m][1] - verts[i][1]) * lines[i][1][1] for i in range(m)]

        def half_tan(e0, e1):
            ang = abs(math.atan2(e0[0] * e1[1] - e0[1] * e1[0], e0[0] * e1[0] + e0[1] * e1[1]))
            return math.tan(min(ang, math.radians(170.0)) / 2)

        def chamfer_dead(i):
            if min_edge <= 0 or span[i] >= 0.5 * min(span[i - 1], span[(i + 1) % m]):
                return False
            reach = min_edge / 2 * (half_tan(lines[i - 1][1], lines[i][1]) + half_tan(lines[i][1], lines[(i + 1) % m][1]))
            return span[i] <= reach

        dead = [i for i in range(m) if span[i] <= 1e-9 or chamfer_dead(i)]
        if not dead:
            out = verts
            after = Contour(out, True).signed_area()
            if area0 * after <= 0 or abs(after) < 1e-9 or _self_intersects(out):
                return None
            return out
        # Drop the most collapsed face first: the others may come back once it is gone.
        worst = min(dead, key=lambda i: span[i])
        lines.pop(worst)
    return None

def _cross3(o, a, b):
    return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])


def _sgn(x, eps=1e-10):
    return 0 if abs(x) <= eps else (1 if x > 0 else -1)


def _self_intersects(pts):
    """True if two non-adjacent edges of the closed polyline cross or touch
    (touching/collinear overlap = the offset reached the far wall of a neck)."""
    n = len(pts)
    segs = []
    for i in range(n):
        a, b = pts[i], pts[(i + 1) % n]
        segs.append((a, b, min(a[0], b[0]), max(a[0], b[0]), min(a[1], b[1]), max(a[1], b[1])))
    for i in range(n):
        a, b, ax0, ax1, ay0, ay1 = segs[i]
        for j in range(i + 2, n):
            if i == 0 and j == n - 1:
                continue
            c, d, cx0, cx1, cy0, cy1 = segs[j]
            if ax1 < cx0 - 1e-9 or cx1 < ax0 - 1e-9 or ay1 < cy0 - 1e-9 or cy1 < ay0 - 1e-9:
                continue
            s1, s2 = _sgn(_cross3(a, b, c)), _sgn(_cross3(a, b, d))
            s3, s4 = _sgn(_cross3(c, d, a)), _sgn(_cross3(c, d, b))
            if s1 * s2 <= 0 and s3 * s4 <= 0:
                return True
    return False


class Run:
    def __init__(self, points, closed):
        clean = []
        for p in points:
            if not clean or math.dist(clean[-1], p) > 1e-12:
                clean.append(p)
        if closed and len(clean) > 1 and math.dist(clean[0], clean[-1]) <= 1e-12:
            clean.pop()
        self.points = clean
        self.closed = closed
        pts = self.points + (self.points[:1] if closed else [])
        self._pts = pts
        self._cum = [0.0]
        for a, b in zip(pts, pts[1:]):
            self._cum.append(self._cum[-1] + math.dist(a, b))
        self.length = self._cum[-1]

    def point_at(self, s):
        pts, cum = self._pts, self._cum
        if self.closed and self.length > 0:
            s %= self.length
        if s <= 0:
            i = 0
        elif s >= self.length:
            i = len(pts) - 2
        else:
            lo, hi = 0, len(cum) - 1
            while hi - lo > 1:
                mid = (lo + hi) // 2
                if cum[mid] <= s:
                    lo = mid
                else:
                    hi = mid
            i = lo
        a, b = pts[i], pts[i + 1]
        seg = cum[i + 1] - cum[i]
        t = (s - cum[i]) / seg if seg > 0 else 0.0
        return (a[0] + t * (b[0] - a[0]), a[1] + t * (b[1] - a[1]))

    def chord_dir(self):
        a, b = self._pts[0], self._pts[-1]
        if self.closed:
            b = self._pts[1]
        return _norm(b[0] - a[0], b[1] - a[1])


def _turn(points, i):
    n = len(points)
    a, b, c = points[i - 1], points[i], points[(i + 1) % n]
    u = _norm(b[0] - a[0], b[1] - a[1])
    v = _norm(c[0] - b[0], c[1] - b[1])
    return math.atan2(u[0] * v[1] - u[1] * v[0], u[0] * v[0] + u[1] * v[1])


def split_runs(points, closed, corner_angle, course, depth):
    """Split a centerline at sharp corners; return (run, start_ext, end_ext)."""
    n = len(points)
    idx = range(n) if closed else range(1, n - 1)
    corners = [i for i in idx if abs(_turn(points, i)) > corner_angle]
    if closed and not corners:
        return [(Run(points, True), 0.0, 0.0)]
    if closed:
        order = points[corners[0]:] + points[:corners[0]]
        cut = sorted((i - corners[0]) % n for i in corners) + [n]
        pieces = [order[cut[j]:cut[j + 1]] + [order[cut[j + 1] % n]] for j in range(len(cut) - 1)]
    else:
        cut = [0] + corners + [n - 1]
        pieces = [points[cut[j]:cut[j + 1] + 1] for j in range(len(cut) - 1)]
    runs = [Run(p, False) for p in pieces]
    for run in runs:
        run.miter = [0.0, 0.0]
    ext = [[0.0, 0.0] for _ in runs]
    joints = list(range(len(runs))) if closed else list(range(len(runs) - 1))
    h = depth / 2
    for j in joints:
        a, b = j, (j + 1) % len(runs)
        pa, pb = runs[a]._pts, runs[b]._pts
        ua = _norm(pa[-1][0] - pa[-2][0], pa[-1][1] - pa[-2][1])
        ub = _norm(pb[1][0] - pb[0][0], pb[1][1] - pb[0][1])
        turn = math.atan2(ua[0] * ub[1] - ua[1] * ub[0], ua[0] * ub[0] + ua[1] * ub[1])
        phi = abs(turn)
        if phi <= MITER_MAX_TURN:
            # Task 16b (user 2026-10-21 "cắt vát chéo"): an OBTUSE corner cannot be closed by
            # interlocking boxes (a hexagon left up to 0.7 m of its outer face bare), so both
            # runs stop at the joint and their end bricks are cut along the bisector.
            runs[a].miter[1] = runs[b].miter[0] = math.tan(turn / 2)
            continue
        e_own, e_non = _corner_exts(phi, h, depth)
        da = runs[a].chord_dir()
        bucket = round(math.atan2(da[1], da[0]) / (math.pi / 2) + 1e-9)
        if (bucket + course) % 2 == 0:
            ext[a][1], ext[b][0] = e_own, -e_non
        else:
            ext[a][1], ext[b][0] = -e_non, e_own
    return [(run, s, e) for run, (s, e) in zip(runs, ext)]


def _corner_exts(phi, h, depth):
    """(owner extension, non-owner setback) for a turn of |phi| on a wall of half-depth h.

    Frame: joint at origin, owner wall {x <= e_own, |y| <= h}, other wall leaves along
    v = (cos phi, sin phi); outer faces meet at x = h tan(phi/2).
    """
    e_own = min(depth, h * math.tan(phi / 2))
    s, c = math.sin(phi), math.cos(phi)
    seps = []
    if s > 1e-9:
        seps.append(h * (1 + abs(c)) / s)  # other band lies beyond y = h
    if c >= 0:
        seps.append(e_own * c + h * s)  # separating axis along v
    # Setback is NOT capped: an over-long one just empties the span (b - a <= 0).
    e_non = min(seps) if seps else depth
    return e_own, e_non


def fill_lengths(total, unit, steps, min_len, rng, offset=0.0):
    """Random brick lengths (multiples of unit) that sum exactly to total.

    A nonzero offset below min_len is raised to min_len so the stagger survives.

    Since Task 11 the wall and cap runs lay STANDARD sizes (`fit_standard`); this
    exact-sum filler stays for the window frame stones, which must still tile a given
    width exactly (frame semantics are unchanged).
    """
    if total <= 1e-9:
        return []
    # Normalize so max_c >= 2 * min_len: then the clamp/merge below stays in bounds.
    max_c = max(steps) * unit
    if max_c <= 1e-9:
        return [total]
    min_len = min(min_len, max_c / 2)
    choices = [max(s * unit, min_len) for s in steps]
    if 0 < offset < min_len:
        offset = min_len
    elif offset > max_c:
        offset = max_c
    if total < min_len:
        return [total]
    lengths = []
    if offset >= min_len and total - offset >= min_len:
        lengths.append(offset)
    rest = total - sum(lengths)
    while rest > 1e-9:
        if rest <= max_c + 1e-9:
            if rest >= min_len or not lengths:
                lengths.append(rest)
            else:
                merged = lengths.pop() + rest
                lengths += [merged / 2, merged / 2] if merged > max_c else [merged]
            break
        pick = rng.choice(choices)
        if rest - pick < min_len:
            pick = rest - min_len
        lengths.append(pick)
        rest -= pick
    return lengths

# Standard sizes (Task 11, user decision 2026-10-19). Every wall and cap brick is one of a
# few standard lengths, so bricks of equal (length, height, depth) share one mesh. A SLOT is
# a standard length plus its head joint: the brick drawn in a slot is `slot - gap` long.
#
# Task 11b (user 2026-10-20, "sửa lại không để khoảng hở giữa các viên nữa" /
# "đoạn dư bây giờ xử lý theo cách chia có 2 viên đầu và cuối hàng"): what the slots leave
# over is NOT spread over the joints any more — the leftover is split in two between the
# FIRST and the LAST brick of the span. Those two end bricks are custom; everything
# between them stays standard.
#
# Task 11c (user 2026-10-20, "cách 2"): an end brick may only grow by a WHOLE multiple of
# `size_step`, rounded DOWN, so a span of any length produces one of a handful of end
# sizes instead of a continuum (`_fill_ends` / `_step_growth`). What the step cannot take
# (under two steps) is spread evenly over that span's joints, which is the only place a
# joint is still wider than `gap` on a straight wall — by under `2 * size_step / (n + 1)`.

HALF_STEP = 0.5
"""A staggered odd course opens with half a standard brick."""

MANY_PIECES = 400
"""Above this many pieces in one span the exhaustive fit falls back to largest-first."""

CAP_DIRS = 8
"""How many of a cap outline's longest edge directions `_cap_rows` tries."""

MITER_MAX_TURN = math.radians(75.0)
"""Corners turning at most this much are mitred (Task 16b, user 2026-10-21): a hexagon (60),
an octagon (45), a pentagon (72). A square (90) keeps its interlocking corner bond."""

ARC_SEGMENTS = 4
"""Slices along the length of an 'arc' brick (Task 16): 3 edge loops across it. The user found
8 slices too dense (2026-10-21 "chỉ tạo 2 hoặc 3 loop thôi"); the bent loop normals keep the
long faces shading round between the loops, and an even count keeps a loop at the middle."""

_RING_FLOOR = 0.25
"""A tight ring whose clearance depth falls below this fraction of the asked brick depth
gets no bricks at all: the course is crowned with an apex block instead."""

def standard_lengths(params, half=False):
    """Allowed slots of a run, ascending: the `length_steps` multiples of brick_length, and
    with `half` also the HALF brick. Degenerate `length_steps` fall back to one whole brick.

    The half brick is a standard size with its own shared mesh, but it is not a free choice:
    it opens a staggered odd course, and `_half_closer` may add ONE at the end of a run that
    the whole multiples leave more than a half brick short (a 6 m wall of 1.6 m bricks would
    otherwise stop 1.22 m short, which reads as a hole rather than a wide joint)."""
    vals = {s * params.brick_length for s in params.length_steps if s > 0}
    if half:
        vals.add(HALF_STEP * params.brick_length)
    out = tuple(sorted(v for v in vals if v > params.gap + 1e-9))
    return out or (max(params.brick_length, 2 * params.gap),)

def _half_closer(slots, total, params, cands):
    """`slots` plus ONE half brick when the whole slots leave at least a half brick of
    shortfall — enough that the gap would read as a hole rather than a wide joint.

    An odd (staggered) course already opens with a half brick, but that starter is not a
    closer: such a course may still take one at its end, so both parities reach equally far.
    The closer goes to the end whose neighbour is not itself a half, to keep alternation.

    A span that no whole slot fits at all (shorter than 1x) takes the half on its own, so a
    short stretch of wall is bricked on both parities instead of only the staggered one."""
    half = HALF_STEP * params.brick_length
    if total - sum(slots) < half - 1e-9:
        return slots
    if not slots:
        return [half]
    body = slots[1:] if slots[0] == half else slots  # the stagger starter is not a closer
    if any(s == half for s in body):
        return slots  # this run already has its one closer
    out = list(slots)
    # Prefer the end whose neighbour is not already a half brick (alternation), else the end.
    if out[-1] != half:
        out.append(half)
    elif out[0] != half:
        out.insert(0, half)
    else:
        out.append(half)
    return out

def _arrangeable(counts, m):
    """True if a multiset with these counts can be ordered with no two equal neighbours."""
    return 2 * max(counts) <= m + 1

_COVER_CACHE = {}
"""Slot set -> (steps, per-(k, q) best-coverage memo). Courses repeat the same slot sets, so
the table is built once and reused across every run of a build."""

def _best_cover(cands, quantum):
    """(cover(k, q), steps): the greatest coverage reachable using slots 0..k with `q`
    quanta left, as integers. Quantising to whole units of `quantum` is what makes the memo
    exact — two states with the same (k, q) have identical futures — and it is a plain
    bounded-coin DP, so it costs O(len(cands) * q) instead of enumerating multisets."""
    key = (cands, round(quantum, 12))
    hit = _COVER_CACHE.get(key)
    if hit is None:
        if len(_COVER_CACHE) > 64:
            _COVER_CACHE.clear()
        hit = ([int(c / quantum + 0.5) for c in cands], {})
        _COVER_CACHE[key] = hit
    steps, memo = hit

    def cover(k, q):
        if k < 0 or q <= 0:
            return 0
        got = memo.get((k, q))
        if got is None:
            step = steps[k]
            got = cover(k - 1, q)
            # Take c of slot k, then the best of the rest; one extra copy at a time keeps
            # this O(q / step) per state and reuses the states already solved.
            if step <= q:
                got = max(got, step + cover(k, q - step))
            memo[(k, q)] = got
        return got

    return cover, steps

def _count_fits(total, cands, alternate):
    """Counts over ascending `cands` for the best standard fill of `total`.

    Ranked by: covered length first; then whether the run's two ENDS are anchored (either
    the fill is exact, or it has two or more pieces, so the leftover can go to the joints
    BETWEEN them and the first and last brick still sit on the ends — this is what keeps a
    corner covered); then, with `alternate`, whether the multiset can be laid without two
    equal neighbours; then the fewest pieces.

    So alternation yields to coverage: a span that only one standard brick fits into is
    laid as two shorter equal ones rather than leaving one end of the run open.

    Two stages, because the secondary keys are not additive (`_arrangeable` needs the whole
    multiset): a memoised DP finds the best reachable coverage, then only the branches that
    still attain it are enumerated and ranked. That subtree is tiny, so the cost no longer
    grows as span^(len(cands) - 1) — a 60 m wall at steps "1, 1.5, 2" went from 184 ms of
    layout to a few ms.

    A span that would take a huge number of pieces (tiny steps) is filled largest-first
    instead of searched, so the work stays bounded whatever the step list."""
    n = len(cands)
    if n == 0 or total < cands[0] - 1e-9:
        return (0,) * n
    if total / cands[0] > MANY_PIECES:
        counts, rest = [0] * n, total
        for i in range(n - 1, -1, -1):
            counts[i] = int(rest / cands[i] + 1e-9)
            rest -= counts[i] * cands[i]
        return tuple(counts)
    # Quantise on a unit that divides every slot closely enough to be exact in integers.
    quantum = cands[0] / 64.0
    cover, steps = _best_cover(cands, quantum)
    budget = int(total / quantum + 1e-6)
    target = cover(n - 1, budget)
    exact = target >= budget
    cur = [0] * n
    best = [None, None]

    def rank(m):
        anchored = m >= 2 or exact
        ok = (not alternate) or m == 0 or _arrangeable(cur, m)
        # Fewer pieces last: at equal coverage, longer bricks (the shortfall is the same
        # either way — it is set by the slot granularity, not by the piece count).
        return (anchored, ok, -m)

    def rec(k, q, got, pieces):
        """Walk only the branches that can still reach `target` coverage, best-first.

        Within one k the piece count only grows as c falls, and the rank's last key prefers
        FEWER pieces, so once a branch is already worse than the best complete answer on
        (anchored, ok) it cannot be rescued by taking more pieces -- stop that loop."""
        if k < 0:
            if got == target:
                key = rank(pieces)
                if best[0] is None or key > best[0]:
                    best[0], best[1] = key, tuple(cur)
            return
        step = steps[k]
        for c in range(q // step, -1, -1):
            if got + c * step + cover(k - 1, q - c * step) < target:
                continue  # this branch can no longer reach the best coverage
            cur[k] = c
            rec(k - 1, q - c * step, got + c * step, pieces + c)
            cur[k] = 0
            # The best possible rank from here on only loses pieces: if we already hold the
            # top rank (anchored and alternating) with no more pieces than this branch can
            # manage, nothing deeper in this loop can beat it.
            if best[0] is not None and best[0][0] and best[0][1] and -best[0][2] <= pieces + c:
                return

    rec(n - 1, budget, 0, 0)
    return best[1] if best[1] is not None else (0,) * n

def _arrange(counts, cands, rng, prev=None):
    """Lay the multiset out so neighbours differ wherever the counts allow: always draw from
    the largest remaining pile whose length is not the previous one (ties broken by `rng`).

    Postcondition: no two equal neighbours IF `_arrangeable(counts, sum(counts))`; otherwise
    one pile outnumbers the gaps between the others and equal neighbours are unavoidable, so
    the result simply contains some ((1, 4) over two lengths gives 3.2 3.2 3.2 1.6 3.2).
    Callers that care rank the multiset by `_arrangeable` BEFORE calling, as `_count_fits`
    does."""
    left, out = list(counts), []
    while sum(left):
        live = [i for i in range(len(cands)) if left[i]]
        top = max(left[i] for i in live)
        pick = [i for i in live if left[i] == top and cands[i] != prev]
        if not pick:
            pick = [i for i in live if left[i] == top]
        i = pick[0] if len(pick) == 1 else rng.choice(pick)
        out.append(cands[i])
        left[i] -= 1
        prev = cands[i]
    return out

def fit_standard(total, cands, rng, offset=0.0, alternate=True):
    """Standard slots filling `total` as fully as possible, in laying order.

    The shortfall is NOT made into an odd brick: the caller spreads it over the joints, so
    every brick keeps a standard size. `offset` prepends one slot (the stagger half brick).
    [] when not even the shortest standard slot fits."""
    if not cands or total <= 1e-9:
        return []
    lead = []
    if offset > 1e-9 and offset <= total + 1e-9:
        lead, total = [offset], total - offset
    body = _arrange(_count_fits(total, cands, alternate), cands, rng, lead[0] if lead else None)
    return lead + body

def _sag(run, s0, s1, samples=8):
    """Max distance of the run between s0 and s1 from the chord joining its ends."""
    pa, pb = run.point_at(s0), run.point_at(s1)
    tx, ty = _norm(pb[0] - pa[0], pb[1] - pa[1])
    worst = 0.0
    for i in range(1, samples):
        q = run.point_at(s0 + (s1 - s0) * i / samples)
        worst = max(worst, abs((q[0] - pa[0]) * ty - (q[1] - pa[1]) * tx))
    return worst

def _is_curved(run):
    return run.closed or len(run.points) > 2

def _arc_for_chord(run, s, chord, hi, steps=12):
    """Run length from `s` whose straight chord measures `chord`, or None if the run bends
    away before reaching it within `hi`. On a curved wall a standard brick is a standard
    CHORD: its mesh keeps the standard length and it eats a little more centerline.

    The chord is NOT monotonic in the arc (a closed run comes back to its start), so the
    first bracket where it reaches `chord` is found by scanning forward and only then
    bisected."""
    if chord <= 1e-9:
        return 0.0
    if hi < chord - 1e-9:
        return None
    at = run.point_at
    x0, y0 = at(s)
    sq = chord * chord

    def short(d):
        x, y = at(s + d)
        return (x - x0) ** 2 + (y - y0) ** 2 < sq

    lo = chord
    if not short(lo):
        return chord  # straight here
    top = min(hi, chord * 4)  # past this a standard chord has bent too far to be a wall
    for i in range(1, steps + 1):
        cur = lo + (top - lo) * i / steps
        if not short(cur):
            hi = cur
            break
        lo = cur
    else:
        return None
    # 20 halvings take the bracket below a micrometre on any sane wall.
    for _ in range(20):
        mid = (lo + hi) / 2
        if short(mid):
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2

def _curve_fit(run, cands, depth, samples=8):
    """(usable slots, brick depth) for a curved run.

    A slot is usable at FULL depth when its chord sags at most depth/4 from the wall
    everywhere along the run and the chord brick clears the inside of the ring.

    Ring clearance: on a ring of radius r a chord c of a brick `depth` deep has its inner
    face at sqrt(r^2 - (c/2)^2) - depth/2 from the centre, so the slot needs
    r^2 >= (c/2)^2 + (depth/2)^2, i.e. depth <= 2 * sqrt(r^2 - (c/2)^2), or opposite bricks
    pass through each other.

    When no slot is usable at full depth the ring is a tight curve: it keeps the SHORTEST
    slot whose chord still closes round it ("1x only on tight curves") and goes SHALLOWER,
    the depth taken from that same clearance inequality, exactly as a thin wall does. Below
    `_RING_FLOOR` of the asked depth not even that fits and the slot list comes back empty,
    so the caller (build_layout) crowns the course with an apex block instead of bending a
    brick to fit."""
    if not _is_curved(run) or run.length <= 1e-9 or not cands:
        return cands, depth
    key = (cands, round(depth, 9))
    cache = getattr(run, "_std_fit", None)
    if cache is not None and cache[0] == key:
        return cache[1]
    tol = depth / 4
    gap = getattr(run, "_std_gap", 0.0)
    r = run.length / math.tau if run.closed else math.inf
    ok, closes = [], []
    for c in cands:
        worst = 0.0
        for i in range(samples):
            s = run.length * i / samples
            arc = _arc_for_chord(run, s, c, run.length)
            if arc is None:
                worst = math.inf
                break
            worst = max(worst, _sag(run, s, s + arc, 4))
        if worst == math.inf:
            continue  # the chord does not close round this run at all
        closes.append(c)
        if r * r < (c / 2) ** 2 + (depth / 2) ** 2 - 1e-12:
            continue  # at full depth opposite bricks would meet in the middle
        if worst <= tol:
            ok.append(c)
    if ok:
        out = (tuple(ok), depth)
    else:
        # Tight curve: keep the shortest slot whose chord closes round the ring at all, and
        # take the depth from the clearance inequality (NOT from the sag: on this branch
        # every sag already exceeds depth/4, so a sag-derived clamp could never bite).
        first = min(closes, default=None)
        if first is None:
            out = ((), depth)
        else:
            fit = 2 * math.sqrt(max(r * r - (first / 2) ** 2, 0.0)) - gap if r < math.inf else depth
            eff = min(depth, fit)
            out = ((), depth) if eff < _RING_FLOOR * depth else ((first,), eff)
    run._std_fit = (key, out)
    return out

def _chord_dir(run, s, arc):
    pa, pb = run.point_at(s), run.point_at(s + arc)
    return _norm(pb[0] - pa[0], pb[1] - pa[1])

def _turn_room(prev_dir, next_dir, depth):
    """Centerline a joint needs so two chord bricks of depth `depth` meeting at the turn from
    `prev_dir` to `next_dir` do not drive their visible (right-hand) corners through each
    other: depth * tan(phi/2) for a right turn of phi, 0 for a left turn or a straight joint.

    (Before Task 11 the same geometry was handled the other way round, by SHRINKING each
    brick back from the joint by depth/2 * tan of its own angle to the local direction. A
    standard brick may not shrink, so the clearance is reserved in the joint instead.)"""
    if prev_dir is None or prev_dir == (0.0, 0.0) or next_dir == (0.0, 0.0):
        return 0.0
    sin = prev_dir[0] * next_dir[1] - prev_dir[1] * next_dir[0]
    cos = prev_dir[0] * next_dir[0] + prev_dir[1] * next_dir[1]
    if sin >= -1e-9:
        return 0.0  # straight, or turning left: the joint opens on the visible side
    return depth * abs(sin) / (1.0 + max(cos, -0.999))  # tan(phi/2) = |sin| / (1 + cos)

def _place_after(run, s_end, slot, b, prev_dir, depth, pad, rounds=3):
    """(start, arc) of the next standard chord after a brick ending at `s_end`, or None.

    The joint's clearance depends on the new brick's chord direction, which in turn depends
    on where the joint puts it, so the two are solved together by a short fixed-point loop."""
    room = 0.0
    out = None
    for _ in range(rounds):
        s = s_end + pad + room
        arc = _arc_for_chord(run, s, slot, b - s)
        if arc is None:
            return None
        out = (s, arc)
        nxt = _turn_room(prev_dir, _chord_dir(run, s, arc), depth)
        if abs(nxt - room) < 1e-6:
            break
        room = nxt
    return out

def _walk_curved(run, a, b, cands, rng, offset, alternate, depth, pad=0.0):
    """[(s, arc, slot), ...] laying standard chords along a curved run from a to b.

    Greedy largest-first: each step takes the longest slot that still fits in what is left,
    preferring one that differs from the slot just laid (greedy, not exhaustive: on a curve
    how much centerline a slot eats depends on where it starts). Each joint also reserves
    `_turn_room` plus `pad`, the share of the leftover spread over the joints."""
    out, s_end, prev, pdir = [], a, None, None
    first = True
    while True:
        pool_cands = [offset] if (first and offset > 1e-9) else list(cands)
        fits = []
        for c in pool_cands:
            place = (_arc_for_chord(run, a, c, b - a) if first and not out else None)
            if first and not out:
                if place is not None:
                    fits.append((c, a, place))
                continue
            got = _place_after(run, s_end, c, b, pdir, depth, pad)
            if got is not None:
                fits.append((c, got[0], got[1]))
        if not fits:
            break
        pool = [f for f in fits if f[0] != prev] if alternate else fits
        pool = pool or fits
        top = max(f[0] for f in pool)
        best = [f for f in pool if f[0] == top]
        slot, s, arc = best[0] if len(best) == 1 else rng.choice(best)
        out.append((s, arc, slot))
        pdir = _chord_dir(run, s, arc)
        s_end, prev, first = s + arc, slot, False
    return out

def _step_growth(left, step, ends=2):
    """How much ONE end brick grows: the largest whole multiple of `step` that fits in
    `left / ends`, rounded DOWN (Task 11c, user 2026-10-20 "cách 2").

    Rounding down is what keeps the grown bricks inside their span, and quantising is what
    keeps them shareable: an end of standard base `s` is only ever `s + k * step` long, so
    at most `ceil(shortest_slot / step)` sizes exist per base instead of one per span."""
    if left <= 1e-12 or step <= 1e-12:
        return 0.0
    return math.floor(left / ends / step + 1e-9) * step

def _fill_ends(slots, span, step):
    """(slots, pad) for a straight span: `slots` with its two END slots grown by the same
    whole multiple of `step`, and `pad`, the share of the rest that every joint takes.

    Task 11b put the whole leftover `L = span - sum(slots)` into the two ends, L/2 each,
    which made every end brick a different size. Task 11c grows them by
    `floor((L/2) / step) * step` instead; what is left over (`r < 2 * step`) is spread
    evenly over the span's `n + 1` joints — the `n - 1` head joints between the bricks and
    the half joint at each end of the run — so the span is still filled exactly end to end
    and no joint is more than `2 * step / (n + 1)` over `gap`.

    A lone slot has no second end to share with: it takes `floor(L / step) * step` and the
    rest splits into the two joints beside it, which leaves the brick centred on its span.

    The remainder goes into the HEAD joints only, and the span's two outer ends stay
    anchored where `fit_standard` put them. The brief asked for it to be spread over
    `n + 1` joints, counting the run's two outer ends, but a span's outer ends are not
    joints between bricks: on a wall they are the CORNER, where the courses interlock and
    where `test_corners_do_not_overlap_and_cover_outer_corner` requires the outer corner
    point to be covered, and beside an opening they are the JAMB. Letting them recede by
    the remainder opened the pentagon's corners by 0.06 and left the brick beside a jamb
    0.03 short. Interior joints take `r / (n - 1)` instead of `r / (n + 1)`, so the bound
    rises from `2 * step / (n + 1)` to `2 * step / (n - 1)` -- at most `2 * step` on a
    two-brick span, which is the brief's stated worst case either way.

    `fit_standard` guarantees `L` is under the shortest slot, so a grown end stays below
    the next standard size up."""
    if not slots:
        return slots, 0.0, 0.0
    out = list(slots)
    left = span - sum(out)
    if left <= 1e-12:
        return out, 0.0, 0.0
    if len(out) == 1:
        # No head joint to widen: the rest shows as a half joint at each end, so the lone
        # brick sits centred on its span (Task 11c rule 2).
        out[0] += _step_growth(left, step, 1)
        return out, 0.0, max(span - sum(out), 0.0) / 2
    grow = _step_growth(left, step, 2)
    out[0] += grow
    out[-1] += left - grow
    return out, max(span - sum(out), 0.0) / (len(out) - 1), 0.0

def _relay_curved(run, a, b, slots, depth, pad=0.0):
    """Lay a given slot (chord) sequence along a curved run from `a`, each chord starting
    where the previous one ended plus `pad` and the turn room the joint needs.

    Every chord keeps the length it was given, which is what lets the two END chords be a
    standard size plus a whole `size_step` (Task 11c). Returns None if a chord no longer
    closes round the run."""
    out, s_end, pdir = [], a, None
    for slot in slots:
        got = ((a, _arc_for_chord(run, a, slot, b - a)) if not out
               else _place_after(run, s_end, slot, b, pdir, depth, pad))
        if got is None or got[1] is None:
            return None
        s, arc = got
        out.append((s, arc, slot))
        pdir = _chord_dir(run, s, arc)
        s_end = s + arc
    return out

def _close_curved(run, a, b, slots, depth, pad, rounds=3):
    """`slots` laid along the curved run with `pad` extra in every joint -- the share of
    the leftover the `size_step` could not put into the two end chords (Task 11c rule 4).
    None if even `pad` 0 no longer fits inside the span.

    `pad` is arithmetic, not solved: how much centerline a chord eats depends on where it
    starts, so the laid run lands a few millimetres short of `b` rather than exactly on
    it. That residue is the same one curved walls have always carried (a chord is shorter
    than the arc it spans) and it closes the seam no worse than Task 11 did. What a solve
    would buy is not worth a secant loop per course: measured, chasing exact closure cost
    11 relays per span and took the 465-brick tower from 97 to 183 ms.

    A pad that pushes the last chord past the span's end is halved until it fits, so the
    bricks never run off the end of their span."""
    for _ in range(rounds):
        out = _relay_curved(run, a, b, slots, depth, pad)
        if out is not None and out[-1][0] + out[-1][1] <= b + 1e-9:
            return out
        if pad <= 1e-12:
            return None
        pad /= 2
    return _relay_curved(run, a, b, slots, depth, 0.0)

def _ends_clear(run, places, depth, gap):
    """True if the two END chords of a curved layout still clear their neighbours on the
    visible (outer) half and stay inside the run.

    A chord grown to swallow the leftover bulges further off the curve than a standard one,
    and on a tight ring or round a hole that is exactly where chord bricks start driving
    through each other. This is the invariant curved walls hold to everywhere else
    (`penetration(outer_half(a), b)`), checked only for the two chords that changed."""
    if len(places) < 2:
        return True
    boxes = []
    for s, arc, slot in places:
        pa, pb = run.point_at(s), run.point_at(s + arc)
        c = math.dist(pa, pb)
        if c < 1e-9:
            return False
        t = ((pb[0] - pa[0]) / c, (pb[1] - pa[1]) / c)
        boxes.append(((pa[0] + pb[0]) / 2, (pa[1] + pb[1]) / 2, t, c - gap))
    for i in (0, len(boxes) - 1):
        cx, cy, t, ln = boxes[i]
        # The outer half of this chord: shifted right of its tangent by depth/4, half deep.
        ox, oy, od = cx + t[1] * depth / 4, cy - t[0] * depth / 4, depth / 2
        for j, (qx, qy, qt, qln) in enumerate(boxes):
            if j == i:
                continue
            if _rect_penetration((ox, oy), t, ln, od, (qx, qy), qt, qln, depth) > 1e-3:
                return False
    return True

def _rect_penetration(ca, ta, la, da, cb, tb, lb, db):
    """SAT penetration depth of two oriented rectangles (centre, unit tangent, length,
    depth) in plan; 0 when they are separated."""
    def corners(c, t, l, d):
        n = (-t[1], t[0])
        return [(c[0] + sx * l / 2 * t[0] + sy * d / 2 * n[0],
                 c[1] + sx * l / 2 * t[1] + sy * d / 2 * n[1])
                for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1))]

    p, q = corners(ca, ta, la, da), corners(cb, tb, lb, db)
    best = math.inf
    for poly in (p, q):
        for i in range(4):
            u, v = poly[i - 1], poly[i]
            ax, ay = v[1] - u[1], u[0] - v[0]
            n = math.hypot(ax, ay)
            if n < 1e-12:
                continue
            ax, ay = ax / n, ay / n
            pa = [x * ax + y * ay for x, y in p]
            qa = [x * ax + y * ay for x, y in q]
            best = min(best, min(max(pa), max(qa)) - max(min(pa), min(qa)))
    return max(best, 0.0) if best < math.inf else 0.0

def _standard_slots(run, a, b, params, rng, offset, alternate):
    """(placements, brick depth) for the span [a, b] of `run`.

    A placement is (start, arc, slot); the brick drawn there is `slot - gap` long. Straight
    runs take the exhaustive best-fit multiset; curved runs are walked once with joints of
    exactly `gap` and then relaid so the two end chords absorb the leftover centerline.

    Task 11b/11c: the two END slots swallow the leftover (`_fill_ends`) in whole steps of
    `size_step`; only what the step cannot take widens the joints, equally across the
    span."""
    cands = standard_lengths(params, half=offset > 1e-9)
    span = b - a
    if span <= 1e-9 or not cands:
        return [], params.brick_depth
    if not _is_curved(run):
        slots = _half_closer(fit_standard(span, cands, rng, offset, alternate), span, params, cands)
        if not slots:
            return [], params.brick_depth
        filled, pad, inset = _fill_ends(slots, span, params.size_step)
        out, s = [], a + inset
        for slot in filled:
            out.append((s, slot, slot))
            s += slot + pad
        return out, params.brick_depth
    run._std_gap = params.gap
    cands, depth = _curve_fit(run, cands, params.brick_depth)
    if not cands:
        return [], depth
    if offset > 1e-9 and offset not in cands:
        offset = cands[0] if cands[0] < offset else 0.0
    first = _walk_curved(run, a, b, cands, rng, offset, alternate, depth)
    if not first:
        return [], depth
    # The leftover centerline goes to the two chords at the run's ends (either side of the
    # ring's seam on a closed run) in whole steps of `size_step` (Task 11c rule 4), and what
    # the step cannot take widens the joints along the arc instead (`_close_curved`).
    # A grown chord bulges further off the curve than a standard one, so the result is kept
    # only while the two end bricks still clear their neighbours on the visible outer half;
    # a step that fails that guard is dropped for the next one down, and on a ring too tight
    # for even one step the walk's own spread-the-leftover layout stands.
    # A closed run laid over its WHOLE length has no ends, so every chord has a joint after
    # it; a SUB-span of one (cut by a window, or a merlon of the crenel band) does have two
    # ends, so it has one joint fewer, exactly like an open run.
    ring = run.closed and b - a >= run.length - 1e-9
    slots = [pl[2] for pl in first]
    left = max(span - (first[-1][0] + first[-1][1] - a), 0.0)
    joints = max(len(slots) - (0 if ring else 1), 1)
    if len(slots) >= 2 and left > 1e-9:
        grow = _step_growth(left, params.size_step)
        while grow > 1e-12:
            grown = list(slots)
            grown[0] += grow
            grown[-1] += grow
            relaid = _close_curved(run, a, b, grown, depth, (left - 2 * grow) / joints)
            if relaid is not None and _ends_clear(run, relaid, depth, params.gap):
                return relaid, depth
            grow -= params.size_step
    pad = left / joints
    spread = _walk_curved(run, a, b, cands, rng, offset, alternate, depth, pad)
    # A wider pad can push a chord off the END of the span, so a spread layout may lay FEWER
    # bricks than the tight walk and leave a stretch of wall bare (Task 13 review C1: a
    # windowed r1.6 ring lost a brick and opened a 1.46 m arc). Never accept that: a hole is
    # worse than a joint a little over `gap`.
    return (spread if len(spread) >= len(first) else first), depth

def layout_span(run, a, b, z, params, rng, offset, alternate=None):
    """Bricks covering run parameters [a, b], STANDARD lengths only.

    Every brick is `slot - gap` long for one of `standard_lengths`, so bricks of equal slot,
    height and depth share one mesh. What the slots do not cover is spread over the head
    joints (slightly wider joints instead of one odd brick). On a curved run a slot is a
    standard CHORD: its arc is solved where the brick actually sits, so its two ends are
    exactly `slot` apart whatever the curvature, and a curve too tight for a slot never
    offers it (the run then lays the shortest slot at a reduced depth).
    """
    if alternate is None:
        alternate = params.alternate_steps
    places, depth = _standard_slots(run, a, b, params, rng, offset, alternate)
    bricks = []
    height = params.brick_height - params.gap
    for s, arc, slot in places:
        pa, pb = run.point_at(s), run.point_at(s + arc)
        length = slot - params.gap
        chord = math.dist(pa, pb)
        if length <= 1e-6 or chord < 1e-9:
            continue
        t = ((pb[0] - pa[0]) / chord, (pb[1] - pa[1]) / chord)
        bricks.append(Brick(((pa[0] + pb[0]) / 2, (pa[1] + pb[1]) / 2, z),
                            (t[0], t[1], 0.0), (0.0, 0.0, 1.0), length, height, depth))
    return bricks

def _fit_radius(run, s0, s1):
    """Signed radius of the circle through the centerline at s0, mid, s1 (positive = the
    run turns LEFT, centre on the solid side), or inf when the three are collinear.

    Task 16 (user 2026-10-21): a curved brick is bent onto THIS circle, so a piece of any
    curved run (not only a true circle) gets the curvature it actually sits on."""
    pa, pm, pb = run.point_at(s0), run.point_at((s0 + s1) / 2), run.point_at(s1)
    ax, ay = pm[0] - pa[0], pm[1] - pa[1]
    bx, by = pb[0] - pm[0], pb[1] - pm[1]
    cross = ax * by - ay * bx
    if abs(cross) < 1e-12:
        return math.inf
    return math.dist(pa, pm) * math.dist(pm, pb) * math.dist(pa, pb) / (2 * cross)


def _circumcentre(pa, pm, pb):
    """Centre of the circle through three plan points (None when collinear). Pairs with
    `_fit_radius` on the same three points, so a brick's bend centre and radius agree."""
    ax, ay = pa
    bx, by = pm
    cx, cy = pb
    d = 2 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by))
    if abs(d) < 1e-12:
        return None
    a2, b2, c2 = ax * ax + ay * ay, bx * bx + by * by, cx * cx + cy * cy
    return ((a2 * (by - cy) + b2 * (cy - ay) + c2 * (ay - by)) / d,
            (a2 * (cx - bx) + b2 * (ax - cx) + c2 * (bx - ax)) / d)


# A merged 2x curved brick may bend through at most this angle: a longer one reads as a
# hoop rather than a brick (Task 16).
_MAX_MERGE_ANGLE = math.pi / 2


def curved_cells(span, closed, params, rng, odd, radius=math.inf):
    """[(offset_from_a, arc), ...] pieces of a curved span; `arc` INCLUDES the trailing joint,
    so the brick laid there is `arc - gap` long. None when a cell is too short for a brick.

    Task 16 (user 2026-10-21, spec rule 1): a curved wall is divided into N EQUAL cells,
    N = round(span / brick_length), so every joint is exactly `gap` and nothing is left
    over — like the hand-made reference tower in test.blend. A full ring has no ends: an odd
    course just rotates by half a cell. An open span (a curved run, or a merlon of a ring)
    staggers with half cells at BOTH ends instead, unless a half would be shorter than
    `min_len`. With a 2x step in `length_steps` a full cell sometimes (1 in 3, seeded by
    `rng`; None = never) merges with the next one, so the joint grid stays a multiple of the
    cell; with `alternate_steps` two merged bricks never touch, not even across a ring's
    seam. `radius` (of the tightest piece) stops a merge that would bend past
    `_MAX_MERGE_ANGLE`."""
    if span <= 1e-9:
        return None
    n = max(1, round(span / params.brick_length))
    cell = span / n
    if cell - params.gap < params.min_len - 1e-9:
        return None
    if closed:
        start = cell / 2 if odd else 0.0
        cells = [(start + i * cell, cell, True) for i in range(n)]
    elif odd and n >= 2 and cell / 2 - params.gap >= params.min_len - 1e-9:
        cells = ([(0.0, cell / 2, False)]
                 + [(cell / 2 + i * cell, cell, True) for i in range(n - 1)]
                 + [(span - cell / 2, cell / 2, False)])
    else:
        cells = [(i * cell, cell, True) for i in range(n)]
    merge = (rng is not None and any(st >= 2.0 - 1e-9 for st in params.length_steps)
             and 2 * cell / abs(radius) <= _MAX_MERGE_ANGLE)
    if not merge:
        return [(o, w) for o, w, _full in cells]
    alternate = params.alternate_steps
    out, merged, i = [], [], 0
    while i < len(cells):
        o, w, full = cells[i]
        pair = i + 1 < len(cells) and full and cells[i + 1][2]
        if pair and alternate:
            # Never beside the previous 2x brick, nor (on a ring) the first one across the
            # seam when this pair ends the course.
            pair = not (merged and merged[-1]) and not (
                closed and merged and merged[0] and i + 2 == len(cells))
        if pair and rng.random() < 1 / 3:
            out.append((o, w + cells[i + 1][1]))
            merged.append(True)
            i += 2
            continue
        out.append((o, w))
        merged.append(False)
        i += 1
    return out


def _arc_brick(c, r, ux, uy, z, length, height, depth):
    """Arc brick whose centre line passes through `c` + |r| * (ux, uy) (u = unit vector from
    the centre of curvature), bent on signed radius r. Its local +Y (up x tangent, the run's
    left / solid side) points to the centre for r > 0 and away from it for r < 0."""
    sg = 1.0 if r > 0 else -1.0
    return Brick((c[0] + abs(r) * ux, c[1] + abs(r) * uy, z), (-sg * uy, sg * ux, 0.0),
                 (0.0, 0.0, 1.0), length, height, depth, "arc", 0, (r,))


def _run_circle(run, depth):
    """(signed radius, centre) when the WHOLE run is one circle to within a twentieth of
    `depth`, else None. Cached on the run.

    Task 16: a faceted round tower is one circle, but three-point fits of single bricks'
    pieces scatter a few percent on its facets (and more on a merlon's short sub-span), which
    would give every brick its own radius and mesh. Judged on the whole run instead, every
    span of a round run shares one circle and the course instances. A closed run takes the
    radius whose circumference IS its centerline length, so N cells close exactly."""
    memo = run.__dict__.setdefault("_circle", {})
    if depth in memo:
        return memo[depth]
    pts, out = run.points, None
    if len(pts) >= 3:
        if run.closed:
            c = (sum(q[0] for q in pts) / len(pts), sum(q[1] for q in pts) / len(pts))
            area = 0.5 * sum(pts[i - 1][0] * pts[i][1] - pts[i][0] * pts[i - 1][1]
                             for i in range(len(pts)))
            r = math.copysign(run.length / math.tau, area) if abs(area) > 1e-12 else math.inf
        else:
            r = _fit_radius(run, 0.0, run.length)
            c = (_circumcentre(run.point_at(0.0), run.point_at(run.length / 2),
                               run.point_at(run.length)) if math.isfinite(r) else None)
        if c is not None and math.isfinite(r) and abs(r) <= 1e4:
            tol = 0.05 * depth + 1e-6
            probe = list(pts) + [run.point_at(run.length * (i + 0.5) / 64) for i in range(64)]
            if all(abs(math.dist(q, c) - abs(r)) <= tol for q in probe):
                out = (round(r, 3), c)
    memo[depth] = out
    return out


def layout_curved_span(run, a, b, z, params, rng, odd):
    """Bricks bent along the curved span [a, b] of `run` (Task 16, user 2026-10-21), or None
    when it is not suitable — a ring too short for 3 cells, a cell too short for a brick, or
    a curve so tight that half the brick depth reaches its centre — so the caller falls back
    to `layout_span` and the existing tight-ring / apex logic still decides.

    On a round run (`_run_circle`) every brick shares that circle and is placed by angle on
    it: a course is then N identical bricks (one mesh) exactly 360/N degrees apart. On any
    other curve each piece is bent onto the circle through three centerline points of that
    piece (`_fit_radius`) and sits on the centerline at its middle; a collinear piece is a
    plain box on its chord, as `layout_span` lays it."""
    span = b - a
    ring = run.closed and span >= run.length - 1e-9
    if ring and round(span / params.brick_length) < 3:
        return None
    base = curved_cells(span, ring, params, None, odd)
    if not base:
        return None
    gap, depth = params.gap, params.brick_depth
    height = params.brick_height - gap
    merge = any(st >= 2.0 - 1e-9 for st in params.length_steps)
    circle = _run_circle(run, depth)
    bricks = []
    if circle is not None:
        r, c = circle
        if depth / 2 >= 0.95 * abs(r):
            return None
        pieces = curved_cells(span, ring, params, rng, odd, r) if merge else base
        pa = run.point_at(a)
        theta0 = math.atan2(pa[1] - c[1], pa[0] - c[0])
        for o, w in pieces:
            th = theta0 + (o + w / 2) / r
            bricks.append(_arc_brick(c, r, math.cos(th), math.sin(th), z, w - gap, height, depth))
        return bricks

    def fit(o, w):
        s0, s1 = a + o + gap / 2, a + o + w - gap / 2
        pm = run.point_at((s0 + s1) / 2)
        r = _fit_radius(run, s0, s1)
        c = None
        if math.isfinite(r) and abs(r) <= 1e4:
            c = _circumcentre(run.point_at(s0), pm, run.point_at(s1))
        return (r, c, pm) if c is not None else (math.inf, None, pm)

    rs = [r for r, c, _p in map(lambda ow: fit(*ow), base) if c is not None]
    if any(depth / 2 >= 0.95 * abs(r) for r in rs):
        return None
    pieces = curved_cells(span, ring, params, rng, odd, min(map(abs, rs), default=math.inf)) if merge else base
    # Task 16c (user 2026-10-21: corner bricks of a rounded box overlapped on one face and
    # gaped on the other): a piece is NOT bent onto a fitted circle any more, it follows the
    # run's own centerline (`_path_brick`). Two neighbours then meet on faces cut along the
    # same offset vector, so they close exactly; the price is fewer shared meshes.
    field = _offset_field(run, depth)
    for o, w in pieces:
        got = _path_brick(run, field, a + o + gap / 2, a + o + w - gap / 2, z, height, depth)
        if got is not None:
            bricks.append(got)
    return bricks

def _offset_field(run, depth):
    """Knots [(s, (nx, ny)), ...] of the run's offset vector field N(s), piecewise linear
    in s and cached on the run (Task 16c).

    The knots are the run's VERTICES only: there N is the MITER vector
    m = (n1 + n2) / (1 + n1 . n2), with m . n = 1 for both neighbouring segments' unit
    normals. Between two vertices N blends linearly from one miter to the next, and every
    blend still has N . n = 1 for that segment, so P(s) + y * N(s) stays exactly on the
    line offset by y. A brick end cut along N(s) and its neighbour's start cut along
    N(s + gap) are therefore (nearly) parallel and touch exactly when gap is 0, wherever
    on the curve the joint falls.

    A knot inside a segment would add an edge loop on a perfectly flat stretch of face (user
    2026-10-21: "lưới thừa ... không có tác dụng gì"), so there is none: a path brick is cut
    only where its faces actually turn."""
    memo = run.__dict__.setdefault("_field", {})
    if depth in memo:
        return memo[depth]
    pts, cum = run._pts, run._cum
    segs = len(pts) - 1
    norms = []
    for k in range(segs):
        t = _norm(pts[k + 1][0] - pts[k][0], pts[k + 1][1] - pts[k][1])
        norms.append((-t[1], t[0]))

    def miter(k):  # at vertex k, between segment k-1 and k
        if not run.closed and (k == 0 or k == segs):
            return norms[0] if k == 0 else norms[-1]
        n1, n2 = norms[(k - 1) % segs], norms[k % segs]
        d = 1.0 + n1[0] * n2[0] + n1[1] * n2[1]
        if d < 0.2:
            return n2  # a near reversal: no sane miter (split_runs cuts such corners anyway)
        return ((n1[0] + n2[0]) / d, (n1[1] + n2[1]) / d)

    knots = [(cum[k], miter(k)) for k in range(segs + 1)]
    memo[depth] = knots
    return knots

def _field_at(run, knots, s):
    """N(s) from `_offset_field` knots; a closed run wraps, an open one keeps its end
    normal beyond either end."""
    if run.closed and run.length > 0:
        s %= run.length
    xs = [k[0] for k in knots]
    if s <= xs[0]:
        return knots[0][1]
    if s >= xs[-1]:
        return knots[-1][1]
    lo, hi = 0, len(xs) - 1
    while hi - lo > 1:
        mid = (lo + hi) // 2
        if xs[mid] <= s:
            lo = mid
        else:
            hi = mid
    t = (s - xs[lo]) / (xs[hi] - xs[lo]) if xs[hi] > xs[lo] else 0.0
    (ax, ay), (bx, by) = knots[lo][1], knots[hi][1]
    return (ax + t * (bx - ax), ay + t * (by - ay))

def _path_brick(run, knots, s0, s1, z, height, depth):
    """A brick along the run's centerline from s0 to s1 (Task 16c): shape 'path', or a
    plain box when the stretch is straight and its ends are square. Its frame is the chord
    (centre at the chord's middle, tangent along it); `outline` samples the centre line at
    both ends and at every knot of the offset field in between."""
    if s1 - s0 <= 1e-6:
        return None
    ss = [s0]
    if run.closed and run.length > 0:
        base = math.floor(s0 / run.length) * run.length
        for rep in (base - run.length, base, base + run.length):
            ss += [rep + k[0] for k in knots if s0 + 1e-6 < rep + k[0] < s1 - 1e-6]
    else:
        ss += [k[0] for k in knots if s0 + 1e-6 < k[0] < s1 - 1e-6]
    ss = sorted(set(ss)) + [s1]
    pa, pb = run.point_at(s0), run.point_at(s1)
    chord = math.dist(pa, pb)
    if chord < 1e-9:
        return None
    t = ((pb[0] - pa[0]) / chord, (pb[1] - pa[1]) / chord)
    n = (-t[1], t[0])
    c = ((pa[0] + pb[0]) / 2, (pa[1] + pb[1]) / 2)
    mid = (s0 + s1) / 2
    path = []
    for s in ss:
        p = run.point_at(s)
        v = _field_at(run, knots, s)
        dx, dy = p[0] - c[0], p[1] - c[1]
        path.append((s - mid, dx * t[0] + dy * t[1], dx * n[0] + dy * n[1],
                     v[0] * t[0] + v[1] * t[1], v[0] * n[0] + v[1] * n[1]))
    straight = all(abs(q[2]) < 1e-6 and abs(q[3]) < 1e-6 and abs(q[4] - 1.0) < 1e-6 for q in path)
    if straight:
        return Brick((c[0], c[1], z), (t[0], t[1], 0.0), (0.0, 0.0, 1.0), chord, height, depth)
    # The inner face must not fold back on itself: on a curve tighter than the wall is deep
    # (user 2026-10-22, "góc bevel cạnh đó đang lỗi": a 2.8 m deep wall round a 2.5 m edge)
    # the inner offset line would run backwards and the brick turn inside out. The brick is
    # made only as deep as every segment's inner offset still runs forward — the same
    # "tight curve -> shallower brick" rule the ring layout uses (Task 11).
    fit = depth
    for q0, q1 in zip(path, path[1:]):
        cx, cy = q1[1] - q0[1], q1[2] - q0[2]
        dvx, dvy = q1[3] - q0[3], q1[4] - q0[4]
        along = cx * cx + cy * cy
        back = -(dvx * cx + dvy * cy)
        if back > 1e-12:
            # Inner offset y: segment (c + y * dv) . c > 0  <=>  y < along / back.
            fit = min(fit, 2 * 0.95 * along / back)
    if fit < depth - 1e-6:
        shift = (depth - fit) / 2           # keep the OUTER face where it is
        path = [(q[0], q[1] - shift * q[3], q[2] - shift * q[4], q[3], q[4]) for q in path]
        depth = fit
    return Brick((c[0], c[1], z), (t[0], t[1], 0.0), (0.0, 0.0, 1.0), s1 - s0, height, depth,
                 "path", 0, tuple(tuple(float(v) for v in q) for q in path))


def crenel_blocks(contour, depth, z, params):
    """Crenel band of one closed outer contour as EQUAL blocks (user 2026-10-22, sample: "các
    viên đều nhau không có viên nào dài hơn cả"). A round outline (no sharp corner) gets
    equal cubes round the ring instead of corner blocks + per-face merlons.

    Every block in the band is the SAME square, `depth` on each side. Every convex corner
    carries one, its outer faces on the two faces. Between two corner blocks each face gets
    q interior merlons of `merlon_bricks` blocks and q + 1 equal crenel gaps: q = the most
    merlons that still leave every gap at least `crenel_gap_bricks` blocks wide (none on a
    face too short for one merlon and two gaps). The faces differ only in how wide their gaps
    are, never in the blocks."""
    pts = [(float(x), float(y)) for x, y in contour.points]
    n = len(pts)
    if n < 3:
        return None
    turns = [_turn(pts, i) for i in range(n)]
    corners = [i for i in range(n) if abs(turns[i]) > params.corner_angle]
    gap, h = params.gap, params.brick_height - params.gap
    proud = max(0.0, float(params.crenel_proud))
    if not corners:
        # A ROUND outline (user 2026-10-22, test.blend Cylinder.002: Số răng / Sâu / Nhô ra
        # had no effect on the tower because its band still went through the old per-run
        # merlon layout). Equal cubes round the ring, each tangent to the face where it
        # sits, `proud` out of it; Số răng blocks (0 = as many as leave a gap of one block),
        # equally spaced, never closer than a joint.
        run = Run(pts, True)
        L = run.length
        if L <= 1e-9:
            return None
        cap = int((L + gap + 1e-9) // (depth + gap))
        want = int(params.crenel_count)
        q = min(want, cap) if want > 0 else int((L + 1e-9) // (2 * depth))
        if q < 2:
            return []
        step = L / q
        out = []
        for i in range(q):
            sm = i * step
            e = min(0.01, L / 4)
            pa, pb = run.point_at(sm - e), run.point_at(sm + e)
            t = _norm(pb[0] - pa[0], pb[1] - pa[1])
            nrm = (-t[1], t[0])
            c0 = run.point_at(sm)
            c = (c0[0] + nrm[0] * (depth / 2 - proud), c0[1] + nrm[1] * (depth / 2 - proud), z)
            out.append(Brick(c, (t[0], t[1], 0.0), (0.0, 0.0, 1.0), depth - gap, h, depth - gap))
        return out
    nk = max(1, int(params.merlon_bricks))
    mw = nk * depth                                  # k square blocks side by side
    cw = max(1, int(params.crenel_gap_bricks)) * depth
    # ONE closed run of the whole outline (user 2026-10-23, test.blend Cube.002, a chamfered
    # octagon): a block on every corner put two blocks on a 1.1 m chamfer that only holds
    # 0.7 m each, and merlons shared per face made the gaps differ face to face. Now the
    # band is ANCHOR blocks (a corner block where both faces beside the corner are long, ONE
    # mid-face block on a face too short for two corner blocks) and merlons spread between
    # neighbouring anchors measured along the outline, so every gap round the band is alike.
    run = Run(pts, True)
    L = run.length
    if L <= 1e-9:
        return None
    s_at = [0.0]
    for i in range(1, n):
        s_at.append(s_at[-1] + math.dist(pts[i - 1], pts[i]))
    nc = len(corners)
    face_len = [((s_at[corners[(ci + 1) % nc]] - s_at[i]) % L) or L for ci, i in enumerate(corners)]
    # Measured with Nhô ra 0, so turning Nhô ra adds or drops no block.
    short = [fl < 2 * depth + gap - 1e-9 for fl in face_len]

    def block_at(sm, length, along, p):
        """A square `length` long centred at outline coordinate `sm`, its outer face on the
        outline, `p` (Nhô ra) out of it, shifted `along` the tangent (a corner block reaches
        back past the corner, out of the incoming face)."""
        e = min(0.01, L / 4)
        pa, pb = run.point_at(sm - e), run.point_at(sm + e)
        t = _norm(pb[0] - pa[0], pb[1] - pa[1])
        nrm = (-t[1], t[0])
        c0 = run.point_at(sm)
        c = (c0[0] + t[0] * along + nrm[0] * (depth / 2 - p),
             c0[1] + t[1] * along + nrm[1] * (depth / 2 - p), z)
        return Brick(c, (t[0], t[1], 0.0), (0.0, 0.0, 1.0), length, h, depth - gap)

    def overlaps(brk, others):
        return any(_rect_penetration(brk.center[:2], brk.tangent[:2], brk.length, brk.depth,
                                     o.center[:2], o.tangent[:2], o.length, o.depth) > 1e-6
                   for o in others)

    # Anchors in outline order, decided at Nhô ra 0: (is_corner, sm, sc). A mid-face block
    # that would overlap an earlier anchor (two short faces meeting at a sharp corner) is
    # dropped, the last one also against the first.
    plan_anchors, kept = [], []
    for ci, i in enumerate(corners):
        sc = s_at[i]
        if turns[i] > 0 and not short[ci - 1] and not short[ci]:
            sm = (sc + depth / 2) % L
            plan_anchors.append((True, sm, sc))
            kept.append(block_at(sm, depth - gap, 0.0, 0.0))
        if short[ci]:
            sm = (sc + face_len[ci] / 2) % L
            brk = block_at(sm, depth - gap, 0.0, 0.0)
            if not overlaps(brk, kept):
                plan_anchors.append((False, sm, sc))
                kept.append(brk)
    if len(kept) > 1 and overlaps(kept[-1], [kept[0]]):
        plan_anchors.pop()
        kept.pop()
    if not plan_anchors:
        return []

    def anchor_bricks(p):
        return [block_at(sm, depth - gap, -p if is_c else 0.0, p) for is_c, sm, _sc in plan_anchors]

    def stretches(p):
        """[lo, hi] of outline a merlon may not enter per anchor: a corner block keeps
        `depth - p` either side of its corner (the gap beside it then equals the gaps between
        merlons), a mid-face block its own footprint."""
        out = []
        for is_c, sm, sc in plan_anchors:
            if is_c:
                out.append(((sc - (depth - p)) % L, (sc + (depth - p)) % L))
            else:
                out.append(((sm - depth / 2) % L, (sm + depth / 2) % L))
        return out

    def spans_of(p):
        """(start, free) per span between consecutive anchors (closed: last -> first)."""
        st = stretches(p)
        out = []
        for ai, (lo_a, hi_a) in enumerate(st):
            lo_b, hi_b = st[(ai + 1) % len(st)]
            free = (lo_b - hi_a) % L if len(st) > 1 else L - (hi_a - lo_a) % L
            out.append((hi_a, free))
        return out

    corner_s = [s_at[i] for i in corners]

    def merlons_of(lo, free, q, p, check, neighbours=()):
        """Bricks of `q` equal merlons spread over [lo, lo + free]. With `check`, None when a
        merlon would contain a corner of the outline or overlap `neighbours` or each other:
        that is what keeps a merlon from straddling a corner the band carries no block on."""
        g = (free - q * mw) / (q + 1)
        bricks = []
        sx = lo + g
        for _ in range(q):
            for m in range(nk):
                s0, s1 = sx + m * depth + gap / 2, sx + (m + 1) * depth - gap / 2
                if check:
                    for cs in corner_s:
                        if 1e-9 < (cs - s0) % L < (s1 - s0) - 1e-9:
                            return None
                bricks.append(block_at(((s0 + s1) / 2) % L, s1 - s0, 0.0, p))
            sx += mw + g
        if check:
            for k_, brk in enumerate(bricks):
                if overlaps(brk, neighbours) or overlaps(brk, bricks[:k_]):
                    return None
        return bricks

    # Capacity per span, at Nhô ra 0: the most merlons that fit with a joint between blocks
    # AND pass the corner / overlap check.
    anchors0 = anchor_bricks(0.0)
    spans0 = spans_of(0.0)
    caps = []
    for lo, free0 in spans0:
        q = max(0, int((free0 + gap + 1e-9) // (mw + gap)))
        while q > 0 and merlons_of(lo, free0, q, 0.0, True, anchors0) is None:
            q -= 1
        caps.append(q)

    # Merlons per span. Số răng (user 2026-10-22) is the TOTAL round the outline, handed out
    # one merlon at a time to the span whose gaps are currently the widest, so the gaps end
    # up as alike as whole blocks allow all the way round.
    spans = spans_of(proud)
    want = int(params.crenel_count)
    if want > 0:
        counts = [0] * len(spans)
        gap_of = lambda t: (spans[t][1] - counts[t] * mw) / (counts[t] + 1)
        for _ in range(min(want, sum(caps))):
            open_ = [t for t in range(len(spans)) if counts[t] < caps[t]]
            if not open_:
                break
            counts[max(open_, key=gap_of)] += 1
    else:
        counts = [min(cap, int((free0 - cw + 1e-9) // (mw + cw)) if free0 > mw + 2 * cw - 1e-9 else 0)
                  for (_lo, free0), cap in zip(spans0, caps)]

    out = anchor_bricks(proud)
    for (lo, free), q in zip(spans, counts):
        if q > 0:
            out += merlons_of(lo, free, q, proud, False)
    return out

def _merlon_bricks(run, sa, sb, z, params):
    """A merlon [sa, sb] of the crenel band laid as `merlon_bricks` EQUAL bricks with joints
    of exactly `gap` (user 2026-10-22). A curved merlon takes equal curved cells through the
    same curved layout as the wall (one count, no merge, no stagger), so its bricks still
    bend with the ring."""
    n = max(1, int(params.merlon_bricks))
    span = sb - sa
    if span <= params.gap + 1e-6:
        return []
    cell = span / n
    if _is_curved(run):
        flat = replace(params, brick_length=cell, length_steps=(1.0,), stagger=False,
                       min_piece=min(params.min_piece, 0.5))
        laid = layout_curved_span(run, sa, sb, z, flat, None, False)
        if laid is not None and len(laid) == n:
            return laid
    height = params.brick_height - params.gap
    out = []
    for i in range(n):
        s0, s1 = sa + i * cell + params.gap / 2, sa + (i + 1) * cell - params.gap / 2
        pa, pb = run.point_at(s0), run.point_at(s1)
        chord = math.dist(pa, pb)
        if chord <= 1e-6:
            continue
        t = ((pb[0] - pa[0]) / chord, (pb[1] - pa[1]) / chord)
        out.append(Brick(((pa[0] + pb[0]) / 2, (pa[1] + pb[1]) / 2, z), (t[0], t[1], 0.0),
                         (0.0, 0.0, 1.0), chord, height, params.brick_depth))
    return out

def _span_bricks(run, sa, sb, course, z, params, rng):
    """One span no opening cuts: bent bricks on a curved run (Task 16 spec rule 3), else —
    or when the curve does not suit them — the standard chord layout."""
    if _is_curved(run):
        laid = layout_curved_span(run, sa, sb, z, params, rng, bool(params.stagger and course % 2))
        if laid is not None:
            return laid
    return layout_span(run, sa, sb, z, params, rng, _stagger_offset(params, course))


def _stagger_offset(params, course):
    """The half-brick slot that opens a staggered odd course (0 on even courses / no stagger)."""
    return HALF_STEP * params.brick_length if (params.stagger and course % 2) else 0.0

def layout_run(run, start_ext, end_ext, course, z, params, rng):
    return layout_span(run, -start_ext, run.length + end_ext, z, params, rng,
                       _stagger_offset(params, course))

def merlon_spans(length, start_ext, end_ext, closed, params):
    """Run parameters [(a, b), ...] of the MERLONS of one run in the crenel band — the
    stretches that still get bricks in the top `crenel_courses` courses (Task 13, user
    2026-10-19; remainder rule updated 2026-10-20 for Tasks 11b/11c).

    Units are whole standard bricks: a merlon is `k = merlon_bricks` of them, a crenel gap
    is `m = crenel_gap_bricks` of them, and one of those units is `brick_length` of run
    parameter (the brick drawn in it is `brick_length - gap` long, so the opening a gap
    actually shows is `m * brick_length + gap` wide).

    OPEN run (a wall between two corners): a merlon sits at EACH corner, then gap, merlon,
    gap, ... — so the count is the largest `q >= 2` whose
    `q * k + (q - 1) * m` units fit the run, i.e. `q = floor((length + m*u) / ((k + m)*u))`.
    What the whole units leave over is split between the two CORNER merlons, half each;
    `layout_span` then grows their end bricks in whole `size_step`s and widens only their
    own head joints (Task 11c), so every INTERIOR merlon is exactly `k` standard bricks with
    joints of `gap`, and every gap is exactly `m` units wide. A run too short for two
    merlons and a gap (`length < 2*k*u + m*u`) becomes ONE merlon spanning the whole run.

    CLOSED ring (a round tower: no corners to anchor to): merlon and gap alternate all the
    way round, `q = floor(length / ((k + m) * u))` of each, the first merlon starting at the
    run's own origin so the band stacks over the courses below. The leftover is shared
    EQUALLY by all `q` merlons (there is no corner merlon to prefer). A ring too small for
    one whole period keeps its full course — a crenel that cannot close round the ring would
    read as a single notch, not as battlements.

    The run's corner extensions are added to the first and last merlon only, and the whole
    pattern is measured on the bare run, so it does not shift when the corner owner
    alternates from course to course: the interlock stays inside the corner merlons."""
    unit = params.brick_length
    k = max(1, int(params.merlon_bricks))
    m = max(1, int(params.crenel_gap_bricks))
    mw, gw = k * unit, m * unit
    if unit <= 1e-9 or length <= 1e-9:
        return [(-start_ext, length + end_ext)]
    if closed:
        q = int((length + 1e-9) / (mw + gw))
        if q < 2:
            return [(0.0, length)]
        extra = (length - q * (mw + gw)) / q
        out, s = [], 0.0
        for _ in range(q):
            out.append((s, s + mw + extra))
            s += mw + extra + gw
        return out
    q = int((length + gw + 1e-9) / (mw + gw))
    if q < 2:
        return [(-start_ext, length + end_ext)]
    extra = (length - (q * mw + (q - 1) * gw)) / 2
    out, s = [], 0.0
    for i in range(q):
        w = mw + (extra if i in (0, q - 1) else 0.0)
        out.append((s, s + w))
        s += w + gw
    out[0] = (-start_ext, out[0][1])
    out[-1] = (out[-1][0], length + end_ext)
    return out


def _course_merlons(contours, params):
    """[(contour, merlon count)] for every OUTER contour of one course, counted the way the
    crenel band itself will count: on the offset centerline, split into runs, each run's
    `merlon_spans` (Task 14).

    A band only reads as battlements when its course yields at least TWO merlons; one
    merlon beside one gap is a single notch. `merlon_spans` already refuses that per RUN
    (the `q < 2` guards, Task 13 review I1), but a whole course can still come out with one
    merlon when its ONE closed ring is too small — the cone tops at `crenel_courses = 1`
    (r3 -> 0: ring 1.537 against a 1.600 period, so `q = 0` and the ring keeps its full
    course as a single unbroken run, which `_notch`-free is exactly one merlon).

    Measured on the real runs rather than on the perimeter so a box's four open runs and a
    tower's single closed run are counted alike, and so the ring depth / corner split this
    course will actually be laid with are the ones that decide."""
    out = []
    min_depth = min(0.05, params.brick_depth / 4)
    ring = _ring_depths(contours, params.brick_depth)
    for ci, c in enumerate(contours):
        if not (c.closed and c.signed_area() > 0):
            continue
        depth = min(_wall_depth(c, params.brick_depth), ring.get(ci, params.brick_depth))
        line = offset_polyline(c.points, c.closed, depth / 2) if depth >= min_depth else None
        if line is None:
            continue
        pk = params if depth == params.brick_depth else replace(params, brick_depth=depth)
        n = 0
        for run, s, e in split_runs(line, c.closed, pk.corner_angle, len(contours), depth):
            n += len(merlon_spans(run.length, s, e, run.closed, pk))
        out.append((c, n))
    return out

# ---- layout

class Layout(namedtuple("Layout", "bricks warnings frames", defaults=((),))):
    """`bricks` = wall + cap bricks; `frames` = window frame stones."""

    @property
    def all(self):
        return list(self.bricks) + list(self.frames)


class TooManyBricks(Exception):
    def __init__(self, count):
        super().__init__(count)
        self.count = count


def cap_regions(verts, faces):
    """Boundary loops of upward-facing horizontal faces, grouped by height."""
    groups = {}
    tri_idx = np.asarray(faces, dtype=np.int64).reshape(-1, 3)
    if len(tri_idx):
        a = verts[tri_idx[:, 0]]
        n = np.cross(verts[tri_idx[:, 1]] - a, verts[tri_idx[:, 2]] - a)
        size = np.linalg.norm(n, axis=1)
        up = (size >= 1e-12) & (n[:, 2] >= 0.99 * size)
        for i in np.nonzero(up)[0]:
            groups.setdefault(round(float(a[i, 2]), 4), []).append(faces[i])
    regions = []
    for z, tris in sorted(groups.items()):
        uses = Counter(frozenset((t[i], t[(i + 1) % 3])) for t in tris for i in range(3))
        nxt = {t[i]: t[(i + 1) % 3] for t in tris for i in range(3)
               if uses[frozenset((t[i], t[(i + 1) % 3]))] == 1}
        loops, seen = [], set()
        for start in nxt:
            if start in seen:
                continue
            loop, cur = [], start
            while cur in nxt and cur not in seen:
                seen.add(cur)
                loop.append((float(verts[cur][0]), float(verts[cur][1])))
                cur = nxt[cur]
            loop = _simplify(loop, True)
            if len(loop) >= 3:
                loops.append(loop)
        if loops:
            regions.append((z, loops))
    return regions


def _point_in_loop(p, loop):
    inside = False
    for a, b in zip(loop, loop[1:] + loop[:1]):
        if (a[1] > p[1]) != (b[1] > p[1]):
            if p[0] < a[0] + (p[1] - a[1]) / (b[1] - a[1]) * (b[0] - a[0]):
                inside = not inside
    return inside


def _all_in_loop(points, loop):
    """True if every point is inside the closed loop (even-odd rule, numpy)."""
    p = np.asarray(points, dtype=np.float64)
    a = np.asarray(loop, dtype=np.float64)
    b = np.roll(a, -1, axis=0)
    px, py = p[:, 0:1], p[:, 1:2]
    straddle = (a[None, :, 1] > py) != (b[None, :, 1] > py)
    dy = np.where(straddle, b[None, :, 1] - a[None, :, 1], 1.0)
    xs = a[None, :, 0] + (py - a[None, :, 1]) / dy * (b[None, :, 0] - a[None, :, 0])
    hits = np.count_nonzero(straddle & (px < xs), axis=1)
    return bool(np.all(hits % 2 == 1))


def _loops_cross(la, lb):
    """True if any edge of closed loop la crosses or touches any edge of closed loop lb."""
    a = np.asarray(la, dtype=np.float64)[:, None, :]
    b = np.roll(np.asarray(la, dtype=np.float64), -1, axis=0)[:, None, :]
    c = np.asarray(lb, dtype=np.float64)[None, :, :]
    d = np.roll(np.asarray(lb, dtype=np.float64), -1, axis=0)[None, :, :]

    def cross(o, u, v):
        return (u[..., 0] - o[..., 0]) * (v[..., 1] - o[..., 1]) - (u[..., 1] - o[..., 1]) * (v[..., 0] - o[..., 0])

    def sgn(x):
        return np.where(np.abs(x) <= 1e-10, 0, np.sign(x))

    s1, s2 = sgn(cross(a, b, c)), sgn(cross(a, b, d))
    s3, s4 = sgn(cross(c, d, a)), sgn(cross(c, d, b))
    box = ((np.maximum(c[..., 0], d[..., 0]) >= np.minimum(a[..., 0], b[..., 0]) - 1e-9)
           & (np.minimum(c[..., 0], d[..., 0]) <= np.maximum(a[..., 0], b[..., 0]) + 1e-9)
           & (np.maximum(c[..., 1], d[..., 1]) >= np.minimum(a[..., 1], b[..., 1]) - 1e-9)
           & (np.minimum(c[..., 1], d[..., 1]) <= np.maximum(a[..., 1], b[..., 1]) + 1e-9))
    return bool(np.any(box & (s1 * s2 <= 0) & (s3 * s4 <= 0)))


def _group_holes(outers, holes):
    """Index of the smallest outer loop enclosing each hole loop (None if no host)."""
    areas = [Contour(o, True).signed_area() for o in outers]
    owner = []
    for h in holes:
        hosts = [i for i, o in enumerate(outers) if _point_in_loop(h[0], o)]
        owner.append(min(hosts, key=lambda i: areas[i]) if hosts else None)
    return owner


def _inset_region(outer, holes, d, prune=False):
    """Outer loop and its holes each inset by d, or None if the region does not survive:
    an offset fails, an inset hole is not strictly inside the inset outer, or loops cross.
    `prune`: collapsed short faces are dropped instead of failing (`offset_polyline`)."""
    off_o = offset_polyline(outer, True, d, prune)
    if off_o is None:
        return None
    off_h = [offset_polyline(h, True, d, prune) for h in holes]
    if any(h is None for h in off_h):
        return None
    if any(not _all_in_loop(h, off_o) or _loops_cross(h, off_o) for h in off_h):
        return None
    if any(_loops_cross(off_h[a], off_h[b]) or _point_in_loop(off_h[a][0], off_h[b])
           or _point_in_loop(off_h[b][0], off_h[a])
           for a in range(len(off_h)) for b in range(a + 1, len(off_h))):
        return None
    return [off_o] + off_h


def _cap_inner_loops(loops, depth):
    """Inset each cap region (outer loop + its holes) by depth.

    A region whose inset outer collapses, or whose inset holes are not strictly inside the
    inset outer (the ring is narrower than two walls), gets no cap at all.
    """
    outers = [l for l in loops if Contour(l, True).signed_area() > 0]
    holes = [l for l in loops if Contour(l, True).signed_area() < 0]
    owner = _group_holes(outers, holes)
    inner = []
    for i, o in enumerate(outers):
        region = _inset_region(o, [h for h, w in zip(holes, owner) if w == i], depth)
        if region:
            inner += region
    return inner


def _ring_depths(contours, depth, steps=8, memo=None):
    """{contour index: max wall depth} for outer contours that own holes and for those holes:
    the largest d in (0, depth] at which the outer and all its holes inset by d still leave a
    region, so the outer and hole walls of a thin ring meet in the middle instead of overlapping.
    `memo` caches results by group geometry (prism courses repeat the same contours)."""
    outers = [i for i, c in enumerate(contours) if c.closed and c.signed_area() > 0]
    holes = [i for i, c in enumerate(contours) if c.closed and c.signed_area() < 0]
    if not holes:
        return {}
    owner = _group_holes([contours[i].points for i in outers], [contours[i].points for i in holes])
    out = {}
    for j, oi in enumerate(outers):
        mine = [holes[h] for h, w in enumerate(owner) if w == j]
        if not mine:
            continue
        hole_pts = [contours[i].points for i in mine]
        key = tuple(tuple((round(x, 6), round(y, 6)) for x, y in contours[i].points) for i in [oi] + mine)
        if memo is not None and key in memo:
            for i in [oi] + mine:
                out[i] = memo[key]
            continue
        ok = lambda d: _inset_region(contours[oi].points, hole_pts, d) is not None
        if ok(depth):
            d = depth
        else:
            lo, hi = 0.0, depth
            for _ in range(steps):
                mid = (lo + hi) / 2
                if ok(mid):
                    lo = mid
                else:
                    hi = mid
            d = lo
        if memo is not None:
            memo[key] = d
        for i in [oi] + mine:
            out[i] = d
    return out


def _row_intervals(uv_loops, v):
    """Even-odd inside intervals of the loops along the line v = const."""
    us = sorted(a[0] + (v - a[1]) / (b[1] - a[1]) * (b[0] - a[0])
                for l in uv_loops for a, b in zip(l, l[1:] + l[:1])
                if (a[1] > v) != (b[1] > v))
    return list(zip(us[0::2], us[1::2]))


def _intersect_intervals(xs, ys):
    out, i, j = [], 0, 0
    while i < len(xs) and j < len(ys):
        lo, hi = max(xs[i][0], ys[j][0]), min(xs[i][1], ys[j][1])
        if hi > lo:
            out.append((lo, hi))
        if xs[i][1] < ys[j][1]:
            i += 1
        else:
            j += 1
    return out


def _plan_half(brick):
    """Half the brick's extent ACROSS its tangent in plan.

    A wall brick stands up (`up` = +Z), so that is half its depth. A cap brick is the same
    brick LAID FLAT (Task 11b rule 8, user 2026-10-20): its `up` is horizontal, so its
    depth is the vertical dimension and its HEIGHT is what lies across the row."""
    return (brick.depth if abs(brick.up[2]) > 0.5 else brick.height) / 2

def _footprint_uv(brick, d, nrm):
    t = brick.tangent
    n = (-t[1], t[0])
    hl, hd = brick.length / 2, _plan_half(brick)
    pts = [(brick.center[0] + sx * hl * t[0] + sy * hd * n[0], brick.center[1] + sx * hl * t[1] + sy * hd * n[1])
           for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
    return [(p[0] * d[0] + p[1] * d[1], p[0] * nrm[0] + p[1] * nrm[1]) for p in pts]


def _footprints_uv(brick, d, nrm):
    """Convex plan pieces of a brick in the (d, nrm) frame: the one rectangle of a straight
    brick, or, for a 'path' brick bent round a corner (Task 16c), one quad per centre-line
    segment. Its chord rectangle claims the whole inside of the bend (2026-10-22, test.blend
    Cube.002: the corner bricks' rectangles emptied the cap rows beside every diagonal face
    and left 0.4-0.8 m of the top bare)."""
    if brick.shape != "path" or len(brick.outline) < 2 or abs(brick.up[2]) < 0.5:
        return [_footprint_uv(brick, d, nrm)]
    t = brick.tangent
    n = (-t[1], t[0])
    h = brick.depth / 2
    c = brick.center

    def world(px, py):
        x = c[0] + px * t[0] + py * n[0]
        y = c[1] + px * t[1] + py * n[1]
        return (x * d[0] + y * d[1], x * nrm[0] + y * nrm[1])

    # outline samples: (x_k, px, py, nx, ny) -- centre-line point and offset vector N in
    # the chord frame; the faces run at P -+ h * N (see `_follow`).
    pts = [(q[1], q[2], q[3], q[4]) for q in brick.outline]
    out = []
    for (px0, py0, nx0, ny0), (px1, py1, nx1, ny1) in zip(pts, pts[1:]):
        out.append([world(px0 - h * nx0, py0 - h * ny0), world(px1 - h * nx1, py1 - h * ny1),
                    world(px1 + h * nx1, py1 + h * ny1), world(px0 + h * nx0, py0 + h * ny0)])
    return out


def _strip_u_range(poly, lo, hi):
    """u-extent of the convex polygon (uv) clipped to the strip lo <= v <= hi, or None."""
    us = [p[0] for p in poly if lo <= p[1] <= hi]
    for a, b in zip(poly, poly[1:] + poly[:1]):
        for v in (lo, hi):
            if (a[1] - v) * (b[1] - v) < 0:
                us.append(a[0] + (v - a[1]) / (b[1] - a[1]) * (b[0] - a[0]))
    return (min(us), max(us)) if us else None


def _subtract_intervals(spans, cut):
    out = []
    for a, b in spans:
        if cut[1] <= a or cut[0] >= b:
            out.append((a, b))
            continue
        if cut[0] > a:
            out.append((a, cut[0]))
        if cut[1] < b:
            out.append((cut[1], b))
    return out


def _seg_dist(p, a, b):
    ex, ey = b[0] - a[0], b[1] - a[1]
    ll = ex * ex + ey * ey
    t = 0.0 if ll < 1e-24 else max(0.0, min(1.0, ((p[0] - a[0]) * ex + (p[1] - a[1]) * ey) / ll))
    return math.hypot(p[0] - a[0] - t * ex, p[1] - a[1] - t * ey)


def _dist_to_poly(p, poly):
    """Distance from p to the polygon (0 inside)."""
    if _point_in_loop(p, poly):
        return 0.0
    return min(_seg_dist(p, a, b) for a, b in zip(poly, poly[1:] + poly[:1]))


def _cap_slab(loops, inner, z, params, walls):
    """One N-sided slab (shape 'prism', N = outline edges clamped to [4, 8]) filling the free
    disc at the centre of a solid cap region (single outer loop, no holes) that is too small
    for a cap row: radius = clearance to the outline and to every wall brick, minus gap/2.
    `inner` = _cap_inner_loops(loops, brick_depth)."""
    if len(loops) != 1 or Contour(loops[0], True).signed_area() <= 0:
        return []
    if not inner:
        return []  # walls meet in the middle: no core to cap (only pinholes between bricks)
    outer = loops[0]
    c = _centroid(outer)
    if not _point_in_loop(c, outer):
        return []
    r = min(_seg_dist(c, a, b) for a, b in zip(outer, outer[1:] + outer[:1]))
    for w in walls:
        for q in _footprints_uv(w, (1.0, 0.0), (0.0, 1.0)):
            r = min(r, _dist_to_poly(c, q))
    r -= params.gap / 2
    if r < max(2 * params.gap, 0.25 * params.min_len):
        return []
    sides = min(8, max(4, len(outer)))
    i = max(range(len(outer)), key=lambda i: math.dist(outer[i - 1], outer[i]))
    d = _norm(outer[i][0] - outer[i - 1][0], outer[i][1] - outer[i - 1][1])
    h = params.brick_height - params.gap
    if sides == 4:
        side = r * math.sqrt(2)  # square inscribed in the free circle
        return [Brick((c[0], c[1], z), (d[0], d[1], 0.0), (0.0, 0.0, 1.0), side, h, side)]
    # Regular N-gon inscribed in the free circle (circumradius r).
    return [Brick((c[0], c[1], z), (d[0], d[1], 0.0), (0.0, 0.0, 1.0), 2 * r, h, 2 * r, "prism", sides)]


def _cap_inset(loops, walls, params):
    """How far in from the cap region's outline the cap band starts: the deepest inner face
    of the wall/solid bricks under the cap, plus one joint (user 2026-10-22), and never less
    than `brick_depth` (the wall ring).

    Each brick is measured against the loop its OUTER face stands on (the outline, or a
    hole of a tube): the outer-face point lies on that loop, so the inner face's distance to
    the same loop is the ring's depth there. Measured against the outline alone, a tube's
    hole-side bricks read as metres deep and the inset swallowed the whole cap."""
    deepest = params.brick_depth
    for b in walls:
        if abs(b.up[2]) < 0.5:
            continue
        t = b.tangent
        n = (-t[1], t[0])
        outer_face = (b.center[0] - n[0] * b.depth / 2, b.center[1] - n[1] * b.depth / 2)
        inner_face = (b.center[0] + n[0] * b.depth / 2, b.center[1] + n[1] * b.depth / 2)
        own = min(loops, key=lambda l: min(_seg_dist(outer_face, l[i - 1], l[i]) for i in range(len(l))))
        if min(_seg_dist(outer_face, own[i - 1], own[i]) for i in range(len(own))) > 0.25 * b.depth:
            continue  # not a face brick of this region (an interior Đặc ring is measured
                      # by its own ring's outer face below, through the ring outside it)
        # A face brick's ring is exactly `b.depth` deep: measured from its (chord-frame)
        # inner-face point a bent brick round a corner over-reads by up to a quarter depth
        # (test.blend Cube.002: 0.97 for a 0.78 ring), and that extra inset made the
        # octagon's offset fail and the cap vanish.
        deepest = max(deepest, b.depth)
    # Interior rings (Đặc) stand behind the face ring: walk inward while a brick's outer face
    # sits a joint behind the deepest inner face found so far.
    grew = True
    while grew:
        grew = False
        for b in walls:
            if abs(b.up[2]) < 0.5:
                continue
            t = b.tangent
            n = (-t[1], t[0])
            outer_face = (b.center[0] - n[0] * b.depth / 2, b.center[1] - n[1] * b.depth / 2)
            inner_face = (b.center[0] + n[0] * b.depth / 2, b.center[1] + n[1] * b.depth / 2)
            d_out = min(min(_seg_dist(outer_face, l[i - 1], l[i]) for i in range(len(l))) for l in loops)
            if abs(d_out - deepest) <= params.gap + 0.25 * b.depth and d_out + b.depth > deepest + 1e-6:
                deepest = d_out + b.depth
                grew = True
    return deepest + params.gap

def layout_cap(loops, z_top, params, rng, walls=(), inset=None):
    """Cap bricks inside the loops inset by `inset` (default brick_depth), their top face at
    `z_top`; `walls` (same course) are kept clear: chord bricks on curved walls reach past
    the inset loop by their sag. A solid region whose rows all come out empty (a small round
    tower top) gets one central slab (_cap_slab)."""
    inner = _cap_inner_loops(loops, params.brick_depth if inset is None else inset)
    if not inner and inset is not None and inset > params.brick_depth + 1e-9:
        # The ring inset collapsed this outline (short edges of a tapered polygon): fall
        # back to the plain wall-depth inset rather than leave the top open.
        inner = _cap_inner_loops(loops, params.brick_depth)
    bricks = _cap_rows(inner, z_top, params, rng, walls)
    # The slab fallback is a single upright block, so its own height is its thickness; like
    # the rows it hangs from `z_top` rather than sitting in the top course. It also wins
    # over rows that cover less than it does (2026-10-22: with the smallest edge piece down
    # to 1/10 brick, a small round top got two slivers instead of its slab).
    slab = _cap_slab(loops, inner, z_top - (params.brick_height - params.gap) / 2, params, walls)
    if slab and _slab_area(slab[0]) > sum(b.length * b.height for b in bricks) + 1e-9:
        return slab
    return bricks

def _slab_area(b):
    """Plan area of a `_cap_slab` block: a square, or a regular N-gon inscribed in its circle."""
    if b.shape == "prism":
        return b.sides / 2 * (b.length / 2) ** 2 * math.sin(math.tau / b.sides)
    return b.length * b.depth


def _lay_flat(brick, nrm):
    """A wall brick turned 90 degrees about its own length axis so its front face
    (length x brick_height) faces UP — the cap brick of Task 11b rule 8 (user 2026-10-20:
    "mặt lát trên là dạng gạch tường xoay 90 độ ngang ra chứ không phải để dọc như hiện tại").

    Same mesh, same `BrickMeshCache` key: only the frame turns. `tangent` still runs along
    the row; `up` becomes the horizontal row normal, so the brick's HEIGHT now lies across
    the row in plan and its DEPTH is the cap's thickness."""
    return brick._replace(up=(nrm[0], nrm[1], 0.0))

def _cap_rows_along(inner, z_top, params, rng, walls, d):
    """Cap rows running along direction `d` inside `inner` (the cap loops inset by
    brick_depth). The band's leftover width is split evenly between its two sides, so every
    row sits on the same grid whatever the outline.

    Task 11b rule 8: a cap brick is a WALL brick laid flat (`_lay_flat`), so what lies
    across the row is `brick_height` and the cap's thickness is `brick_depth`. The row
    pitch is therefore `brick_height + gap` and the cap's top face sits at `z_top`, the
    solid's real top. Same mesh key as a wall brick of the same length (fix round 1 / S1)."""
    nrm = (-d[1], d[0])
    uv_loops = [[(p[0] * d[0] + p[1] * d[1], p[0] * nrm[0] + p[1] * nrm[1]) for p in l] for l in inner]
    vs = [p[1] for l in uv_loops for p in l]
    v0, v1 = min(vs), max(vs)
    width = params.brick_height          # across the row, since the brick is on its side
    pitch = width + params.gap
    # n rows need n row widths and n-1 bed joints between them.
    rows = int((v1 - v0 + params.gap) / pitch + 1e-6)
    if rows < 1:
        return []  # not even one brick wide: the caller falls back to a central slab
    band = rows * pitch - params.gap
    side = ((v1 - v0) - band) / 2
    v0 += side
    z = z_top - params.brick_depth / 2   # the cap's top face is the solid's top
    shortest = standard_lengths(params)[0]
    eps = 1e-7
    wall_uv = [q for b in walls for q in _footprints_uv(b, d, nrm)]
    bricks = []
    # User 2026-10-22 ("viên mép cắt vừa"): the leftover across the band used to stay bare
    # on both sides; each side now gets a row narrowed to exactly what is left (one joint
    # off), so the cap meets the wall ring a joint away. Rows are (centre v, width).
    strips = [(v0 + width / 2 + r * pitch, width) for r in range(rows)]
    edge = side - params.gap
    min_piece = CAP_MIN_PIECE * params.brick_length
    if edge >= min_piece:
        strips.append((v0 - params.gap - edge / 2, edge))
        strips.append((v0 + band + params.gap + edge / 2, edge))
    for r, (v, w) in enumerate(strips):
        lo, hi = v - w / 2, v + w / 2
        pr = params if abs(w - width) < 1e-9 else replace(params, brick_height=w + params.gap)
        # The inside set along u changes only at loop vertices: sampling the strip edges and
        # just around every vertex inside the strip gives the exact strip-wide intersection.
        samples = [lo, v, hi]
        samples += [q for vv in vs if lo < vv < hi for q in (vv - eps, vv + eps) if lo <= q <= hi]
        spans = _row_intervals(uv_loops, samples[0])
        for vv in samples[1:]:
            spans = _intersect_intervals(spans, _row_intervals(uv_loops, vv))
        if not spans and r >= rows:
            continue
        if not spans:
            # The loop's apex (a diagonal face meeting its neighbour) lies inside this
            # strip, so no u-interval survives across its whole width. Narrow the strip
            # from the side nearer the apex until one does, and lay it as a thinner row
            # (user 2026-10-22, Cube.002: the row under each diagonal apex went missing).
            apex_hi = max(vs) - hi < v - min(vs)
            best = None
            for k in range(1, 12):
                w2 = w * (1 - k / 12)
                if w2 < min_piece:
                    break
                lo2, hi2 = (lo, lo + w2) if apex_hi else (hi - w2, hi)
                smp = [lo2, (lo2 + hi2) / 2, hi2]
                smp += [q for vv in vs if lo2 < vv < hi2 for q in (vv - eps, vv + eps) if lo2 <= q <= hi2]
                sp = _row_intervals(uv_loops, smp[0])
                for vv in smp[1:]:
                    sp = _intersect_intervals(sp, _row_intervals(uv_loops, vv))
                if sp:
                    best = (lo2, hi2, sp)
                    break
            if best is None:
                continue
            lo, hi, spans = best
            v, w = (lo + hi) / 2, hi - lo
            pr = replace(params, brick_height=w + params.gap)
        for poly in wall_uv:
            if not spans:
                break
            # Shrunk by a hair: wall bricks whose inner face lies exactly on the inset
            # (straight walls) only touch the strip and must not empty the row.
            cut = _strip_u_range(poly, lo - params.gap / 2 + 1e-5, hi + params.gap / 2 - 1e-5)
            if cut:
                spans = _subtract_intervals(spans, cut)
        for ua, ub in spans:
            pa = (ua * d[0] + v * nrm[0], ua * d[1] + v * nrm[1])
            pb = (ub * d[0] + v * nrm[0], ub * d[1] + v * nrm[1])
            if ub - ua < shortest - 1e-9:
                # Shorter than one standard brick: one brick cut to the span (user
                # 2026-10-22), a joint off each end, instead of leaving it bare.
                length = ub - ua - params.gap
                if length < min_piece:
                    continue
                c = ((pa[0] + pb[0]) / 2, (pa[1] + pb[1]) / 2, z)
                row = [_lay_flat(Brick(c, (d[0], d[1], 0.0), (0.0, 0.0, 1.0), length,
                                       pr.brick_height - params.gap, params.brick_depth), nrm)]
            else:
                run = Run([pa, pb], False)
                row = [_lay_flat(b, nrm) for b in
                       layout_span(run, 0.0, run.length, z, pr, rng, _stagger_offset(params, r))]
            if row:
                # Where the inner loop meets the row at a slant (an octagon's 45-degree
                # faces) the strip-wide intersection stops at the NEAR corner of the slant;
                # the end bricks grow out to the loop as pieces cut along it.
                row.sort(key=lambda b: b.center[0] * d[0] + b.center[1] * d[1])
                row[0] = _cap_end_piece(row[0], -1, uv_loops, lo, hi, d, params, wall_uv)
                row[-1] = _cap_end_piece(row[-1], 1, uv_loops, lo, hi, d, params, wall_uv)
            bricks += row
    return bricks

def _polys_touch(p, q, margin):
    """True unless the convex polygons p and q are separated by at least `margin` along some
    edge normal of either (SAT with unit normals)."""
    for poly in (p, q):
        for i in range(len(poly)):
            a, b = poly[i - 1], poly[i]
            nx, ny = b[1] - a[1], a[0] - b[0]
            ln = math.hypot(nx, ny)
            if ln < 1e-12:
                continue
            nx, ny = nx / ln, ny / ln
            pa = [x * nx + y * ny for x, y in p]
            qa = [x * nx + y * ny for x, y in q]
            if max(pa) + margin <= min(qa) or max(qa) + margin <= min(pa):
                return False
    return True

def _cap_end_piece(brick, side, uv_loops, lo, hi, d, params, wall_uv):
    """The end brick of a cap row grown out to the inner loop where the loop meets the row
    at a slant (an octagon's diagonal face): a 'wedge' whose (x, z) profile (z across the
    row, since a cap brick lies flat with its height across) is the row strip clipped by
    the chain of loop edges the row end runs into, each a half joint inside. The strip is
    taken between the two loop crossings at its edges; when those land on different loops
    (a tube's hole beside the outer ring), when the chain between them leaves the strip, or
    when a wall brick (a chord brick's sag) stands in the grown part, the plain end brick is
    kept. Square to the row nothing grows, so straight caps keep sharing the wall mesh.

    User 2026-10-22 (test.blend Cube.002): 0.4-0.8 m triangles stayed bare beside every
    diagonal face while the end bricks stopped at the near corner of the slant."""
    g = params.gap / 2
    v_lo, v_hi, vc = lo + g, hi - g, (lo + hi) / 2
    uc = brick.center[0] * d[0] + brick.center[1] * d[1]
    hl = brick.length / 2
    u_far, u_brick = uc - side * hl, uc + side * hl
    grow_min = 2 * params.gap + 0.01

    def hit(v):
        # The first loop crossing beyond the brick's end at height v.
        best = None
        for li, loop in enumerate(uv_loops):
            for i in range(len(loop)):
                a, b = loop[i], loop[(i + 1) % len(loop)]
                if (a[1] > v) != (b[1] > v):
                    u = a[0] + (v - a[1]) / (b[1] - a[1]) * (b[0] - a[0])
                    if side * (u - u_brick) > -1e-6 and (best is None or side * u < side * best[0]):
                        best = (u, li, i)
        return best

    h_lo, h_hi = hit(v_lo), hit(v_hi)
    if h_lo is None or h_hi is None or h_lo[1] != h_hi[1]:
        return brick
    if max(side * (h_lo[0] - u_brick), side * (h_hi[0] - u_brick)) < grow_min:
        return brick
    loop = uv_loops[h_lo[1]]
    n = len(loop)
    i, j = h_lo[2], h_hi[2]

    def chain(i, j):
        idx, k = [i], i
        while k != j:
            k = (k + 1) % n
            if not (lo - 1e-9 <= loop[k][1] <= hi + 1e-9) or len(idx) > n:
                return None
            idx.append(k)
        return idx

    if i == j:
        edges = [i]
    else:
        fwd, bwd = chain(i, j), chain(j, i)
        if (fwd is None) == (bwd is None):
            return brick  # neither (or both) ways stay inside the strip: not one plain chain
        edges = fwd if fwd is not None else bwd
    sgn = 1.0 if Contour(loop, True).signed_area() > 0 else -1.0
    reach = max(side * (h_lo[0] - u_brick), side * (h_hi[0] - u_brick)) + 2 * params.brick_length
    u_big = u_brick + side * reach
    poly = [(u_far, v_lo), (u_big, v_lo), (u_big, v_hi), (u_far, v_hi)]
    if brick.shape == "wedge" and brick.outline:
        # Already grown at its other end: keep that slant (every profile edge except the
        # one on the end being grown now).
        base = [(uc + x, vc + z) for x, z in brick.outline]
        bs = 1.0 if Contour(base, True).signed_area() > 0 else -1.0
        for k in range(len(base)):
            a, b = base[k], base[(k + 1) % len(base)]
            if abs(a[0] - u_brick) < 1e-6 and abs(b[0] - u_brick) < 1e-6:
                continue
            ex, ey = b[0] - a[0], b[1] - a[1]
            ln = math.hypot(ex, ey)
            if ln < 1e-12:
                continue
            nx, ny = -ey / ln * bs, ex / ln * bs
            poly = _clip_half(poly, -nx, -ny, -(nx * a[0] + ny * a[1]))
    for k in edges:
        a, b = loop[k], loop[(k + 1) % n]
        ex, ey = b[0] - a[0], b[1] - a[1]
        ln = math.hypot(ex, ey)
        if ln < 1e-12:
            continue
        nx, ny = -ey / ln * sgn, ex / ln * sgn  # into the region
        # keep n.p >= n.a + g  <=>  (-n).p <= -(n.a + g)
        poly = _clip_half(poly, -nx, -ny, -(nx * a[0] + ny * a[1] + g))
        if len(poly) < 3:
            return brick
    us = [q[0] for q in poly]
    far = max(us) if side > 0 else min(us)
    if side * (far - u_big) > -1e-6 or side * (far - u_brick) < grow_min:
        return brick  # unbounded by the chain, or nothing worth growing into
    grown = _clip_half(poly, -side, 0.0, -side * u_brick)
    if len(grown) >= 3 and any(_polys_touch(grown, w, g) for w in wall_uv):
        return brick
    pts = []
    for q in poly:
        if not pts or math.dist(q, pts[-1]) > 2 * params.gap + 1e-6:
            pts.append(q)
    if len(pts) > 2 and math.dist(pts[0], pts[-1]) <= 2 * params.gap + 1e-6:
        pts.pop()
    if len(pts) < 3:
        return brick
    us = [q[0] for q in pts]
    mu = (max(us) + min(us)) / 2
    c = (brick.center[0] + d[0] * (mu - uc), brick.center[1] + d[1] * (mu - uc), brick.center[2])
    return brick._replace(center=c, length=max(us) - min(us), shape="wedge", sides=4,
                          outline=tuple((round(u - mu, 6), round(v - vc, 6)) for u, v in pts))

def _cap_rows(inner, z_top, params, rng, walls):
    """Cap rows inside `inner`, laid along whichever outline direction covers the most.

    Since Task 11 a cap brick may not be shrunk to fit, so a band whose rows come out
    shorter than one standard brick stays empty. Trying the outline's few longest edge
    directions and keeping the best-covered layout is what lets an L-shaped or stepped cap
    still get bricks instead of falling back to a slab; a many-sided outline (a round top)
    is near isotropic, so only CAP_DIRS of them are worth trying."""
    if not inner:
        return []
    outer = max(inner, key=lambda l: Contour(l, True).signed_area())
    dirs = []
    for a, b in sorted(zip(outer, outer[1:] + outer[:1]), key=lambda e: -math.dist(*e)):
        d = _norm(b[0] - a[0], b[1] - a[1])
        if d == (0.0, 0.0):
            continue
        if d[0] < 0 or (abs(d[0]) < 1e-12 and d[1] < 0):
            d = (-d[0], -d[1])  # direction, not orientation: fold to a half plane
        if not any(abs(d[0] * e[0] + d[1] * e[1]) > 1 - 1e-9 for e in dirs):
            dirs.append(d)
        if len(dirs) >= CAP_DIRS:
            break
    best = []
    for d in dirs:
        got = _cap_rows_along(inner, z_top, params, rng, walls, d)
        if sum(b.length for b in got) > sum(b.length for b in best) + 1e-9:
            best = got
    return best

def run_bricks(run, start_ext, end_ext, course, z, params, rng, windows, frame_cuts=(), spans=None, clear=()):
    """`frame_cuts`: extra opening-shaped prisms (frame outlines) the centerline is cut at,
    so a course starts right beside a jamb/arch instead of leaving a trimmed stub.

    `spans`: run parameters this course may be bricked in at all — the MERLONS of the
    crenel band (Task 13, `merlon_spans`). None lays the whole run as before. Each span is
    laid on its own, so the merlon's end bricks absorb its leftover and the crenel gaps
    between them stay empty."""
    a, b = -start_ext, run.length + end_ext
    bands = [(a, b)] if spans is None else list(spans)
    even = spans is not None
    if clear:
        # Task 18e: a quoin column takes the corner. Its cuts only SHORTEN the spans, so
        # what is left is laid exactly like an uncut span (curved bricks stay curved), and a
        # stub too short for a brick is left to the joint.
        zb, zt = z - params.brick_height / 2, z + params.brick_height / 2
        qc = []
        for blk in clear:
            hw = window_band_halfwidth(blk, zb, zt)
            if hw is not None and hw > 1e-6:
                qc += window_cuts(run, blk, hw, a, b)
        if qc:
            bands = [(sa, sb) for ba, bb in bands for sa, sb in _subtract(ba, bb, qc)
                     if sb - sa >= params.min_len - params.gap]
    if even:
        # User 2026-10-22: "gạch phần răng cưa đều nhau không bị ảnh hưởng về bội số hay tỉ
        # lệ": every merlon is exactly `merlon_bricks` EQUAL bricks — no 1x/2x mix, no
        # grown end bricks, no half-brick stagger — whatever its width.
        lay = lambda sa, sb: _merlon_bricks(run, sa, sb, z, params)
    else:
        lay = lambda sa, sb: _span_bricks(run, sa, sb, course, z, params, rng)
    if not windows and not frame_cuts:
        return _miter_ends([brick for sa, sb in bands for brick in lay(sa, sb)],
                           run, a, b, params)
    offset = _stagger_offset(params, course)
    zb, zt = z - params.brick_height / 2, z + params.brick_height / 2
    cuts = []
    for win in tuple(windows) + tuple(frame_cuts):
        hw = window_band_halfwidth(win, zb, zt)
        if hw is not None and hw > 1e-6:
            cuts += window_cuts(run, win, hw, a, b)
    # User 2026-10-27: a sub-span a window cut is laid with CURVED bricks too, by the same
    # rule as an uncut band (`_span_bricks`) — `layout_span`'s standard chords quantise so
    # coarsely on a tight ring that a 1.72 m sub-span took no brick at all and a 5.04 m one
    # took two (r1.6 tower, z = 1.90: 2 bricks / 3.34 m of 6.76 m available, a 3.1 m bare
    # arc the dropped arch frame stones used to hide).
    # EXCEPT in a course an arched head's arc band crosses: `arch_cut_bricks` grows and cuts
    # `box` bricks only, so a curved cell there would leave the strip up to the arc bare.
    # `windows` is already snapped (`build_layout`), which is the opening that cuts.
    # The gate is per COURSE over ALL windows, not per sub-span: an arched opening anywhere in
    # the scene at this height turns the whole course back to plain chords, so another tower's
    # arch disables curved cells on this run too (review minor, round 2 — accepted; a per-span
    # gate would have to know which window's band reaches which sub-span, and the cost is a
    # coarser course on a ring that has an arch somewhere at its own height).
    arch_band = any(w.arched and w.width / 2 <= w.height
                    and w.z0 + w.height - min(w.width / 2, w.height) < zt
                    and zb < w.z0 + w.height
                    for w in windows)
    bend = _is_curved(run) and not arch_band
    bricks = []
    for ba, bb in bands:
        if not cuts:
            # Task 16: no opening's band reaches this course, so its spans are uncut.
            bricks += lay(ba, bb)
            continue
        for sa, sb in _subtract(ba, bb, cuts):
            if sb - sa < params.min_len - params.gap:
                continue  # sliver between an opening/frame cut and a corner: no brick fits
            laid = (layout_curved_span(run, sa, sb, z, params, rng,
                                       bool(params.stagger and course % 2)) if bend else None)
            bricks += laid if laid is not None else layout_span(run, sa, sb, z, params, rng, offset)
    return _miter_ends(arch_cut_bricks(trim_to_windows(bricks, windows, params), windows, params),
                       run, a, b, params)

def _miter_ends(bricks, run, a, b, params):
    """The bricks touching a mitred corner of `run` (`run.miter`, set by split_runs) cut
    along the corner's bisector: shape 'miter' with its plan outline in the brick's local
    frame (x along the tangent, y = left; the outer face is -y). At a corner of signed turn
    phi the outer face reaches h * tan(phi/2) past the centerline joint and the inner face
    stops that far short of it, h = depth / 2 (Task 16b).

    Only straight boxes are cut: an arc brick or a brick a window trimmed away from the
    corner keeps its shape."""
    ts, te = getattr(run, "miter", (0.0, 0.0))
    if not bricks or (not ts and not te):
        return bricks
    pa, pb = run.point_at(a), run.point_at(b)
    reach = params.gap + 1e-6
    # The corner is closed only if the end brick really reaches it: a lone brick sits
    # centred on its span and an end the step could not grow stops short, so the brick
    # nearest each mitred end is stretched to half a joint from it first (under one size
    # step plus a joint, never across a gap a window cut).
    slack = params.size_step + params.gap + 1e-6
    bricks = list(bricks)
    for k, p0, sign in ((ts, pa, -1), (te, pb, 1)):
        if not k:
            continue
        ends = [(math.dist((br.center[0] + sign * br.tangent[0] * br.length / 2,
                            br.center[1] + sign * br.tangent[1] * br.length / 2), p0), i)
                for i, br in enumerate(bricks) if br.shape == "box"]
        if not ends:
            continue
        d, i = min(ends)
        grow = d - params.gap / 2
        if 1e-9 < grow <= slack:
            br = bricks[i]
            t = br.tangent
            c = (br.center[0] + sign * t[0] * grow / 2, br.center[1] + sign * t[1] * grow / 2, br.center[2])
            bricks[i] = br._replace(center=c, length=br.length + grow)
    reach = params.gap / 2 + 1e-6
    out = []
    for br in bricks:
        if br.shape != "box":
            out.append(br)
            continue
        t, hl, h = br.tangent, br.length / 2, br.depth / 2
        s = (br.center[0] - t[0] * hl, br.center[1] - t[1] * hl)
        e = (br.center[0] + t[0] * hl, br.center[1] + t[1] * hl)
        ks = ts if ts and math.dist(s, pa) <= reach else 0.0
        ke = te if te and math.dist(e, pb) <= reach else 0.0
        if (not ks and not ke) or 2 * hl - h * (abs(ks) + abs(ke)) < 2 * params.gap + 0.05:
            out.append(br)
            continue
        outline = ((-hl - h * ks, -h), (hl + h * ke, -h), (hl - h * ke, h), (-hl + h * ks, h))
        out.append(br._replace(shape="miter", sides=4,
                               outline=tuple((round(x, 6), round(y, 6)) for x, y in outline)))
    return out


def _centroid(points):
    """Area centroid of a closed polygon (vertex mean if degenerate)."""
    a = cx = cy = 0.0
    for p, q in zip(points, points[1:] + points[:1]):
        w = p[0] * q[1] - q[0] * p[1]
        a += w
        cx += (p[0] + q[0]) * w
        cy += (p[1] + q[1]) * w
    if abs(a) < 1e-12:
        n = len(points)
        return (sum(p[0] for p in points) / n, sum(p[1] for p in points) / n)
    return (cx / (3 * a), cy / (3 * a))


def _bbox_side(points):
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    return max(xs) - min(xs), max(ys) - min(ys)


def _single_leaf_axis(contour, depth, gap):
    """(open centerline, leaf depth) of a closed outline thinner than two leaves laid as
    ONE leaf down its middle (user 2026-10-22, "Tường đơn"), or None when the outline is
    thick enough for two leaves (then the normal two-face layout stands).

    The outline's inset collapses at half its thickness; the leaf is twice that (capped at
    two brick depths) and its centerline is the medial line of the collapsed inset: the
    inset just before collapse is a sliver, whose two long sides' midpoints trace the axis.
    Taken as an OPEN polyline from one end of the sliver to the other, so the leaf runs
    end to end once instead of closing round a zero-width loop."""
    limit = 2 * depth + gap
    collapse = _wall_depth(contour, limit)
    # `collapse` is HALF the thickness where the two faces meet; thick enough for two full
    # leaves (a joint apart) when 2 * collapse >= 2 * depth + gap -> the normal layout.
    if 2 * collapse >= limit - 1e-6 or collapse <= 1e-6:
        return None
    sliver = offset_polyline(contour.points, True, 0.98 * collapse)
    if sliver is None or len(sliver) < 3:
        return None
    # Pair each vertex with its nearest on the far side: the mid points, ordered along the
    # sliver's long axis, are the leaf's centerline.
    n = len(sliver)
    cx = sum(x for x, _ in sliver) / n
    cy = sum(y for _, y in sliver) / n
    # Long axis = principal direction of the sliver's vertices.
    sxx = sum((x - cx) ** 2 for x, _ in sliver)
    syy = sum((y - cy) ** 2 for _, y in sliver)
    sxy = sum((x - cx) * (y - cy) for x, y in sliver)
    ang = 0.5 * math.atan2(2 * sxy, sxx - syy)
    ax, ay = math.cos(ang), math.sin(ang)
    along = sorted(((x - cx) * ax + (y - cy) * ay, (x, y)) for x, y in sliver)
    # Walk the sliver in order along its axis; average points that share an axis station.
    pts = []
    for t, (x, y) in along:
        if pts and abs(t - pts[-1][0]) < 0.25 * depth:
            tt, (px, py), k = pts[-1]
            pts[-1] = (tt, ((px * k + x) / (k + 1), (py * k + y) / (k + 1)), k + 1)
        else:
            pts.append((t, (x, y), 1))
    line = [q for _t, q, _k in pts]
    if len(line) < 2:
        return None
    # The sliver is the outline inset by (almost) the half thickness on EVERY side, so it
    # also stops that far short of the wall's two END faces. Push each end of the axis back
    # out to the outline along the axis direction, so the leaf runs end to end.
    leaf = min(2 * collapse, 2 * depth)
    out = list(line)
    for end, step in ((0, -1), (-1, 1)):
        a, b = out[end], out[end + (1 if end == 0 else -1)]
        d = _norm(a[0] - b[0], a[1] - b[1])
        if d == (0.0, 0.0):
            continue
        hits = [t for t, _s in _face_hits([Contour(list(contour.points), True)], a[0], a[1], d[0], d[1]) if t > 1e-9]
        if hits:
            t = min(hits)
            out[end] = (a[0] + d[0] * t, a[1] + d[1] * t)
    return out, leaf

def _wall_depth(contour, depth, steps=8):
    """Brick depth for one contour: `depth`, or (thin wall) the largest inset in (0, depth]
    that still leaves >= 5% of the contour's area. Open contours keep `depth`; hole contours
    offset outward, so they pass the fast path."""
    if not contour.closed:
        return depth
    area0 = abs(contour.signed_area())

    # 5% guard: a miter inset can survive offset_polyline's flip/fold checks as a sliver
    # (e.g. near-degenerate corners) long after the wall's two faces have met; requiring a
    # small but real leftover area treats such slivers as "faces met" instead.
    def ok(d):
        off = offset_polyline(contour.points, True, d)
        return off is not None and abs(Contour(off, True).signed_area()) >= 0.05 * area0

    if ok(depth):
        return depth
    lo, hi = 0.0, depth
    for _ in range(steps):
        mid = (lo + hi) / 2
        if ok(mid):
            lo = mid
        else:
            hi = mid
    if lo <= 0.0:
        return lo
    # The guard stops short of the faces meeting (d = half the thickness on a straight wall),
    # leaving a centre span on the end faces too short for a brick. When the inset itself
    # survives up to within 10% beyond the guarded value, use that collapse depth instead:
    # the two faces' bricks then meet in the middle.
    c_lo, c_hi = lo, min(depth, lo / 0.9)
    if offset_polyline(contour.points, True, c_hi) is not None:
        return lo  # not collapsing within 10%: not a plain thin wall, keep the guarded depth
    for _ in range(12):
        mid = (c_lo + c_hi) / 2
        if offset_polyline(contour.points, True, mid) is not None:
            c_lo = mid
        else:
            c_hi = mid
    return c_lo


def _is_small(contour, depth):
    """Small outer outline (a peak candidate): bbox max side < 2 * brick depth."""
    return (contour.closed and contour.signed_area() > 0
            and max(_bbox_side(contour.points)) < 2 * depth)


def _near(contours, centre, radius, depth):
    return [c for c in contours if _is_small(c, depth) and math.dist(_centroid(c.points), centre) <= radius]


def _apex_brick(contour, bottom, top, params):
    """Square apex block aligned with the contour's longest edge (a pyramid's diamond
    outline gets a block turned with its faces, not an axis-aligned one sticking out)."""
    pts = contour.points
    i = max(range(len(pts)), key=lambda i: math.dist(pts[i - 1], pts[i]))
    d = _norm(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1])
    if d == (0.0, 0.0):
        d = (1.0, 0.0)
    us = [p[0] * d[0] + p[1] * d[1] for p in pts]
    vs = [p[1] * d[0] - p[0] * d[1] for p in pts]
    side = max(params.min_len, min(max(us) - min(us), max(vs) - min(vs))) - params.gap
    cx, cy = _centroid(pts)
    return Brick((cx, cy, (bottom + top) / 2), (d[0], d[1], 0.0), (0.0, 0.0, 1.0),
                 side, top - bottom - params.gap, side)


def _nearest_outline(contours, centre):
    """Closed outer contour whose centroid is nearest `centre`, or None."""
    outers = [c for c in contours if c.closed and c.signed_area() > 0]
    return min(outers, key=lambda c: math.dist(_centroid(c.points), centre)) if outers else None


def _apex_peak(prep, contour, bottom, top, params):
    """Pointed apex block (shape 'pyramid') when the source tapers to a peak within the apex
    column [bottom, top]: its base is the source outline just above `bottom` (rectangle for a
    4-sided outline, else a regular N-gon, N = outline edges clamped to [4, 8], one edge on the
    outline's longest edge), its tip at `top`. None when the column does not taper (pillar)."""
    eps = 0.02 * (top - bottom)
    centre = _centroid(contour.points)
    low = _nearest_outline(_slice_prepared(prep, bottom + eps)[0], centre)
    if low is None:
        return None
    high = _nearest_outline(_slice_prepared(prep, top - eps)[0], centre)
    if high is not None and max(_bbox_side(high.points)) >= 0.5 * max(_bbox_side(low.points)):
        return None
    pts = low.points
    i = max(range(len(pts)), key=lambda i: math.dist(pts[i - 1], pts[i]))
    d = _norm(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1])
    if d == (0.0, 0.0):
        return None
    cx, cy = _centroid(pts)
    us = [(p[0] - cx) * d[0] + (p[1] - cy) * d[1] for p in pts]
    vs = [(p[1] - cy) * d[0] - (p[0] - cx) * d[1] for p in pts]
    sides = min(8, max(4, len(pts)))
    gap = params.gap
    if sides == 4:
        # Centre the rectangle on the outline's extents in the edge frame.
        mu, mv = (max(us) + min(us)) / 2, (max(vs) + min(vs)) / 2
        cx, cy = cx + mu * d[0] - mv * d[1], cy + mu * d[1] + mv * d[0]
        length, depth = max(us) - min(us) - gap, max(vs) - min(vs) - gap
    else:
        # Apothem = distance to the nearest edge line; the N-gon matches the outline exactly
        # when N equals its edge count, else it is inscribed in that apothem circle.
        apothem = min(abs((b[0] - a[0]) * (cy - a[1]) - (b[1] - a[1]) * (cx - a[0])) / max(math.dist(a, b), 1e-12)
                      for a, b in zip(pts, pts[1:] + pts[:1])) - gap / 2
        r = apothem / math.cos(math.pi / sides) if sides == len(pts) else apothem
        length = depth = 2 * r
    if min(length, depth) <= gap:
        return None
    return Brick((cx, cy, (bottom + top) / 2), (d[0], d[1], 0.0), (0.0, 0.0, 1.0),
                 length, top - bottom - gap, depth, "pyramid", sides)


_CUT_SHAPES = {}
"""Geometry of 'cut' bricks by digest: (verts centred on the brick, faces, loop normals).
Filled by `_cut_apex` in the same `build_layout` that emits the brick, read back by
`BrickMeshCache.shape` when the output is written. Bounded (oldest dropped) so a long live
session does not keep every tip it ever cut."""
_CUT_LIMIT = 256

def _cut_apex(verts, faces, z_cut, z_clip, centre, params):
    """The source solid above `z_cut` (and below `z_clip`, if given) as ONE brick of shape
    'cut' (user 2026-10-23, a cone with a rounded top: "phần chóp ... thành 1 viên gạch ở
    phần bo nhỏ nhất ở chóp"): the connected piece nearest `centre` in plan, floored at the
    cut, pulled gap/2 in from its faces, its floor edges bevelled like a pyramid's base. The
    rounded, pointed or domed top of the source is what the user drew; cutting it keeps it.
    None when nothing remains."""
    gap = params.gap
    bm = bmesh.new()
    try:
        vs = [bm.verts.new((float(v[0]), float(v[1]), float(v[2]))) for v in verts]
        for f in faces:
            try:
                bm.faces.new([vs[i] for i in f])
            except ValueError:
                pass
        bmesh.ops.remove_doubles(bm, verts=bm.verts[:], dist=1e-9)
        geom = bm.verts[:] + bm.edges[:] + bm.faces[:]
        bmesh.ops.bisect_plane(bm, geom=geom, plane_co=(0.0, 0.0, z_cut), plane_no=(0.0, 0.0, 1.0),
                               clear_inner=True)
        if z_clip is not None:
            geom = bm.verts[:] + bm.edges[:] + bm.faces[:]
            bmesh.ops.bisect_plane(bm, geom=geom, plane_co=(0.0, 0.0, z_clip), plane_no=(0.0, 0.0, 1.0),
                                   clear_outer=True)
        if not bm.verts:
            return None
        seen, islands = set(), []
        for v in bm.verts:
            if v in seen:
                continue
            stack, isl = [v], []
            while stack:
                x = stack.pop()
                if x in seen:
                    continue
                seen.add(x)
                isl.append(x)
                stack += [e.other_vert(x) for e in x.link_edges]
            islands.append(isl)
        plan = lambda isl: (sum(v.co.x for v in isl) / len(isl), sum(v.co.y for v in isl) / len(isl))
        keep = min(islands, key=lambda isl: math.dist(plan(isl), centre))
        drop = [v for isl in islands if isl is not keep for v in isl]
        if drop:
            bmesh.ops.delete(bm, geom=drop, context='VERTS')
        bmesh.ops.holes_fill(bm, edges=bm.edges[:], sides=0)
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        # The source arrived triangulated (`read_source_mesh`) and the floor came back as a
        # fan: dissolve every edge between coplanar faces, so a flat facet is one n-gon
        # again and the floor one polygon (user 2026-10-23: "nó đang tạo ra các lưới thừa").
        bmesh.ops.dissolve_limit(bm, angle_limit=math.radians(0.5), use_dissolve_boundaries=False,
                                 verts=bm.verts[:], edges=bm.edges[:], delimit={'NORMAL'})
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        bm.normal_update()
        # The joint: every vertex moves gap/2 in along the horizontal part of its normal (a
        # pointed tip or a dome's pole has none and stays).
        for v in bm.verts:
            n = Vector((v.normal.x, v.normal.y, 0.0))
            if n.length > 1e-9:
                v.co -= n.normalized() * (gap / 2)
        ring = [e for e in bm.edges if all(abs(v.co.z - z_cut) < 1e-6 for v in e.verts)]
        xs = [v.co.x for v in bm.verts]
        ys = [v.co.y for v in bm.verts]
        zs = [v.co.z for v in bm.verts]
        size = min(max(xs) - min(xs), max(ys) - min(ys), max(zs) - min(zs))
        width = min(params.bevel_width, 0.2 * size)
        if width > 1e-6 and params.bevel_segments > 0 and ring:
            bmesh.ops.bevel(bm, geom=list({v for e in ring for v in e.verts}) + ring, offset=width,
                            offset_type='OFFSET', segments=params.bevel_segments, profile=0.5,
                            affect='EDGES', clamp_overlap=True)
        if len(bm.faces) < 4:
            return None
        bm.normal_update()
        bm.verts.index_update()
        out_verts = np.array([v.co[:] for v in bm.verts], dtype=np.float64)
        out_faces = [tuple(v.index for v in f.verts) for f in bm.faces]
        # The source's own surface shades smooth (a dome, a rounded rim); the floor flat.
        normals = [(f.normal[:] if f.normal.z < -0.99 else v.normal[:]) for f in bm.faces for v in f.verts]
    finally:
        bm.free()
    normals = np.array(normals, dtype=np.float64).reshape(-1, 3)
    lo, hi = out_verts.min(axis=0), out_verts.max(axis=0)
    c = (lo + hi) / 2
    out_verts = out_verts - c
    digest = hashlib.sha1(np.round(out_verts, 5).tobytes() + repr(out_faces).encode("utf-8")).hexdigest()
    if digest not in _CUT_SHAPES:
        while len(_CUT_SHAPES) >= _CUT_LIMIT:
            del _CUT_SHAPES[next(iter(_CUT_SHAPES))]
        _CUT_SHAPES[digest] = (out_verts, out_faces, normals)
    return Brick((float(c[0]), float(c[1]), float(c[2])), (1.0, 0.0, 0.0), (0.0, 0.0, 1.0),
                 float(hi[0] - lo[0]), float(hi[2] - lo[2]), float(hi[1] - lo[1]), "cut", 0, (digest,))

def _cut_columns(courses, base, z_lo, zmid, params):
    """({(course, contour index)} of the apex COLUMNS (user 2026-10-23, `apex_bricks`),
    [(z_cut, z_clip, centre)] = the cut to make for each). A column is a run of outer
    contours, one per course, whose centreline holds fewer than `apex_bricks` bricks, from a
    TOP (no outer contour above it) down to the last such course; a column reaching the
    bottom course is the whole block (a pillar), not a tip, and is left to the courses."""
    want = int(params.apex_bricks)
    skip, cuts = set(), []
    if want <= 0 or len(courses) < 2:
        return skip, cuts
    info, holes = [], []
    for k, contours in enumerate(courses):
        q = base[k]
        min_depth = min(0.05, q.brick_depth / 4)
        row = []
        for ci, c in enumerate(contours):
            if not (c.closed and c.signed_area() > 0):
                continue
            d = _wall_depth(c, q.brick_depth)
            line = offset_polyline(c.points, True, d / 2) if d >= min_depth else None
            n = Contour(line, True).perimeter() / q.brick_length if line else 0.0
            sx, sy = _bbox_side(c.points)
            row.append((ci, _centroid(c.points), max(math.hypot(sx, sy) / 2, q.brick_depth), n < want))
        info.append(row)
        holes.append([_centroid(c.points) for c in contours if c.closed and c.signed_area() < 0])

    def near(k, centre, radius):
        cands = [r for r in info[k] if math.dist(r[1], centre) <= radius]
        return min(cands, key=lambda r: math.dist(r[1], centre)) if cands else None

    for k in range(len(courses) - 1, 0, -1):
        for ci, centre, radius, small in info[k]:
            if not small or (k, ci) in skip:
                continue
            if k + 1 < len(courses) and near(k + 1, centre, radius) is not None:
                continue   # not a top: the course above continues this contour
            chain = [(k, ci, centre, radius)]
            j = k
            while j > 0:
                below = near(j - 1, chain[-1][2], chain[-1][3])
                if below is None or not below[3]:
                    break
                chain.append((j - 1,) + below[:3])
                j -= 1
            k0 = chain[-1][0]
            if k0 == 0:
                continue
            if any(math.dist(h, chain[-1][2]) <= chain[-1][3] for kk in range(k0, k + 1) for h in holes[kk]):
                continue
            skip.update((kk, cc) for kk, cc, _c, _r in chain)
            cuts.append((z_lo[k0] + params.gap / 2, zmid[k + 1] if k + 1 < len(courses) else None, chain[-1][2]))
    return skip, cuts

QUOIN_MIN_TURN = math.radians(60.0 - 0.5)
QUOIN_MAX_TURN = math.radians(120.0 + 0.5)
"""Task 18 (user 2026-10-21): only CONVEX corners turning 60..120 degrees get a quoin column
(a box's 90, a hexagon's 60, an L's outer corners). Half a degree of slack so a hexagon's
float 60 is not lost to rounding."""

QUOIN_FLAT = math.radians(1.0)
"""A quoin leg runs along its face only while the outline stays straight: a vertex turning more
than this starts a bend (a rounded edge), where the leg stops (Task 18c)."""

def _qround(x, step):
    """`x` rounded to the nearest whole `size_step` (at least one step), so equal quoins share
    one mesh like the wall's end bricks do."""
    return max(step, round(x / step) * step)

def _quoin_layers(z0, z1, height):
    """(bottom, top) of each quoin layer from z0 to z1. Quoins stack in their OWN layers, not
    the wall's courses (Task 18): whole `height` layers, and a remainder under half a layer is
    merged into the top layer (a taller block) rather than left as a sliver."""
    total = z1 - z0
    if total <= 1e-6 or height <= 1e-6:
        return []
    n = int(total / height + 1e-6)
    rem = total - n * height
    hs = [height] * n
    if rem > 1e-6:
        if n and rem < height / 2 - 1e-9:
            hs[-1] += rem
        else:
            hs.append(rem)
    out, z = [], z0
    for h in hs:
        out.append((z, z + h))
        z += h
    out[-1] = (out[-1][0], z1)
    return out

def _quoin_corners(contours, curve_angle):
    """[(P, u, v, phi, limit_in, limit_out)] for every convex 60..120 degree corner of the
    closed OUTER outlines in `contours`: corner point, unit incoming / outgoing edge
    directions, turn, and the most each leg may reach along its face.

    Task 18c (user 2026-10-21): the corners are read from the source outline itself, and a
    leg may only run along the STRAIGHT face next to the corner — it stops where the face
    starts to bend (a vertex turning more than a few degrees, the start of a rounded edge),
    so a quoin never wraps round a curve. Two quoins on one face meet at most half way."""
    out = []
    for c in contours:
        if not c.closed or len(c.points) < 3 or c.signed_area() <= 0:
            continue
        pts = [(float(x), float(y)) for x, y in c.points]
        n = len(pts)
        turns = [_turn(pts, i) for i in range(n)]
        hit = [QUOIN_MIN_TURN <= t <= QUOIN_MAX_TURN for t in turns]
        bend = [abs(t) > curve_angle for t in turns]

        def reach(i, step):
            """Straight length from corner i along the face in direction `step`, and whether
            that face ends at another quoin corner."""
            total, j = 0.0, i
            for _ in range(n):
                k = (j + step) % n
                total += math.dist(pts[j], pts[k])
                if bend[k]:
                    return total, hit[k]
                j = k
            return total, False

        for i in range(n):
            if not hit[i]:
                continue
            p, a, b = pts[i], pts[i - 1], pts[(i + 1) % n]
            ra, qa = reach(i, -1)
            rb, qb = reach(i, 1)
            out.append((p, _norm(p[0] - a[0], p[1] - a[1]), _norm(b[0] - p[0], b[1] - p[1]),
                        turns[i], ra / 2 if qa else ra, rb / 2 if qb else rb))
    return out

def _cross_lines(p, d, q, e):
    """Intersection of the lines p + s*d and q + r*e (None when parallel)."""
    den = d[0] * e[1] - d[1] * e[0]
    if abs(den) < 1e-12:
        return None
    s_ = ((q[0] - p[0]) * e[1] - (q[1] - p[1]) * e[0]) / den
    return (p[0] + s_ * d[0], p[1] + s_ * d[1])

def _ring_area(pts):
    """Signed area of a closed plan ring (CCW positive)."""
    return sum(pts[i - 1][0] * pts[i][1] - pts[i][0] * pts[i - 1][1] for i in range(len(pts))) / 2

def _face_moves(contours_at, o, dirs, zm, z, expected=None, depth=None):
    """Per direction in `dirs`, how far that face has moved IN at height `z` against height
    `zm`, each a ray cast from `o`: `_end_hit(zm) - _end_hit(z)`, or 0.0 when either ray
    misses the outline. Shared by `_quoin_piece` and `_leaf_end_piece`'s `moved` (Task 25
    minor, user 2026-10-27: same mid-vs-z `_end_hit` pattern, same `eps` at the call site).

    With `expected` (and `depth`) given, a face whose mid-height hit lands further than
    25% of `depth` from its expected distance (a ray left over a neighbouring edge, e.g. a
    short chamfer, instead of the face it was meant to measure) is treated as unmoved, the
    same sanity `fit_slopes` and `_lean_path_ends` apply to their own mid-height hit."""
    out_ = []
    for i, d in enumerate(dirs):
        dm = _end_hit(contours_at(zm), o, d)
        if dm is None or (expected is not None and abs(dm - expected[i]) > 0.25 * depth):
            out_.append(0.0)
            continue
        dz = _end_hit(contours_at(z), o, d)
        out_.append(0.0 if dz is None else dm - dz)
    return tuple(out_)

def _quoin_piece(corner, la, lb, ta, tb, zb, zt, params, depth, contours_at=None):
    """(block, wall cuts, trim box) of one quoin layer at `corner`, or None.

    Task 18e (user 2026-10-22: the blocks overlapped the wall): a layer is ONE block (Task
    18d) that REPLACES the wall at the corner. It shows `la` on the incoming face and `lb` on
    the outgoing one, both measured on the wall face from the corner, so the seam where it
    meets the wall bricks sits exactly there; its outer faces stand `ta` / `tb` out of the
    two faces. Its back is where the two seams' perpendiculars meet: with the header side
    equal to the wall depth (see `_legs`) the block fills the wall's corner exactly and never
    pokes into the inside.

    The wall courses are cut at each seam (one joint clear) instead of trimmed, so the
    bricks beside the column are whole bricks that start a joint from it.

    Task 25 (user 2026-10-27, "cạnh góc đang không ôm mặt vát"): with `contours_at` and
    `slope_fit` on, a layer on a BATTERED block leans its two outer faces with the face,
    measured at the layer's own bottom and top like `fit_slopes` does, so the block keeps
    `ta` / `tb` proud all the way up instead of standing square and poking out at the
    bottom. The seams against the wall bricks and the back (the wall's inner faces) stay
    vertical, as the leaning wall bricks beside them do."""
    p, u, v, phi, _la, _lb = corner
    gap = params.gap
    if max(ta, tb) <= 1e-6 or min(la, lb) <= params.size_step / 2:
        return None
    na, nb = (-u[1], u[0]), (-v[1], v[0])
    ea = (p[0] - la * u[0], p[1] - la * u[1])          # seam on the incoming face
    eb = (p[0] + lb * v[0], p[1] + lb * v[1])          # seam on the outgoing face
    # Inner corner of the wall: where its two inner faces (`depth` in) meet.
    c_in = _cross_lines((p[0] + depth * na[0], p[1] + depth * na[1]), u,
                        (p[0] + depth * nb[0], p[1] + depth * nb[1]), v)
    if c_in is None:
        return None

    def ring(dy_a, dy_b):
        """Plan points of the layer with its outer faces moved IN by dy_a / dy_b (Task 25).

        The two SEAM points slide along their own face with it (their outer end follows the
        face, so the seam line itself stays put and vertical); the outer corner is where the
        two moved faces meet; the back points never move."""
        qa, qb = ta - dy_a, tb - dy_b
        qc = _cross_lines((p[0] - qa * na[0], p[1] - qa * na[1]), u,
                          (p[0] - qb * nb[0], p[1] - qb * nb[1]), v)
        if qc is None:
            return None
        return [(ea[0] - qa * na[0], ea[1] - qa * na[1]), qc,
                (eb[0] - qb * nb[0], eb[1] - qb * nb[1]),
                (eb[0] + depth * nb[0], eb[1] + depth * nb[1]), c_in,
                (ea[0] + depth * na[0], ea[1] + depth * na[1])]

    def moved(z):
        """(dy_a, dy_b): how far the two faces have moved IN at height z against the layer's
        middle, measured from a point inside the wall like `fit_slopes` does."""
        if contours_at is None or not params.slope_fit:
            return 0.0, 0.0
        o = (p[0] + (na[0] + nb[0]) * depth / 2, p[1] + (na[1] + nb[1]) * depth / 2)
        dirs = ((-na[0], -na[1]), (-nb[0], -nb[1]))
        # Task 25 minor (user 2026-10-27): the same 25%-of-depth sanity `fit_slopes` and
        # `_lean_path_ends` apply to their own mid-height hit. `o` sits at (na+nb)*depth/2
        # from the corner `p`, so by symmetry both faces are expected the same distance away:
        # depth/2 * (1 + na.nb) = depth/2 * (1 + cos phi).
        expect = depth / 2 * (1 + na[0] * nb[0] + na[1] * nb[1])
        return _face_moves(contours_at, o, dirs, (zb + zt) / 2, z, (expect, expect), depth)

    eps = 1e-4
    lo_dy, hi_dy = moved(zb + eps), moved(zt - eps)
    battered = any(abs(d) > 1e-5 for d in lo_dy + hi_dy)

    def filtered(pts):
        """(points, their indices in the full 6-point ring) after dropping repeats and points
        on a straight edge (a square corner's back is just one corner point)."""
        keep = [i for i, w in enumerate(pts) if math.dist(w, pts[i - 1]) > 1e-6]
        kept = [pts[i] for i in keep]
        idx = [i for i, w in enumerate(kept)
               if abs((w[0] - kept[i - 1][0]) * (kept[(i + 1) % len(kept)][1] - w[1])
                      - (w[1] - kept[i - 1][1]) * (kept[(i + 1) % len(kept)][0] - w[0])) > 1e-9]
        return [kept[i] for i in idx], [keep[i] for i in idx]

    def to_local(pts):
        return [((w[0] - p[0]) * u[0] + (w[1] - p[1]) * u[1],
                 (w[0] - p[0]) * na[0] + (w[1] - p[1]) * na[1]) for w in pts]

    # The back follows the wall's inner faces from each seam to the inner corner, so the
    # block fills the wall's corner and never reaches into the inside, at any turn.
    plain = ring(0.0, 0.0)
    if plain is None:
        return None
    world = ring(*lo_dy) if battered else plain
    if world is None:
        return None
    world, kept = filtered(world)
    local, local_hi = to_local(world), None
    if battered:
        # The TOP ring takes the SAME kept indices, so both rings have the same point count
        # and order (what a 2N 'plan' outline means). A top ring that would degenerate (two
        # points meeting, or the block turned inside out because a face crossed its seam)
        # falls back to the plain vertical block for this layer.
        full_hi = ring(*hi_dy)
        world_hi = None if full_hi is None else [full_hi[i] for i in kept]
        # Task 25 minor (user 2026-10-27): the bevel clamps to 0.49 x the shortest edge of
        # BOTH rings, so a top edge shorter than a joint (gap) silently un-bevels the layer
        # and gives it its own mesh key; raise the degenerate threshold to match, so a top
        # edge that short falls back to the vertical block instead.
        degenerate_edge = max(1e-6, 2 * params.gap)
        if (world_hi is None
                or any(math.dist(w, world_hi[i - 1]) < degenerate_edge for i, w in enumerate(world_hi))
                or _ring_area(world_hi) * _ring_area(world) <= 0):
            battered = False
            world, _k = filtered(plain)
            local = to_local(world)
        else:
            local_hi = to_local(world_hi)
    rings = [local] if local_hi is None else [local, local_hi]
    # Centred on its plan bounding box, so `center +- length/2, depth/2` (what footprints, the
    # trim box and the mesh cache read) is the block's true extent. With two rings the box
    # spans BOTH, so it still contains the whole leaning block.
    xs = [x for r in rings for x, _ in r]
    ys = [y for r in rings for _, y in r]
    mx, my = (max(xs) + min(xs)) / 2, (max(ys) + min(ys)) / 2
    zc = (zb + zt) / 2
    outline = tuple((round(x - mx, 6), round(y - my, 6)) for r in rings for x, y in r)
    block = Brick((p[0] + mx * u[0] + my * na[0], p[1] + mx * u[1] + my * na[1], zc),
                  (u[0], u[1], 0.0), (0.0, 0.0, 1.0), max(xs) - min(xs), zt - zb - gap,
                  max(ys) - min(ys), "plan", len(local), outline)
    cuts = []
    for axis, inward, leg, t_own, t_other in (((-u[0], -u[1]), na, la, ta, tb), (v, nb, lb, tb, ta)):
        # Along the face from past the outer corner to one joint beyond the seam; across
        # from the block's outer face through the whole wall.
        lo, hi = -(t_other + depth + gap), leg + gap / 2
        across_lo, across_hi = -(t_own + gap), depth + gap
        am, cm = (lo + hi) / 2, (across_lo + across_hi) / 2
        c = (p[0] + axis[0] * am + inward[0] * cm, p[1] + axis[1] * am + inward[1] * cm)
        cuts.append(Window(c[0], c[1], zb, axis[0], axis[1], hi - lo, zt - zb,
                           across_hi - across_lo, False, False))
    return block, cuts, _box_of(block)

def _leaf_end_piece(end, d_out, leaf, width, proud, zb, zt, params, contours_at=None):
    """(block, wall cuts, trim box) of one quoin layer at an END of a single leaf (Tường đơn,
    user 2026-10-22): a block `width` long along the leaf, as deep as the leaf plus `proud`
    out of both long faces, standing `proud` past the end face. The leaf's courses are cut
    one joint short of it.

    Task 25.3 (user 2026-10-27): with `contours_at` and `slope_fit` on, a layer on a BATTERED
    block becomes a 'frustum' whose three OUTER faces -- the two long ones (local -+y) and the
    END face (local -x: `t` points INWARD from the end) -- follow the source face at the
    layer's own bottom and top, measured like `fit_slopes` does, so the block keeps `proud` out
    of all three all the way up instead of standing square and poking out at the bottom. The
    inner (seam) face against the leaf's bricks stays vertical, as the leaf's own leaning
    bricks keep their joints vertical."""
    gap = params.gap
    if width <= params.size_step / 2:
        return None
    t = (-d_out[0], -d_out[1])                       # along the leaf, inward
    n = (-t[1], t[0])
    c = (end[0] + t[0] * (width / 2 - proud), end[1] + t[1] * (width / 2 - proud), (zb + zt) / 2)
    depth = leaf + 2 * proud

    def moved(z):
        """(end, -n, +n): how far each outer face has moved IN at height z against the layer's
        middle, measured along its own normal from the block's centre (which lies on the leaf's
        axis, inside the wall)."""
        if contours_at is None or not params.slope_fit:
            return 0.0, 0.0, 0.0
        o = (c[0], c[1])
        return _face_moves(contours_at, o, (d_out, (-n[0], -n[1]), n), (zb + zt) / 2, z)

    def ring(deltas):
        """Plan points of the layer at one height, CCW in the block's local frame (x along `t`,
        y along `n`) like `fit_slopes`' box base: end, end+, seam+, seam-."""
        dx_end, dy_minus, dy_plus = deltas
        return [(-width / 2 + dx_end, -depth / 2 + dy_minus),
                (width / 2, -depth / 2 + dy_minus),
                (width / 2, depth / 2 - dy_plus),
                (-width / 2 + dx_end, depth / 2 - dy_plus)]

    eps = 1e-4
    lo_d, hi_d = moved(zb + eps), moved(zt - eps)
    battered = any(abs(v) > 1e-5 for v in lo_d + hi_d)
    # A ring the move would collapse (a face crossing the seam, or the two long faces meeting)
    # falls back to the plain vertical block for this layer, as a quoin layer does.
    if battered and min(min(width - d[0], depth - d[1] - d[2]) for d in (lo_d, hi_d)) <= max(2 * gap, 0.05):
        battered = False
    base = (t[0], t[1], 0.0), (0.0, 0.0, 1.0), width, zt - zb - gap, depth
    if battered:
        # Task 25 minor (user 2026-10-27): kept at the NOMINAL (mid-ring) box, unlike
        # `_quoin_piece`'s union of both rings -- a battered wall is wider at the bottom, so
        # the bottom ring only bulges into air (outward past the two outer faces and the
        # end, never past the inner seam), which makes the nominal box still safe for
        # `_box_of` / the cut `Window`.
        block = Brick(c, *base, "frustum", 8,
                      tuple((round(x, 6), round(y, 6)) for x, y in ring(lo_d) + ring(hi_d)))
    else:
        block = Brick(c, *base)
    cut = Window(c[0] + t[0] * (gap / 4), c[1] + t[1] * (gap / 4), zb, t[0], t[1],
                 width + gap / 2, zt - zb, depth + 2 * gap, False, False)
    return block, [cut], _box_of(block)

def _legs(width, j, params, header):
    """(side on the incoming face, side on the outgoing face) of layer j.

    Task 18e: a real quoin is laid as stretcher and header — the long side `width` on one
    face and the `header` on the other: depth * tan(turn / 2), the face length the wall's
    corner occupies, so the block closes the corner exactly (the wall depth on a square
    corner). With `quoin_alternate` they swap faces every layer (the alternating seam of a
    quoined corner); without it the long side stays on the incoming face, so both seams run
    straight."""
    width = max(width, header)
    if params.quoin_alternate and j % 2:
        return header, width
    return width, header

def _prouds(j, params):
    """(out of the incoming face, out of the outgoing face) of layer j: `quoin_proud`, and on
    every other layer `quoin_proud_step` more out of BOTH faces (Task 18e; user 2026-10-22
    "nhô ra đều 2 hướng": a big block, a small block, a big block... while the seam against
    the wall stays straight)."""
    t = params.quoin_proud + (params.quoin_proud_step if j % 2 else 0.0)
    return t, t

def corner_quoins(contours_at, z0, z1, params, depth):
    """Task 18 (user 2026-10-21, "Cạnh góc"): castle-tower corner quoins like the hand-made
    PurpleWatchtouwer sample in test.blend — a column of single blocks set on every convex
    60..120 degree corner of the source outline, from z0 (wall bottom) to z1 (wall
    top: the crenel floor under a band, whose merlons stay as they are). `contours_at(z)`
    slices the source: each layer reads its corners at its OWN mid-height, so a tapering
    block's quoins follow its faces.

    Rules:
    - Every layer is `quoin_height` tall (a remainder under half a layer joins the top one).
    - Width = `quoin_width` rounded to `size_step`, so equal blocks share a mesh. (The random
      width and taper of Task 18b were removed again, user 2026-10-22.)
    - Task 18e: each layer is stretcher + header (`_legs`) and replaces the wall at the
      corner; `quoin_proud_step` alternates how far it sticks out (`_prouds`).
    Returns (quoin bricks, wall cuts, trim boxes)."""
    if not params.quoins:
        return [], [], []
    step = params.size_step
    layers = _quoin_layers(z0, z1, params.quoin_height)
    n = len(layers)
    bricks, cuts, boxes, memo = [], [], [], {}
    # Task 25: every corner of a layer measures the batter at the SAME three heights, so the
    # slices are memoized like `fit_slopes` does -- without this a tapering block re-sliced
    # the source once per corner per height (~29 ms of a 48 ms hex rebuild).
    slices = {}

    def sliced(z):
        key = round(z, 6)
        if key not in slices:
            slices[key] = contours_at(key)
        return slices[key]

    for j, (zb, zt) in enumerate(layers):
        zm = round((zb + zt) / 2, 6)
        if zm not in memo:
            contours = sliced(zm)
            corners = _quoin_corners(contours, QUOIN_FLAT)
            ends = []
            if params.single_leaf:
                # Tường đơn (user 2026-10-22: "có tới 4 cạnh góc, đúng thì chỉ cần 2"): a
                # thin outline laid as one leaf has two ENDS, not four corners. Each end gets
                # one block as deep as the leaf; the leaf's own corners are dropped.
                for c in contours:
                    if not (c.closed and c.signed_area() > 0):
                        continue
                    axis = _single_leaf_axis(c, depth, params.gap)
                    if axis is None:
                        continue
                    line, leaf = axis
                    corners = [q for q in corners
                               if not any(_point_in_loop(q[0], c.points) or
                                          min(_seg_dist(q[0], c.points[i - 1], c.points[i]) for i in range(len(c.points))) < 1e-6
                                          for _ in (0,))]
                    for end, nxt in ((line[0], line[1]), (line[-1], line[-2])):
                        ends.append((end, _norm(end[0] - nxt[0], end[1] - nxt[1]), leaf))
            memo[zm] = (corners, ends)
        corners, ends = memo[zm]
        for end, d_out, leaf in ends:
            width = _qround(params.quoin_width, step)
            ta, _tb = _prouds(j, params)
            piece = _leaf_end_piece(end, d_out, leaf, width, ta, zb, zt, params, sliced)
            if piece is not None:
                bricks.append(piece[0])
                cuts += piece[1]
                boxes.append(piece[2])
        for corner in corners:
            width = _qround(params.quoin_width, step)
            la, lb = _legs(width, j, params, depth * math.tan(corner[3] / 2))
            ta, tb = _prouds(j, params)
            lim_a = math.floor((corner[4] - params.gap / 2) / step + 1e-9) * step
            lim_b = math.floor((corner[5] - params.gap / 2) / step + 1e-9) * step
            piece = _quoin_piece(corner, min(la, lim_a), min(lb, lim_b), ta, tb, zb, zt, params,
                                 depth, sliced)
            if piece is not None:
                bricks.append(piece[0])
                cuts += piece[1]
                boxes.append(piece[2])
    return bricks, cuts, boxes

CAP_MIN_PIECE = 0.10
"""Smallest cut-to-fit cap piece, as a share of `brick_length` (user 2026-10-22, lowered from
1/4 to 1/10 the same day): a narrowed edge row across, or a short span along a row, below
this is left bare (a core too narrow keeps its slab or stays open, as before)."""

SOLID_MIN_RING = 0.05
"""Thinnest last ring the solid fill lays (m), so `solid_fill` shows at every slider step."""

def _solid_reach(contours, steps=16, memo=None):
    """{contour index: deepest inset (m) at which that contour's region still survives} for
    the closed contours of one course: an outer outline together with the holes it owns, so a
    tube's outer and inner faces both fill toward the middle of the ring and stop where they
    meet (Task 19). `memo` caches by rounded geometry (prism courses repeat)."""
    outers = [i for i, c in enumerate(contours) if c.closed and c.signed_area() > 0]
    holes = [i for i, c in enumerate(contours) if c.closed and c.signed_area() < 0]
    owner = _group_holes([contours[i].points for i in outers], [contours[i].points for i in holes])
    out = {}
    for j, oi in enumerate(outers):
        mine = [holes[h] for h, w in enumerate(owner) if w == j]
        key = tuple(tuple((round(x, 6), round(y, 6)) for x, y in contours[i].points) for i in [oi] + mine)
        if memo is not None and key in memo:
            d = memo[key]
        else:
            outer = contours[oi].points
            hole_pts = [contours[i].points for i in mine]
            area0 = abs(contours[oi].signed_area())

            def ok(d):
                # User 2026-10-26: pruned, so a chamfer that vanishes does not end the fill.
                reg = _inset_region(outer, hole_pts, d, prune=True)
                return reg is not None and abs(Contour(reg[0], True).signed_area()) >= 1e-3 * area0

            lo, hi = 0.0, 0.5 * max(_bbox_side(outer))
            for _ in range(steps):
                mid = (lo + hi) / 2
                if ok(mid):
                    lo = mid
                else:
                    hi = mid
            d = lo
            if memo is not None:
                memo[key] = d
        for i in [oi] + mine:
            out[i] = d
    return out

def solid_rings(contour, wall_depth, reach, k, z, params, rng_keys, windows, cuts, outside=()):
    """Task 19 (user 2026-10-21, "Đặc": "xếp gạch ở bên trong kín và có lựa chọn nó kín đến
    đâu, khoảng kín đó tính theo khoảng cách từ tường bao bên ngoài đến tâm"): the concentric
    rings of bricks laid INSIDE the wall ring of one contour.

    Ring i (i = 1, 2, ...) starts one joint inside ring i - 1 (the wall ring is ring 0, depth
    `wall_depth`) and is a full `brick_depth` deep; its centerline is the contour offset
    toward the solid by the ring's middle, exactly as the wall's is, so straight runs, corners,
    mitres and curved (arc / path) runs all come from the same split_runs / run_bricks code.
    A hole contour offsets toward the solid too, so a tube fills from both faces.

    `solid_fill` (0..1) is the share of the band between the wall ring and the core (where
    the faces meet, `reach`, see `_solid_reach`) that is filled. By default it grows from the
    wall ring INWARD; with `solid_from_core` (user 2026-10-22: "fill từ lõi ra ngoài", kept
    as an option) it grows from the CORE outward. The ring at the growing edge is THINNED to
    whatever is left (down to `SOLID_MIN_RING`), so every step of the slider shows. (The
    first version took a depth in metres from the face, 0 meaning "to the centre", and read
    as an on/off switch.)
    Each ring flips the stagger (course + i parity) so its head joints do not line up with
    the ring beside it. Openings cut every ring, so a window stays see-through."""
    depth, gap = params.brick_depth, params.gap
    # User 2026-10-22 "fill từ lõi ra ngoài": the filled band grows from the CORE outward.
    # `core` is where the faces meet (minus half a joint), `start` the wall ring's inner face
    # plus a joint; `solid_fill` is the share of that band filled, measured from the core.
    core, start = reach - gap / 2, wall_depth + gap
    share = max(0.0, min(1.0, params.solid_fill)) * (core - start)
    outward = params.solid_from_core
    # Each ring is the band [lo, lo + d] measured from the face. Outside-in: from the wall
    # ring toward `start + share`, the innermost ring thinned. Core-out: from the core toward
    # `core - share`, the outermost ring thinned.
    out, edge, i = [], (core if outward else start), 1
    end = core - share if outward else start + share
    while True:
        d = min(depth, (edge - end) if outward else (end - edge))
        if d < max(SOLID_MIN_RING, 2 * gap) - 1e-9:
            break
        lo = edge - d if outward else edge
        # User 2026-10-26 (test.blend Cylinder.002): a face that collapses deeper in (a
        # chamfer) is dropped so the fill carries on to the core, and so is one too short
        # at this ring's centreline for the two mitred bricks either side of it to meet.
        line = offset_polyline(contour.points, contour.closed, lo + d / 2, prune=True, min_edge=d)
        if line is not None and len(line) >= 3:
            pk = params if d == depth else replace(params, brick_depth=d)
            rng = course_rng(params, *rng_keys, "solid", i)
            ring = []
            for run, a, b in split_runs(line, contour.closed, pk.corner_angle, k + i, d):
                ring += run_bricks(run, a, b, k + i, z, pk, rng, windows, cuts)
            # A ring that dropped a chamfer turns ONE sharp corner where the ring outside it
            # still turns two; the point of its corner brick reaches into that ring's chamfer
            # brick (0.12 m on test.blend Cylinder.002). Its mitred corner bricks are pulled
            # back off the bricks it stands beside: the wall ring (`outside`) and every ring
            # laid so far.
            if outside or out:
                ring = _clear_mitres(ring, list(outside) + out, gap)
            out += ring
        elif not outward:
            break
        edge = edge - (d + gap) if outward else edge + d + gap
        i += 1
    return out

def _plan_poly(b):
    """Plan outline of a box / miter brick (world), for the solid rings' corner check."""
    t = b.tangent
    n = (-t[1], t[0])
    if b.shape == "miter" and b.outline:
        local = [(float(x), float(y)) for x, y in b.outline]
    else:
        hl, hd = b.length / 2, b.depth / 2
        local = [(-hl, -hd), (hl, -hd), (hl, hd), (-hl, hd)]
    return [(b.center[0] + x * t[0] + y * n[0], b.center[1] + x * t[1] + y * n[1]) for x, y in local]

def _poly_penetration(p, q):
    """SAT penetration depth of two convex plan polygons (0 when apart)."""
    best = math.inf
    for poly in (p, q):
        for i in range(len(poly)):
            a, c = poly[i - 1], poly[i]
            ax, ay = c[1] - a[1], a[0] - c[0]
            ln = math.hypot(ax, ay)
            if ln < 1e-12:
                continue
            ax, ay = ax / ln, ay / ln
            pa = [x * ax + y * ay for x, y in p]
            qa = [x * ax + y * ay for x, y in q]
            best = min(best, min(max(pa), max(qa)) - max(min(pa), min(qa)))
    return max(best, 0.0) if best < math.inf else 0.0

def _clear_mitres(ring, others, gap):
    """Solid-ring bricks (user 2026-10-26) whose plan overlaps a brick of `others` (same
    course) shortened from the end that overlaps, in steps of a joint, until they clear it;
    one that cannot clear while keeping half its length is dropped. Only the corner bricks
    of a ring that dropped a chamfer ever touch the ring outside them."""
    # Straight bricks only, both sides: a bent (arc / path) brick's chord rectangle is not
    # its plan, and curved rings never drop a chamfer anyway.
    flat = ("box", "miter")
    near = [o for o in others if abs(o.up[2]) > 0.5 and o.shape in flat]
    out = []
    for b in ring:
        if b.shape not in flat:
            out.append(b)
            continue
        hits = [o for o in near if abs(o.center[2] - b.center[2]) < 1e-6
                and math.dist(o.center[:2], b.center[:2]) < (o.length + b.length) / 2 + o.depth + b.depth]
        poly = _plan_poly(b)
        bad = [o for o in hits if _poly_penetration(poly, _plan_poly(o)) > 1e-6]
        if not bad:
            out.append(b)
            continue
        t = b.tangent
        # The end nearer the overlap is the one to pull back.
        mx = sum(o.center[0] for o in bad) / len(bad)
        my = sum(o.center[1] for o in bad) / len(bad)
        sign = 1 if (mx - b.center[0]) * t[0] + (my - b.center[1]) * t[1] > 0 else -1
        cur, cut = b, 0.0
        while cut < b.length / 2:
            cut += max(gap, 0.01)
            ln = b.length - cut
            c = (b.center[0] - sign * t[0] * cut / 2, b.center[1] - sign * t[1] * cut / 2, b.center[2])
            cur = b._replace(center=c, length=ln)
            if b.shape == "miter" and b.outline:
                # Shift the plan outline with the centre, clip the pulled-back end to the new
                # half length so the opposite (still mitred) end keeps its cut.
                sh = sign * cut / 2
                pts = [(float(x) + sh, float(y)) for x, y in b.outline]
                pts = [(min(x, ln / 2) if sign > 0 else max(x, -ln / 2), y) for x, y in pts]
                cur = cur._replace(outline=tuple((round(x, 6), round(y, 6)) for x, y in pts))
            p2 = _plan_poly(cur)
            if all(_poly_penetration(p2, _plan_poly(o)) <= 1e-6 for o in bad):
                break
        else:
            continue
        out.append(cur)
    return out

def _apex_last_course(courses, k, centre, side, depth):
    """Last course of the contiguous column of small contours near `centre` from course k."""
    last = k
    while last + 1 < len(courses) and _near(courses[last + 1], centre, side, depth):
        last += 1
    return last


def _end_hit(contours, o, d):
    """Smallest positive distance from `o` along unit `d` to an outline edge, or None."""
    ts = [t for t, _sgn in _face_hits(contours, o[0], o[1], d[0], d[1]) if t > 1e-9]
    return min(ts) if ts else None

def _lean_path_ends(b, contours_at, eps):
    """A path brick whose end sits against the outline (a corner of the run) gets `ends`:
    how far that end moves along the brick between mid-height and the top, so it follows
    the other face's slope like a box brick's corner end does (Task 20, user 2026-10-22)."""
    t = b.tangent
    nrm = (-t[1], t[0])
    hh = b.height / 2
    mid, bot, top = (contours_at(b.center[2]), contours_at(b.center[2] - hh + eps),
                     contours_at(b.center[2] + hh - eps))
    shifts = []
    for q, nxt, sg in ((b.outline[0], b.outline[1], -1), (b.outline[-1], b.outline[-2], 1)):
        e = (b.center[0] + q[1] * t[0] + q[2] * nrm[0], b.center[1] + q[1] * t[1] + q[2] * nrm[1])
        f = (b.center[0] + nxt[1] * t[0] + nxt[2] * nrm[0], b.center[1] + nxt[1] * t[1] + nxt[2] * nrm[1])
        d = _norm(e[0] - f[0], e[1] - f[1])               # outward along the brick at this end
        # Measured from a point a wall depth back inside the brick: the corner-owning end
        # reaches the outline itself (or past it at the course top), where a ray from the
        # end point finds nothing.
        back = b.depth
        e = (e[0] - d[0] * back, e[1] - d[1] * back)
        hm = _end_hit(mid, e, d)
        if hm is None or abs(hm - back) > 0.25 * b.depth:
            shifts.append(0.0)
            continue
        h0, h1 = _end_hit(bot, e, d), _end_hit(top, e, d)
        if h0 is None or h1 is None:
            shifts.append(0.0)
            continue
        # + along the brick's x at the top: the end moves out by (h1 - h0) / 2 at the top.
        shifts.append(sg * (h1 - h0) / 2)
    if not any(abs(x) > 1e-4 for x in shifts):
        return b
    return b._replace(ends=tuple(round(round(x / LEAN_STEP) * LEAN_STEP, 6) for x in shifts))

LEAN_STEP = 0.005
"""Curved bricks' lean (Task 20) is rounded to this many metres, so a course instances."""

_Lean = namedtuple("_Lean", "brick levels")
"""A brick `fit_slopes` will lean, with its bottom and top plan outlines (lists, edited in
place while same-face neighbours are kept apart)."""

def fit_slopes(bricks, prep, params):
    """Task 20 (user 2026-10-22, "ôm sát theo khối box hơn theo đường vát chéo"; follow-up
    the same day: "tất cả các viên phải vát", on every face): on a tapering block every wall
    brick leans with its face instead of standing square inside it.

    Each straight brick ('box' or mitred 'miter') becomes a 'frustum': its bottom and top
    plan outlines are measured where the source outline is at the brick's OWN bottom and top.
    Only the OUTER side leans (user 2026-10-22); the inner side and every joint stay vertical:
    - the outer face moves across by how far the face moves between the course's mid-height
      and that level;
    - the outer corner of an end that is ON the outline (the corner-owning brick) moves along
      the face by how far the other face moves, so the building's corner edge follows both
      slopes; ends against another brick stay put;
    - a mitred end stays on its bisector plane, which a uniformly battered corner keeps.
    Bricks whose face does not move (vertical walls), curved, apex, quoin and cap bricks are
    left as they are."""
    eps = 1e-4
    memo = {}

    def contours_at(z):
        key = round(z, 6)
        if key not in memo:
            memo[key] = _slice_prepared(prep, z)[0]
        return memo[key]

    # The FACE ENDS: per course and face (same tangent, same line), only the first brick's
    # start and the last brick's end may move with the outline. User 2026-10-22: deciding it
    # by distance to the outline also moved the inner end of the brick next to a short corner
    # brick, which opened a wedge-shaped joint between the two.
    rows = {}
    for idx, b in enumerate(bricks):
        if b.shape in ("box", "miter") and abs(b.up[2]) > 0.5:
            t = b.tangent
            key = (round(b.center[2], 4), round(t[0], 4), round(t[1], 4),
                   round(-t[1] * b.center[0] + t[0] * b.center[1], 3))
            rows.setdefault(key, []).append((t[0] * b.center[0] + t[1] * b.center[1], idx))
    face_end = set()
    for row in rows.values():
        row.sort()
        face_end.add((row[0][1], -1))
        face_end.add((row[-1][1], 1))

    out = []
    for idx, b in enumerate(bricks):
        if b.shape in ("arc", "path") and abs(b.up[2]) > 0.5:
            # A curved brick (user 2026-10-22 "làm cho nó hoạt động với mặt cong nữa"): its
            # outer face leans by how far the face moves between the brick's bottom and top,
            # measured straight out from its centre; its ends are radial joints and stay put.
            t = b.tangent
            c, out_dir = (b.center[0], b.center[1]), (t[1], -t[0])
            hh = b.height / 2
            # On the face, or an interior (Đặc) ring? The brick's OUTER face at its middle
            # lies ON the source face when it is a wall brick (a ray from there finds
            # nothing, so this is a distance to the outline, not a hit), and a full brick
            # depth plus a joint inside it when it is an interior ring.
            face_pt = (c[0] + out_dir[0] * b.depth / 2, c[1] + out_dir[1] * b.depth / 2)
            near = min((_dist_to_poly(face_pt, cc.points) for cc in contours_at(b.center[2])
                        if cc.closed and len(cc.points) >= 3), default=math.inf)
            if near > 0.25 * b.depth:
                out.append(b)
                continue
            d0 = _end_hit(contours_at(b.center[2] - hh + eps), c, out_dir)
            d1 = _end_hit(contours_at(b.center[2] + hh - eps), c, out_dir)
            if d0 is not None and d1 is not None and abs(d0 - d1) > 1e-4:
                # Quantised to LEAN_STEP so the bricks of one course of a faceted cone (whose
                # facets give the lean a tiny spread) still share one mesh.
                b = b._replace(lean=round(round((d0 - d1) / LEAN_STEP) * LEAN_STEP, 6))
            if b.shape == "path":
                b = _lean_path_ends(b, contours_at, eps)
            out.append(b)
            continue
        if b.shape not in ("box", "miter") or abs(b.up[2]) < 0.5:
            out.append(b)
            continue
        t = b.tangent
        n = (-t[1], t[0])
        hl, hd, hh = b.length / 2, b.depth / 2, b.height / 2
        c = (b.center[0], b.center[1])
        mid = contours_at(b.center[2])
        dm = _end_hit(mid, c, (-n[0], -n[1]))
        # Only a brick whose outer face IS the source face leans (user 2026-10-22: with Đặc
        # the interior rings leaned too and overlapped the ring outside them, whose inner
        # face stays vertical). An interior ring's "outer" face is a joint, so it stays put.
        if dm is None or abs(dm - hd) > 0.25 * b.depth:
            out.append(b)
            continue
        # Task 25.3 (user 2026-10-27): a single-leaf brick (Tường đơn) has the source face on
        # BOTH long sides, so both lean. On a two-leaf wall the +n ray crosses the wall and
        # hits the far face a whole depth away, so `both` is False and the inner side stays
        # vertical as before.
        dm2 = _end_hit(mid, c, (n[0], n[1]))
        both = dm2 is not None and abs(dm2 - hd) <= 0.25 * b.depth
        hm = {sg: _end_hit(mid, c, (sg * t[0], sg * t[1])) for sg in (-1, 1)}
        if b.shape == "box":
            base = [(-hl, -hd), (hl, -hd), (hl, hd), (-hl, hd)]
        else:
            base = [(float(x), float(y)) for x, y in b.outline]
        levels, moved = [], False
        for z in (b.center[2] - hh + eps, b.center[2] + hh - eps):
            cs = contours_at(z)
            d = _end_hit(cs, c, (-n[0], -n[1]))
            dy = 0.0 if d is None else dm - d      # > 0: the face moved in (toward +y)
            # Task 25 minor (user 2026-10-27): skip the ray cast entirely when the +n face
            # isn't a source face (two-leaf walls), not just the move it would compute.
            d2 = _end_hit(cs, c, (n[0], n[1])) if both else None
            # Task 25.3: the +n face's own move (toward -y), only when it IS a source face.
            dy2 = 0.0 if d2 is None else dm2 - d2
            o = (c[0] + n[0] * dy, c[1] + n[1] * dy)
            dx = {}
            if b.shape == "box":
                for sg in (-1, 1):
                    # An end at the corner — on the outline itself, or set back behind the
                    # corner brick of the other face (up to a wall depth + joint) — moves with
                    # the outline, so it keeps its place against that corner brick as the
                    # other face leans in too.
                    if ((idx, sg) in face_end and hm[sg] is not None
                            and abs(hm[sg] - hl) <= 0.25 * b.depth):
                        hz = _end_hit(cs, o, (sg * t[0], sg * t[1]))
                        if hz is not None:
                            dx[sg] = sg * (hz - hm[sg])
            pts = []
            for i, (x, y) in enumerate(base):
                sg = 1 if x > 0 else -1
                if y > 0 and sg not in dx:
                    # User 2026-10-22 "vẫn còn cạnh trong bị vát chéo": only the OUTER edges
                    # lean; the brick's inner side, and so every joint against another brick,
                    # stays vertical. The one exception is the end of the corner-owning brick:
                    # that end face IS the other face of the building, so it leans whole.
                    # Task 25.3: on a single leaf the +y side is a source face too (`both`),
                    # so it leans by its own `dy2`.
                    pts.append((x, y - dy2))
                    moved |= abs(dy2) > 1e-5
                    continue
                ny = y + dy if y < 0 else y - dy2 if y > 0 else y
                if b.shape == "miter":
                    # On the end's own (bisector) line through this point and its partner.
                    j = {0: 3, 3: 0, 1: 2, 2: 1}[i]
                    (x0, y0), (x1, y1) = base[i], base[j]
                    nx = x0 + (x1 - x0) * (ny - y0) / (y1 - y0) if abs(y1 - y0) > 1e-12 else x0
                else:
                    nx = x + dx.get(sg, 0.0)
                pts.append((nx, ny))
                moved |= abs(nx - x) > 1e-5 or abs(ny - y) > 1e-5
            levels.append(pts)
        if not moved:
            out.append(b)
            continue
        out.append(_Lean(b, levels))
    # Two ends of one face that the move brought within a joint of each other (a short corner
    # brick moved by its corner, its neighbour not): the moved end yields, so they never
    # overlap. Checked on the same face only (same tangent, same course).
    result = []
    for i, item in enumerate(out):
        if not isinstance(item, _Lean):
            result.append(item)
            continue
        b, (lo, hi) = item
        for other in out:
            if not isinstance(other, _Lean) or other is item:
                continue
            o_b, (olo, ohi) = other
            if (abs(o_b.center[2] - b.center[2]) > 1e-6
                    or o_b.tangent[0] * b.tangent[0] + o_b.tangent[1] * b.tangent[1] < 1 - 1e-6):
                continue
            # Along this brick's tangent, the other brick's span at each level.
            t = b.tangent
            off = (o_b.center[0] - b.center[0]) * t[0] + (o_b.center[1] - b.center[1]) * t[1]
            for pts, opts in ((lo, olo), (hi, ohi)):
                a0, a1 = min(x for x, _ in pts), max(x for x, _ in pts)
                b0 = off + min(x for x, _ in opts)
                b1 = off + max(x for x, _ in opts)
                if b0 >= a1 - 1e-9 or b1 <= a0 + 1e-9:
                    continue
                for k, (x, y) in enumerate(pts):
                    if off > 0 and x > b0 - params.gap:
                        pts[k] = (b0 - params.gap, y)
                    elif off < 0 and x < b1 + params.gap:
                        pts[k] = (b1 + params.gap, y)
        if min(abs(lo[1][0] - lo[0][0]), abs(hi[1][0] - hi[0][0])) < max(2 * params.gap, 0.05):
            result.append(b)
            continue
        result.append(b._replace(shape="frustum", sides=8,
                                 outline=tuple((round(float(x), 6), round(float(y), 6)) for x, y in lo + hi)))
    return result

VERTICAL_WINDOW_WARNING = "Xếp dọc: cửa cắt chữ nhật, chưa có vòm/viền."
VERTICAL_SKIP_WARNING = "Xếp dọc: bỏ {n} cửa không nằm trên mặt tường."

def _vertical_axis(verts, choice):
    """The horizontal axis Xếp dọc turns about: the one the block is THINNEST along (the
    wall's normal), or the user's X / Y. Equal extents fall to Y (a wall along X)."""
    if choice in ("X", "Y"):
        return choice
    if len(verts) == 0:
        return "Y"
    ext = np.asarray(verts).max(axis=0) - np.asarray(verts).min(axis=0)
    return "Y" if ext[1] <= ext[0] + 1e-6 else "X"

def _vertical_rotation(axis):
    """+90 degrees about `axis` as a 3x3 matrix: about Y (x, y, z) -> (z, y, -x), about X
    (x, y, z) -> (x, -z, y). A proper rotation, so faces keep their winding."""
    if axis == "Y":
        return np.array(((0.0, 0.0, 1.0), (0.0, 1.0, 0.0), (-1.0, 0.0, 0.0)))
    return np.array(((1.0, 0.0, 0.0), (0.0, 0.0, -1.0), (0.0, 1.0, 0.0)))

def _vertical_windows(windows, rot, axis):
    """(windows in the turned frame, skipped count, any arched/framed). A window ON the wall
    (width axis across the turning axis) turns with it: its height becomes the width, its
    width the height, always rectangular and unframed (an arch would turn into a side, a
    frame into stones lying across). One whose width axis runs along the turning axis
    (skewed, or on the wall's end face) has no upright opening in the turned frame."""
    n = (1.0, 0.0) if axis == "X" else (0.0, 1.0)
    kept, skipped, plain = [], 0, False
    for w in windows:
        if abs(w.ux * n[0] + w.uy * n[1]) > 0.1:
            skipped += 1
            continue
        c = rot @ np.array((w.cx, w.cy, w.z0 + w.height / 2))
        u = rot @ np.array((0.0, 0.0, 1.0))
        plain = plain or bool(w.arched or w.framed)
        kept.append(Window(float(c[0]), float(c[1]), float(c[2] - w.width / 2), float(u[0]), float(u[1]),
                           w.height, w.width, w.depth, False, False))
    return tuple(kept), skipped, plain

def _rotate_brick(b, inv):
    """`b` turned back by `inv`: only its frame moves, every outline is in the brick's own
    local frame and `write_output` places it through `brick_matrix`."""
    turn = lambda v: tuple(float(x) for x in inv @ np.asarray(v, dtype=np.float64))
    return b._replace(center=turn(b.center), tangent=turn(b.tangent), up=turn(b.up))

def _build_vertical(verts, faces, closed, params, windows):
    """Xếp dọc (user 2026-10-23: "chỉ cần xoay dựng góc 90 độ lên là được"): the source is
    turned 90 degrees about the wall's normal, laid exactly as usual, and every brick turned
    back -- so the courses stand as columns and the stagger becomes the columns' offset.
    The top cap, crenels, quoins and the apex cut read the solid's TOP, which is an END of
    the wall in the turned frame, so they are off here (the panel greys them)."""
    axis = _vertical_axis(verts, params.vertical_axis)
    rot = _vertical_rotation(axis)
    turned = np.asarray(verts, dtype=np.float64) @ rot.T
    wins, skipped, plain = _vertical_windows(windows, rot, axis)
    flat = replace(params, vertical=False, cap_top=False, crenels=False, quoins=False, apex_bricks=0)
    lay = build_layout(turned, faces, closed, flat, wins)
    warnings = list(lay.warnings)
    if plain:
        warnings.append(VERTICAL_WINDOW_WARNING)
    if skipped:
        warnings.append(VERTICAL_SKIP_WARNING.format(n=skipped))
    inv = rot.T
    return Layout([_rotate_brick(b, inv) for b in lay.bricks], warnings,
                  tuple(_rotate_brick(b, inv) for b in lay.frames))

def build_layout(verts, faces, closed, params, windows=()):
    if params.vertical:
        return _build_vertical(verts, faces, closed, params, windows)
    warnings = [] if closed else ["Mesh không kín: gạch chỉ xếp theo phần mặt có sẵn."]
    prep = _prepare_slicing(verts, faces)
    slices = slice_courses(verts, faces, params.brick_height, prep)
    if not slices.courses:
        return Layout([], warnings + ["Khối thấp hơn 1 lớp gạch."])
    if slices.skipped:
        warnings.append(f"Bỏ {slices.skipped} lớp không cắt được (mesh lỗi).")
    p = replace(params, brick_height=slices.course_h)
    courses = slices.courses
    grid = (slices.z_min, slices.course_h)
    # Per-course centre / bottom / top and base params. Written with the very expressions the
    # single-height layout always used, so with `crenel_own_size` off every number is the same.
    zmid = [slices.z_min + (k + 0.5) * slices.course_h for k in range(len(courses))]
    z_lo = [z - slices.course_h / 2 for z in zmid]
    z_hi = [slices.z_min + (k + 1) * slices.course_h for k in range(len(courses))]
    base = [p] * len(courses)
    # Task 13 (user 2026-10-19): the top `crenel_courses` courses are the crenel BAND — only
    # the merlons of each closed OUTER contour are bricked there, and everything that asks
    # "where does the wall end" (the cap, the window frames, the arch-to-lintel clip) uses
    # the crenel FLOOR, the top of the last full course, as the wall top. A block with no
    # full course left under the band keeps its courses: battlements need a wall to stand on.
    band = max(1, int(p.crenel_courses)) if p.crenels else 0
    if band >= len(courses) and not p.crenel_own_size:
        # (An own-size band (Task 17) is checked against the room it needs below instead.)
        # Every other give-up path warns; without this a user nudging "Cao (hàng)" one step
        # up watches the battlements vanish with nothing in the panel explaining why.
        band = 0
        warnings.append(CRENEL_TOO_TALL_WARNING)
    floor_k = len(courses) - band
    z_floor = slices.z_min + floor_k * slices.course_h if band else None
    pc = p
    if band and p.crenel_own_size:
        # Task 17 (user 2026-10-21, "Gạch riêng"): the band is laid in its OWN brick. Whole
        # wall courses rise as high as still leaves room for the band within the solid (the
        # wall may lose a course to taller crenel bricks), the band sits straight on the last
        # one, and its courses are sliced at their own mid-heights. `slices` keeps only the
        # wall courses, so windows (which live in the wall) never see the band.
        # User 2026-10-22: no own length any more — a cornered band is square blocks of the
        # band's depth (`crenel_blocks`) and a round band keeps the wall's brick length.
        pc = replace(p, brick_height=p.crenel_brick_height, brick_depth=p.crenel_brick_depth)
        band_h = band * pc.brick_height
        floor_k = min(len(courses), max(0, int((slices.z_top - slices.z_min - band_h) / p.brick_height + 1e-6)))
        if floor_k < 1:
            band, z_floor, pc = 0, None, p
            warnings.append(CRENEL_TOO_TALL_WARNING)
        else:
            z_floor = slices.z_min + floor_k * slices.course_h
            slices = slices._replace(courses=courses[:floor_k])
            courses, zmid, z_lo, z_hi, base = courses[:floor_k], zmid[:floor_k], z_lo[:floor_k], z_hi[:floor_k], base[:floor_k]
            bad = 0
            for j in range(band):
                lo = z_floor + j * pc.brick_height
                contours, ok = _slice_prepared(prep, lo + pc.brick_height / 2)
                if not ok:
                    bad, contours = bad + 1, []
                courses.append(contours)
                zmid.append(lo + pc.brick_height / 2)
                z_lo.append(lo)
                z_hi.append(lo + pc.brick_height)
                base.append(pc)
            if bad:
                warnings.append(f"Bỏ {bad} lớp không cắt được (mesh lỗi).")
    frames, frame_cuts, snapped, moved = [], [], [], 0.0
    keys, key_boxes = [], []            # Task 26.4 keystones: WALL bricks, never frames
    # Task 12 decision 1: a FRAMED opening snaps to the course grid (sill and the top of its
    # straight part on course lines) and the snapped opening is what cuts the bricks too, so
    # every course beside it is a whole course. Unframed (plain mesh) windows are untouched.
    # Deterministic order (sorted records); each later window's stones are trimmed against
    # all earlier windows' stones, so close windows never get overlapping frames.
    for raw in sorted(windows):
        win, shift = _snap_window(raw, grid)
        snapped.append(win)
        # Measured before the frame gate: snapping moved the opening that CUTS the bricks, so
        # the hint belongs to every snapped opening, framed or not (Task 26.2 review I1).
        moved = max(moved, shift)
        # Task 26 (user 2026-10-27): an ARCHED opening has no frame stones and no frame cut —
        # the wall bricks are cut to the arc itself. Only a flat head is framed.
        arched = win.arched and win.width / 2 <= win.height
        site = _wall_depth_at(prep, win, p) if win.framed else None
        if site is None:
            continue
        z_wall = _wall_top_at(slices, win)
        if z_floor is not None and z_wall is not None:
            z_wall = min(z_wall, z_floor)   # a lintel may not rise into the merlon band
        if arched:
            # Task 26.4: the only stone an arch gets is the keystone over its crown, which
            # absorbs the part course between the crown and the next joint. Its cut goes into
            # `frame_cuts` so the courses it crosses start a joint beside it, and its box into
            # `key_boxes` so the wedges grown to the arc are trimmed back off it.
            key, cut = _keystone(win, p, grid, site, z_wall)
            if key is not None:
                keys.append(key)
                key_boxes.append(_box_of(key))
                frame_cuts.append(cut)
            continue
        stones = window_frame_bricks(win, p, site, grid, z_wall)
        if frames:
            stones = _trim_to_boxes(stones, [_box_of(f) for f in frames], p, floor=2 * p.gap)
        frames += stones
        frame_cuts += _frame_cut(win, p, site, grid, z_wall)
    if moved > p.brick_height / 4:
        warnings.append(SNAP_HINT.format(d=moved))
    # Task 13 review I2: a crenel band only reads as battlements when it STACKS — the same
    # merlons over the same wall, course after course. `merlon_spans` measures each course on
    # its own perimeter, so on a SHRINKING outline (a cone) each course lands its merlons at
    # different angles and the top course can come out as a single brick beside one notch.
    # Such a contour keeps its full course instead, and the panel says so. Measured against
    # the FLOOR course (the last full one), so a band of any height stacks or is dropped as a
    # whole; the tolerance is one merlon period, the point at which the pattern itself shifts.
    # Decided from the TOPMOST course, so the band is kept or dropped AS A WHOLE: a cone
    # tapers a little each course, so judging course by course crenelled the bottom of the
    # band and not the top, which is worse than either.
    #
    # Task 14 (Task 13 re-review (c)): that stacking test needs TWO courses to compare, and
    # at the DEFAULT `crenel_courses = 1` there are not two — `floor_k = len(courses) - 1`
    # makes the reference `courses[floor_k - 1]` the course immediately under the top, one
    # course of taper apart and so always inside one period. Measured at `d5cac7c`: cones
    # r3 -> 0 and r4 -> 0 taper 1.192 and 1.589 against a 1.600 period and were NOT
    # suppressed, coming out as one merlon beside one notch — the very shape I1's `q < 2`
    # ring guard exists to prevent. Stepping the reference one course further down (the
    # re-review's first suggestion) is an exact NO-OP here, because `floor_k - 1` ALREADY
    # is `len(courses) - 2` when `band == 1`; measured, every one of those numbers is
    # unchanged. So the working lever is the re-review's SECOND clause, and it is the
    # better rule anyway because it reads the band's own output instead of inferring it:
    # a contour whose band course yields FEWER THAN TWO MERLONS is a notch, not
    # battlements, whatever the taper says and at any `n`. It is measured on the real runs
    # (`split_runs` + `merlon_spans` with this course's own depth), not on the perimeter,
    # so a box's four runs and a ring's single closed run are counted the same way the
    # band itself will count them.
    #
    # The merlon count is a BAND-LEVEL veto, not a per-contour one, and that distinction
    # is load-bearing twice over. It decides the band as a whole, like the stacking test
    # above it — and the per-contour path cannot reach the case at all: on `r3 -> 0` the
    # topmost course is small enough to be swallowed by the APEX column, so the loop below
    # `continue`s past it before any crenel decision is made and the band would ship
    # uncrenelled but UNWARNED. Measured exactly that way: `r4 -> 0` (apex starts at the
    # top course itself) warned, `r3 -> 0` (apex already covers it) did not, on the same
    # defect. So `shrunk` is seeded from the band-level verdict instead.
    floor_ref, period, shrunk = [], 1.0, False
    if band:
        period = (max(1, int(p.merlon_bricks)) + max(1, int(p.crenel_gap_bricks))) * pc.brick_length
        top_merlons = _course_merlons(courses[-1], pc)
        top_outer = [(_centroid(c.points), c.perimeter()) for c, _n in top_merlons]
        # Fewer than two merlons anywhere on the band's top course: a notch, not battlements.
        shrunk = not top_merlons or min(n for _c, n in top_merlons) < 2
        for c in courses[floor_k - 1]:
            if not (c.closed and c.signed_area() > 0):
                continue
            here = _centroid(c.points)
            top = min(top_outer, key=lambda r: math.dist(r[0], here), default=None)
            floor_ref.append((here, not shrunk and top is not None
                              and abs(top[1] - c.perimeter()) <= period))
    boxes = [_box_of(f) for f in frames] + key_boxes
    windows = tuple(snapped)
    # Task 18 (user 2026-10-21): corner quoin columns from the wall bottom to the wall top
    # (the crenel floor under a band). Task 18e: each block replaces the wall at its corner;
    # the courses are cut a joint clear of it (`clear`), and only on the wall ring.
    z_wall_top = z_floor if z_floor is not None else slices.z_min + len(slices.courses) * slices.course_h
    quoins, quoin_cuts, quoin_boxes = corner_quoins(lambda zq: _slice_prepared(prep, zq)[0], slices.z_min,
                                                    z_wall_top, p, p.brick_depth)
    run_cuts = tuple(frame_cuts)
    bricks, apexes, thin, ring_memo, solid_memo = [], [], 0, {}, {}
    crenel_ids = set()   # crenel band blocks: free-standing cubes, never leaned
    # User 2026-10-23: the small rings at the top of a cone / sphere become ONE piece cut
    # from the source. Not under a crenel band: battlements are the top there.
    cut_skip, cut_plan = _cut_columns(courses, base, z_lo, zmid, p) if not band else (set(), [])
    for k, contours in enumerate(courses):
        # `q` is this course's base brick: the wall's, or the band's own (Task 17).
        z, q = zmid[k], base[k]
        min_depth = min(0.05, q.brick_depth / 4)
        ring = _ring_depths(contours, q.brick_depth, memo=ring_memo if q is p else None)
        # Task 19: a solid block fills inward from every face, but not inside the crenel
        # band, whose gaps must stay open.
        fill = p.solid and not (band and k >= floor_k)
        reach = _solid_reach(contours, memo=solid_memo) if fill else {}
        for ci, contour in enumerate(contours):
            if (k, ci) in cut_skip:
                continue
            small = _is_small(contour, q.brick_depth)
            # Only small outlines belong to an apex column; big concentric walls never do.
            if small and any(k <= last and math.dist(_centroid(contour.points), a.center[:2]) <= a.length
                             for a, last in apexes):
                continue
            rng = course_rng(q, k, ci)
            depth = min(_wall_depth(contour, q.brick_depth), ring.get(ci, q.brick_depth))
            # Tường đơn (user 2026-10-22): a closed outline thinner than two leaves takes ONE
            # leaf down its middle, as deep as the block is thick there (the collapse depth
            # doubled), so the two faces share one brick instead of each getting a leaf.
            single = False
            axis = None
            if p.single_leaf and contour.closed and contour.signed_area() > 0:
                axis = _single_leaf_axis(contour, q.brick_depth, q.gap)
            if axis is not None:
                depth, single = axis[1], True
                line = axis[0]
            else:
                line = offset_polyline(contour.points, contour.closed, depth / 2) if depth >= min_depth else None
            if single:
                # The leaf IS the wall: never mirror it as a hole-side leaf (a thin ring's
                # inner contour would lay a second one), and no solid fill inside it.
                reach = {k2: val for k2, val in reach.items() if k2 != ci}
            # Apex only for small outlines (never a giant block on a long thin wall), and only
            # when a ring of bricks no longer fits: no centerline, a ring tighter than half
            # its own depth, or a wall less than half a standard brick deep.
            pk = q if depth == q.brick_depth else replace(q, brick_depth=depth)
            laid = []
            if line is not None:
                # Crenel band: only the merlons of a closed OUTER contour are bricked. A hole
                # contour (the inside of a tube) keeps its full course — inner battlements
                # are not asked for (report open question).
                crenel = band and k >= floor_k and contour.closed and contour.signed_area() > 0
                if crenel and floor_ref:
                    here = _centroid(contour.points)
                    if not min(floor_ref, key=lambda r: math.dist(r[0], here))[1]:
                        crenel, shrunk = False, True
                # The blocks take the ASKED depth, not the thin-wall / ring clamp: they are
                # free-standing squares on the faces, not an offset ring, so a rounded edge
                # tighter than the depth does not limit them (user 2026-10-22: "phần chỉnh
                # độ sâu đang giới hạn").
                blocks = crenel_blocks(contour, q.brick_depth, z, pk) if crenel else None
                if blocks is not None:
                    blocks = trim_to_windows(blocks, windows, pk)
                    crenel_ids.update(id(b) for b in blocks)
                    laid += blocks
                else:
                    for run, s, e in split_runs(line, contour.closed and not single, pk.corner_angle, k, depth):
                        spans = (merlon_spans(run.length, s, e, run.closed, pk) if crenel else None)
                        laid += run_bricks(run, s, e, k, z, pk, rng, windows, run_cuts, spans,
                                           clear=quoin_cuts)
            if small:
                side = max(q.min_len, min(_bbox_side(contour.points))) - q.gap
                # Tight also when the ring takes no standard brick at all: since Task 11 a
                # brick may not be shrunk to fit, so such a course is crowned, not bricked.
                tight = (line is None or depth < q.brick_depth / 2 or not laid
                         or Contour(line, True).perimeter() / math.tau < depth / 2)
                if tight:
                    last = _apex_last_course(courses, k, _centroid(contour.points), side, q.brick_depth)
                    # Courses stop at the last whole brick, but an apex crowns the peak: when
                    # it is the topmost course of this column it still runs up to the solid's
                    # real top, so a spire keeps its point instead of being cut off.
                    top = z_hi[last]
                    if last >= len(courses) - 1:
                        top = slices.z_top
                    apex = (_apex_peak(prep, contour, z_lo[k], top, q)
                            or _apex_brick(contour, z_lo[k], top, q))
                    apexes.append((apex, last))
                    bricks.append(apex)
                    continue
            if line is None:
                thin += 1
                continue
            bricks += laid
            if fill and contour.closed and ci in reach:
                bricks += solid_rings(contour, depth, reach[ci], k, z, q, (k, ci), windows, run_cuts, laid)
        if len(bricks) > p.max_bricks:
            raise TooManyBricks(len(bricks))
    if thin:
        warnings.append(f"Bỏ {thin} đoạn tường quá mỏng.")
    if shrunk:
        warnings.append(CRENEL_SHRINKING_WARNING)
    for z_cut, z_clip, centre in cut_plan:
        cut = _cut_apex(verts, faces, z_cut, z_clip, centre, p)
        if cut is not None:
            bricks.append(cut)
    boxes += quoin_boxes
    bricks = _trim_to_boxes(bricks, boxes, p)
    if p.slope_fit:
        leaned = fit_slopes(bricks, prep, p)
        bricks = [o if id(o) in crenel_ids else n for o, n in zip(bricks, leaned)]
    if p.cap_top:
        regions = cap_regions(verts, faces)
        for z_region, loops in regions:
            zc = z_region
            if zc - slices.z_min < slices.course_h:
                continue
            # Task 13 rule 4: with crenels the cap drops to the crenel floor, so a gap's
            # bottom shows the cap and the wall-brick tops of the course below the band.
            if z_floor is not None and zc > z_floor:
                zc = z_floor
            # User 2026-10-22 (test.blend Cube.001, "Lát mặt trên chưa khít với các hàng
            # gạch"): the courses stop at the last WHOLE brick and the remainder stays empty
            # (Task 11), but the cap still hung from the solid's own top, 0.69 m above the
            # top course there. The cap now sits level with the last whole course under the
            # region, and is laid in the solid's cross-section AT that height (on a tapered
            # block the top face is smaller than the outline lower down, which left a bare
            # strip between cap and wall). A region that would then cover the footprint of
            # a HIGHER region (a stepped block) keeps its own top-face outline instead, so
            # no floor appears inside the taller part.
            k_top = int((zc - slices.z_min) / slices.course_h + 1e-6)
            z_courses = slices.z_min + k_top * slices.course_h
            if zc > z_courses + 1e-3:
                zc = z_courses
            # User 2026-10-28 ("lát mặt trên có thêm mục điều chỉnh vị trí cao hay thấp"):
            # the cap's vertical position is the user's own say — `Nâng lát` lifts it proud of
            # the top or sinks it into the wall, applied AFTER the crenel-floor and course
            # clamps. The cross-section below follows the shifted mid-height (above the solid
            # it comes back empty and the region keeps its own top-face outline), and the
            # `walls` trim adapts to the shifted band.
            zc += p.cap_lift
            # Task 11b rule 8: the cap is wall bricks laid flat, so its top face is the
            # solid's own top here and it hangs `brick_depth` down from it — it is a slab
            # over the interior, not a course. It can therefore never meet a wall brick,
            # whatever the courses do underneath: the cap band is the outline inset by
            # `brick_depth` AND every wall brick that shares its z range is subtracted from
            # each row strip (`walls` below), so the two are disjoint in plan. That is the
            # rule where the cap would otherwise hang into the top course.
            zlo, zhi = zc - p.brick_depth, zc
            walls = [b for b in bricks
                     if b.center[2] + b.height / 2 > zlo + 1e-9
                     and b.center[2] - b.height / 2 < zhi - 1e-9]
            # User 2026-10-22 ("viên mép cắt vừa"): the cap band is inset by the DEEPEST ring
            # under it (a Đặc block's innermost ring, a thin wall's reduced depth), plus one
            # joint, instead of a fixed brick_depth — so the cap meets the ring it sits beside
            # a joint away, with the edge pieces cut to what is left.
            # The rings under the cap are laid on the course's MID-height cross-section; on a
            # tapered block that outline is wider than the one at the cap's top, so the
            # ring depth is measured there and the cap band is cut from that outline.
            z_mid = zc - slices.course_h / 2
            mid = [c.points for c in _slice_prepared(prep, z_mid)[0] if c.closed and len(c.points) >= 3]
            if mid:
                # Other regions ABOVE this one (a stepped block): their footprints must not
                # fall inside the cross-section, or the floor would appear inside them.
                higher = [q for zr, ls in regions if zr > z_region + 1e-6 for l in ls for q in l]
                outers = [l for l in mid if Contour(l, True).signed_area() > 0]
                if not any(_point_in_loop(q, o) for o in outers for q in higher):
                    loops = mid
            inset = _cap_inset(loops, walls, p)
            caps = trim_to_windows(layout_cap(loops, zc, p, course_rng(p, "cap", zc), walls, inset), windows, p)
            bricks += _trim_to_boxes(caps, boxes, p)
        if len(bricks) > p.max_bricks:
            raise TooManyBricks(len(bricks))
    # Task 26.4: the keystones are added after every trim, like the quoins — they ARE the
    # obstacle the wall and cap were just cut back from, so trimming them against their own
    # boxes would delete them. No `fit_slopes` either: a keystone is cut to its arch, not to
    # a battered face.
    bricks += keys
    bricks += quoins
    return Layout(bricks, warnings, tuple(frames))


# ---- windows

Window = namedtuple("Window", "cx cy z0 ux uy width height depth arched framed")


def window_halfwidth(win, h):
    if h < -1e-9 or h > win.height + 1e-9:
        return None
    r = min(win.width / 2, win.height)
    if win.arched and h > win.height - r:
        dh = h - (win.height - r)
        return math.sqrt(max(r * r - dh * dh, 0.0)) * (win.width / 2) / r
    return win.width / 2


def window_band_halfwidth(win, zb, zt):
    lo = max(zb - win.z0, 0.0)
    hi = min(zt - win.z0, win.height)
    if hi - lo < 1e-6:
        return None
    return window_halfwidth(win, lo)


def window_cuts(run, win, hw, a=0.0, b=None):
    """Run-parameter intervals where the centerline is inside the opening.

    [a, b] is the laid span; on an open run the end segments are extended linearly
    (as Run.point_at does) so corner extensions are cut too."""
    b = run.length if b is None else b
    u = (win.ux, win.uy)
    v = (-win.uy, win.ux)
    hd = win.depth / 2
    last = len(run._pts) - 2
    cuts = []
    for i, (p, q) in enumerate(zip(run._pts, run._pts[1:])):
        seg = run._cum[i + 1] - run._cum[i]
        if seg <= 1e-12:
            continue
        t0, t1 = 0.0, 1.0
        if not run.closed:
            if i == 0:
                t0 = min(0.0, a / seg)
            if i == last:
                t1 = max(1.0, 1.0 + (b - run.length) / seg)
        rp = (p[0] - win.cx, p[1] - win.cy)
        d = (q[0] - p[0], q[1] - p[1])
        for axis, half in ((u, hw), (v, hd)):
            pp = rp[0] * axis[0] + rp[1] * axis[1]
            dq = d[0] * axis[0] + d[1] * axis[1]
            if abs(dq) < 1e-12:
                if abs(pp) > half:
                    t0, t1 = 1.0, 0.0
                continue
            ta, tb = (-half - pp) / dq, (half - pp) / dq
            t0, t1 = max(t0, min(ta, tb)), min(t1, max(ta, tb))
        if t1 - t0 > 1e-9:
            cuts.append((run._cum[i] + t0 * seg, run._cum[i] + t1 * seg))
    return cuts


def _clip_half(poly, nx, ny, limit):
    """Part of convex polygon `poly` with (p . n) <= limit (Sutherland-Hodgman, one plane)."""
    out = []
    for i, p in enumerate(poly):
        q = poly[(i + 1) % len(poly)]
        dp, dq = p[0] * nx + p[1] * ny - limit, q[0] * nx + q[1] * ny - limit
        if dp <= 0:
            out.append(p)
        if (dp < 0 < dq) or (dq < 0 < dp):
            k = dp / (dp - dq)
            out.append((p[0] + k * (q[0] - p[0]), p[1] + k * (q[1] - p[1])))
    return out


def _opening_span(brick, win, hw):
    """Interval of the brick's axis parameter s (0 = centre) whose cross-section (full brick
    depth) meets the opening footprint (hw x depth); None if the brick misses it."""
    t = brick.tangent
    n = (-t[1], t[0])
    cx, cy = win.cx - brick.center[0], win.cy - brick.center[1]
    hd, eps = win.depth / 2, 1e-6
    half = _plan_half(brick)  # across the brick in plan: depth upright, height laid flat
    if math.hypot(cx, cy) > brick.length / 2 + half + hw + hd:
        return None
    u, v = (win.ux, win.uy), (-win.uy, win.ux)
    rect = [(cx + su * hw * u[0] + sv * hd * v[0], cy + su * hw * u[1] + sv * hd * v[1])
            for su, sv in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
    half -= eps
    poly = _clip_half(_clip_half(rect, n[0], n[1], half), -n[0], -n[1], half)
    if len(poly) < 3:
        return None
    s = [p[0] * t[0] + p[1] * t[1] for p in poly]
    lo, hi = min(s), max(s)
    if hi <= -brick.length / 2 + eps or lo >= brick.length / 2 - eps:
        return None
    return lo, hi


def trim_to_windows(bricks, windows, params):
    """Shrink (or split, or drop) bricks whose box enters an opening prism, leaving gap/2
    clearance from the opening. A remaining piece shorter than min_len - gap is dropped.

    The centerline cuts in run_bricks already make square jambs exact on straight walls;
    this pass only bites where a brick's axis is not parallel to the opening's width axis
    (angled windows, curved walls, cap rows)."""
    if not windows:
        return bricks
    floor = max(params.min_len - params.gap, 1e-6)
    out = []
    for b in bricks:
        # A cap brick lies flat (Task 11b rule 8): its depth is vertical. The cap is as thick
        # as a wall brick is deep, so it reaches below its course line into an opening whose
        # head sits there (2026-10-22: 2 cm of cap hung into a window's top).
        hz = (b.depth if abs(b.up[2]) < 0.5 else b.height) / 2
        zb, zt = b.center[2] - hz, b.center[2] + hz
        cuts = []
        for win in windows:
            hw = window_band_halfwidth(win, zb, zt)
            if hw is None or hw < 1e-6:
                continue
            span = _opening_span(b, win, hw)
            if span is not None:
                cuts.append((span[0] - params.gap / 2, span[1] + params.gap / 2))
        if not cuts:
            out.append(b)
            continue
        for s0, s1 in _subtract(-b.length / 2, b.length / 2, cuts):
            if s1 - s0 < floor - 1e-9:
                continue
            mid = (s0 + s1) / 2
            # A curved brick (since Task 26.3 a windowed curved sub-span is laid with them) is
            # re-placed on its own circle / kept chord; sliding it along its chord tangent would
            # lift it off the ring by about mid**2 / (2R) (review I2 round 2).
            curved = _shorten_curved(b, mid, s1 - s0)
            if curved is not None:
                out.append(curved)
                continue
            c = (b.center[0] + b.tangent[0] * mid, b.center[1] + b.tangent[1] * mid, b.center[2])
            out.append(b._replace(center=c, length=s1 - s0))
    return out


ARCH_SEG = 2
"""Arc samples per course on a brick cut to an arched opening (Task 26). Two, half of the bent
'arc' bricks' ARC_SEGMENTS (user 2026-10-28, "giảm lưới đoạn bo đó thêm 1 nửa nữa"): the
chords' extra clearance is radial (`_arc_sagitta`) and much cheaper than the loops."""


def _arc_sagitta(win, zs, params):
    """EXTRA clearance, beyond the half joint, a sample needs so the CHORD to its neighbour
    still clears the half-joint ring: the samples sit on the circle of radius r + pad, the
    chord between two of them an angular step `step` apart approaches that circle only to
    (r + pad) * cos(step/2), so pad must grow to (r + gap/2)/cos(step/2) - r - gap/2 (user
    2026-10-28, ARCH_SEG 2: the old r*(1 - cos(step/2)) underestimate left the coarse chords
    dipping inside the ring). `step` = the coarsest angular step among the sample heights;
    only the samples at or above the springing count -- below it the opening edge is straight
    and its chords lie exactly on it."""
    r = min(win.width / 2, win.height)
    if r <= 1e-9:
        return 0.0
    z_top = win.z0 + win.height
    spring = z_top - r
    angs = sorted({math.acos(min(max((zc - spring) / r, 0.0), 1.0))
                   for zc in (min(max(z, win.z0), z_top) for z in zs) if zc >= spring - 1e-9})
    if len(angs) < 2:
        return 0.0
    step = max(b - a for a, b in zip(angs, angs[1:]))
    return max((r + params.gap / 2) / math.cos(step / 2) - r - params.gap / 2, 0.0)


def _arc_x(brick, win, z, params, pad=None):
    """Brick-local x interval the opening (a half width `pad` clear of it, full depth) occupies
    at height z, over BOTH faces y = +-depth/2 -- the union, so the brick never reaches into
    the opening on either face (a chord brick on a round tower is turned against the window's
    width axis). None when z is outside the opening or the brick runs along it.

    `pad` defaults to the half joint `gap/2`; callers that join their samples with chords pass
    `gap/2 + _arc_sagitta(...)` so no chord dips inside the half joint. The clearance is
    RADIAL off the arc's circle (user 2026-10-28, ARCH_SEG 4): a horizontal lift of d clears
    the circle by only d*cos(a) -- 11 mm short at the crown on the 1.4/2.2 door at four
    samples -- so above the springing the half width is sqrt((r + pad)^2 - dz^2) about the
    circle's centre; below it the edge is the straight jamb, one joint clear."""
    r = min(win.width / 2, win.height)
    spring = win.z0 + win.height - r
    pad_v = params.gap / 2 if pad is None else pad
    dz = z - spring
    if dz <= 1e-9:
        hw = win.width / 2 + pad_v
    else:
        hw = math.sqrt(max((r + pad_v) ** 2 - dz * dz, 0.0))
    if hw is None:
        return None
    t, c = brick.tangent, brick.center
    n = (-t[1], t[0])
    tu = t[0] * win.ux + t[1] * win.uy
    if abs(tu) < 1e-6:
        return None
    lo, hi = math.inf, -math.inf
    for y in (-brick.depth / 2, brick.depth / 2):
        # u(x) = u0 + x * tu with u0 the u of the brick-local point (0, y).
        u0 = (c[0] + y * n[0] - win.cx) * win.ux + (c[1] + y * n[1] - win.cy) * win.uy
        xa, xb = (-hw - u0) / tu, (hw - u0) / tu
        lo, hi = min(lo, xa, xb), max(hi, xa, xb)
    return lo, hi


def arch_cut_bricks(bricks, windows, params):
    """Task 26 (user 2026-10-27): the end brick of each side of an arched opening, in every
    course the arc crosses, GROWS to the arc and is cut to it -- a 'wedge' whose inner edge
    samples the circle (ARCH_SEG per course, each sample gap/2 clear of it). The opening is
    the arc itself: no voussoir ring, no jamb stones.

    The centerline cuts of `run_bricks` end the course at the band's WIDEST half width (the
    course bottom), so above that line the wall is bare up to the arc; this pass fills it by
    stretching that end brick to `|u| = hw(z_narrow) + gap/2` and cutting the arc out of it.
    x is taken over BOTH faces `y = +-depth/2` (`_arc_x`), so the brick stays out of the
    opening on either face even when its tangent is turned against the window's width axis
    (a chord brick on a round tower). A tip the arc leaves thinner than `2 * gap` TRUNCATES
    the profile at the last good sample's height, and a piece shorter than `min_len - gap` is
    dropped.

    Candidates are picked from the bricks as they come in and every window's cut is applied
    to a brick ONCE, together: the pier between two arched openings is cut by BOTH of them
    (review I2 — the second window used to find only the wedge the first had made, skip it as
    `shape != "box"`, and leave its side of the pier uncut)."""
    arches = [w for w in windows if w.arched and w.width / 2 <= w.height]
    if not arches or not bricks:
        return bricks
    gap = params.gap
    out = list(bricks)
    jobs = {}                                   # brick index -> the cuts it takes
    for win in arches:
        r = min(win.width / 2, win.height)
        spring = win.z0 + win.height - r
        z_top = win.z0 + win.height
        for side in (-1, 1):
            # One brick per course: the one whose end reaches nearest the opening on `side`.
            best = {}
            for i, b in enumerate(out):
                if abs(b.up[2]) < 0.5 or b.shape != "box":
                    continue
                zb, zt = b.center[2] - b.height / 2, b.center[2] + b.height / 2
                if zt <= spring + 1e-6 or zb >= z_top - 1e-6:
                    continue
                tu = b.tangent[0] * win.ux + b.tangent[1] * win.uy
                if abs(tu) < 1e-6:
                    continue
                # The brick's end nearer the opening must sit on `side` of the axis, within
                # reach of the widest point of the arc in this course (plus a short piece).
                sgn = 1 if tu > 0 else -1           # brick-local +x goes toward +u
                end_x = -sgn * side * b.length / 2  # the brick end facing the axis
                px = b.center[0] + b.tangent[0] * end_x - win.cx
                py = b.center[1] + b.tangent[1] * end_x - win.cy
                u_end = px * win.ux + py * win.uy
                if abs(-px * win.uy + py * win.ux) > win.depth / 2 + b.depth:
                    continue                        # the far side of a tower, or another wall
                hw_b = window_halfwidth(win, min(max(zb - win.z0, 0.0), win.height)) or 0.0
                reach = hw_b + gap + params.brick_length * params.min_piece + 1e-6
                if side * u_end < -1e-6 or side * u_end > reach:
                    continue
                z_key = round(b.center[2], 6)
                if z_key not in best or side * u_end < best[z_key][0]:
                    best[z_key] = (side * u_end, i)
            for _u, i in best.values():
                jobs.setdefault(i, []).append((win, side, spring, z_top))
    for i, cuts in jobs.items():
        out[i] = _arch_cut_one(out[i], cuts, params)
    return [b for b in out if b is not None]


def _arch_cut_one(b, cuts, params):
    """`b` grown to the arcs of `cuts` and cut to a 'wedge' (see `arch_cut_bricks`), or None
    when nothing of it survives.

    `cuts` is [(win, side, spring, z_top), ...] — usually one, two for the pier BETWEEN
    two arched openings (review I2), in which case one profile is built with each end's inner
    edge owned by whichever window cuts there: both arcs are sampled per height and the
    narrowest x on each side wins."""
    gap = params.gap
    zb, zt = b.center[2] - b.height / 2, b.center[2] + b.height / 2
    t = b.tangent
    ends = {}                              # toward (-1/+1) -> [(win, z_top), ...]
    far = {}                               # toward -> the plain far edge on the OTHER side
    for win, side, spring, z_top in cuts:
        tu = t[0] * win.ux + t[1] * win.uy
        sgn = 1 if tu > 0 else -1
        toward = -sgn * side                           # local x direction of the opening
        ends.setdefault(toward, []).append((win, spring, z_top))
        far[-toward] = sgn * side * b.length / 2       # the end away from THIS opening
    # Sample heights: the course's own band, plus each springing and crown inside it.
    zs = sorted({zb + (zt - zb) * k / ARCH_SEG for k in range(ARCH_SEG + 1)}
                | {z for ws in ends.values() for _w, sp, zt_w in ws for z in (sp, zt_w)
                   if zb < z < zt})
    # Per height, the two x edges of the piece: an end a window cuts gets that window's arc
    # (`_arc_x`, gap/2 clear of it), the other end keeps its plain far edge. A shared pier
    # (review I2) has an arc on BOTH, each from its own window; two windows reaching the same
    # end both bound it and the one that keeps LESS brick wins.
    # Each window's own chord bound over THESE sample heights (review I1 round 3): the samples
    # are spread by z, so the angular step is coarsest near the springing and the max over the
    # course is what every chord has to clear.
    sag = {win: _arc_sagitta(win, zs, params) for win, _s, _sp, _zt in cuts}
    rows = []
    for z in zs:
        xs2 = {}
        for toward, ws in ends.items():
            picks = []
            for win, _sp, z_top in ws:
                # At and above the crown the half width is 0, so the inner edge is the
                # straight line gap/2 off the window axis; the keystone (Task 26.4) cuts
                # that strip back.
                span = _arc_x(b, win, min(max(z, win.z0), z_top), params,
                              pad=gap / 2 + sag[win])
                if span is not None:
                    # Where the opening ENDS on this brick's side: the brick keeps x beyond.
                    picks.append(span[1] if toward < 0 else span[0])
            if picks:
                xs2[toward] = max(picks) if toward < 0 else min(picks)
        if len(xs2) < len(ends):
            continue
        x_lo = xs2[-1] if -1 in xs2 else far[-1]
        x_hi = xs2[1] if 1 in xs2 else far[1]
        rows.append((x_lo, x_hi, z))
    # TRUNCATE where the arc leaves a piece thinner than `2 * gap`: the profile keeps the
    # longest contiguous run of heights that are thick enough and is cut HORIZONTALLY at that
    # run's ends, so no vertex ever lands on the opening side of the sampled x (plan "Mẫu để
    # lại phần mỏng hơn 2*gap -> cắt ngang tại đó"; review I1 — the old clamp instead pushed
    # the inner edge up to `2 * gap` PAST the opening boundary). The thin part is at the
    # course BOTTOM beside the springing and at its TOP under a crown just below a course
    # line, hence a run rather than a prefix.
    best, kept = [], []
    for row in rows:
        kept = kept + [row] if row[1] - row[0] >= 2 * gap else []
        if len(kept) > len(best):
            best = kept
    if len(best) < 2 or max(x1 - x0 for x0, x1, _z in best) < params.min_len - gap:
        # The length rule is defence in depth once the truncation above runs (a band thinner
        # than 2*gap everywhere keeps no run at all), but it still drops a piece left under
        # `min_len - gap` at every height it did keep.
        return None
    # The piece is only as TALL as the kept run (review I1 round 2: it used to keep the full
    # course `height` and the course centre, so `_box_of` / `_trim_to_boxes` over-trimmed it
    # against the keystone and the height assertions passed vacuously). An untruncated run
    # keeps the course's own centre and height exactly, so nothing moves where no cut happened.
    z_lo, z_hi = best[0][2], best[-1][2]
    if len(best) == len(rows) == len(zs):
        z_mid, z_span = b.center[2], b.height
    else:
        z_mid, z_span = (z_lo + z_hi) / 2, z_hi - z_lo
    if z_span < 2 * gap:
        return None                        # a sliver no taller than two joints is not a brick
    # A simple polygon: up the -x edge, then back down the +x one. `_simplify` keeps a
    # collinear run (the straight part of an opening, the strip above a crown, a plain far
    # edge) as ONE edge, so the bevel is not clamped to nothing.
    lo = _simplify([(x0, z) for x0, _x1, z in best], False)
    hi = _simplify([(x1, z) for _x0, x1, z in best], False)
    pts = lo + hi[::-1]
    xs = [x for x, _ in pts]
    mx = (min(xs) + max(xs)) / 2
    c = (b.center[0] + t[0] * mx, b.center[1] + t[1] * mx, z_mid)
    outline = [(x - mx, z - z_mid) for x, z in pts]
    area = sum(outline[k - 1][0] * outline[k][1] - outline[k][0] * outline[k - 1][1]
               for k in range(len(outline)))
    if area < 0:
        outline.reverse()                              # counter-clockwise in (x, z)
    return b._replace(center=c, length=max(xs) - min(xs), height=z_span, shape="wedge", sides=4,
                      outline=tuple((round(x, 6), round(z, 6)) for x, z in outline))


def _keystone(win, params, grid, site, z_wall):
    """Task 26.4 (user 2026-10-27, "viên khóa hút phần dư"): (keystone brick, rectangular cut)
    for one arched opening -- a single flat-topped stone over the crown, from the arc up to the
    next course line (one more course if that would leave it thinner than a quarter course over
    the axis), `min(width, brick_length / 2)` wide rounded to `size_step` and never wider than
    the opening, with its bottom hollowed to the arc. It is the piece that ABSORBS the part
    course between the crown and the next joint, which the wedges beside it cannot reach.

    The cut is a plain box-shaped `Window` fed to `run_bricks`'s `frame_cuts`, so every course
    the keystone crosses starts a joint right beside it (what `_frame_cut` does for a flat
    frame) instead of running a brick into it; `build_layout` also puts the keystone's box into
    the `_trim_to_boxes` obstacles, so the wedges `arch_cut_bricks` grows to the arc are cut
    back to it. (None, None) when the stone would be thinner than two joints everywhere --
    including when the wall top clips it away.

    Only called for an ARCH (`win.arched and win.width / 2 <= win.height`), so the arc is the
    circle of radius `win.width / 2` centred on the window axis at `z_top - r`.

    The stone sits on the wall CENTRELINE at the window axis: `site.offset` is the wall face on
    the window's depth axis and `site.out` its outward sign, so the centre is half the frame
    depth in from that face. It is straight even on a curved wall (spec "Cắt gạch" 3: a chord
    at the window axis, like every other brick in a course a window cuts), so its tangent is
    the window's own width axis `u` and `u` maps to the brick's local x directly."""
    ch, gap = params.brick_height, params.gap
    r = win.width / 2
    z_top = win.z0 + win.height
    z_min = grid[0] if grid is not None else 0.0
    z_k = z_min + math.ceil((z_top - z_min) / ch - 1e-9) * ch
    if z_k - z_top < ch / 4:
        z_k += ch                       # a sliver of a course is not a stone: take one more
    if z_wall is not None:
        z_k = min(z_k, z_wall)          # never above the wall top
    w_k = min(_qround(min(win.width, params.brick_length / 2), params.size_step), win.width)
    hw_k = w_k / 2
    # Bottom: the arc between u = -hw_k and +hw_k, each sample pushed up by gap/2 PLUS the
    # chord sagitta `r * (1 - cos(dθ/2))` of the step actually used.
    # Sampled at even ANGLES, not at even u: the sampled bottom is a POLYLINE and each chord
    # dips below the arc it spans, so the samples have to be spread along the arc. Even u
    # bunches them where the arc is flat and leaves the steep part near the springing one
    # long chord -- measured 0.049 of dip there on the suite's 0.8/1.4 wall, i.e. the stone
    # reaching into its own opening. Even angles bound every dip by r * (1 - cos(dθ/2)), and
    # that bound is now ADDED to the offset (review I1 round 3): a gap/2 offset alone leaves
    # each chord inside the half-joint ring by the sagitta, 0.0037 here -- harmless at the
    # suite's gap 0.02 but 3 mm into the opening at the add-on's DEFAULT gap 0.001.
    zc = z_top - r
    # Offset RADIALLY, not in z: a vertical lift of d clears the circle by only d*cos(a), so
    # near the springing (a = 30 deg on the suite's 0.8/1.4 wall) a gap/2 lift left 0.0010 less
    # than a half joint. r_k is the circle every sample sits ON, grown until the CHORD between
    # neighbouring samples still clears the half-joint ring -- the chord dips
    # r_k * (1 - cos(step/2)) below its circle, and a bigger r_k shrinks the span angle a_k,
    # which shrinks the step, which shrinks the dip: a few passes converge (user 2026-10-28,
    # ARCH_SEG 4: a fixed 1/cos(pi/2N) margin left the crown chords 17 mm deep and a real
    # notch over the keystone). The half angle is taken on THAT circle so the profile still
    # ends exactly at the stone's own edge +-hw_k.
    r_k = r + gap / 2
    for _ in range(4):
        a_k = math.asin(min(hw_k / r_k, 1.0)) if r_k > 1e-9 else 0.0
        r_k = (r + gap / 2) / math.cos(a_k / ARCH_SEG) if r_k > 1e-9 else 0.0
    a_k = math.asin(min(hw_k / r_k, 1.0)) if r_k > 1e-9 else 0.0
    bottom = [(r_k * math.sin(a), zc + r_k * math.cos(a))
              for a in (-a_k + 2 * a_k * k / ARCH_SEG for k in range(ARCH_SEG + 1))]
    z_foot = min(z for _u, z in bottom)
    top = z_k - gap / 2
    if top - max(z for _u, z in bottom) < 2 * gap:
        return None, None               # thinner than two joints over the axis: no stone
    cz = (z_foot + top) / 2
    # Counter-clockwise in (x, z) like every other wedge profile: up the arc, over the top.
    outline = [(u, z - cz) for u, z in bottom] + [(hw_k, top - cz), (-hw_k, top - cz)]
    m = site.offset - site.out * site.depth / 2
    c = (win.cx - win.uy * m, win.cy + win.ux * m, cz)
    brick = Brick(c, (win.ux, win.uy, 0.0), (0.0, 0.0, 1.0), w_k, top - z_foot, site.depth,
                  "wedge", 4, tuple((round(u, 6), round(z, 6)) for u, z in outline))
    # The cut is the stone's own footprint, NOT a joint wider (spec "Cắt gạch" 4: `w_k`): a
    # `run_bricks` cut leaves the neighbour ending exactly ON the cut edge (`window_cuts` adds
    # nothing, the half joint of a real opening is the opening's own), so a `w_k + gap` cut
    # leaves a gap-wide STRIP of bare wall beside the keystone — measured as 156 outside_miss
    # at u = +-0.41/0.42 over the whole keystone band on the suite's 1.4/2.2 wall, against 0
    # with this width. Depth takes 2 gaps of slack so the cut still catches a course
    # centerline that bows across the window (a curved wall).
    cut = Window(c[0], c[1], z_foot, win.ux, win.uy, w_k, z_k - z_foot,
                 site.depth + 2 * gap, False, False)
    return brick, cut


# Window frames: stones on the wall's outer face around a framed opening. Wall and cap
# bricks are kept clear of every stone by an exact oriented-box SAT trim (_trim_to_boxes).

FrameSite = namedtuple("FrameSite", "offset out depth jambs curve", defaults=((),))
"""Where a frame goes: wall outer face at `offset` along the window depth axis (-uy, ux) with
outward sign `out` (+1/-1 along that axis), frame depth `depth`; `jambs` = ((side, offset,
depth), ...) for each side (-1/+1 along u) whose jamb column finds the same wall face;
`curve` = face offsets at u = (-hw - t, -hw, hw, hw + t) (empty if any is missing), used to
bend the sill and lintel along a curved face."""

CURVE_TOL = 0.05  # a straight sill/lintel may stand at most this far proud of a receding face


def _face_hits(contours, ox, oy, dx, dy):
    """(t, outward sign along d) for every contour edge crossed by the line o + t*d."""
    hits = []
    for c in contours:
        pts = c.points
        pairs = zip(pts, pts[1:] + pts[:1]) if c.closed else zip(pts, pts[1:])
        for a, b in pairs:
            ex, ey = b[0] - a[0], b[1] - a[1]
            den = dx * ey - dy * ex
            if abs(den) < 1e-12:
                continue
            wx, wy = a[0] - ox, a[1] - oy
            if 0.0 <= (wx * dy - wy * dx) / den <= 1.0:
                # Solid is on the left of e: outward normal = right side = (ey, -ex).
                hits.append(((wx * ey - wy * ex) / den, 1 if ey * dx - ex * dy > 0 else -1))
    return hits


_FACE_TOL = 1e-6


def _face_at(contours, win, off_u, out=None, near=0.0):
    """(offset, outward sign, wall thickness) of a wall face on the window's depth line
    (shifted by off_u along u), within the window's depth, or None.

    out=None chooses the frame face: the face looking toward the window's local -Y (outward
    sign -1 along the depth axis (-uy, ux)) that the ray from the centre toward -Y meets first
    (else the nearest such face toward +Y); a +Y-looking face only if no -Y-looking one exists.
    With `out` given (jambs) the face with that outward sign nearest offset `near` is used."""
    hits = _face_hits(contours, win.cx + win.ux * off_u, win.cy + win.uy * off_u, -win.uy, win.ux)
    reach = win.depth / 2 + 1e-9
    cands = [h for h in hits if abs(h[0]) <= reach]
    if out is not None:
        same = [h for h in cands if h[1] == out]
        if not same:
            return None
        t, s = min(same, key=lambda h: (abs(h[0] - near), h[0]))
    else:
        toward = [h for h in cands if h[1] == -1]
        if toward:
            back = [h for h in toward if h[0] <= _FACE_TOL]
            t, s = max(back) if back else min(toward)
        else:
            away = [h for h in cands if h[1] == 1]
            if not away:
                return None
            front = [h for h in away if h[0] >= -_FACE_TOL]
            t, s = min(front) if front else max(away)
    behind = [abs(h[0] - t) for h in hits if (h[0] - t) * s < -1e-9 and h[1] == -s]
    return t, s, (min(behind) if behind else math.inf)


def _wall_depth_at(prep, win, params):
    """FrameSite of a framed window (source sliced once at z0 + min(height, 0.5) with the
    prepared slicing data), or None when the window is not on a wall face. The face is chosen
    once (window -Y side, see _face_at); both jambs are probed on that same face.

    Task 26.4: an ARCHED opening has no frame stones, but it does get a keystone, and that
    stone sits on the wall centreline — so it needs `offset` / `out` / `depth` from here too.
    The `jambs` / `curve` probes are simply unused for one."""
    contours, ok = _slice_prepared(prep, win.z0 + min(win.height, 0.5))
    if not ok:
        return None
    main = _face_at(contours, win, 0.0)
    if main is None:
        return None
    offset, out, thick = main
    # Never past the back of a thin wall. An arch is `width / 2 <= height` (spec), so a wide
    # shallow window carrying the arched flag is a FLAT one everywhere — including here — and
    # gets the flat depth (review I3).
    depth = min(params.brick_depth, thick)
    if depth < 1e-3:
        return None
    jambs = []
    for side in (-1, 1):
        f = _face_at(contours, win, side * (win.width / 2 + params.brick_height / 2), out, offset)
        if f is not None and min(params.brick_depth, f[2]) >= 1e-3:
            jambs.append((side, f[0], min(params.brick_depth, f[2])))
    hw, t = win.width / 2, params.brick_height
    curve = [_face_at(contours, win, u, out, offset) for u in (-hw - t, -hw, hw, hw + t)]
    curve = tuple(f[0] for f in curve) if all(f is not None for f in curve) else ()
    return FrameSite(offset, out, depth, tuple(jambs), curve)


CRENEL_TOO_TALL_WARNING = "Răng cưa: khối thấp hơn số hàng răng."
"""The band would swallow every course, so it is dropped: battlements need a wall under them."""

CRENEL_SHRINKING_WARNING = "Răng cưa: bỏ qua đường viền thu nhỏ."
"""A contour that shrinks by more than one merlon period from the course below cannot carry a
band that stacks, so it keeps its full course (Task 13 review I2)."""

SNAP_HINT = "Cửa bám lưới hàng: mép dời {d:.2f}"
"""Status hint when snapping a framed opening to the course grid moved an edge by > h/4."""

def _snap_line(z, grid):
    """`z` rounded to the NEAREST course line z_min + k*ch."""
    z_min, ch = grid
    return z_min + round((z - z_min) / ch) * ch

def _snap_window(win, grid):
    """(snapped window, largest edge shift) — Task 12 decision 1.

    A framed opening sits on the course grid: its SILL and the top of its STRAIGHT part
    (the springing of an arch, the lintel bottom of a flat head) are each rounded to the
    nearest course line, and the opening used for cutting bricks and placing frame stones is
    that snapped one. The window object keeps its own size; only the layout snaps.

    An arch then springs from a course line with the window's own width, so every course the
    arc crosses is a whole course and the wedge stones beside it are whole-course high. Its
    crown may land mid-course - that course is where the wedges meet."""
    if grid is None or not win.framed or win.height <= 0.0:
        return win, 0.0
    z0 = _snap_line(win.z0, grid)
    r = min(win.width / 2, win.height)
    arched = win.arched and win.width / 2 <= win.height
    # Top of the straight part: the springing of an arch, else the opening top.
    straight = win.z0 + win.height - (r if arched else 0.0)
    top = _snap_line(straight, grid)
    if top <= z0 + 1e-9:  # a straight part under half a course: keep at least one course
        top = z0 + grid[1]
    height = top - z0 + (r if arched else 0.0)
    if height <= 1e-6:
        return win, 0.0
    shift = max(abs(z0 - win.z0), abs(top - straight))
    return win._replace(z0=z0, height=height), shift

def _frame_levels(win, params, grid):
    """(sill top, lintel top).

    `win` is the SNAPPED opening (see `_snap_window`), so its sill and the top of its straight
    part already lie on course lines: the sill top is the window's own z0 and the lintel grows
    up to the first course boundary at least 0.75 t above the opening, so no part-course hole
    is left above it."""
    t = params.brick_height
    z_lo, z_top = win.z0, win.z0 + win.height + t
    if grid is not None:
        z_min, ch = grid
        z_lo = z_min + math.floor((z_lo - z_min) / ch + 1e-6) * ch
        z_top = z_min + math.ceil((win.z0 + win.height + 0.75 * t - z_min) / ch - 1e-6) * ch
    return z_lo, z_top


FrameHead = namedtuple("FrameHead", "z_lo z_top kind")
"""Vertical plan of a frame: sill top z_lo, lintel top z_top (already clamped to the wall top),
kind "lintel" / None (no top stones). Task 26 (user 2026-10-27): an ARCHED opening is never
framed, so there is no "arch" kind and no springing to carry."""


def _frame_head(win, params, grid, z_wall):
    """FrameHead for a FLAT-headed framed window (Task 26: arched openings are not framed at
    all, so this is only ever called for one). The lintel is clamped to the wall top z_wall
    and dropped (kind None) when less than half a course is left above the opening."""
    t = params.brick_height
    z_lo, z_top = _frame_levels(win, params, grid)
    cap = math.inf if z_wall is None else z_wall
    z_top = min(z_top, cap)
    kind = "lintel" if z_top - (win.z0 + win.height) >= t / 2 - 1e-6 else None
    return FrameHead(z_lo, z_top, kind)


def _wall_top_at(slices, win):
    """Top of the wall at the window (from the window's sill course up), or None if the wall
    does not reach it. Frame stones stand on the wall FACE, so where the solid continues past
    the last whole course this is the solid's own top (slices.z_top), not the course top:
    the empty remainder at the top of a block is a gap in the BRICKS, not in the wall."""
    z_min, ch = slices.z_min, slices.course_h
    top, last = None, len(slices.courses) - 1
    for k in range(max(0, int((win.z0 - z_min) / ch + 1e-6)), len(slices.courses)):
        hits = _face_hits(slices.courses[k], win.cx, win.cy, -win.uy, win.ux)
        if not any(abs(h[0]) <= win.depth / 2 + 1e-9 for h in hits):
            break
        top = slices.z_top if k == last else z_min + (k + 1) * ch
    return top


def _box_of(brick):
    """(centre, rows = unit axes x/y/z, half extents) of a brick's box."""
    x = np.array(brick.tangent, dtype=np.float64)
    z = np.array(brick.up, dtype=np.float64)
    x /= np.linalg.norm(x)
    z /= np.linalg.norm(z)
    return (np.array(brick.center, dtype=np.float64), np.array((x, np.cross(z, x), z)),
            np.array((brick.length / 2, brick.depth / 2, brick.height / 2)))


def _box_spans(c, ax, half, oc, oax, oh, eps=1e-6):
    """For K obstacle boxes (centres oc (K,3), axes oax (K,3,3), half extents oh (K,3)): the
    exact interval of s where the brick cross-section at c + s*ax[0] (full depth and height)
    overlaps each box (SAT on the 15 axes, each a linear condition in s). Returns (lo, hi)
    arrays; hi <= lo means no overlap."""
    k = len(oc)
    cross = np.cross(ax[None, :, None, :], oax[:, None, :, :]).reshape(k, 9, 3)
    L = np.concatenate([np.broadcast_to(ax, (k, 3, 3)), oax, cross], axis=1)  # (K, 15, 3)
    n = np.linalg.norm(L, axis=2)
    a = np.einsum('kij,kj->ki', L, c - oc)
    b = L @ ax[0]
    r = (half[1] * np.abs(L @ ax[1]) + half[2] * np.abs(L @ ax[2])
         + np.einsum('kij,kj->ki', np.abs(np.einsum('kij,kmj->kim', L, oax)), oh) - eps * n)
    # Degenerate (zero) cross axes carry no condition; axes parallel to the brick's axis
    # (b = 0) are a fixed yes/no for every s.
    live = n > 1e-9
    par = np.abs(b) < 1e-12 * np.maximum(n, 1e-300)
    blocked = np.any(live & par & (np.abs(a) >= r), axis=1)
    q = live & ~par
    bs = np.where(q, b, 1.0)
    s1, s2 = (-r - a) / bs, (r - a) / bs
    lo = np.max(np.where(q, np.minimum(s1, s2), -np.inf), axis=1)
    hi = np.min(np.where(q, np.maximum(s1, s2), np.inf), axis=1)
    hi = np.where(blocked, -np.inf, hi)
    return lo, hi


def _trim_to_boxes(bricks, boxes, params, floor=None):
    """Shorten/split/drop bricks along their tangent so none overlaps an obstacle box, leaving
    gap/2 clearance (the 3D oriented-box form of trim_to_windows). Pieces shorter than `floor`
    (default min_len - gap) are dropped."""
    if not boxes or not bricks:
        return bricks
    gap = params.gap
    floor = max(params.min_len - gap, 1e-6) if floor is None else floor
    oc = np.array([bx[0] for bx in boxes])
    oax = np.array([bx[1] for bx in boxes])
    oh = np.array([bx[2] for bx in boxes])
    orad = np.linalg.norm(oh, axis=1)
    cen = np.array([b.center for b in bricks], dtype=np.float64)
    rad = 0.5 * np.sqrt(np.array([b.length ** 2 + b.height ** 2 + b.depth ** 2 for b in bricks]))
    near = np.linalg.norm(cen[:, None, :] - oc[None, :, :], axis=2) < rad[:, None] + orad[None, :] + gap
    out = []
    for i, b in enumerate(bricks):
        idx = np.nonzero(near[i])[0]
        if not len(idx):
            out.append(b)
            continue
        c, ax, half = _box_of(b)
        lo, hi = _box_spans(c, ax, half, oc[idx], oax[idx], oh[idx])
        hit = (hi > lo) & (hi > -half[0]) & (lo < half[0])
        cuts = [(float(s0) - gap / 2, float(s1) + gap / 2) for s0, s1 in zip(lo[hit], hi[hit])]
        if not cuts:
            out.append(b)
            continue
        for s0, s1 in _subtract(-half[0], half[0], cuts):
            if s1 - s0 < floor - 1e-9:
                continue
            mid = (s0 + s1) / 2
            out.append(_resized(b, tuple(float(v) for v in c + ax[0] * mid), mid, s1 - s0))
    return out

def _shorten_curved(brick, mid, length):
    """An 'arc' or 'path' brick shortened to `length`, `mid` along its own tangent from its old
    centre, RE-PLACED so it still follows the wall; None for any other shape.

    Review I2 round 2: since Task 26.3 a windowed curved sub-span is laid with curved bricks,
    so `trim_to_windows` / `_trim_to_boxes` now cut them, and both used to slide the piece along
    the brick's CHORD tangent — which lifts an arc's centre off the ring by about
    `mid**2 / (2 * R)` (0.028 m at R 1.6).

    'arc' keeps its circle (`outline = (R,)`, centre of curvature at local (0, R), i.e. world
    `center + R * n` with `n = (-t[1], t[0])`): the piece is turned along that circle, its
    tangent turned by the same angle, and `length` stays the cut's own `s1 - s0` as ARC length.

    The turn is `asin(mid / R)`, not `mid / R`. The cut parameters are produced against the
    brick's straight BOX (`_box_of` / `_box_spans`, `_opening_span`), so `mid` is a distance
    along the chord TANGENT, and the circle point whose tangent coordinate is exactly `mid` sits
    at angle `asin(mid / R)` (`_bend`: the point at local x has tangent coordinate `R*sin(x/R)`).
    Turning by that angle therefore leaves the piece's tangential footprint exactly where the
    cut put it — only now seated on the ring instead of `mid**2 / (2*R)` off it (0.028 m at
    R 1.6) — and `cos` of the turn only shrinks it, so it cannot reach past the cut into the
    opening or into a frame stone. `mid = 0` reproduces the brick unchanged.

    'path' still becomes a plain box (a cut piece no longer follows its own samples, Task 16c),
    but the box is re-seated on the CHORD of the stretch that was KEPT -- read off the path
    samples, whose first coordinate is the run offset from the brick's middle and so spans
    exactly the cut parameter's own range -- instead of on the old, longer chord's tangent. Its
    ends are then on the wall, with the usual chord sagitta."""
    t, c = brick.tangent, brick.center
    n = (-t[1], t[0])
    if brick.shape == "arc":
        r = brick.outline[0] if brick.outline else 0.0
        if not r or not math.isfinite(r):
            return None
        if abs(mid) >= abs(r):
            return None                                # no circle point reaches that tangent
        th = math.asin(mid / r)         # signed by r, so + mid always turns the way +x does
        cx, cy = c[0] + r * n[0], c[1] + r * n[1]      # centre of curvature
        vx, vy = c[0] - cx, c[1] - cy
        co, si = math.cos(th), math.sin(th)
        centre = (cx + vx * co - vy * si, cy + vx * si + vy * co, c[2])
        tan = (t[0] * co - t[1] * si, t[0] * si + t[1] * co, 0.0)
        return brick._replace(center=centre, tangent=tan, length=length)
    if brick.shape == "path" and len(brick.outline) >= 2:
        pts = sorted(((q[0], q[1], q[2]) for q in brick.outline), key=lambda q: q[0])

        def at(s):
            for a, b in zip(pts, pts[1:]):
                if a[0] - 1e-9 <= s <= b[0] + 1e-9 and b[0] - a[0] > 1e-12:
                    f = (s - a[0]) / (b[0] - a[0])
                    return (a[1] + f * (b[1] - a[1]), a[2] + f * (b[2] - a[2]))
            q = pts[0] if s < pts[0][0] else pts[-1]
            return (q[1], q[2])

        p0, p1 = at(mid - length / 2), at(mid + length / 2)
        dx, dy = p1[0] - p0[0], p1[1] - p0[1]
        chord = math.hypot(dx, dy)
        if chord < 1e-9:
            return None
        mx, my = (p0[0] + p1[0]) / 2, (p0[1] + p1[1]) / 2
        centre = (c[0] + t[0] * mx + n[0] * my, c[1] + t[1] * mx + n[1] * my, c[2])
        tan = ((t[0] * dx + n[0] * dy) / chord, (t[1] * dx + n[1] * dy) / chord, 0.0)
        return brick._replace(center=centre, tangent=tan, length=chord,
                              shape="box", sides=4, outline=())
    return None


def _resized(brick, center, mid, length):
    """`brick` moved to `center` and shortened to `length` along its own tangent, `mid` from
    its old centre. A 'wedge' carries a profile in that same local frame, so the profile is
    shifted with it and clipped to the new half length - its chamfered end keeps sitting on
    the arc, and a cut that would remove the chamfer leaves a plain box. An 'arc' brick
    (Task 16) keeps its radius: it becomes a shorter arc of the same circle, re-placed ON that
    circle by `_shorten_curved` (review I2 round 2) rather than slid along its chord."""
    curved = _shorten_curved(brick, mid, length)
    if curved is not None:
        return curved
    out = brick._replace(center=center, length=length)
    if brick.shape in ("miter", "path", "frustum"):
        # A cut miter brick no longer reaches its corner, and a cut path brick no longer
        # follows its own samples: both become plain boxes again (Task 16b/16c). A path with
        # usable samples has already been re-seated on the kept chord by `_shorten_curved`;
        # this is the degenerate case.
        return out._replace(shape="box", sides=4, outline=())
    if brick.shape != "wedge" or not brick.outline:
        return out
    half = length / 2
    prof = [(x - mid, z) for x, z in brick.outline]
    if min(x for x, _ in prof) >= -half - 1e-9 and max(x for x, _ in prof) <= half + 1e-9:
        return out._replace(outline=tuple(prof))
    clipped = _clip_half(_clip_half(prof, 1.0, 0.0, half), -1.0, 0.0, half)
    if len(clipped) < 3:
        return out._replace(shape="box", outline=())
    return out._replace(outline=tuple((float(x), float(z)) for x, z in clipped))


def window_frame_bricks(win, params, site, grid=None, z_wall=None):
    """Frame stones of a FLAT-headed framed window on the wall face `site` (FrameSite): lintel,
    side jamb stones, sill. `grid` = (z_min, course_h) snaps the sill top / lintel bottom to
    course boundaries; `z_wall` (wall top at the window) clamps the lintel (see _frame_head).

    Task 26 (user 2026-10-27): an ARCHED opening gets no frame at all — `build_layout` does not
    call this for one. The wall bricks are cut to the arc instead."""
    t, gap, d = params.brick_height, params.gap, site.depth
    hw = win.width / 2
    u = np.array((win.ux, win.uy, 0.0))
    dv = np.array((-win.uy, win.ux, 0.0))
    plan = _frame_head(win, params, grid, z_wall)
    opening_top = win.z0 + win.height

    def at(off_u, z, face, depth, shift=0.0):
        """Centre of a stone `depth` deep whose front is `shift` proud of the face at `face`."""
        c = np.array((win.cx, win.cy, 0.0)) + u * off_u + dv * (face - site.out * (depth / 2 - shift))
        return (float(c[0]), float(c[1]), float(z))

    frames = []
    top = min(opening_top, plan.z_top)
    if plan.kind == "lintel":
        frames += _ledge_stones(win, params, site, (top + plan.z_top) / 2, plan.z_top - top - gap, d, 0.0)
    head = [_box_of(f) for f in frames]
    for side, face, depth in site.jambs:
        frames += _jamb_stones(win, params, side, at(side * (hw + t / 2), 0.0, face, depth), depth,
                               plan.z_lo, top, head)
    if grid is None or plan.z_lo - t >= grid[0] - 1e-9:
        # The sill fills the course BELOW the (snapped) sill line, its top a half joint clear
        # of it, so it never rises into the opening the snapped window actually cuts.
        frames += _ledge_stones(win, params, site, plan.z_lo - gap / 2 - (t - gap) / 2,
                                t - gap, d, d / 4)
    # There is NO back panel (user 2026-10-21, "xóa phần tấm hậu ở window đi"): an opening
    # looks straight through into the hollow shell, which is what the user wants to see.
    return frames


def _ledge_stones(win, params, site, z, height, depth, shift):
    """Sill / lintel stones (width + 2t long, front `shift` proud of the face) at height z.
    A straight face (or one receding <= CURVE_TOL at the ends) gets one straight stone. A
    curved face gets 3: a straight middle stone across the opening (on the more receded of its
    two end faces) and an end stone under each jamb, angled along the face chord there and
    shortened so it clears the middle stone."""
    t, gap, hw = params.brick_height, params.gap, win.width / 2
    u = (win.ux, win.uy)
    dv = (-win.uy, win.ux)
    out = site.out
    curve = site.curve
    if not curve or max((site.offset - f) * out for f in (curve[0], curve[3])) <= CURVE_TOL:
        c = (float(win.cx + dv[0] * (site.offset - out * (depth / 2 - shift))),
             float(win.cy + dv[1] * (site.offset - out * (depth / 2 - shift))), float(z))
        return [Brick(c, (u[0], u[1], 0.0), (0.0, 0.0, 1.0), win.width + 2 * t - gap, height, depth)]

    def plan(off_u, face):
        return (win.cx + u[0] * off_u + dv[0] * face, win.cy + u[1] * off_u + dv[1] * face)

    def stone(pa, pb):
        tx, ty = _norm(pb[0] - pa[0], pb[1] - pa[1])
        fx, fy = out * -ty, out * tx  # outward = out * (up x tangent)
        k = shift - depth / 2
        c = (float((pa[0] + pb[0]) / 2 + fx * k), float((pa[1] + pb[1]) / 2 + fy * k), float(z))
        return Brick(c, (tx, ty, 0.0), (0.0, 0.0, 1.0), math.dist(pa, pb) - gap, height, depth)

    mid = min(curve[1], curve[2], key=lambda f: f * out)
    centre = stone(plan(-hw, mid), plan(hw, mid))
    ends = [stone(plan(-hw - t, curve[0]), plan(-hw, curve[1])),
            stone(plan(hw, curve[2]), plan(hw + t, curve[3]))]
    # The angled end stones would cut into the middle one behind the face: shorten them.
    return [centre] + _trim_to_boxes(ends, [_box_of(centre)], params, floor=2 * gap)


def _jamb_stones(win, params, side, base, depth, z_lo, top, head):
    """Jamb column on one side: stones t wide (along u), about one course high (the jamb
    height divided evenly), inner face at hw + gap/2; trimmed under the arch's lowest stones."""
    t, gap = params.brick_height, params.gap
    if top - z_lo < t / 2:
        return []
    n = max(1, round((top - z_lo) / t))
    step = (top - z_lo) / n
    flat = (win.ux, win.uy, 0.0)
    stones = []
    for k in range(n):
        zc = z_lo + (k + 0.5) * step
        # Lay the stone on its side (tangent = Z) so the box trim shortens it vertically.
        upright = Brick((base[0], base[1], zc), (0.0, 0.0, 1.0), flat, step - gap, t - gap, depth)
        for piece in _trim_to_boxes([upright], head, params, floor=2 * gap):
            stones.append(Brick(piece.center, flat, (0.0, 0.0, 1.0), t - gap, piece.length, depth))
    return stones


def _frame_cut(win, params, site, grid=None, z_wall=None):
    """Prisms around the whole frame that run centerlines are cut at, so courses start right
    beside the frame instead of being trimmed into stubs: one from the sill course to the
    lintel top, t beyond each jamb, through the frame layer only.

    Task 26 (user 2026-10-27): only FLAT-headed windows are framed, so there is no arch head
    band to widen the cut over any more."""
    t = params.brick_height
    plan = _frame_head(win, params, grid, z_wall)
    z_lo = plan.z_lo
    if grid is None or z_lo - t >= grid[0] - 1e-9:
        z_lo -= t
    top = plan.z_top if plan.kind == "lintel" else win.z0 + win.height
    layers = [(site.offset, site.depth)] + [(f, dp) for _, f, dp in site.jambs]
    ends = [v for f, dp in layers for v in (f, f - site.out * dp)]
    lo, hi = min(ends), max(ends)
    mid = (lo + hi) / 2
    cx, cy = win.cx - win.uy * mid, win.cy + win.ux * mid
    return [Window(cx, cy, z_lo, win.ux, win.uy, win.width + 2 * t, top - z_lo, hi - lo,
                   False, False)]


def _subtract(a, b, cuts):
    spans, cur = [], a
    for s0, s1 in sorted(cuts):
        if s1 <= cur:
            continue
        if s0 > cur:
            spans.append((cur, min(s0, b)))
        cur = max(cur, s1)
        if cur >= b:
            break
    if cur < b:
        spans.append((cur, b))
    return [(x, y) for x, y in spans if y - x > 1e-6]


def window_geometry(width, height, depth, arched, segments=12):
    hw, hd = width / 2, depth / 2
    r = min(hw, height)
    profile = [(-hw, 0.0), (hw, 0.0)]
    if arched:
        base = height - r
        profile += [(hw * math.cos(math.pi * i / segments), base + r * math.sin(math.pi * i / segments))
                    for i in range(segments + 1)]
    else:
        profile += [(hw, height), (-hw, height)]
    n = len(profile)
    verts = [(x, -hd, z) for x, z in profile] + [(x, hd, z) for x, z in profile]
    faces = [tuple(range(n)), tuple(range(2 * n - 1, n - 1, -1))]
    faces += [(i, n + i, n + (i + 1) % n, (i + 1) % n) for i in range(n)]
    return verts, faces


def window_record(ob, to_local):
    w = ob.brickify_window
    if w.generated:
        lo, hi = Vector((-w.width / 2, -w.depth / 2, 0.0)), Vector((w.width / 2, w.depth / 2, w.height))
    else:
        corners = [Vector(c) for c in ob.bound_box]
        lo = Vector(tuple(min(c[i] for c in corners) for i in range(3)))
        hi = Vector(tuple(max(c[i] for c in corners) for i in range(3)))
    m = to_local @ ob.matrix_world
    rot = m.to_3x3()
    origin = m @ Vector(((lo.x + hi.x) / 2, (lo.y + hi.y) / 2, lo.z))
    ax = rot @ Vector((1.0, 0.0, 0.0))
    # Width axis (nearly) vertical: no horizontal opening. Relative tolerance, because
    # float32 matrices leave ~1e-8 of horizontal component after a 90-degree tilt.
    ux, uy = _norm(ax.x, ax.y) if math.hypot(ax.x, ax.y) > 1e-5 * ax.length else (0.0, 0.0)
    width = (hi.x - lo.x) * ax.length
    depth = (hi.y - lo.y) * (rot @ Vector((0.0, 1.0, 0.0))).length
    height = (hi.z - lo.z) * (rot @ Vector((0.0, 0.0, 1.0))).length
    return Window(origin.x, origin.y, origin.z, ux, uy, width, height, depth,
                  bool(w.generated and w.arched), bool(w.generated))


def _relevant_windows(src, lo, hi):
    loc, rot, _ = src.matrix_world.decompose()
    to_local = Matrix.LocRotScale(loc, rot, None).inverted()
    found = []
    for ob in bpy.data.objects:
        if ob == src or not ob.brickify_window.is_window:
            continue
        win = window_record(ob, to_local)
        if win.ux == 0.0 and win.uy == 0.0:
            continue  # width axis vertical: no horizontal opening (windows are upright)
        reach = win.width / 2 + win.depth / 2
        if (win.cx + reach < lo[0] or win.cx - reach > hi[0] or win.cy + reach < lo[1]
                or win.cy - reach > hi[1] or win.z0 > hi[2] or win.z0 + win.height < lo[2]):
            continue
        found.append((ob, win))
    return found


# ---- live

_pending = set()
_state = {}      # source name -> _Cached of its last rebuild attempt
# Defensive only: write_output runs synchronously and the output's own depsgraph update
# arrives in a LATER evaluation, so this flag rarely matters. Recursion safety comes from
# output objects never having brickify.enabled = True: the handler ignores them.
_writing = False

_Cached = namedtuple("_Cached", "key scale error")
OWNER_PROP = "brickify_owner"
OWNER_UID_PROP = "brickify_owner_uid"
KEY_PROP = "brickify_key"
LOST_STATUS = "Mất object gạch — bấm Make Brick lại."


def _owner_update(self, context):
    mark_dirty(self.id_data.name)


def _window_update(self, context):
    """Settings callback (not in the rebuild path): regenerate a generated window's mesh."""
    ob = self.id_data
    if self.generated and ob.type == 'MESH':
        verts, faces = window_geometry(self.width, self.height, self.depth, self.arched)
        ob.data.clear_geometry()
        ob.data.from_pydata(verts, [], faces)
        ob.data.update()
    _mark_all_sources()


class BrickifyWindowSettings(bpy.types.PropertyGroup):
    is_window: bpy.props.BoolProperty(name="Là cửa sổ", default=False, update=_window_update)
    generated: bpy.props.BoolProperty(default=False)
    width: bpy.props.FloatProperty(name="Rộng", default=0.8, min=0.05, unit='LENGTH', update=_window_update)
    height: bpy.props.FloatProperty(name="Cao", default=1.4, min=0.05, unit='LENGTH', update=_window_update)
    arched: bpy.props.BoolProperty(name="Đỉnh vòm", default=True, update=_window_update)
    depth: bpy.props.FloatProperty(name="Sâu", default=2.0, min=0.05, unit='LENGTH', update=_window_update)


class BrickifySettings(bpy.types.PropertyGroup):
    enabled: bpy.props.BoolProperty(name="Bật", default=False, update=_owner_update)
    brick_length: bpy.props.FloatProperty(name="Dài", default=1.6, min=0.05, soft_max=5.0, unit='LENGTH', update=_owner_update)
    brick_height: bpy.props.FloatProperty(name="Cao", default=0.76, min=0.05, soft_max=5.0, unit='LENGTH', update=_owner_update)
    brick_depth: bpy.props.FloatProperty(name="Sâu", default=0.78, min=0.02, soft_max=5.0, unit='LENGTH', update=_owner_update)
    # Default 0.001 (user 2026-10-22): a hair of joint keeps coincident brick faces from
    # z-fighting in the viewport without a visible gap.
    gap: bpy.props.FloatProperty(name="Mạch", default=0.001, min=0.0, soft_max=0.2, unit='LENGTH', update=_owner_update)
    length_steps: bpy.props.StringProperty(name="Bội số dài", default="1, 2", update=_owner_update)
    size_step: bpy.props.FloatProperty(name="Bước cỡ", default=0.1, min=0.01, soft_max=5.0, unit='LENGTH',
                                       update=_owner_update,
                                       description="Viên đầu/cuối hàng được làm tròn theo bước này để dùng chung mesh. "
                                                   "Bước càng nhỏ càng chậm trên tường cong (tháp 64 cạnh: 47 ms ở 0.8, "
                                                   "57 ms ở 0.1, 75 ms ở 0.01)")
    alternate_steps: bpy.props.BoolProperty(name="Xen kẽ cỡ", default=True, update=_owner_update,
                                            description="Hai viên kề nhau khác cỡ dài khi có thể (ưu tiên phủ kín tường)")
    seed: bpy.props.IntProperty(name="Hạt giống", default=0, update=_owner_update)
    stagger: bpy.props.BoolProperty(name="So le", default=True, update=_owner_update,
                                    description="Lớp lẻ mở đầu bằng nửa viên chuẩn")
    corner_angle: bpy.props.FloatProperty(name="Góc gãy", default=math.radians(30.0), min=math.radians(1.0),
                                          max=math.radians(179.0), subtype='ANGLE', update=_owner_update)
    min_piece: bpy.props.FloatProperty(name="Mẩu ngắn nhất", default=0.3, min=0.05, max=1.0, update=_owner_update)
    bevel_width: bpy.props.FloatProperty(name="Vát", default=0.1, min=0.0, soft_max=0.5, unit='LENGTH', update=_owner_update)
    bevel_segments: bpy.props.IntProperty(name="Số đoạn", default=1, min=0, max=6, update=_owner_update)
    cap_top: bpy.props.BoolProperty(name="Lát mặt trên", default=False, update=_owner_update)
    # User 2026-10-28: the cap's vertical position is adjustable — proud of the top (positive)
    # or sunk into the wall (negative).
    cap_lift: bpy.props.FloatProperty(name="Độ cao", default=0.0, min=-5.0, max=5.0,
                                      soft_min=-1.0, soft_max=1.0, unit='LENGTH',
                                      update=_owner_update,
                                      description="Vị trí tấm lát mặt trên: dương nâng lên, âm hạ xuống")
    crenels: bpy.props.BoolProperty(name="Răng cưa", default=False, update=_owner_update,
                                    description="Mấy lớp trên cùng chỉ xây thành từng răng, "
                                                "xen kẽ khe trống; mặt lát tụt xuống sàn khe")
    merlon_bricks: bpy.props.IntProperty(name="Răng (viên)", default=1, min=1, soft_max=6,
                                         update=_owner_update,
                                         description="Bề ngang một răng, tính bằng viên chuẩn")
    crenel_courses: bpy.props.IntProperty(name="Cao (hàng)", default=1, min=1, soft_max=6,
                                          update=_owner_update,
                                          description="Răng cao mấy hàng gạch")
    # Task 17 (user 2026-10-21, "Viên gạch riêng"): the band may use its own brick size.
    crenel_own_size: bpy.props.BoolProperty(name="Gạch riêng", default=False, update=_owner_update,
                                            description="Răng cưa xây bằng cỡ gạch riêng; mặt ngoài "
                                                        "vẫn thẳng với tường")
    crenel_brick_height: bpy.props.FloatProperty(name="Cao", default=0.76, min=0.05, soft_max=10.0,
                                                 unit='LENGTH', update=_owner_update,
                                                 description="Chiều cao một hàng răng cưa")
    crenel_brick_depth: bpy.props.FloatProperty(name="Sâu", default=0.78, min=0.05, soft_max=10.0,
                                                unit='LENGTH', update=_owner_update,
                                                description="Độ dày răng cưa, đo từ mặt ngoài tường vào")
    # User 2026-10-22 (sample image): the crenel blocks may stand out of the wall faces.
    # User 2026-10-22: "tại sao khi tôi tăng độ sâu lên thì lại mất số lượng" — a block is
    # Sâu wide, so a deeper band fits fewer merlons per face. Số răng pins the count.
    crenel_count: bpy.props.IntProperty(name="Số răng", default=0, min=0, soft_max=40,
                                        update=_owner_update,
                                        description="Tổng số răng quanh khối (không kể khối góc), chia "
                                                    "đều cho các mặt; 0 = tự tính, khe rộng ít nhất một "
                                                    "khối. Nhiều hơn chỗ chứa thì dừng ở mức vừa")
    crenel_proud: bpy.props.FloatProperty(name="Nhô ra", default=0.0, min=0.0, soft_max=2.0,
                                          unit='LENGTH', update=_owner_update,
                                          description="Các khối răng cưa đẩy ra ngoài mặt tường bấy nhiêu; "
                                                      "khối góc nhô ra cả hai mặt")
    # Task 18 (user 2026-10-21, "Cạnh góc"): corner quoin columns.
    quoins: bpy.props.BoolProperty(name="Cạnh góc", default=False, update=_owner_update,
                                   description="Đặt khối đá góc ở mỗi góc lồi 60-120 độ, xếp xen kẽ "
                                               "thành cột từ chân lên đỉnh tường; tường giữ nguyên")
    quoin_width: bpy.props.FloatProperty(name="Rộng", default=0.9, min=0.05, soft_max=5.0, unit='LENGTH',
                                         update=_owner_update,
                                         description="Bề rộng khối góc thấy trên mỗi mặt tường, tính từ góc")
    quoin_height: bpy.props.FloatProperty(name="Cao", default=0.76, min=0.05, soft_max=5.0, unit='LENGTH',
                                          update=_owner_update,
                                          description="Chiều cao một khối góc; các khối góc xếp lớp riêng, "
                                                      "không theo hàng gạch tường")
    quoin_proud: bpy.props.FloatProperty(name="Nhô ra", default=0.1, min=0.01, soft_max=1.0, unit='LENGTH',
                                         update=_owner_update,
                                         description="Khối góc nhô ra khỏi hai mặt tường bao nhiêu")
    quoin_proud_step: bpy.props.FloatProperty(name="Nhô xen kẽ", default=0.0, min=0.0, soft_max=1.0,
                                              unit='LENGTH', update=_owner_update,
                                              description="Cứ cách một lớp, khối góc nhô ra thêm bấy nhiêu đều cả "
                                                          "hai mặt; mép giáp tường vẫn thẳng (tắt Xen kẽ để mép thẳng cả hai mặt)")
    quoin_alternate: bpy.props.BoolProperty(name="Xen kẽ", default=True, update=_owner_update,
                                            description="Mặt dài (Rộng) và mặt ngắn (bằng độ sâu tường) "
                                                        "đổi mặt mỗi lớp, như khối góc thật")
    # Task 19 (user 2026-10-21, "Đặc"): fill the block's inside with rings of bricks.
    # Task 20 (user 2026-10-22): end bricks follow a sloping face.
    # User 2026-10-22: a thin wall came out as two leaves (one per face); 'Tường đơn' lays
    # one leaf as deep as the block is thick.
    single_leaf: bpy.props.BoolProperty(name="Tường đơn", default=False, update=_owner_update,
                                        description="Khối mỏng hơn 2 x Sâu + Mạch xếp MỘT lớp gạch ở giữa, "
                                                    "viên dày bằng bề dày khối (thay vì hai lớp áp hai mặt)")
    slope_fit: bpy.props.BoolProperty(name="Ôm mặt vát", default=True, update=_owner_update,
                                      description="Trên khối thu nhỏ dần lên trên, mọi viên gạch "
                                                  "nghiêng theo mặt vát (cả viên góc) thay vì đứng vuông")
    solid: bpy.props.BoolProperty(name="Đặc", default=False, update=_owner_update,
                                  description="Xếp kín gạch bên trong khối, từng vòng đồng tâm "
                                              "từ tường bao vào tâm")
    solid_fill: bpy.props.FloatProperty(name="Độ dày đặc", default=1.0, min=0.0, max=1.0,
                                        subtype='FACTOR', update=_owner_update,
                                        description="Phần giữa tường bao và tâm được xếp kín: "
                                                    "0 = rỗng (chỉ tường bao), 1 = kín hết")
    solid_from_core: bpy.props.BoolProperty(name="Từ lõi ra", default=False, update=_owner_update,
                                            description="Phần đặc lớn dần từ tâm ra tường bao "
                                                        "(tắt: từ tường bao vào tâm)")
    # User 2026-10-23 (a cone with a rounded top): the tip is one piece cut from the source.
    apex_bricks: bpy.props.IntProperty(name="Đỉnh liền từ", default=4, min=0, soft_max=12, update=_owner_update,
                                       description="Hàng mà vành gạch chứa ít hơn N viên Dài, và mọi hàng "
                                                   "trên nó, gộp thành MỘT viên cắt từ chính khối gốc "
                                                   "(chỏm tròn, mũi nhọn); 0 = chỉ khi không còn chỗ cho một viên")
    # User 2026-10-23 ("Xếp dọc"): the wall turned 90 degrees inside the add-on.
    vertical: bpy.props.BoolProperty(name="Xếp dọc", default=False, update=_owner_update,
                                     description="Xoay khối 90° quanh pháp tuyến tường rồi xếp như thường: "
                                                 "hàng gạch thành cột đứng so le. Phần dư nằm ở một đầu tường. "
                                                 "Lát mặt trên, răng cưa, cạnh góc, đỉnh liền tạm tắt; nên bật Tường đơn")
    vertical_axis: bpy.props.EnumProperty(name="Trục xoay", default="AUTO", update=_owner_update,
                                          items=(("AUTO", "Tự động", "Cạnh ngang mỏng nhất của khối (pháp tuyến tường)"),
                                                 ("X", "X", "Xoay quanh trục X"),
                                                 ("Y", "Y", "Xoay quanh trục Y")),
                                          description="Trục ngang để xoay khối khi Xếp dọc")
    max_bricks: bpy.props.IntProperty(name="Tối đa viên", default=1000, min=1, update=_owner_update)
    output: bpy.props.PointerProperty(type=bpy.types.Object)
    status: bpy.props.StringProperty(default="")
    last_count: bpy.props.IntProperty(default=0)


def _parse_steps(text):
    steps = []
    for part in text.replace(";", ",").split(","):
        try:
            value = float(part)
        except ValueError:
            continue
        if value > 0:
            steps.append(value)
    return tuple(steps) or (1.0,)


def params_from_settings(s):
    return Params(brick_length=s.brick_length, brick_height=s.brick_height, brick_depth=s.brick_depth,
                  gap=s.gap, size_step=s.size_step, length_steps=_parse_steps(s.length_steps),
                  alternate_steps=s.alternate_steps, seed=s.seed, stagger=s.stagger,
                  corner_angle=s.corner_angle, min_piece=s.min_piece, bevel_width=s.bevel_width,
                  bevel_segments=s.bevel_segments, cap_top=s.cap_top, cap_lift=s.cap_lift, crenels=s.crenels,
                  merlon_bricks=s.merlon_bricks,
                  crenel_courses=s.crenel_courses, crenel_own_size=s.crenel_own_size, crenel_proud=s.crenel_proud, crenel_count=s.crenel_count,
                  crenel_brick_height=s.crenel_brick_height,
                  crenel_brick_depth=s.crenel_brick_depth, quoins=s.quoins, quoin_width=s.quoin_width,
                  quoin_height=s.quoin_height, quoin_proud=s.quoin_proud, quoin_proud_step=s.quoin_proud_step,
                  quoin_alternate=s.quoin_alternate, slope_fit=s.slope_fit, single_leaf=s.single_leaf, solid=s.solid, solid_fill=s.solid_fill, solid_from_core=s.solid_from_core,
                  apex_bricks=s.apex_bricks, vertical=s.vertical, vertical_axis=s.vertical_axis,
                  max_bricks=s.max_bricks)


def _is_output(obj):
    return OWNER_PROP in obj or any(o.brickify.output == obj for o in bpy.data.objects if o.brickify.enabled)


def _new_output(src):
    """Fresh output object for src, in the source's collections, tagged with its owner."""
    mesh = bpy.data.meshes.new(f"{src.name}_Bricks")
    out = bpy.data.objects.new(f"{src.name}_Bricks", mesh)
    for coll in src.users_collection:
        coll.objects.link(out)
    out[OWNER_PROP] = src.name
    out[OWNER_UID_PROP] = src.session_uid
    src.brickify.output = out
    return out


def _owns(src, out):
    """Ownership rule (name tag + session uid tag on the output):
    1. tag name == src.name -> owner.
    2. another live, enabled object carries the tag name and points at `out` -> src is a copy.
    3. tag uid == src.session_uid -> owner that was renamed this session.
    4. another live, enabled object pointing at `out` has the tagged uid -> src is a copy.
    5. otherwise nobody else claims it (renamed before a reload, untagged legacy) -> owner.
    session_uid is not saved, so after a reload rule 1/2 (names) decide; within a session the
    uid also covers "rename the original, then duplicate it" before any flush."""
    tag, uid = out.get(OWNER_PROP), out.get(OWNER_UID_PROP)
    if tag == src.name:
        return True

    def claims(o):
        return o != src and o.brickify.enabled and o.brickify.output == out

    named = bpy.data.objects.get(tag) if isinstance(tag, str) else None
    if named is not None and claims(named):
        return False
    if uid == src.session_uid:
        return True
    return not any(claims(o) and o.session_uid == uid for o in bpy.data.objects)


def _live_output(src, create=True):
    """src's own output, creating one if src is a copy sharing another source's output
    (create=False returns None then). None when the output was deleted or unlinked from
    every scene (Make Brick restores it)."""
    out = src.brickify.output
    if out is None or out.name not in bpy.data.objects or not out.users_scene:
        return None
    if not _owns(src, out):
        return _new_output(src) if create else None
    if out.get(OWNER_PROP) != src.name:
        out[OWNER_PROP] = src.name
    if out.get(OWNER_UID_PROP) != src.session_uid:
        out[OWNER_UID_PROP] = src.session_uid
    return out


def _sync_materials(src, out):
    mats = _first_material(src)
    if list(out.data.materials) != mats:
        out.data.materials.clear()
        for m in mats:
            out.data.materials.append(m)


def _sync_out_matrix(src, out):
    loc, rot, _ = src.matrix_world.decompose()
    target = Matrix.LocRotScale(loc, rot, None)
    if out.matrix_world != target:
        out.matrix_world = target


def sync_matrix(src, create=True):
    out = _live_output(src, create)
    if out is not None:
        _sync_out_matrix(src, out)
    return out


def _scale_of(src):
    return tuple(round(v, 5) for v in src.matrix_world.to_scale())


def _round_any(value):
    if isinstance(value, float):
        return round(value, 5)
    if isinstance(value, tuple):
        return tuple(_round_any(v) for v in value)
    return value


ALGO_VERSION = 25
"""Bump whenever the layout output changes for the same inputs: it is part of the rebuild key,
so outputs saved by older code (their saved digest no longer matches) rebuild once."""


def _rebuild_key(src, verts, windows, faces=(), closed=True):
    s = src.brickify
    settings = (ALGO_VERSION,) + tuple(getattr(s, name) for name in (
        "brick_length", "brick_height", "brick_depth", "gap", "size_step", "length_steps", "alternate_steps",
        "seed", "stagger", "corner_angle", "min_piece", "bevel_width", "bevel_segments",
        "cap_top", "cap_lift", "crenels", "merlon_bricks", "crenel_courses",
        "crenel_own_size", "crenel_brick_height", "crenel_brick_depth", "crenel_proud", "crenel_count",
        "quoins", "quoin_width", "quoin_height", "quoin_proud", "quoin_proud_step", "quoin_alternate",
        "slope_fit", "single_leaf", "solid", "solid_fill", "solid_from_core", "apex_bricks",
        "vertical", "vertical_axis", "max_bricks"))
    tris = np.asarray(faces, dtype=np.int64).reshape(-1)
    # sha1, not hash(): bytes/str hashes are salted per process, and the key's digest is
    # saved on the output to skip the rebuild after reopening the file.
    return (_scale_of(src), len(verts), hashlib.sha1(np.round(verts, 5).tobytes()).hexdigest(),
            len(tris), hashlib.sha1(tris.tobytes()).hexdigest(), bool(closed), settings,
            tuple(_round_any(tuple(w)) for w in windows))


def _key_digest(key):
    """Stable across sessions (Python's str hash is salted per process)."""
    return hashlib.sha1(repr(key).encode("utf-8")).hexdigest()


def _collect_windows(src, verts):
    """Relevant window records, sorted: hashable and deterministic for _rebuild_key."""
    if len(verts) == 0:
        return ()
    verts = np.asarray(verts)
    return tuple(sorted(win for _, win in _relevant_windows(src, verts.min(axis=0), verts.max(axis=0))))


def _window_objects(src):
    scale = np.array(src.matrix_world.to_scale())
    box = np.array([c[:] for c in src.bound_box]) * scale
    return [ob for ob, _ in _relevant_windows(src, box.min(axis=0), box.max(axis=0))]


def compute_layout(src, depsgraph):
    params = params_from_settings(src.brickify)
    verts, faces, closed = read_source_mesh(src, depsgraph)
    return build_layout(verts, faces, closed, params, _collect_windows(src, verts)), params


def _first_material(src):
    """The source's first non-empty material slot as a 0/1-item list (outputs get only it)."""
    return [m for m in src.data.materials if m is not None][:1]


def apply_bricks(src, depsgraph):
    """Split src's bricks into linked objects placed straight into src's own collection (no
    wrapper collection: Task 17, user 2026-10-21 "khi apply brick không cần đưa nó vào 1
    collection"). Returns the created objects. Raises (TooManyBricks, ...) with nothing created
    and src untouched when the layout or the object creation fails."""
    layout, params = compute_layout(src, depsgraph)
    cache = BrickMeshCache(params.bevel_width, params.bevel_segments)
    parent = src.users_collection[0] if src.users_collection else bpy.context.scene.collection
    loc, rot, _ = src.matrix_world.decompose()
    base = Matrix.LocRotScale(loc, rot, None)
    mats = _first_material(src)
    meshes, objects = {}, []
    try:
        for i, brick in enumerate(layout.all, 1):
            key = cache.key(brick)
            if key not in meshes:
                tag = ("" if len(key) == 3 else f"_arc{key[5]}" if key[3] == "arc"
                       else f"_{key[3]}{key[4]}")
                me = bpy.data.meshes.new(f"{src.name}_Brick_{key[0]}x{key[1]}x{key[2]}{tag}")
                meshes[key] = me
                # The brick itself at the origin (not Brick(*key)): an arc key flattens its
                # outline (R,) to a bare float, the brick keeps the real fields (Task 16).
                write_output([brick._replace(center=(0.0, 0.0, 0.0), tangent=(1.0, 0.0, 0.0),
                                             up=(0.0, 0.0, 1.0))], cache, me)
                for m in mats:
                    me.materials.append(m)
            ob = bpy.data.objects.new(f"{src.name}_Brick_{i:04d}", meshes[key])
            objects.append(ob)
            ob.matrix_world = base @ brick_matrix(brick)
            parent.objects.link(ob)
    except Exception:
        for ob in objects:
            bpy.data.objects.remove(ob)
        for me in meshes.values():
            bpy.data.meshes.remove(me)
        raise
    s = src.brickify
    out = _live_output(src, create=False)  # only src's own output; a copy's borrowed one is untouched
    s.enabled = False
    s.output = None
    if out is not None:
        mesh = out.data
        bpy.data.objects.remove(out)
        if mesh.users == 0:
            bpy.data.meshes.remove(mesh)
    for ob in [src] + _window_objects(src):
        ob.hide_set(True)
        ob.hide_render = True
    _state.pop(src.name, None)
    _pending.discard(src.name)
    return objects


def _remember(src, key, error=False):
    _state[src.name] = _Cached(key, _scale_of(src), error)


def rebuild_source(src, depsgraph=None):
    global _writing
    s = src.brickify
    if not s.enabled:
        return False
    out = sync_matrix(src)
    if out is None:
        s.status = LOST_STATUS
        return False
    _sync_materials(src, out)
    depsgraph = depsgraph or bpy.context.evaluated_depsgraph_get()
    verts, faces, closed = read_source_mesh(src, depsgraph)
    windows = _collect_windows(src, verts)
    key = _rebuild_key(src, verts, windows, faces, closed)
    cached = _state.get(src.name)
    if cached is not None and cached.key == key:
        return False
    digest = _key_digest(key)
    if cached is None and out.get(KEY_PROP) == digest:
        # Reopened file / fresh session: the saved output already matches this key.
        _remember(src, key)
        if s.status == LOST_STATUS:
            s.status = ""
        return False
    params = params_from_settings(s)
    try:
        layout = build_layout(verts, faces, closed, params, windows)
    except TooManyBricks as exc:
        s.status = f"Quá {exc.count} viên — tăng kích thước gạch."
        _remember(src, key)
        return False
    except Exception:
        # Persistent error: remember the failing key so it is not retried on every tick.
        _remember(src, key, error=True)
        raise
    _writing = True
    try:
        write_output(layout.all, BrickMeshCache(params.bevel_width, params.bevel_segments), out.data)
        out[KEY_PROP] = digest
    finally:
        _writing = False
    s.last_count = len(layout.all)
    s.status = " ".join(layout.warnings)
    _remember(src, key)
    return True


def mark_dirty(src_name):
    _pending.add(src_name)
    if not bpy.app.timers.is_registered(flush_pending):
        bpy.app.timers.register(flush_pending, first_interval=0.0)


def _drop_stale_state():
    """Drop cache entries whose source no longer exists under that name (renamed/deleted).
    A renamed source re-keys under its new name; its output's KEY_PROP digest then avoids
    a rewrite."""
    for name in [n for n in _state if n not in bpy.data.objects]:
        del _state[name]


def flush_pending():
    names = list(_pending)
    _pending.clear()
    _drop_stale_state()
    for name in names:
        src = bpy.data.objects.get(name)
        if src is None or not src.brickify.enabled:
            continue
        try:
            rebuild_source(src)
        except Exception as exc:
            traceback.print_exc()
            src.brickify.status = f"Lỗi: {exc}"
    return None


def _windows_unchanged(obj, cached, depsgraph):
    """True if the windows relevant to obj, seen from its new placement, match the cached
    key. The evaluated bound box times scale is the same bbox _collect_windows takes from
    the vertices, so the same windows are selected."""
    if not _window_names:
        return not cached.key[-1]
    box = np.array([c[:] for c in obj.evaluated_get(depsgraph).bound_box]) * np.array(obj.matrix_world.to_scale())
    wins = sorted(win for _, win in _relevant_windows(obj, box.min(axis=0), box.max(axis=0)))
    return tuple(_round_any(tuple(w)) for w in wins) == cached.key[-1]


def _cheap_move(obj, depsgraph=None):
    """Transform-only update: True if handled without a rebuild (scale unchanged, and no
    window entered, left or moved relative to the source)."""
    cached = _state.get(obj.name)
    if cached is None or cached.scale != _scale_of(obj):
        return False
    if depsgraph is not None and not _windows_unchanged(obj, cached, depsgraph):
        return False
    out = sync_matrix(obj, create=False)
    if out is None:
        return False  # copy sharing an output, or output lost: let the rebuild path decide
    _sync_materials(obj, out)
    return True


_window_names = set()  # names of window objects seen by the last depsgraph update


def _mark_all_sources():
    for src in bpy.data.objects:
        if src.brickify.enabled:
            mark_dirty(src.name)


@bpy.app.handlers.persistent
def _on_depsgraph(scene, depsgraph):
    global _window_names
    if _writing:
        return
    try:
        names = {o.name for o in bpy.data.objects if o.brickify_window.is_window}
        windows_changed = names != _window_names
        _window_names = names
        for update in depsgraph.updates:
            obj = update.id
            if not isinstance(obj, bpy.types.Object):
                continue
            obj = obj.original
            if obj.brickify_window.is_window and not obj.brickify.enabled:
                # Any window move/edit: every source re-keys (unrelated windows do not
                # change a source's key, so they cost a key check, not a rewrite).
                windows_changed = True
                continue
            if not obj.brickify.enabled:
                continue
            if update.is_updated_transform and not update.is_updated_geometry and _cheap_move(obj, depsgraph):
                continue
            mark_dirty(obj.name)
        if windows_changed:
            # Only sources whose relevant windows actually differ from their cached key;
            # unrelated walls skip the mesh read entirely.
            for src in bpy.data.objects:
                if not src.brickify.enabled or src.name in _pending:
                    continue
                cached = _state.get(src.name)
                if cached is not None and _windows_unchanged(src, cached, depsgraph):
                    continue
                mark_dirty(src.name)
    except Exception:
        traceback.print_exc()


@bpy.app.handlers.persistent
def _on_load(_):
    _pending.clear()
    _state.clear()
    _window_names.clear()


# ---- ui

class BRICKIFY_OT_make(bpy.types.Operator):
    bl_idname = "brickify.make"
    bl_label = "Make Brick"
    bl_description = "Biến khối đang chọn thành tường gạch live"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return any(o.type == 'MESH' for o in context.selected_objects)

    def execute(self, context):
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        made = 0
        for src in [o for o in context.selected_objects
                    if o.type == 'MESH' and not _is_output(o) and not o.brickify_window.is_window]:
            s = src.brickify
            if _live_output(src) is None:  # never made, deleted or unlinked: fresh output
                _new_output(src)
            src.display_type = 'WIRE'
            src.hide_render = True
            s.enabled = True
            _state.pop(src.name, None)
            rebuild_source(src, context.evaluated_depsgraph_get())
            _pending.discard(src.name)
            made += 1
        self.report({'INFO'}, f"Brickify: {made} khối")
        return {'FINISHED'}


class BRICKIFY_OT_apply(bpy.types.Operator):
    bl_idname = "brickify.apply"
    bl_label = "Apply Bricks"
    bl_description = "Tách gạch live thành từng object (viên cùng cỡ dùng chung mesh)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return any(o.type == 'MESH' and o.brickify.enabled for o in context.selected_objects)

    def execute(self, context):
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        depsgraph = context.evaluated_depsgraph_get()
        total = applied = 0
        for src in [o for o in context.selected_objects if o.type == 'MESH' and o.brickify.enabled]:
            # One failing source is reported and left live; the others still apply.
            try:
                total += len(apply_bricks(src, depsgraph))
                applied += 1
            except TooManyBricks as exc:
                self.report({'ERROR'}, f"{src.name}: quá {exc.count} viên — tăng kích thước gạch, chưa tách.")
            except Exception as exc:
                traceback.print_exc()
                self.report({'ERROR'}, f"{src.name}: lỗi khi tách gạch ({exc}), giữ nguyên.")
        if not applied:
            return {'CANCELLED'}
        self.report({'INFO'}, f"Apply: {total} viên")
        return {'FINISHED'}


class BRICKIFY_OT_add_window(bpy.types.Operator):
    bl_idname = "brickify.add_window"
    bl_label = "Add Window"
    bl_description = "Thêm khối cửa sổ tại 3D cursor; gạch tự tránh và bo quanh"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        mesh = bpy.data.meshes.new("Window")
        ob = bpy.data.objects.new("Window", mesh)
        context.collection.objects.link(ob)
        ob.location = context.scene.cursor.location
        ob.display_type = 'WIRE'
        ob.hide_render = True
        ob.brickify_window.generated = True
        ob.brickify_window.is_window = True
        for o in context.selected_objects:
            o.select_set(False)
        ob.select_set(True)
        context.view_layer.objects.active = ob
        return {'FINISHED'}


class BRICKIFY_PT_main(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Brickify"
    bl_label = "Brickify"

    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        row = layout.row(align=True)
        row.operator("brickify.make", icon='MOD_BUILD')
        row.operator("brickify.add_window", icon='MESH_PLANE')
        if obj is not None and obj.type == 'MESH' and obj.brickify_window.is_window:
            w = obj.brickify_window
            col = layout.column(align=True)
            col.label(text="Cửa sổ")
            col.prop(w, "is_window")
            if w.generated:
                for name in ("width", "height", "depth", "arched"):
                    col.prop(w, name)
            return
        if obj is None or obj.type != 'MESH' or not obj.brickify.enabled:
            return
        s = obj.brickify
        layout.operator("brickify.apply", icon='CHECKMARK')
        col = layout.column(align=True)
        col.label(text="Viên gạch")
        for name in ("brick_length", "brick_height", "brick_depth", "gap", "length_steps",
                     "size_step", "alternate_steps"):
            col.prop(s, name)
        col = layout.column(align=True)
        col.label(text="Vát")
        col.prop(s, "bevel_width")
        col.prop(s, "bevel_segments")
        col = layout.column(align=True)
        col.label(text="Xếp")
        for name in ("seed", "stagger", "vertical", "vertical_axis", "corner_angle", "min_piece",
                     "slope_fit", "apex_bricks", "single_leaf"):
            row = col.row(align=True)
            # Xếp dọc (user 2026-10-23): the cap and the apex cut read the solid's top, an END
            # of the wall in the turned frame, so they are off (crenels and quoins below too).
            if name == "vertical_axis":
                row.active = s.vertical
            elif name == "apex_bricks":
                row.active = not s.vertical
            row.prop(s, name)
        # User 2026-10-28: "Lát mặt trên" is its own section — the height offset ("Độ cao")
        # appears only while the cap is ticked, like the other sections' settings.
        col = layout.column(align=True)
        col.label(text="Lát mặt trên")
        col.active = not s.vertical
        col.prop(s, "cap_top")
        if s.cap_top:
            sub = col.column(align=True)
            sub.prop(s, "cap_lift")
        # User 2026-10-28: "phần Đặc cũng làm vậy" — its own section, settings only when ticked.
        col = layout.column(align=True)
        col.label(text="Đặc")
        col.prop(s, "solid")
        if s.solid:
            sub = col.column(align=True)
            sub.prop(s, "solid_fill")
            sub.prop(s, "solid_from_core")
        col = layout.column(align=True)
        col.label(text="Răng cưa")
        col.active = not s.vertical
        col.prop(s, "crenels")
        if s.crenels:
            sub = col.column(align=True)
            # "Răng (viên)" is no longer shown (user 2026-10-22: a merlon is one block); it stays 1.
            # "Khe (viên)" removed (user 2026-10-22): Số răng 0 = gaps at least one block wide.
            for name in ("crenel_count", "crenel_proud", "crenel_own_size"):
                sub.prop(s, name)
            if s.crenel_own_size:
                own = sub.column(align=True)
                for name in ("crenel_brick_height", "crenel_brick_depth"):
                    own.prop(s, name)
        col = layout.column(align=True)
        col.label(text="Cạnh góc")
        col.active = not s.vertical
        col.prop(s, "quoins")
        if s.quoins:
            sub = col.column(align=True)
            for name in ("quoin_width", "quoin_height", "quoin_proud", "quoin_proud_step", "quoin_alternate"):
                sub.prop(s, name)
        layout.label(text=f"{s.last_count} viên")
        if s.status:
            layout.label(text=s.status, icon='ERROR')


# ---- register

CLASSES = (BrickifyWindowSettings, BrickifySettings, BRICKIFY_OT_make, BRICKIFY_OT_apply,
           BRICKIFY_OT_add_window, BRICKIFY_PT_main)


def _drop_handlers(handlers, name):
    """Remove every handler named `name` from this module (also stale copies left by a reload)."""
    for fn in [f for f in handlers if getattr(f, "__name__", "") == name
               and getattr(f, "__module__", "") == __name__]:
        handlers.remove(fn)


def register():
    for cls in CLASSES:
        if getattr(cls, "is_registered", False):
            bpy.utils.unregister_class(cls)
        bpy.utils.register_class(cls)
    bpy.types.Object.brickify = bpy.props.PointerProperty(type=BrickifySettings)
    bpy.types.Object.brickify_window = bpy.props.PointerProperty(type=BrickifyWindowSettings)
    _drop_handlers(bpy.app.handlers.depsgraph_update_post, "_on_depsgraph")
    _drop_handlers(bpy.app.handlers.load_post, "_on_load")
    bpy.app.handlers.depsgraph_update_post.append(_on_depsgraph)
    bpy.app.handlers.load_post.append(_on_load)


def unregister():
    _drop_handlers(bpy.app.handlers.depsgraph_update_post, "_on_depsgraph")
    _drop_handlers(bpy.app.handlers.load_post, "_on_load")
    if bpy.app.timers.is_registered(flush_pending):
        bpy.app.timers.unregister(flush_pending)
    if hasattr(bpy.types.Object, "brickify"):
        del bpy.types.Object.brickify
    if hasattr(bpy.types.Object, "brickify_window"):
        del bpy.types.Object.brickify_window
    for cls in reversed(CLASSES):
        if getattr(cls, "is_registered", False):
            bpy.utils.unregister_class(cls)
    _pending.clear()
    _state.clear()
    _window_names.clear()
